--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: citations; Type: TABLE; Schema: public; Owner: pierre; Tablespace: 
--

CREATE TABLE citations (
    citation text NOT NULL,
    auteur text NOT NULL,
    titre text,
    date text,
    concept text NOT NULL,
    comment text,
    saisie text,
    recordid integer DEFAULT nextval(('"citations_recordid_seq"'::text)::regclass) NOT NULL
);


ALTER TABLE public.citations OWNER TO pierre;

--
-- Name: citations_recordid_seq; Type: SEQUENCE; Schema: public; Owner: pierre
--

CREATE SEQUENCE citations_recordid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.citations_recordid_seq OWNER TO pierre;

--
-- Data for Name: citations; Type: TABLE DATA; Schema: public; Owner: pierre
--

COPY citations (citation, auteur, titre, date, concept, comment, saisie, recordid) FROM stdin;
C'est Dieu qui a créé le monde, mais c'est le Diable qui le fait vivre.	BERNARD Tristan	Contes, Répliques et Bons Mots		110     entropie	1866-1947. (Paul Bernard)	berkeley	709
Ce que nous aimons dans nos amis, c'est le cas qu'ils font de nous.	BERNARD Tristan	Deux amateurs de femmes		221     vanité	1866-1947. (Paul Bernard)	berkeley	710
Le hasard, voyez-vous, ne sert que les hommes forts et c'est ce qui indigne les sots.	GABORIAU Emile	L"Affaire Lerouge		441     sang-froid	1832-1873.	berkeley	2899
Les héros ne sentent pas bon !	FLAUBERT Gustave	L"Education sentimentale		221     vanité		berkeley	2717
Tout est dans le plaisir. Si vous aimez ce que vous faites, il y a de fortes chances pour que vous réussissiez.	WEST Morris	De main de Maître.	1988	460     plaisir		berkeley	5437
Il faut plutôt, pour opérer une révolution, une certaine masse de bêtise d'une part qu'une certaine dose de lumière de l'autre.	RIVAROL Antoine de	Fragments et pensées politiques		215     mystifications	1753-1801. (Antoine Rivarol)	berkeley	4825
La vie finit toujours par tuer...	CHARASSE Michel			515     tragédie		berkeley	1190
Il faut être modeste. Modeste mais humain.	HENEIN Georges	Lettres.		330     coeur		berkeley	3115
C'est une chose plus enivrante que le vin d'être une belle jeune femme! 	CLAUDEL Paul	L"Otage, I, 1, Sygne		510     ironie	1868-1955.	berkeley	1459
La colère est une courte folie.  Ira furor brevis est.	Horace	Epîtres, I, II, 62		441     sang-froid	65-8 av. J.-C. (Quintus Horatius Flaccus)	berkeley	3250
Toute chose a deux anses: l'une par où on peut la porter, l'autre par où on ne le peut pas.	EPICTETE	Manuel, XLIII		441     sang-froid	v. 50-v. 125.	berkeley	2356
Je fus pelaudé* à toutes mains; au Gibelin j'étais Guelphe; au Guelphe Gibelin.	MONTAIGNE Michel Eyquem de	Essais, III, 12 		539     ironie sociale	1533-1592.  *Etrillé.	berkeley	4388
Vous autres médecins aurez à répondre de plus de vies dans l'autre monde que même nous, généraux.	Napoléon I	Lettre à Barry 0"MEARA	1817	510     ironie	(29/09/1817)	berkeley	4562
Où donc un enfant dormirait-il avec plus de sécurité que dans la chambre de son père ?	NOVALIS	Journal Intime.		420     capital affectif		berkeley	4611
Le froid maintient le chaud; le chaud maintient le froid;  L'humide tient le sec, le sec ayde à l'humide,  Et à mêmes effets la concorde les guide.	NUYSEMENT Clovis de	Les Gémissements de la France		140     rapport à la cosmogonie	v. 1555-?. (Clovis Herteau)	berkeley	4612
Il y a une juste mesure; il y a enfin des limites précises hors desquelles ne peut se tenir le bien.  Est modus in rebus, sunt certi denique fines,  Quos ultra citraque nequit consistere rectum.	Horace	Satires, I, 1, 106		365     discernement	65-8 av. J.-C. (Quintus Horatius Flaccus)	berkeley	3241
Tout est affaire de point de vue, et le malheur n'est souvent que le signe d'une fausse interprétation de la vie.	MONTHERLANT Henry Millon de	Textes sous une occupation.		433     perversion		berkeley	4483
En un mot, le moi a deux qualités : il est injuste en soi, en ce qu'il se fait centre du tout; il est incommode aux autres, en ce qu'il les veut asservir : car chaque moi est l'ennemi et voudrait être le tyran de tous les autres.	PASCAL Blaise	Pensées		221     vanité	1623/1662. recueil posthume	berkeley	4640
Diseur de bons mots, mauvais caractère.	PASCAL Blaise	Pensées		510     ironie		berkeley	4651
Lorsqu'on crie 'Vive le progrès', demande toujours 'le progrès de quoi ?'.	LEC Stanislas	Pensées Echevelées.		441     sang-froid		berkeley	4086
Où finit la paresse, où commence la contemplation? 	DUTOURD Jean	Doucin		340     sensibilité	1920-.	berkeley	2243
Le parfum dont l'argile a été une fois imprégnée, elle le conservera longtemps.  Quo semel est imbuta recens servabit odorem  Testa diu.	Horace	Epîtres, I, II, 69		540     mémoire	65-8 av. J.-C. (Quintus Horatius Flaccus)	berkeley	3265
Il est en chacun, chacune d'entre nous un certain point de sensibilité et de vulnérabilité. Les épreuves de la vie nous forment à l'enfouir, loin des regards, celui de notre propre conscience par faiblesse, ceux de nos contemporains par bravade du monde sur lequel nous voulons peser. L'illusion et l'apparence de la force nous gagnent chaque fois que nous bravons, avec empathie, l'entropie des sentiments que nous suscitons chez nous, chez eux... Il n'est rien l à, au fond, qu'une petite loi de prégnance grégaire, formellement vitale.	FAIRGAGNETR Oscar		1991	120     grégarité		berkeley	2482
Il n'appartient qu'aux souverains, ou à ceux qui sont autorisés par eux, de se mêler de régler les moeurs des autres.	DESCARTES René	Correspondance, à Chanut, 20 novembre 1647		370     esprit	1596-1650.	berkeley	1926
Tout ce que tu as su ou vu n'est ni ce que tu as su ni ce que tu as vu.	ATTAR Farid al-din	Langage des oiseaux		510     ironie	v. 1150-v. 1220. Persan.	berkeley	1
Il n'y a que deux sortes d'hommes : les uns justes, qui se croient pécheurs ; les autres pécheurs, qui se croient justes.	PASCAL Blaise	Pensées		330     coeur		berkeley	4642
Peindre, c'est faire apparaître une image qui n'est pas celle de l'apparence naturelle des choses, mais qui a la force de la réalité.	DUFY Raoul	Carnet		393     création artistique	1877-1953.	berkeley	2200
La nuit vient quand un homme ne peut plus travailler.	WEST Morris	L"Avocat du Diable.	1959	110     entropie		berkeley	5350
Je n'ai jamais laissé dans le domaine du possible une chose qui demandait à naitre.	DUFY Raoul	Propos.		440     courage		berkeley	2201
Les grands hommes sont plus grands que nature dans le souvenir. Ce que nous voyons en eux, c'est à la fois le meilleur d'eux et le meilleur de nous.	CHARTIER Emile	Préliminaires A La Mythologie.		540     mémoire	alias Alain (1868-1951)	berkeley	1280
La morale consiste à se savoir esprit et, à ce titre, obligé, absolument ; car noblesse oblige.	CHARTIER Emile	Lettres Sur La Philosophie De Kant.		546     éthique	alias Alain (1868-1951)	berkeley	1281
Les grands hommes sont plus grands que nature dans le souvenir. Ce que nous voyons en eux, c'est à la fois le meilleur d'eux et le meilleur de nous.	CHARTIER Emile	Préliminaires à la mythologie.		550     grandeur	alias ALAIN	berkeley	1282
Tout ce que l'homme peut oser, je l'ose.	SHAKESPEARE William			520     ironie de soi		berkeley	5063
Danser est le fin mot de vivre et c'est par danser aussi soi-même qu'on peut seulement connaître quoi que ce soit: il faut s'approcher en dansant.	DUBUFFET Jean	Prospectus et tous Ecrits suivants		311     distinction	1901-1985.	berkeley	2185
Le bon sens est l'instinct du vrai.	JACOB Max	Philosophies.		360     bon sens		berkeley	3405
L'art de persuader consiste autant en celui d'agréer qu'en celui de convaincre.	PASCAL Blaise	Pensées		234     communication		berkeley	4641
L'homme juste produit la justice hors de lui parce qu'il porte la justice en lui.	CHARTIER Emile	Cent Un Propos, 5e Série.		550     grandeur	alias Alain (1868-1951)	berkeley	1283
... Un sage se distingue des autres hommes, non par moins de folie, mais par plus de raison.	CHARTIER Emile	Idées, Etude Sur Descartes.		560     sagesse	alias Alain (1868-1951)	berkeley	1284
C'est chose notoire que l'homme ne parvient jamais à la pure connaissance de soi-même jusqu' à ce qu'il ait contemplé la face de Dieu, et que, du regard de celle-ci, il descende à regarder soi.	CALVIN Jean	Institution de la religion chrétienne		215     mystifications	1509-1564.	berkeley	974
La majesté de Dieu est trop haute pour dire que les hommes mortels y puissent parvenir, vu qu'ils ne font que ramper sur la terre comme petits vers.	CALVIN Jean	Institution de la religion chrétienne		225     cynisme	1509-1564.	berkeley	975
Il n'y a pas de place pour le désespoir chez l'homme qui prend conscience de l'infini en contemplant les bornes de son petit univers.	BROCHE François	De Gaulle secret		520     ironie de soi		berkeley	864
L'amour à la sauvage églantine est pareil,  Et l'amitié pareille au houx,  Sombre est le houx, quand l'églantine est tout en fleur,  Mais lequel fleurit avec plus de constance?  Love is like the wild rose-briar,  Friendship like the holly-tree,  The holly is dark when the rose-briar blooms  But which will bloom most constantly? 	BRONTE Emily	Love and Friendship		420     capital affectif	1818-1848. (Anglaise)	berkeley	867
L'existence du Soldat est (après la peine de mort) la trace la plus douloureuse de barbarie qui subsiste parmi les hommes.	VIGNY Alfred de	Servitude et grandeur militaires		211     guerre	1797-1863.	berkeley	5291
Que chacun vante ses goûts, moi, j'aime ma bergère !	OPITZ Martin	Sylves poétiques.		531     communication amoureuse		berkeley	4627
Le printemps revient pour toi, les roses vont s'épanouir pour toi, et tu voudrais mourir ? Sors, dans la plus suave nuit de l'année. Il pleut des fleurs de pruniers, qui sècheront tes larmes.	TAI-CHOU-LOUEN	Poèmes.		130     liberté		berkeley	5186
Jusqu'ici, et avec plus ou moins de bonheur, voire de discernement, je n'ai jamais eu à me plaindre que de moi-même.	FAIRGAGNETR Oscar	Vitalités.	1993	441     sang-froid		berkeley	2609
Sois plus sage que les autres, si tu peux ; mais ne leur fais point sentir.	CHESTERFIELD Lord			441     sang-froid		berkeley	1344
J'avoue que je ne m'accommode pas bien de l'expression dont se servent des hommes pourtant avisés : tel peuple (que l'on conçoit en train d'élaborer sa liberté légale) n'est pas mûr pour la liberté, les serfs d'un propriétaire terrien ne sont pas encore mûrs pour la liberté ; et ainsi de même ; les hommes en général ne sont pas encore mûrs pour la liberté de croire. Mais suivant une telle hypothèse la liberté ne surgira jamais. Car on ne peut pas mûrir pour la liberté si l'on n'a pas été préalablement mis en liberté (on doit être libre pour se servir utilement de ses forces dans la liberté).	KANT	La Religion dans les limites de la simple raison.	1793	130     liberté	La Religion dans les limites de la simple raison.	berkeley	3536
Las de se faire aimer, il veut se faire craindre.	RACINE Jean	Britannicus		225     cynisme		berkeley	4772
Rien ne sert de penser, faut réfléchir avant.	DAC Pierre	L"os à moelle.		510     ironie		berkeley	1740
L'eau peut agir sans poisson,  Mais le poisson ne peut agir sans eau.	LAO TSEU	Tao tö King, XXXIV		441     sang-froid		berkeley	4035
Au chaudron des douleurs, chacun porte son écuelle.	ESTIENNE Henri	Les Prémices		510     ironie	1531-1598.	berkeley	2385
Rien pour l'Etat n'est plus dangereux qu'un tyran.	Euripide	Les Suppliantes, 429		239     servitudes du pouvoir autoritaire	480-406 av. J.-C.	berkeley	2390
Un dévot est celui qui sous un roi athée serait athée.	LA BRUYERE Jean de	Les Caractères		120     grégarité	1645-1696.	berkeley	3591
Si un homme vaut plus, lui seul, que tout le reste de sa ville, il n'aurait pas raison de se vouloir perdre pour la sauver.	DESCARTES René	Correspondance		221     vanité	1596-1650.	berkeley	1913
Combien de fois l'homme en colère nie-t-il avec rage ce que lui souffle son moi intérieur ?	HERBERT Franck	Dune	1965	430     paradoxal émotionnel		berkeley	3144
Ne jamais compter, dans les grandes affaires, la fatigue, le péril et la dépense pour quelque chose.	RETZ Cardinal de	Mémoires.		321     volonté		berkeley	4815
Rares ceux qui, dans leur vie et dans leur art, savent rejoindre le tact et la mesure en passant par la démesure.	REVERDY Pierre	En vrac.		441     sang-froid		berkeley	4816
Le rêve est le semblable qui renvoie éternellement au semblable.	BLANCHOT Maurice	L"Espace littéraire		320     intuition	1907-.	berkeley	767
Pour vous mieux contempler, demeurez au désert.	LA FONTAINE Jean de	Fables, le Juge arbitre, l"Hospitalier et le Solitaire		221     vanité	1621-1695.	berkeley	3660
Penser est désormais ce pas toujours à porter en arrière.	BLANCHOT Maurice	Le Livre à venir		441     sang-froid	1907-.	berkeley	771
Rien n'est si insupportable à l'homme que d'être dans un plein repos, sans passion, sans affaire, sans divertissement, sans application. Il sent alors son néant, son abandon, son insuffisance, sa dépendance, son impuissance, son vide. Incontinent, il sortira au fond de son âme, l'ennui, la noirceur, la tristesse, le chargrin, le dépit, le désespoir.	PASCAL Blaise	Pensées, 131		430     paradoxal émotionnel		berkeley	4646
On a toujours le choix entre l'entropie et le reste.	FAIRGAGNETR Oscar	Vitalités.	1993	130     liberté		berkeley	2485
Gouverne le mieux qui gouverne le moins.	LAO TSEU	Tao tö King, LVIII		510     ironie		berkeley	4037
Ce n'est rien que de le dire pour celui qui peut le faire.	FAIRGAGNETR Oscar			441     sang-froid		berkeley	2605
A fui le stable et le ferme,  Et seul perdure le fugace.  Huyo lo que era firme, y solamente  lo fugitivo permanece y dura.  Poesías, A Roma sepultada en sus ruinas  	QUEVEDO Y VILLEGAS Francisco Gomez de			140     rapport à la cosmogonie	1580-1645. (Espagnol)  Ici l"auteur imite un sonnet célèbre de Du Bellay: "Ce qui est ferme est par le temps détruit, et ce qui fuit au temps fait résistance" (les Antiquités de Rome, sonnet 3).	berkeley	4748
Le plus souvent, c'est la capacité de nuisance qui conditionne la position sociale d'un individu.	FAIRGAGNETR Oscar	Vitalités.	1995	230     pouvoir		berkeley	2468
Le travail est partout et la souffrance partout: seulement il y a des travaux stériles et des travaux féconds, des souffrances infâmes et des souffrances glorieuses.	LAMENNAIS Félicité Robert de	Paroles d"un croyant		510     ironie	1782-1854.	berkeley	4026
La méchanceté boit elle-même la plus grande partie de son venin.  Malitia ipsa maximam partem veneni sui bibit.  Lettres à Lucilius, LXXXI  	Sénèque	Mot attribué par Sénèque au stoïcien Attale, son maître		210     violence		berkeley	5020
La plus grande partie de la vie passe à mal faire, une grande partie à ne rien faire, toute la vie à faire autre chose que ce que l'on devrait.  Maxima pars vitae elabitur male agentibus, magna nihil agentibus, tota vita aliud agentibus.	Sénèque	Lettres à Lucilius, I		520     ironie de soi		berkeley	5021
Travaillez, prenez de la peine:  C'est le fonds qui manque le moins.	LA FONTAINE Jean de	Fables, le Laboureur et ses Enfants		380     travail	1621-1695.	berkeley	3704
Il n'y a pas de serrure dont le crime n'ait la clef.	BERTRAND Aloysius	Gaspard de la Nuit		210     violence	1807-1841. (Louis Bertrand)	berkeley	736
Le jeu n'a pas d'autre sens que lui-même.	CAILLOIS Roger	Les Jeux et les hommes		441     sang-froid	1913-1978.	berkeley	965
Sans alliés, la guerre est déj à suffisement difficile - avec des alliés, c'est l'enfer !	PLESSOR Sir John	Stratégie pour l"Occident	1954	211     guerre		berkeley	4722
Je sais que si tu ne te pardonnes pas, tu vas finir par haïr ton reflet dans le miroir. Et quand tu en aura assez de te haïr, tu reporteras ta haine sur moi.	WEST Morris	De main de Maître.	1988	433     perversion		berkeley	5426
Il est plus laborieux de conduire les hommes par la persuasion que par le fer.	CLAUDEL Paul	La Ville		231     légitimité du pouvoir	1868-1955.	berkeley	1438
L'esclavage a la voix enrouée et ne peut parler haut.	SHAKESPEARE William	Roméo et Juliette.		130     liberté		berkeley	5043
Une bonne renommée est un second héritage.  Honestus rumor alterum est patrimonium.	WIMPFELING Jacob	La Jeunesse de Jacob		230     pouvoir	1450-1528.	berkeley	5489
En persévérant on arrive à tout.	THEOCRITE	Idylle.		321     volonté		berkeley	5197
Le début de la vie d'un homme en est la partie la plus importante. Habituellement c'est le travail du père d'engager son fils dans le droit chemin.	WEST Morris	L"Avocat du diable.	1959	421     initiation		berkeley	5409
Pas assez sorti : il faut voir les gens pour les remettre à leur place.	Dictons et proverbes			432     expérience		berkeley	2065
La colère est une maladie, et la vengeance appartient aux esprits étroits.	VAN DE VETERING J.	Cash-Cash Millions	1988	433     perversion		berkeley	5253
(Balzac) a des intuitions de génie, et des réflexions d'imbécile. C'est un chaos et un problème.	FAGUET Emile	Etudes littéraires du dix-neuvième siècle		393     création artistique	1847-1916.	berkeley	2449
Nous vivons une vie, nous en rêvons une autre, mais celle que nous rêvons est la vraie.	GUéHENNO Jean	La Foi difficile		520     ironie de soi	1890-1978.	berkeley	3039
Je ne me défie pas de la machine que je regarde avec curiosité sur son socle ou sous sa verrière. Je me défie de la machine qui est en moi.	DUHAMEL Georges	Paroles de médecin		520     ironie de soi	1884-1966.	berkeley	2217
Le désir d'ordre est le seul ordre du monde.	DUHAMEL Georges	Cécile parmi nous		539     ironie sociale	1884-1966.	berkeley	2219
J'ai appris à aimer certains hommes par le mal que j'en ai entendu dire par d'autres hommes que je n'aimais pas.	GUITRY Sacha			370     esprit		berkeley	3061
A l'heure où nous sommes, tous les français comprennent que les formes ordinaires du pouvoir ont disparu. Devant la confusion des âmes françaises, devant la liquéfaction du gouvernement tombé sous la servitude ennemie, devant l'impossibi- lité de faire jouer nos institutions, moi, général de Gaulle, soldat et chef français, j'ai conscience de parler au nom de la France. Au nom de la France, je déclare formellement ce qui suit : Tout français qui porte encore des armes a le devoir absolu de continuer la résistance [...]. Dans l'Afrique de Clauzel, de Bugeaud, de Lyautey, de Noguès, tout ce qui a de l'honneur a le strict devoir de refuser l'exécution des conditions ennemies. Il ne serait pas tolérable que la panique de Bordeaux ait pu traver- ser la mer. Soldats de France, où que vous soyez, debout !	DE GAULLE Charles	Appel du général de Gaulle - BBC Londres - 19/06/40.	1940	321     volonté		berkeley	1818
Quand tout le monde pense de la même manière, personne ne réfléchit beaucoup.	OECH Roger von	Créatif de choc.	1983	120     grégarité	é	berkeley	4618
Il ne faut choisir pour épouse que la femme que l'on choisirait pour ami, si elle était homme.	JOUBERT Joseph	Pnsées.		530     ironie amoureuse		berkeley	3469
Le bonheur, c'est tout de suite ou jamais.	JOUHANDEAU Marcel	Eléments pour une éthique		420     capital affectif	1888-1979.	berkeley	3478
R. me demande ce que j'ai contre lui. Je ne peux lui pardonner les confidences que je lui ai faites.	JOUHANDEAU Marcel	Algèbre des valeurs morales		433     perversion	1888-1979.	berkeley	3479
La prose n'est pas une danse. Elle marche.	COCTEAU Jean	La Difficulté d"être		393     création artistique	1889-1963.	berkeley	1505
Tout problème profane un mystère; à son tour, le problème est profané par sa solution.	CIORAN Emile-Michel	Syllogismes de l"amertume		441     sang-froid	1911-.	berkeley	1391
Trop de culture épuise un champ fertile.	BERNIS François Joachim de Pierres de	Poésies diverses		560     sagesse	1715-1794.	berkeley	726
Tout ce qui monte converge.	TEILHARD de CHARDIN Pierre			234     communication		berkeley	5194
Il n'y a guère d'homme assez habile pour connaitre tout le mal qu'il fait.	LA ROCHEFOUCAULD François de	Maximes.		520     ironie de soi		berkeley	3913
On ne découvre une saveur aux jours que lorsqu'on se dérobe à l'obligation d'avoir un destin.	CIORAN Emile-Michel	Syllogismes de l"amertume		441     sang-froid	1911-.	berkeley	1392
S'il est bien vrai que l'on ne se forme jamais que sur des déchets de sagesse, l'enseignement est certainement une imposture délicate.	FAIRGAGNETR Oscar	Vitalités.	1993	421     initiation		berkeley	2571
Redressons-nous. Les raisons nous manquent d'être si modeste.	DE GAULLE Charles	Carnet inédit	1916	321     volonté		berkeley	1812
La matière demeure et la forme se perd! 	RONSARD Pierre de	Elégies		390     création	1524-1585.	berkeley	4853
Depuis six mille ans, la guerre Plaît aux peuples querelleurs,Et Dieu perd son temps à faire Les étoiles et les fleurs.	HUGO Victor	Les chansons des rues et des bois.		211     guerre		berkeley	3286
Un règne acquis vaut mieux que l'espoir d'estre Roy.	JODELLE Etienne	Didon se sacrifiant		441     sang-froid	1532-1573.	berkeley	3441
De tout temps les hommes, pour quelque morceau de terre de plus ou de moins, sont convenus entre eux de se dépouiller, se brûler, se tuer, s'égorger les uns les autres; et pour le faire plus ingénieusement et avec plus de sûreté, ils ont inventé de belles règles qu'on appelle l'art militaire.	LA BRUYERE Jean de	Les Caractères, Du souverain ou de la république		211     guerre	1645-1696.	berkeley	3596
Les grands hommes se passionnent pour les petites choses, quand les grandes viennent à leur manquer.	TOCQUEVILLE Alexis de	Correspondance, à G. de Beaumont, 22 mars 1857		510     ironie	1805-1859.	berkeley	5209
J'aime les paysans, ils ne sont pas assez savants pour raisonner de travers.	MONTESQUIEU Charles de	Mes pensées		433     perversion	1689-1755. (C. de Secondat, baron de La Brède et de M.)	berkeley	4444
Les canaris ne chantent pas quand on leur tord le cou.	Dictons et Proverbes	Proverbe.		120     grégarité		berkeley	1988
Celui qui remue le passé perd un oeil, celui qui l'oublie perd les deux.	Dictons et Proverbes	Proverbe russe		540     mémoire		berkeley	2055
Il y a dans le coeur du plus honnête homme un cloaque plein de reptiles affreux. Se rendre compte de cela, c'est participer à l'exploration de l'homme en général, c'est une tache profondément bénéfique, à moins qu'on ait décidé de mener la vie d'un frère ignorantin ou d'un prêcheur de la Ligue des droits de l'homme.	VERGES Jacques	Le salaud lumineux.	1990	440     courage	entretiens avec Jean-Louis Remilleux	berkeley	5279
... la recherche des phrases nouvelles et des mots peu connus vient d'une ambition puérile et pédantesque. Puissé-je ne me servir que de ceux qui servent aux Halles à Paris! 	MONTAIGNE Michel Eyquem de	Essais, I, 26		221     vanité	1533-1592.	berkeley	4321
L'obstination et ardeur d'opinion est la plus sûre preuve de bêtise: est-il rien certain, résolu, dédaigneux, contemplatif, grave, sérieux, comme l'âne? 	MONTAIGNE Michel Eyquem de	Essais, III, 8		221     vanité	1533-1592.	berkeley	4322
Il est doux d'avancer. Mais la question est ailleurs ; il d'agit de marquer.	DE GAULLE Charles		1927	390     création	promu chef de bataillon ; en réponse aux félicitations2 de Lucien NACHIN.	berkeley	1819
Qu'est-ce que le nationalisme ? C'est un patriotisme qui a perdu sa noblesse et qui est au patriotisme noble et raisonnable, ce que l'idée fixe est à la conviction normale.	SCHWEITZER Docteur Albert	Décadence et renaissance de la culture.		110     entropie		berkeley	4986
Les grammatistes trouvent des taches dans le soleil, et souvent ces taches n'existent que sur leurs médiocres lunettes.	VEUILLOT Louis			221     vanité		berkeley	5285
Quand je suis le plus faible, je vous demande la liberté parce que tel est votre principe ; mais quand je suis le plus fort, je vous l'ôte, parceque tel est le mien.	VEUILLOT Louis	Conversation avec Augustin Cochin.		225     cynisme		berkeley	5286
Après le don qui vient d'en-haut, la condition des grandes choses [en littérature] c'est le travail. Car, d'avoir une première fleur d'imagination et de style, c'est la matière d'un heureux début, et pas du tout d'une grande chose.	VEUILLOT Louis \t	Mélanges.\t\t		380     travail		berkeley	5287
C'est par lui-même que naît l'artiste. C'est sa bonne fortune qui lui permet de travailler.	FAIRGAGNETR Oscar		1992	393     création artistique		berkeley	2565
Le mérite a sa pudeur comme la chasteté.	DUCLOS Charles Pinot	Considérations sur les moeurs de ce siècle		560     sagesse	1704-1772.	berkeley	2198
C'est bien plus souvent dans les petites choses que dans les grandes que l'on connaît les gens courageux.  Molte volte più nelle cose piccole che nelle grandi si conoscono i coraggiosi.	CASTIGLIONE Baldassarye	Il Cortegiano, I, 17		440     courage	1478-1529. (Italien)	berkeley	1052
Ce soir, au cirque, un dompteur montrait à la fois des poules, des renards et des chiens. Les renards s'avançaient amicalement vers les poules : c'était le progrès. Les poules n'avaient pas l'air trop rassurées : c'était la routine. Grâce aux chiens pacificateurs, tout allait bien : c'était la civilisation.	RENARD Jules	Journal.		539     ironie sociale		berkeley	4814
La quête de l'irresponsabilité personnelle par tous moyens est la plus naturelle des entropies individuelles. La démission du discernement au profit d'une grégarité matricielle nourrie de préjugés et d'esprit de corps sera toujours le pire des cancers sociaux. Il n'y a rien qui puisse protéger, de lui-même, le plus grand nombre quand, apeuré devant le réel, il cherche refuge auprès des chimères de la facilité. Dans une chute choisie par omission, il se verra toujours et irrémédiablement entrainé vers le chaos totalitaire de la dépersonalisation individuelle et du fascisme social.	FAIRGAGNETR Oscar	Vitalités.	1995	110     entropie		berkeley	2467
Les passions détruisent plus de préjugés que la philosophie.	DIDEROT Denis	Discours sur la poésie dramatique		430     paradoxal émotionnel	1713-1784.	berkeley	2108
L'homme est, de tous les êtres vivants, le seul à courir deux plaisirs à la fois.	CHAZAL Malcolm de	Sens plastique		520     ironie de soi	1902-1981.	berkeley	1334
Si l'esclavage n'est pas mauvais, rien n'est mauvais.	LINCOLN Abraham	Lettre à A.G. Hodges.	1864	546     éthique		berkeley	4142
Aucune histoire ne finit bien, car il y en a toujours un qui meurt avant l'autre.	HEMINGWAY Ernest			530     ironie amoureuse		berkeley	3113
Le gain de notre étude, c'est en être devenu meilleur et plus sage.	MONTAIGNE Michel Eyquem de	Essais.		421     initiation		berkeley	4349
Le petit d'homme n'est pas un petit homme.	ROUSSEAU Jean-Jacques			421     initiation	(attribué  à)	berkeley	4886
On ne devrait écrire des livres que pour dire des choses qu'on n'oserait confier à personne.	CIORAN Emile-Michel	De l"inconvénient d"être né.		393     création artistique	1911-.	berkeley	1388
C'est au moment où l'on triche pour le beau que l'on est artiste.	JACOB Max	Art poétique		393     création artistique	1876-1944.	berkeley	3406
Le propre du lyrisme est l'inconscience, mais une inconscience surveillée.	JACOB Max	Conseils à une jeune poète		393     création artistique	1876-1944.	berkeley	3407
Il entre, dans toute espèce de débauche, beaucoup de froideur d'âme. Elle est un abus réfléchi et volontaire du plaisir.	JOUBERT Joseph	Carnets		240     débauche	1754-1824.	berkeley	3455
L'éthique contraint et grandit le coeur. L'esthétique embellit le coeur ferme et perd le vulgaire.	FAIRGAGNETR Oscar	Vitalités.	1992	550     grandeur		berkeley	2650
Il y a des esprits qui vont à l'erreur par toutes les vérités; il en est de plus heureux qui vont aux grandes vérités par toutes les erreurs.	JOUBERT Joseph	Carnets		510     ironie	1754-1824.	berkeley	3467
Je vous aime  Beaucoup moins que mon Dieu, mais bien plus que moi-même.	CORNEILLE Pierre	Polyeucte, IV, 3, Polyeucte		433     perversion	1606-1684.	berkeley	1665
Qui ne craint point la mort ne craint point les menaces.	CORNEILLE Pierre	Le Cid, II, 1, le comte		440     courage	1606-1684.	berkeley	1666
La calomnie est une guêpe qui vous importune et contre laquelle il ne faut faire aucun mouvement, à moins qu'on ne soit sûr de la tuer, sans quoi elle revient à la charge, plus furieuse que jamais.	CHAMFORT Nicolas-Sébastien de	Maximes et pensées		441     sang-froid	1740/1794. Ac. Française	berkeley	1129
Toute parole que tu libères enchaîne.	CROMMELYNCK Fernand	Une femme qui a le coeur trop petit		510     ironie	1886-1970.	berkeley	1726
Maintenez vivante en vous la faculté de l'effort en la soumettant chaque jour à un petit exercice sans profit.  Keep the faculty of effort alive in you by a little gratuitous exercise every day.	JAMES William	Principles of Psychology, X		321     volonté	1842-1910. (Américain)	berkeley	3416
C'est étrange. Prenez le marin le plus courageux, l'aviateur le plus intrépide, le soldat le plus brave, et réunissez-les autour d'une table. Et qu'obtenez vous ? La somme de toutes leurs peurs.	CHURCHILL Sir Winston Leonard Spencer			120     grégarité		berkeley	1364
L'élément unifiant pourrait être défini ainsi : aventure et solitude d'un individu égaré dans le vaste monde, vers une initiation et une reconstruction intérieure.	CALVINO Italo	Entretien Avec Maria CORTI.	1985	430     paradoxal émotionnel	Autographo n°6 (10/1985)	berkeley	977
Faites ce que je dis et non ce que j'ai fait.	DELAVIGNE Casimir	Louis XI		221     vanité	1793-1843.	berkeley	1885
Le caractère, c'est- à-dire la passion d'être soi, à tout prix.	SUARES André	Le Voyage du condottiere		440     courage		berkeley	5161
L'érudition est bien loin d'être un mal ; elle agrandit le champ de l'expérience, et l'expérience des hommes et des choses est la base du talent.	JACOB Max	Conseils à un jeune poète.		432     expérience		berkeley	3411
Quand on ne regarde la vérité que de profil ou de trois-quart, on la voit toujours mal. Il y a peu de gens qui savent la contempler de face.	FLAUBERT Gustave	L"amour de l"art.	1915	440     courage	(1821/1880) édition posthume	berkeley	2767
On n'arrive au style qu'avec un labeur atroce, avec une opiniâtreté fanatique et dévouée.	FLAUBERT Gustave	L"amour de l"art.	1915	440     courage	(1821/1880) édition posthume	berkeley	2768
Quand on observe avec un peu d'attention la vie on y voit les cèdres moins hauts et les roseaux plus grands.	FLAUBERT Gustave	L"amour de l"art.	1915	441     sang-froid	(1821/1880) édition posthume	berkeley	2769
L'irrésolution me semble le plus commun et apparent vice de notre nature.	MONTAIGNE Michel Eyquem de	Essais, II, 1		442     démission	1533-1592.	berkeley	4368
Le poète est semblable aux oiseaux de passage  Qui ne bâtissent point leurs nids sur le rivage,  Qui ne se posent pas sur les rameaux des bois;  Nonchalamment bercés sur le courant de l'onde,  Ils passent en chantant loin des bords et le monde  Ne connaît rien d'eux que leur voix.	LAMARTINE Alphonse de	Nouvelles Méditations		393     création artistique	1790-1869.	berkeley	3999
Je ne sais pas d'avance ce qui pourrait me toucher. Heurusement !	KAHNWEILER Daniel-Heinrich	Entretien accordé au périodique "Lectures pour tous".	1969	312     foi	Entretien accordé au périodique "Lectures pour tous".	berkeley	3517
Il faut assommer les peintres.	DEGAS	\\010iS∞\\020		520     ironie de soi		berkeley	1879
On va d'un pas plus ferme à suivre qu' à conduire.	CORNEILLE Pierre	Imitation de Jésus-Christ, I, ch. IX		120     grégarité	1606-1684.	berkeley	1647
Les colonies ne cessent pas d'être des colonies parce qu'elles sont indépendantes.  Colonies do not cease to be colonies because they are independent.	DISRAELI Benjamin	Speech in House of Commons, 17 mars 1845		215     mystifications	1804-1881. (Anglais)	berkeley	2122
L'oeuvre d'art n'est pas le reflet, l'image du monde; mais elle est à l'image du monde.	IONESCO Eugène	Notes et Contre-notes		393     création artistique	1912-.	berkeley	3386
Plutôt que le maître d'école, le critique doit être l'élève de l'oeuvre.	IONESCO Eugène	Notes et Contre-notes		393     création artistique	1912-.	berkeley	3387
Ce qui semble périr se change seulement.	CHASSIGNET Jean-Baptiste	Le Mespris de la vie et consolation contre la mort		545     épistémologie	v. 1570-v. 1635.	berkeley	1287
Jusqu'ici le grand art n'a jamais surgi sur la terre ailleurs que dans une nation de soldats.	RUSKIN John	The Crown of Wild Olive. III.	1866	510     ironie		berkeley	4900
Il y a à parier que le grand Newton ne vivra pas aussi longtemps que le vieux Homère.	BERNIS François Joachim de Pierres de	Discours sur la poésie		560     sagesse	1715-1794.	berkeley	727
Il se croit des talents et de l'esprit : il est riche.	LA BRUYERE Jean de	Les Caractères		422     confiance en soi	1645-1696.	berkeley	3616
On rencontre sa destinée  Souvent par des chemins qu'on prend pour l'éviter.	LA FONTAINE Jean de	Fables, l"Horoscope		520     ironie de soi	1621-1695.	berkeley	3750
La raison habite rarement les âmes communes et bien plus rarement encore les grands esprits.	FRANCE Anatole	Le Petit Pierre		365     discernement	1844-1924. (Anatole François Thibault)	berkeley	2859
Aimer un être, c'est accepter de vieillir avec lui.	CAMUS Albert	vieillir av\\010[&#229;p\\010[ç à		530     ironie amoureuse		berkeley	1025
La peinture est poésie muette, la poésie peinture aveugle.  La Pittura è una Poesia muta, e la Poesia è una Pittura cieca.	VINCI Léonard de	Traité de la peinture		393     création artistique	1452-1519. (Italien)	berkeley	5316
Où il y a des figues, il y a des amis.	Dictons et Proverbes	Proverbe espagnol		120     grégarité		berkeley	1987
Je comprenais, très clairement , l'irrésistible attrait qui pousse les anachorètes à fuir la confusion des vieilles cités, leurs injustices, leurs corruptions, et leurs cruautés. Je compris la séduction des déserts et des hauts lieux où un homme peut commencer à renaître.	WEST Morris	Le Loup Rouge.	1971	130     liberté		berkeley	5354
Un équipage bien nourri est un équipage heureux, et les hommes se défoncent pour un commandant qui s'occupe d'eux.	CLANCY Tom	La somme de toutes les peurs. II.	1991	391     commandement		berkeley	1424
La liberté tient moins de l'absence de contraintes que du choix de celles que l'on s'impose à soi-même.	FAIRGAGNETR Oscar		1991	130     liberté		berkeley	2486
Mais la haine qu'il éprouvait pour les hommes restait sans écho de leur part. Plus il les haïssait, à cet instant, plus ils l'adoraient comme un dieu, car ils ne percevaient de lui que l'aura qu'il s'était arrogée, son masque odorant, son parfum volé, et celui-ci était effectivement digne d'adoration.	SUSKIND Patrick	Le Parfum.	1985	215     mystifications		berkeley	5175
Car l'odeur était soeur de la respiration. Elle pénétrait dans les hommes en même temps que celle-ci ; ils ne pouvaient se défendre d'elle, s'ils voulaient vivre. Et l'odeur pénétrait directement en eux jusqu' à leur coeur, et elle y décidait catégoriquement de l'inclinai- son et du mépris, du dégoût et du désir, de l'amour et de la haine. Qui maîtrisait les odeurs maîtrisait le coeur des hommes.	SUSKIND Patrick	Le Parfum.		215     mystifications		berkeley	5176
En France, on laisse en repos ceux qui mettent le feu et on persécute ceux qui sonnent le tocsin.	CHAMFORT Nicolas-Sébastien de	Maximes et pensées		110     entropie	1740/1794. Ac. Française	berkeley	1103
On ne peut répondre de son courage quand on n'a jamais été dans le péril.	LA ROCHEFOUCAULD François de	Maximes.		440     courage		berkeley	3886
Bornons ici cette carrière:  Les longs ouvrages me font peur.  Loin d'épuiser une matière,  On n'en doit prendre que la fleur.	LA FONTAINE Jean de	Fables, Epilogue du premier recueil, 1668		390     création	1621-1695.	berkeley	3707
Les vertus se perdent dans l'intérêt, comme les fleuves dans la mer.	LA ROCHEFOUCAULD François de	Réflexions ou Sentences et Maximes morales.	1665	110     entropie	1613/1680	berkeley	3784
L'on n'estime guère dans les autres que les qualités que l'on croit posséder soi-même.	LAMENNAIS Félicité Robert de	Mélanges religieux et philosophiques		221     vanité	1782-1854.	berkeley	4023
Le diable existe ... On le voit partout comme je vous vois. C'est pour lui épiler mieux la barbe que les miroirs de poche ont été inventés.	BERTRAND Aloysius	Gaspard de la Nuit		520     ironie de soi	1807-1841. (Louis Bertrand)	berkeley	737
La vie est l'ensemble des fonctions qui résistent à la mort.	BICHAT François Xavier	Recherches physiologiques sur la vie et la mort		310     énergie	1771-1802.	berkeley	739
Une civilisation qui ne croit plus aux mots qu'elle emploie est morte.	DENIAU Jean-François		1994	515     tragédie	La Marche du Siècle, 14/12/94.	berkeley	1900
A mesure que l'on vieillit, la nature descend, les âmes montent.	LACORDAIRE			520     ironie de soi		berkeley	3970
Son visage était assez beau, mais pâle après plusieurs mois d'hôpital. Et ses yeux trahissaient son absence totale d'espoir ; en fait, ils n'exprimaient absolument rien.	HIGGINS Jack	Opération Cornouailles.	1990	420     capital affectif		berkeley	3188
Dans le monde, disait M..., vous avez trois sortes d'amis: vos amis qui vous aiment; vos amis qui ne soucient pas de vous, et vos amis qui vous haïssent.	CHAMFORT Nicolas-Sébastien de	Caractères et anecdotes		510     ironie	1740/1794. Ac. Française	berkeley	1142
Tout notre mal vient de ne pouvoir être seuls: de l à le jeu, le luxe, la dissipation, le vin, les femmes, l'ignorance, la médisance, l'envie, l'oubli de soi-même et de Dieu.	LA BRUYERE Jean de	Les Caractères		423     solitude	1645-1696.	berkeley	3617
Nul gouvernement ne peut être longtemps solide sans une redoutable opposition.  No government can be long secure without a formidable opposition.	DISRAELI Benjamin	Coningsby, I, 1		232     servitudes du pouvoir	1804-1881. (Anglais)	berkeley	2125
Les hommes ne savent être ni entièrement bons, ni entièrement mauvais.	MACHIAVEL Nicolas	Pensées.		510     ironie		berkeley	4162
- Mais de quoi sont composées les affaires du monde?  - Du bien d'autrui.	BéROALDE DE VERVILLE François	Le Moyen de parvenir		215     mystifications	v. 1556-v. 1621.	berkeley	728
Il n'y a pas de honte à préférer le bonheur.	CAMUS Albert	La Peste		510     ironie	1913-1960.	berkeley	1018
La plus sublime révélation, c'est que Dieu est en chaque homme.  The highest revelation is that God is in every man.	EMERSON Ralph Waldo	Journals, 8 septembre 1833		560     sagesse	1803-1882. (Américain)	berkeley	2344
Des moyens accrus et des loisirs accrus sont les deux agents de civilisation de l'homme.  Increased means and increased leisure are the two civilizers of man.	DISRAELI Benjamin	Speech at Manchester, 3 avril 1872		421     initiation	1804-1881. (Anglais)	berkeley	2127
L'homme qui n'a rien à se glorifier sauf de ses illustres ancêtres, est semblable à la pomme de terre : la seule qualité qu'il possède, se trouve sous terre.	OVERBURY Sir Thomas	Caractères.		221     vanité		berkeley	4628
... Ce génie particulier de la femme qui comprend l'homme mieux que l'homme ne se comprend.	HUGO Victor	Les Misérables		365     discernement	1802-1885.	berkeley	3308
Ecouter un témoin fait de vous un témoin.	WIESEL Elie			540     mémoire	Intervention pendant la Marche du Siècle du 08/09/93, en duplex de Philadelphie. (Projection d"extraits du procès Barbie, montés par Paul Lefèvre)	berkeley	5464
Aujourd'hui, on vous invente un génie par semaine et on s'étonne qu'il y ait des ratés. Un génie, c'est long à s'accomplir. Les peintres d'hier étaient moins pressés. Ce n'est pas à vingt-deux ans qu'ils rencontraient leur génie et ce n'est pas à trente ans qu'ils faisaient fortune.	KAHNWEILER Daniel-Heinrich	Article au Figaro littéraire.	1965	390     création		berkeley	3520
Volontiers pédagogue, très allemand dans son goût de la démonstration, Kahnweiler divise l'acte de création en plusieurs étapes : l'émotion intérieure, l'image mentale floue aux contours imprécis, la volonté de préciser puis de concrétiser, la lutte intérieure suscitée par tout véritable acte de création, la matérialisation en une image extérieure sur une surface plane, enfin la lecture de cette image. La peinture ayant un rôle biologique de création du monde, le peintre s'exprime grace à un ensemble de signes. Cette peinture étant une écriture, le spectateur la lit. S'il la comprend, c'est qu'il a identifié le signe avec la chose signifiée. En ce sens, d'accord avec Masson auquel il emprunte la formule, Kahnweiler estime que la grande peinture est une peinture où les intervalles sont chargés d'autant d'énergie que les figures qui les déterminent. Naturellement, il ne saurait être question pour lui d'expliquer la peinture sans tracer un parallèle avec la musique. Evoquant l'art de Gris lui-même, il emploie le terme de 'polyphonie' pour définir la structure de certains de ses tableaux et celui de 'contrepoint' pour qualifier sa méthode car elle vise, elle aussi, à conduire simultanément des lignes mélodiques indépendantes. Se référant sans cesse à Arnold Schonberg, un musicien qu'il place très haut puisque, de son point de vue, il domine son siècle, il établit une similitude plus totale encore entre musique et peinture, du moins dans l'approche que le débutant peut en avoir. La première fois qu'il écoute une symphonie moderne ou qu'il voit un tableau d'avant- garde, il n'y comprend rien si aucune accoutumance ne l'y a préparé. En fait, il n'a rien vu et rien entendu. Il ne verra et n'entendra que quand il aura reproduit, ou plutôt reconstitué en lui les images et les sons. C'est l à une vieille idée qu'il creuse depuis près de trente ans et dont il ne se déprendra jamais : la peinture n'existe que dans la conscience du spectateur, par sa communion avec le peintre et l'émotion qu'il a voulu transmettre. [...] On passe alors [en 1913] de ce qu'il appelle 'le cubisme analytique', une peinture empirique où l'artiste multiplie les renseignements sur ce qu'il peint, au 'cubisme synthétique', qui rassemble tout le savoir du peintre sur un objet ou un emblème unique. Cette transition, cristalisée par deux formules qui passeront à la postérité, marque le moment où l'on rompt véritablement avec l'esprit de la Renaissance et où l'on renoue avec la peinture du Moyen-Age, mais avec d'autres moyens et dans un tout autre but. Selon DHK, c'est bien l à, en cet instant privilégié de 1913 où l'ensemble de la société intellectuelle et artistique est en pleine mutation, que l'on assiste à la naissance d'une peinture conceptuelle.	KAHNWEILER Daniel-Heinrich	Gris, sa vie, son oeuvre,...	1945	393     création artistique	rapporté par Pierre Assouline dans "Un Homme d"Influence".	berkeley	3523
Un art académique est un art qui se sert de formes prises ailleurs en les employant soit à contresens soit en leur enlevant tout sens.	KAHNWEILER Daniel-Heinrich	Lettre à l"historien d"art Meyer Shapiro.	1962	393     création artistique		berkeley	3524
... D'être un homme,  l'homme et beaucoup d'hommes s'en fatiguent terriblement.  ... La hombría  del hombre, de muchos hombres, se cansa atrozmente.	GUILLéN ALVAREZ Jorge	Clamor, III, A la altura de las circunstancias		510     ironie	1893-. (Espagnol)	berkeley	3047
En voulant éviter un défaut, les sots se jettent dans le défaut contraire.  Dum vitant stulti vitia, in contraria currunt.	Horace	Satires, I, 2, 24		221     vanité	65-8 av. J.-C. (Quintus Horatius Flaccus)	berkeley	3236
En cage a commencé Ma vie. Je connais l'Homme. Oh ! par le Cadenas Brisé qui m'a sauvée, Prends garde, Petit d'Homme, A la race des Hommes. Enivré de rosée Ou bien baigné d'étoiles, Ne choisis pas la piste Des chats, grimpeurs oisifs. Au conseil, à la chasse, Au repaire ou en meute, Ne fais jamais la trêve Avec l'Homme-Chacal ! Et lorsqu'il te dira : 'Viens chez nous : on vit bien', Réponds par le silence. Réponds par le silence Quand il recherchera Ton bras contre les faibles. Ne fais pas le bandar, Ce vantard, et tais-toi Au dessus de ta proie ! Signe, appel ou chanson, Que rien ne te détourne De ta ligne de chasse ! Des brumes du matin Jusqu'au clair crépuscule, Soyez ses serviteurs !) Arbre et Vent, Bois et Eaux, La Faveur de la Jungle T'accompagne partout.	KIPLING Rudyard	Le second livre de la Jungle.	1895	421     initiation	La dernière chanson, Bagheera à Mowgli.	berkeley	3560
Je me tiendrai toujours plus obligé à ceux par la faveur desquels je jouirai sans empêchement de mon loisir, que je ne ferais à ceux qui m'offriraient les plus honorables emplois de la terre.	DESCARTES René	Discours de la méthode		365     discernement	1596-1650.	berkeley	1923
Il faut, pour bien écrire, que la nécéssité intervienne ; le libre choix paralyse.	RAMUZ Charles-Ferdinand	Journal.		390     création		berkeley	4796
Dans l'idéal que j'ai de l'art, je crois qu'on ne doit rien montrer de ses convictions et que l'artiste ne doit pas plus apparaître dans son oeuvre que Dieu dans la nature. L'homme n'est rien, l'oeuvre tout.	FLAUBERT Gustave	L"amour de l"art.	1915	393     création artistique	(1821/1880) édition posthume	berkeley	2749
La jalousie naît toujours avec l'amour; mais elle ne meurt pas toujours avec lui.	LA ROCHEFOUCAULD François de	Maximes		530     ironie amoureuse	1613-1680.	berkeley	3931
La modestie est le seul éclat qu'il soit permis d'ajouter à la gloire.	DUCLOS Charles Pinot	Considérations sur les moeurs de ce siècle		550     grandeur	1704-1772.	berkeley	2197
Le meilleur procédé pour réussir dans l'action est de savoir perpétu- ellement se dominer soi-même [...]. Mais se dominer soi-même doit être devenu l'habitude,le réflexe moral obtenu par une gymnastique constante de la volonté, notamment dans les petites choses : tenue, conversation, conduite de la pensée, méthode recherchée et appli- quée en toutes choses, notamment dans le travail. Il faut parler peu, il le faut absolument. L'avantage d'être un causeur brillant ne vaut pas au centième celui d'être replié sur soi-même, même au point de vue de l'influence générale. Chez  l'homme de valeur, la réflexion doit être concentrée. Autrui ne s'y trompe pas. Et dans l'action, il ne faut rien dire. Le chef est celui qui ne parle pas.	DE GAULLE Charles	carnet inédit.	1916	321     volonté		berkeley	1813
Le silence, a dit quelqu'un, est une vertu qui nous rend agréables à nos semblables.  Silence, it has been said by one writer, is a virtue which renders us agreeable to our fellow-creatures.	BUTLER Samuel	Erewhon, New Travels, 23		510     ironie	1835-1902. (Anglais)	berkeley	929
Il faut bien de la force pour dire en mourant les mêmes choses qu'on dirait en bonne santé.	BUSSY-RABUTIN Roger de Rabutin	Lettres, à Madame de Sévigné, 6 janvier 1681		440     courage	1618-1693. comte de Bussy	berkeley	922
Je me sers d'animaux pour instruire les hommes.	LA FONTAINE Jean de	Fables		510     ironie	1621-1695.	berkeley	3744
Le loup attaque de la dent, le taureau des cornes.  Dente lupus, cornu taurus petit.	Horace	Satires, I, 1, 52		210     violence	65-8 av. J.-C. (Quintus Horatius Flaccus)	berkeley	3233
Si la noblesse est vertu, elle se perd par tout ce qui n'est pas vertueux; et si elle n'est pas vertu, c'est peu de chose.	LA BRUYERE Jean de	Les Caractères		546     éthique	1645-1696.	berkeley	3632
Aimer, c'est se surpasser.	WILDE Oscar	Le Portrait de Dorian Gray.		420     capital affectif		berkeley	5475
La possession n'est rien si la jouissance ne s'y joint.	Esope	Fables, 344, l"Avare		460     plaisir	VIe s. av. J.-C.	berkeley	2378
Dans les changements de fortune les gens les plus puissants ont besoin des faibles.	Esope	Fables, 206, le Lion et le Rat reconnaissant		510     ironie	VIe s. av. J.-C.	berkeley	2379
Dès qu'on approche un être humain, on touche à l'inconnu.	ESTAUNIE E.			234     communication		berkeley	2380
Un je ne sais quoi, qui surgit je ne sais d'où, vient je ne sais comment, et fait mal je ne sais pourquoi.  Um nao sei quê, que nasce nao sei onde,  Vem nao sei como, e doi nao sei porquê.	CAMOENS Luis Vaz de	Sonnets, 12		420     capital affectif	1524-1580. (Portugais)	berkeley	978
Il est d'étranges soirs où les fleurs ont une âme.	SAMAIN Albert	Au jardin de l"Infante.		140     rapport à la cosmogonie		berkeley	4948
Ne pas verser, pour ce qui est du langage, vin nouveau en vieilles outres.  No caben, en punto a lenguaje, vinos nuevos en viejos odres.	UNAMUNO Miguel de	Ensayos, III		234     communication	1864-1936. (Espagnol)	berkeley	5228
Le sentiment n'est qu'illusion ; seule l'illusion du sentiment est bien réelle.	FAIRGAGNETR Oscar		1990	430     paradoxal émotionnel	in lettre à Claire	berkeley	2583
Ce qui fait le succès de quantité d'ouvrages est le rapport qui se trouve entre la médiocrité des idées de l'auteur et la médiocrité des idées du public.	CHAMFORT Nicolas-Sébastien de	Maximes et pensées		510     ironie	1740/1794. Ac. Française	berkeley	1143
Il perçut avec une clarté aveuglante la nature de l'enfer : il a ceci de particulier que nous nous l'infligeons à nous-mêmes, de manière irréversible. Le repas qu'on a préparé brûle le gosier mais on l'avale. On boit la coupe du traître jusqu'au bout mais avant même de l'avoir reposée on découvre qu'elle déborde de bile et de vermine. Les mensonges qu'on a proférés sont gravés dans la pierre et demeurent suspendus au-dessus de notre tête en signe d'infamie.	WEST Morris	De main de Maître.	1992	433     perversion		berkeley	5427
Au contact de cet homme immense et flegmatique, sous son attitude impassible et impénétrable, je sentis que de Gaulle avait une surprenante sensibilité à la douleur. Et je pensais : 'Voil à le Connétable de France...'.	CHURCHILL Sir Winston Leonard Spencer	Mémoires.		550     grandeur		berkeley	1376
La réponse post-moderne au moderne consiste à reconnaitre que le passé, étant donné qu'il ne peut être détruit parce que sa destru- ction conduit au silence, doit être revisité : avec ironie, d'une façon non innocente. Je pense à l'attitude post-moderne comme à l'atti- tude de celui qui aimerait une femme très cultivée et qui saurait qu'il ne peut lui dire : 'Je t'aime désespérément' parcequ'il sait qu'elle sait (et elle sait qu'il sait) que ces phrases, Barbara Cartland les a déj à écrites. Pourtant, il y a une solution. Il pourra dire : 'Comme dirait Barbara Cartland, je t'aime désespérément.' Alors, en ayant évité la fausse innocence, en ayant dit clairement que l'on ne peut parler de façon innocente, celui-ci aura pourtant dit à cette femme ce qu'il voulait lui dire : qu'il l'aime et qu'il l'aime à une époque d'innocence perdue. Si la femme joue le jeu, elle aura reçu une déclaration d'amour. Aucun des deux interlocuteurs ne se sentira innocent, tous deux auront accepté le défi du passé, du déj à-dit que l'on ne peut éliminer, tous deux joueront consciemment et avec plaisir au jeu de l'ironie... mais tous deux auront réussi encore une fois à parler d'amour.	ECO Umberto	Apostille au nom de la rose.		530     ironie amoureuse		berkeley	2276
Devant l'innovation, la surdité et la lâcheté sont plutôt des constantes que des exceptions. Chacun de nous a rencontré l'hésitation et le renoncement devant ce qui rompait avec la tradition du milieu.	LEFRANC Pierre	Avec De Gaulle	1979	120     grégarité	2e édition en 1990	berkeley	4095
J'ai souvent mené en main, avec une bride d'or, de vieilles rosses de souvenirs qui ne pouvaient se tenir debout, et que je prenais pour de jeunes et fringantes espérances.	CHATEAUBRIAND François-René de	Mémoires d"outre-tombe		433     perversion	1768-1848.	berkeley	1304
Il n'est pas si dangereux de faire du mal à la plupart des hommes que de leur faire trop de bien.	LA ROCHEFOUCAULD François de	Maximes		510     ironie	1613-1680.	berkeley	3905
La poutre que l'on a dans l'oeil, n'empêche nullement de voir la paille qui est dans celui de son voisin: dans ce cas, la poutre devient une longue-vue, très longue, qui grossit la paille de façon démesurée.	SATIE Erik	Eloge des critiques		221     vanité	1866-1925.	berkeley	4961
Il n'est aucun problème humain qui ne puisse trouver sa solution, puisque cette solution est en nous. Mais la trouver, la dégager, l'appliquer exige un effort d'une intensité et d'une fécondité particulières, puisqu'il s'agit d'un effort de conscience.	SAUVY Alfred			370     esprit		berkeley	4964
Qui sait jusqu' à quel point l'homme pourrait perfectionner sa nature, soit au moral, soit au physique ? 	BUFFON Georges-Louis Leclerc de	Histoire Naturelle, Les Epoques De La Nature.		370     esprit	1707-1788. Discours sur le style, prononcé à l"Académie française, le jour de sa réception, le 25 août 1753.	berkeley	891
L'esprit humain n'a pas de bornes, il s'étend à mesure que l'univers se déploie.	BUFFON Georges-Louis Leclerc de	Histoire Naturelle, De L"homme.		370     esprit	1707-1788. Discours sur le style, prononcé à l"Académie française, le jour de sa réception, le 25 août 1753.	berkeley	893
La solitude ne dépend pas de l'extérieur ; C'est une chose du dedans.	ESTAUNIE E.			423     solitude		berkeley	2381
La bêtise insiste toujours.	CAMUS Albert	La Peste		221     vanité	1913-1960.	berkeley	991
Allez en paix, si vous en trouvez la force.	Dictons et Proverbes	Dicton		421     initiation		berkeley	2026
'Ta pathemata, mathemata.' Nos souffrances sont nos leçons.	Dictons et Proverbes	adage grec.		421     initiation	l"un des préférés du Connétable.	berkeley	2027
Qui me veut du mal, me fait blanchir ; Qui me veut du bien, me fait rougir.	Dictons et Proverbes	Dicton.		423     solitude		berkeley	2028
Terre qui nous a vu naître, nous te consacrons Notre amour et nos tâches pour les ans qui viendront.	KIPLING Rudyard	Hymne national (GB?)	1932	140     rapport à la cosmogonie		berkeley	3548
La débauche : une pauvre perversion de vitalité.	FAIRGAGNETR Oscar	Vitalités.	1992	240     débauche		berkeley	2529
Il eut l'orgueil de ne commander jamais, de ne disposer de rien ni de personne. Sans subalternes, sans maîtres, il ne donna des ordres ni n'en reçut. Soustrait à l'empire des lois, et comme antérieur au bien et au mal, il ne fit pâtir âme qui vive. Dans sa mémoire s'effaceront les noms des choses...	CIORANUS le DACE			330     coeur	philo. cité in Les Chevaliers du Crépuscule par Pierre COMBESCOT	berkeley	1398
D'un magistrat ignorant  C'est la robe qu'on salue.	LA FONTAINE Jean de	Fables, l"Ane portant des reliques		221     vanité	1621-1695.	berkeley	3671
On reconnait le goût d'un littérateur à l'importance de ses ratures.	JACOB Max	Art poétique.		393     création artistique	1876/1944	berkeley	3408
O pédérastes incompréhensibles, ce n'est pas moi qui lancerai des injures à votre grande dégradation.	LAUTRéAMONT Comte de	Les Chants de Maldoror		515     tragédie	1846-1870. (Isidore Ducasse)	berkeley	4053
Ne vous fiez pas à tout esprit, mais éprouvez les esprits pour voir s'ils sont de Dieu ; car beaucoup de faux prophètes se sont montrés de par le monde.	Nouveau Testament	Première Epître de Saint Jean (IV,1).		441     sang-froid		berkeley	4609
Las! où est maintenant ce mépris de fortune?  Où est ce coeur vainqueur de toute adversité ...? 	DU BELLAY Joachim	Les Regrets		520     ironie de soi	1522-1560.	berkeley	2164
Ma maison Poésie est ma seule demeure, Elle donne du ciel aux plus secrètes heures A mon jardin toujours renouvelé de vent.	SUPERVIELLE Jules	18 Poèmes.		460     plaisir		berkeley	5173
Je sais : je parle trop. Mais c'est que je suis heureux.	LENTERIC Bernard	La nuit des enfants rois.	1981	430     paradoxal émotionnel		berkeley	4110
Toute nation a le gouvernement qu'elle mérite.	MAISTRE Joseph de	Lettres et Opuscules inédits		539     ironie sociale	1753-1821.	berkeley	4188
Le crétin diffère moins de l'homme ordinaire que celui-ci ne diffère de l'homme de génie.	FLAUBERT Gustave	Carnets		365     discernement	1821-1880.	berkeley	2737
Les poètes mettent la lumière en même temps que la parole sur nos joies confuses et sur nos obscures douleurs ; ils nous disent ce que nous sentons vaguement ; ils sont la voix de nos âmes. C'est par eux que nous prenons une pleine conscience de nos voluptés et de nos angoisses.	FRANCE Anatole	La Vie littéraire.		393     création artistique		berkeley	2862
Le jour où vous cesserez de croire en la beauté, votre coeur mourra.	FAIRGAGNETR Oscar	Vitalités.	1992	330     coeur		berkeley	2539
Jamais Université ne décerna diplôme d'esprit.	PETIT Karl	Préface du Dictionnaire des citations2 du monde entier.	1977	510     ironie	510     iron\\010m8	berkeley	4692
La douceur, les bonnes paroles influenceront plus vite les gens que toute la colère et tout le tapage du monde.	ESOPE			234     communication		berkeley	2375
Vous avez soixante secondes pour imaginer deux histoires drôles. Vous avez soixante secondes pour imaginer deux nouveaux supplices. (...) Variante (pour ceux qui n'ont pas compris) : trois heures, et puis on compte le nombre de créations.	MORENO Roland	Théorie du Bordel Ambiant	1990	510     ironie	Inventeur de la carte à mémoire, vendue cash.	berkeley	4504
Nous attendons l'invasion promise de longue date. Les poissons aussi.  We are waiting for the long-promised invasion. So are the fishes.  	CHURCHILL Sir Winston Leonard Spencer			441     sang-froid	1874-1965.   Paroles prononcées par Winston Churchill au cours d"un message radiodiffusé adressé aux Français le 21 octobre 1940.	berkeley	1373
Vous êtes tout seul ? Eh bien, je vous reconnais tout seul !	CHURCHILL Sir Winston Leonard Spencer	Reconnaissance de la France Libre. 10 Downing Street le 27/06/40	1940	550     grandeur	 à de Gaulle dont il a reçu un mémorandum plaidant een ce sens.	berkeley	1375
La victoire aime l'effort.  Amat victoria curam.	Catulle	Poésies, 62		380     travail	v. 87-v.. 54. av. J.-C. (Caius Valerius Catullus)	berkeley	1058
Il est évidemment bien dur de ne plus être aimé quand on aime, mais cela n'est pas comparable à l'être encore quand on n'aime plus.	COURTELINE Georges	La Philosophie de G. Courteline		530     ironie amoureuse	1860-1929. (Georges Moinaux)	berkeley	1704
Le style est autant sous les mots que dans les mots.	FLAUBERT Gustave	Correspondance, 1842, à Ernest Feydeau, 1860		311     distinction	1821-1880.	berkeley	2726
L'éducation tout entière se réduit à ces deux enseignements: apprendre à supporter l'injustice et apprendre à souffrir l'ennui.  Tutta l'educazione si riduce a questi due insegnamenti: imparare a sopportare l'ingiustizia e imparare a soffrir la noia.	GALIANI Abbé	Lettere, 27 août 1774		120     grégarité	1728-1787. (Italien)	berkeley	2900
Fais ce que dois, advienne que pourra.	Dictons et Proverbes	Proverbe français.		510     ironie		berkeley	2051
Entreprenez l'impossible, l'impossible fera le reste.	CARLES François	Osiris ou Du fragment		440     courage		berkeley	1035
Miracle n'est pas oeuvre.	DUHAMEL Georges	Le Notaire du Havre		441     sang-froid	1884-1966.	berkeley	2211
Pour un homme intelligent, vous n'êtes pas si bête que ça.	BERNARD Tristan	Le Petit Café		510     ironie	1866-1947. (Paul Bernard)	berkeley	716
Dans tout le commerce de la guerre, il n'est pas d'exploit plus valeureux qu'une retraite courageuse.	BULTER Samuel	HUDIBRAS	1663	440     courage		berkeley	901
La vérité est comme la religion ; elle n'a que deux ennemis : le trop et le trop peu.	BULTER Samuel	Nouveaux voyages en Erewhon.		441     sang-froid		berkeley	902
L'habitude nous réconcilie avec tout.  Custom reconciles us to everything.	BURKE Edmund	On the Sublime and Beautiful, IV, 18		110     entropie	1729-1797. (Irlandais)	berkeley	904
Croyez en vous.	VINCENT Raymond	La Passion du succès.		440     courage		berkeley	5312
Les hommes de pensée préparent les hommes d'action. Ils ne les remplacent pas.	LE BON Gustave	Hier et Demain.		432     expérience		berkeley	4064
Les honneurs déshonorent ; le titre dégrade ; la fonction abrutit.	FLAUBERT Gustave	L"amour de l"art.	1915	221     vanité	1821/1880, édition posthume	berkeley	2716
Ariane, ma soeur, de quel amour blessée, Vous mourûtes aux bords où vous fûtes laissée !	RACINE Jean	Phèdre.		420     capital affectif		berkeley	4779
La plus méprisable des nations est aujourd'hui la nôtre, parce qu'elle n'a nulle espèce d'honneur et qu'elle ne songe qu' à l'argent et au repos.	BERNIS DE PIERRES François Joachim de	Lettre, au comte de Choiseul, 1758		240     débauche	1715-1794.	berkeley	723
Mais Degas, ce n'est pas avec des idées qu'on fait des vers, c'est avec des mots.	MALLARME Stéphane de			393     création artistique	rapporté par Paul VALERY dans Conférences (1939)	berkeley	4196
Vous savez, la guerre, c'est un peu comme le magicien qui incite les gens à regarder sa main droite pendant que la gauche fait tout le travail sérieux.	HIGGINS Jack	Opération Cornouailles.	1990	215     mystifications	\\010j&#237;ê\\020	berkeley	3181
Un proverbe sicilien affirme que 'la vengeance est une saison en enfer'. Je le sais, parce que j'y suis allé, et on en revient les mains vides.	HIGGINS Jack	Saison en enfer.	1989	221     vanité		berkeley	3182
Mes pensées, ce sont mes catins.	DIDEROT Denis	Le Neveu de Rameau		370     esprit	1713-1784.	berkeley	2096
N'apprend qu'avec réserve.	MICHAUX Henri	\\010ZZ†\\020		421     initiation		berkeley	4277
Il est parfois bon d'avoir un grain de folie.  Aliquando et insanire jucundum est.	Sénèque	De la tranquillité de l"âme, 17		312     foi		berkeley	5014
[...] l'acte de perception n'est pas suffisant pour coder un message et [...] il faut toujours y ajouter un travail d'évocation mentale.	LA GARANDERIE Antoine de la			421     initiation	entretien avec Patrick Tapernoux, Inter-CDI 135, mai-juin 95	berkeley	3768
On voit bien encore aux tessons ce que fut le pot.	LA HALLE Adam de	Le Jeu de la feuillée		110     entropie	v. 1240-v. 1285. (ou Adam le Bossu)	berkeley	3769
Quel est le partage d'un serviteur du monde ? Un immense ennui parsemé de quelques rares plaisirs.	DE GAULLE Charles	Carnet inédit.	1916	510     ironie		berkeley	1854
Tout usage finit par se changer en abus.	DUTOURD Jean	Le Fond et la forme		110     entropie	1920-.	berkeley	2242
La guerre ! C'est une chose trop grave pour la confier à des militaires.	CLEMENCEAU Georges			211     guerre	cité dans le "Clémenceau" de Georges SUARES	berkeley	1481
Le malheureux, chose sacrée.  Res est sacra, miser.	Sénèque	Epigrammes, 4		515     tragédie		berkeley	5015
L'esprit de parti abaisse les plus grands hommes jusques aux petitesses du peuple.	LA BRUYERE Jean de	Les Caractères		120     grégarité	1645-1696.	berkeley	3593
Le bien, nous le faisons; le mal, c'est la Fortune;  On a toujours raison, le Destin toujours tort.	LA FONTAINE Jean de	Fables, l"Ingratitude et l"Injustice des hommes envers la Fortune		221     vanité	1621-1695.	berkeley	3664
Les épines que j'ai recueillies viennent de l'arbre que j'ai planté.  The thorns which I have reaped are of the tree I planted.	BYRON George Gordon lord	Childe Harold"s Pilgrimage, IV, 10		520     ironie de soi	1788-1824. (Anglais)	berkeley	945
On ne se méfie jamais assez des mots.	CéLINE L.-F.	Voyage au bout de la nuit		110     entropie	1894-1961. (Louis-Ferdinand Destouches)	berkeley	1068
La place de l'homme dans la vie est marquée non par ce qu'il sait, mais par ce qu'il veut et ce qu'il peut.	LE BON Gustave	Hier et Demain		441     sang-froid		berkeley	4067
Je méprise profondément ceux qui aiment marcher en rangs sur une musique: ce ne peut être que par erreur qu'ils ont reçu un cerveau; une moelle épinière leur suffirait amplement.  Wenn einer mit Vergnügen in Reih und Glied zu einer Musik marschieren kann, den verachte ich schon; er hat sein großes Gehirn nur aus Irrtum bekommen, da für ihn das Rückenmark schon völlig genügen würde.	EINSTEIN Albert	Comment je vois le monde		120     grégarité	1879-1955. (Allemand, naturalisé Américain)	berkeley	2289
Si le vin de toi n'est aimé,  Visiteur retourne en arrière :  Le Pont de Bordeaux t'est fermé.	BERRY André	Les Esprits de Garonne		460     plaisir	1902-1986.	berkeley	730
Seuls les mensonges nous tuent et seule la vérité nous fait vivre.	WEST Morris	Le Loup Rouge.	1971	546     éthique		berkeley	5457
La guerre est un acte de violence destiné à contraindre l'adversaire à exécuter notre volonté.	CLAUSEWITZ	De la Guerre.	1812	211     guerre		berkeley	1471
La moralité de l'absurde, c'est la raison.	DEVOS Raymond		1992	510     ironie	in La Marche du Siècle de JM Cavada FR3	berkeley	1972
Mon garçon, je viens à peine de regarder par-dessus le mur. Je n'ai plus peur de traverser. J'ai appris quelque chose. La seule chose qui rende la vie supportable de ce côté est l'amour que l'on rencontre le long du chemin.	WEST Morris	Le Loup Rouge.	1971	420     capital affectif	\\010uiÄ\\020	berkeley	5404
La pudeur sied bien à tout le monde; mais il faut savoir la vaincre et jamais la perdre.	MONTESQUIEU Charles de	Mes pensées		430     paradoxal émotionnel	1689-1755. (C. de Secondat, baron de La Brède et de M.)	berkeley	4442
Pour parvenir à la science, il faut nécéssairement traverser l'empirisme et ne pas y croupir, sous prétexte qu'on a des lois empiriques qui suffisent. L'empirisme, quand on y reste, arrête la science et abrutit l'esprit. Nous avons vu, en effet, que le premier principe de l'empirisme, c'est de supprimer l'intervention de l'idée. [...] Ce que nous voulons, c'est un rationalisme soumis à l'expérience qui lui servira toujours de critérium et de flambeau. [...] Le savant complet est celui qui embrasse à la fois la théorie et la pratique expérimentale. 1) Il constate un fait ; 2) à propos de ce fait, une idée naît dans son esprit ; 3) en vue de cette > idée, il raisonne, institue une expérience, en imagine et en réalise les conditions matérielles ; 4) de cette expérience résultent de nouveaux phénomènes qu'il faut observer, et ainsi de suite. L'esprit du savant se trouve en quelque sorte toujours placé entre deux observations : celle qui sert de point de départ au raisonnement, et l'autre qui lui sert de conclusion.	BERNARD Claude	Principes de la médecine expérimentale, Ch. VIII.		390     création		berkeley	702
J'ai observé que le métier le plus naturel à l'homme est celui de soldat ; c'est celui auquel il est porté le plus facilement par ses instincts et par ses goûts, qui ne sont pas la fin de l'espèce.	FRANCE Anatole	Les opinions de Monsieur Jérôme Coignard.		211     guerre	Les opinions de Monsieur Jérôme Coignard.	berkeley	2854
Ainsi la paresse est mère.  Elle a un fils, le vol, et une fille, la faim.	HUGO Victor	Les Misérables		110     entropie	1802-1885.	berkeley	3274
L'eau qui ne court pas fait un marais, l'esprit qui ne travaille pas fait un sot.	HUGO Victor	Tas de pierres.		110     entropie		berkeley	3275
Aujourd'hui, la vie va si vite que la conscience ne peut pas suivre.	FLERS Robert de	La Belle Aventure		515     tragédie	1872-1927. (et Gaston Arman de Caillavet)	berkeley	2797
Fermer les yeux devant le danger, c'est se donner en proie et renoncer à son libre-arbitre.	MEREDITH George	Les comédiens tragiques.		440     courage	1828/1909	berkeley	4271
La moindre blessure laisse une cicatrice dans les tissus. Le moindre choc laisse une strie dans la mémoire.	WEST Morris	La seconde victoire.	1972	420     capital affectif		berkeley	5405
Dans une association entre deux hommes, il y en a toujours un qui porte l'autre...	DE GAULLE Charles		1922	120     grégarité		berkeley	1787
Si nous n'avions point de défauts, nous ne prendrions pas tant de plaisir à en remarquer dans les autres.	LA ROCHEFOUCAULD François de	Maximes		221     vanité	1613-1680.	berkeley	3810
Rien n'empêche tant d'être naturel que l'envie de le paraître.	LA ROCHEFOUCAULD François de	Maximes		221     vanité	1613-1680.	berkeley	3812
Que chacun se persuade que ceux qui vivent dans l'obéissance doivent se laisser conduire aux ordres de la Providence divine par le moyen de leurs Supérieurs, comme s'ils étaient un corps mort qui se laisse porter de tous côtés et manier de la façon que l'on veut.  Quisque sibi persuadeat, quod qui sub obedientia vivunt, se ferri ac regi a Divina providentia per Superiores suos sinere debent perinde ac si cadaver essent, quod quoquoversus ferri, et quacumque ratione tractari se sinit.  Constitutions  	St. Ignace de Loyola			215     mystifications	1491-1556. On reconnaît une autre devise des Jésuites: "Perinde ac cadaver": comme un cadavre.	berkeley	5109
( ) tâcher plutôt à me vaincre que la fortune, et à changer mes désirs plutôt que l'ordre du monde.	DESCARTES René	Discours de la méthode.	1637	441     sang-froid	(1596/1650)	berkeley	1948
Vous pouvez faire tenir un idiot sur le trône pendant un demi-siècle à condition que personne ne l'entende parler, ne le voie manger, ou ne sache ce qu'il fait au lit.	WEST Morris	Kaloni le navigateur	1976	215     mystifications		berkeley	5361
L'accent du pays où l'on est né demeure dans l'esprit et dans le coeur.	LA ROCHEFOUCAULD François de	Maximes.		420     capital affectif		berkeley	3865
Il y a une éloquence dans les yeux et dans l'air de la personne qui ne persuadent pas moins que celle de la parole.	LA ROCHEFOUCAULD François de	Maximes		420     capital affectif		berkeley	3866
Jamais par tes leçons du méchant tu ne feras un homme de bien.	THEOGNIS			221     vanité	(Théognis)	berkeley	5198
Les institutions s'effondrent quand elles cessent d'être accordées avec les nécéssités de l'époque... Alors sans doute la force les balaie... mais la composition des troupes a peu d'importance en l'espèce. C'est une affaire de commandement général.	DE GAULLE Charles		1933	238     servitudes du pouvoir politique		berkeley	1808
Ah ! Frappe-toi le coeur, C'est l à qu'est le génie.	MUSSET Alfred de			330     coeur		berkeley	4528
Il faut que quelqu'un nous aime assez pour que nous puissions nous aimer un peu.	WEST Morris	Le Loup Rouge.	1971	420     capital affectif		berkeley	5406
Si vous franchissez une crête, vous devez apprendre un nouveau langage.	WEST Morris	La seconde victoire.	1972	421     initiation		berkeley	5407
Le respect de soi, le respect d'autrui n'appartiennent qu' à ceux qui montrent de la foi. Le reste suit.	FAIRGAGNETR Oscar	Vitalités.	1992	320     intuition		berkeley	2536
Pour avoir, dans un élan de jeunesse, su aller trop loin sur la voie de la volonté, je connaîs maintenant ce qu'il en faut sans exagération.	FAIRGAGNETR Oscar	Vitalités.	1994	321     volonté		berkeley	2537
... ô amour rempli de larmes  parce que le plus proche est à jamais lointain !  ... ô Lieb voll Tränen,  Weil sich unendlich Nahes ewig fern ! 	BRENTANO Clemens	Le Rêve du désert		530     ironie amoureuse	1778-1842. (Allemand)	berkeley	842
Je n'étais rien au départ... Mais ce dénuement même me traçait ma ligne de conduite. C'est en épousant sans ménager rien, la cause du salut national, que je pouvais trouver l'autorité. C'est en agissant comme champion inflexible de la nation et de l'Etat qu'il me serait possible de grouper, parmi les Français, les consentements, voire les enthousiasmes, et d'obtenir des étrangers respect et considé- ration. Les gens, qui tout au long du drame, s'offusquèrent de cette intransigeance ne voulurent pas voir que,pour moi, tendu à refouler d'innombrables pressions contraires, le moindre fléchissement eût entraîné l'effondrement. Bref, tout limité et solitaire que je fusse, et justement parce que je l'étais, il me fallait gagner les sommets et n'en descendre jamais plus.	DE GAULLE Charles	Mémoires de guerre.		321     volonté		berkeley	1814
Il faut souvent donner à la sagesse l'air de la folie, afin de lui procurer ses entrées.	DIDEROT Denis	Lettres		234     communication	1713-1784.	berkeley	2089
La bonne stratégie de l'erreur vaut mieux que certains succès. L'art du jeu des échecs nous l'enseigne, qui consiste à tirer avantage de ses propres fautes. Elles déroutent l'adversaire plus qu'elles ne nous égarent.	MITTERAND François	L"Abeille et l"Architecte.		225     cynisme		berkeley	4291
La vertu dans le monde est toujours poursuivie. Les envieux mourront, mais non jamais l'envie.	MOLIERE	Le Tartufe.		120     grégarité		berkeley	4294
Je voyais donc l'imagination à sa naissance, l'imagination qui n'est que naissance, car elle n'est que le premier état de toutes nos idées. C'est pourquoi tous les dieux sont au passé.	CHARTIER Emile	Histoire De Mes Pensées.		350     imagination	alias Alain (1868-1951)	berkeley	1227
Nous ne sommes pas dans la vie pour être heureux, mais nous devons tacher de mériter le bonheur.	ERCKMANN-CHATRIAN Alexandre	L"ami Fritz.		440     courage		berkeley	2368
La grandeur de l'homme est dans sa décision d'être plus fort que sa condition.	CAMUS Albert	Chroniques		321     volonté	1913-1960.	berkeley	996
Il y a seulement de la malchance à n'être pas aimé: il y a du malheur à ne point aimer.	CAMUS Albert	L"Eté		330     coeur	1913-1960.	berkeley	998
Peu d'êtres sont capables d'exprimer posément une opinion différente des préjugés de leur milieu.	EINSTEIN Albert	Comment je vois le Monde	1934	120     grégarité	rééd.corr. en 1952 et 1978.	berkeley	2288
Telle est la vocation de l'homme: se délivrer de sa cécité.	ERNST Max	Ecritures		130     liberté	1891-1976.	berkeley	2369
... A la guerre, la chance des généraux, c'est l'honneur des gouvernements.	DE GAULLE Charles	Mémoires de guerre.		211     guerre		berkeley	1797
L'analogie des contraires, c'est le rapport de la lumière à l'ombre, de la saillie au creux, du plein au vide. L'allégorie, mère de tous les dogmes, est la substitution des empreintes aux cachets, des ombres aux réalités. C'est le mensonge de la vérité et la vérité du mensonge.	LEVI Eliphas	Dogme De La Haute Magie.	1856	430     paradoxal émotionnel	XXII/22.	berkeley	4119
La critique est un impôt que l'envie perçoit sur le mérite.	LéVIS Duc de	Maximes et réflexions sur divers sujets		221     vanité	1764-1830.	berkeley	4121
Sire, ce n'est pas tout d'être roi de France... Le roi sans la vertu porte le sceptre en vain.	RONSARD			110     entropie		berkeley	4847
Raisonner. Peser des probabilités sur la balance du désir.  To reason. To weigh probabilities in the scales of desire.	BIERCE Ambrose	The Devil"s Dictionary		431     désir	1842-1914. (Américain)	berkeley	740
La chasse au con est un safari sans espoir.	DARD Frédéric			510     ironie	cité par Antoine de Caunes dans les Nuls (Canal+ le 18/01/93).	berkeley	1761
Les médecins les plus dangereux sont ceux qui, comédiens nés, imitent le médecin né avec un art consommé d'illusion.	NIETZSCHE Friedrich	Humain, trop humain.		222     fourberie		berkeley	4586
Que dit la conscience ? Tu dois devenir l'homme que tu es.	NIETZSCHE Friedrich	Le Gai Savoir.		421     initiation		berkeley	4590
Si l'on croyait en l'humaine bonté, on ne pouvait pas en réfréner sans cesse les élans chez autrui ; car, ce faisant, on lésait les deux parties en cause. Pourquoi se refuserait-il un réconfort qui apportait autant de plaisir au donateur qu' à lui-même ?	WEST Morris	La seconde victoire.	1972	423     solitude		berkeley	5414
Il n'y a pas d'amour de vivre sans désespoir de vivre.	CAMUS Albert	L"Envers et l"endroit		430     paradoxal émotionnel	1913-1960.	berkeley	1007
La vérité, comme la lumière, aveugle. Le mensonge, au contraire, est un beau crépuscule qui met chaque objet en valeur.	CAMUS Albert	La Chute		433     perversion	1913-1960.	berkeley	1008
La force et la duperie sont les deux vertus cardinales de la guerre.	HOBBES Thomas	Léviathan	1651	211     guerre	philosophe, politologue	berkeley	3197
Je peux est le fils de je suis.	KRAMER Edward L.	Chemins vers la puissance.		230     pouvoir		berkeley	3574
Les princes me donnent prou* s'ils ne m'ôtent rien, et me font assez de bien quand ils ne me font point de mal; c'est tout ce que j'en demande.	MONTAIGNE Michel Eyquem de	Essais, III, 9 		130     liberté	1533-1592.  *Beaucoup.	berkeley	4309
La vie n'est qu'un rire sur les lèvres de la mort.	Dictons et Proverbes	Aphorisme.		510     ironie		berkeley	2049
Celui qui connait l'art de vivre avec lui-même ignore l'ennui.	ERASME Didier	Colloques		421     initiation	v. 1469-1536	berkeley	2366
Les partisans se levaient au son rauque du tambour;	COMBESCOT Pierre	Les Chevaliers du Crépuscule.		120     grégarité	é	berkeley	1574
Il vient toujours un moment où il faut savoir jouer au père Noël.	LAGERSFELD Karl		1991	330     coeur	pour paraphraser... Interview sur France-Inter un samedi A.M.	berkeley	3987
Heureux qui a quelque chose à donner, car à celui qui n'a pas, on ôtera même ce qu'il a.	CLAUDEL Paul	L"Otage, I, 1, Sygne		515     tragédie	1868-1955.	berkeley	1462
Ce n'est point le temps qui manque, c'est nous qui lui manquons.	CLAUDEL Paul	Partage de midi, I, Mesa		520     ironie de soi	1868-1955.	berkeley	1464
Un grand peuple sans âme est une vaste foule! 	LAMARTINE Alphonse de	Premières Méditations poétiques, Ressouvenir du lac Léman		120     grégarité	1790-1869.	berkeley	3991
Le parler que j'aime, c'est un parler simple et naïf, tel sur le papier qu' à la bouche, un parler succulent et nerveux, court et serré, non tant délicat et peigné comme véhément et brusque.	MONTAIGNE Michel Eyquem de	Essais, I, 26		234     communication	1533-1592.	berkeley	4332
Une belle âme ne va guère avec un goût faux.	DIDEROT Denis	Lettres		370     esprit	1713-1784.	berkeley	2097
L'incrédulité est quelquefois le vice d'un sot, et la crédulité le défaut d'un homme d'esprit.	DIDEROT Denis	Pensées philosophiques		370     esprit		berkeley	2098
Si j'avais le pouvoir d'oublier, j'oublierais. Toute mémoire humaine est chargée de chagrins et de troubles.	DICKENS Charles	Contes de Noël.		540     mémoire		berkeley	1980
Italie! Italie! ah! pleure tes collines,  Où l'histoire du monde est écrite en ruines! 	LAMARTINE Alphonse de	Harmonies poétiques et religieuses		221     vanité	1790-1869.	berkeley	3993
L'Etre fondamental n'a aucun autre besoin que celui de s'assumer. Le reste suit. L'oublier, c'est plonger dans la vanité et la perversion jusqu' à l'entropie.	FAIRGAGNETR Oscar	Vitalités.	1993	433     perversion		berkeley	2593
Si tu entends éviter les déconvenues inutiles, évite de prendre les amis du succès pour les tiens propres.	FAIRGAGNETR Oscar		1992	120     grégarité		berkeley	2479
(intéressante métaphore  des trois vagues de travailleurs  successivement chargés d'activer, d'investir et de policer un marché, de sa naissance à sa mort : les commandos, l'infanterie et les gendarmes)	CRINGELY Robert X.	Batisseurs d"empires par accident	1992	392     création économique		berkeley	1720
Rien de grand n'a jamais pu être réalisé sans enthousiasme.	EMERSON Ralph Waldo	Cercles.		312     foi		berkeley	2340
Qui l'emportera de l'artiste qui vit avec les pensées de la nuit ou de l'homme qui se satisfait des pensées du jour ?	FAIRGAGNETR Oscar		1992	510     ironie		berkeley	2616
Le vulgaire, les soldats et les artistes se partagent le monde.	FAIRGAGNETR Oscar	Aphorismes.	1992	510     ironie		berkeley	2619
Dans la dyslexie, ce qu'on observe, c'est une organisation défectueuse. Non pas une organisation cérébrale défectueuse ou une organisation psychologique ou encore psychomotrice défectueuse, mais une organisation défectueuse du langage (où il y a du cérébral, du psychologique, etc...). [...] C'est donc du langage en tant que système organisé qu'on s'occupera pour essayer de comprendre en quoi cette organisation a pu se faire de façon défectueuse.	LAMBRICHS Louise L.	La Dyslexie en question.	1989	410     santé		berkeley	4020
La sincérité toujours surmonte les obstacles.	VERCORS. Jean BRULAIRE	Le Silence et la Mer		330     coeur	résistant et fondateur des Editions de Minuit	berkeley	5273
La vitalité n'est que la transgession d'une entropie inférieure par une entropie supérieure. La grandeur n'est qu'une vitalité qui surajoute aux moyens d'action de l'entropie supérieure une harmonisation entre la foi et le plaisir.	FAIRGAGNETR Oscar	Vitalités.	1992	550     grandeur		berkeley	2649
Un homme amoureux est un homme qui veut être plus aimable qu'il ne peut; et voil à pourquoi tous les amoureux sont ridicules.	CHAMFORT Nicolas-Sébastien de	Maximes et pensées		530     ironie amoureuse	1740/1794. Ac. Française	berkeley	1149
Marcher lentement lors des processions pour ne pas que le saint tombe.	Dictons et Proverbes	Proverbe paysan brésilien		215     mystifications		berkeley	1997
Politesse. Forme la plus acceptable de l'hypocrisie.  Politeness. The most acceptable hypocrisy.	BIERCE Ambrose	The Devil"s Dictionary		510     ironie	1842-1914. (Américain)	berkeley	742
Pour assurer sa survie morale, chacun doit croire en quelque chose de supérieur.	FAIRGAGNETR Oscar	Vitalités.		422     confiance en soi		berkeley	2576
Croire qu'il est toujours mieux de bien faire, tenir en respect ceux qui ne le croient pas,... voil à la vie !	FAIRGAGNETR Oscar	Vitalités.		422     confiance en soi		berkeley	2577
Rompre l'os et suçer la substantifique moëlle.	RABELAIS François	GARGANTUA	1534	421     initiation	1494/1553	berkeley	4754
Cette autre vie qu'est cette vie dès qu'on se soucie de son âme.	CHARTIER Emile	Histoire De Mes Pensées.		370     esprit	alias Alain (1868-1951)	berkeley	1236
La paresse est nécessaire. Il faut la mêler à sa vie pour prendre conscience de la vie.	CHARDONNE Jacques	L"Amour, c"est beaucoup plus que l"amour		432     expérience	1884-1968.	berkeley	1195
Les êtres ont la mobilité et l'éphémère durée des vagues; seules, les choses qui leur ont servi de témoins sont comme la mer et demeurent immuables.	ESTAUNIé Edouard	Les choses voient		520     ironie de soi	1862-1942.	berkeley	2383
Tiens vis- à-vis des autres ce que tu t'es promis à toi seul.	CHAR René	Feuillets d"Hypnos		441     sang-froid	1907-1988.	berkeley	1180
La création est l'instant qui arrête le temps.	FAIRGAGNETR Oscar	Vitalités.	1993	390     création		berkeley	2559
Je vis sur le fonds de frivolité qui vient au secours des existences longues.	COLETTE Sidonie Gabrielle	L"Etoile Vesper		520     ironie de soi	1873-1954.	berkeley	1567
Aimez qu'on vous conseille et non pas qu'on vous loue.	BOILEAU Nicolas			550     grandeur		berkeley	786
L'avenir, fantôme aux mains vides,  Qui promet tout et qui n'a rien! 	HUGO Victor	Les Voix intérieures, Sunt lacrymae rerum		441     sang-froid	1802-1885.	berkeley	3334
Ne laisse personne choisir tes boucs émissaires.	MICHAUX Henri	Poteaux D"angle.		440     courage		berkeley	4279
Le dévouement au bien commun, voil à ce qui est nécéssaire, puisque le moment est venu de rebâtir. Et justement pour vous, jeunesse libanaise, ce grand devoir prend un sens immédiat, car c'est une patrie que vous avez à faire. Sur ce sol merveilleux et pétri d'histoire, appuyés au rempart de vos montagnes, liés par la mer aux activités de l'Occident, aidés par la sagesse et par la force de la France, il vous appartient de construire un Etat. Non point seulement d'en partager les fonctions, d'en exercer les attributs, mais bien de lui donner cette vie propre, cette force intérieure, sans lesquelles il n'y a que des institutions vides. Il vous faudra créer et nourrir un esprit public, c'est- à-dire la subordination volontaire de chacun à l'intérêt général, condition sine qua non de l'autorité des gouvernants, de la vraie justice dans les prétoires, de l'ordre dans les rues, de la conscience des fonctionnaires. Point d'Etat sans sacrifices : d'ailleurs, c'est bien de sacrifices qu'est sorti celui du Liban... ... Oui, la jeunesse libanaise qui demain sortira d'ici sera bien préparée à sa tâche nationale. Marchant sur les traces de ses aînés, parmi lesquels nous saluerons avant tout le président de la République libanaise, résolue à la discipline et au désintéressement, liée à la France par toutes les voies de l'esprit et du coeur, cette élite sera le ferment d'un peuple chargé dorénavant, des lourds devoirs de la liberté.	DE GAULLE Charles		1931	550     grandeur	Allocution de remise de prix. Université St. Joseph - Beyrouth	berkeley	1859
Peuple caméléon, peuple singe du maître.	LA FONTAINE Jean de	Fables, les Obsèques de la Lionne		120     grégarité	1621-1695.	berkeley	3646
Ne faut-il que délibérer? La cour en conseillers foisonne:  Est-il besoin d'exécuter?  L'on ne rencontre plus personne.	LA FONTAINE Jean de	Fables		120     grégarité	1621-1695.	berkeley	3647
La politesse n'est pas une vertu, et ne saurait tenir lieu d'aucune. [...] La politesse est une petite chose, qui en prépare de grandes. C'est un rituel, mais sans Dieu ; un cérémonial, mais sans culte ; une étiquette, mais sans monarque. Forme vide, mais qui ne vaut que par ce vide même. [...] La politesse ne suffit pas, et il est impoli d'être suffisant.	COMTE-SPONVILLE André	Petit Traité des Grandes Vertus, La Politesse	1995	546     éthique		berkeley	1586
Il s'est trouvé des filles qui avaient de la vertu, de la santé, de la ferveur et une bonne vocation, mais qui n'étaient pas assez riches pour faire dans une riche abbaye voeu de pauvreté 	LA BRUYERE Jean de	Les Caractères		215     mystifications	1645-1696.	berkeley	3598
Le plaisir le plus délicat est de faire celui d'autrui.	LA BRUYERE Jean de	Les Caractères		330     coeur	1645-1696	berkeley	3609
Les meilleurs divertissements sont les plus futiles.	CHARDONNE Jacques	Propos comme ça		460     plaisir	1884-1968.	berkeley	1200
Patience. Forme mineure de désespoir, déguisée en vertu.  Patience. A minor form of despair, disguised as a virtue.	BIERCE Ambrose	The Devil"s Dictionary		510     ironie	1842-1914. (Américain)	berkeley	743
Vous aimez les livres ? Vous voici heureux pour la vie.	CLARETIE Jules			341     étonnement		berkeley	1437
C'était un méchant tour, dit Haroun le visir. Montre-m'en un qui soit honnête.	SMULLYAN Raymond			222     fourberie		berkeley	5089
Bois à mon souvenir et puis casse le verre.	WEST Morris	De main de Maître.	1988	540     mémoire		berkeley	5456
N'exige rien que de toi-même ou tu sera toujours déçu.	FAIRGAGNETR Oscar	Vitalités.	1993	441     sang-froid		berkeley	2607
C'est des hommes et d'eux seulement qu'il faut avoir peur, toujours.	CéLINE L.-F.	Voyage au bout de la nuit		442     démission	1894-1961. (Louis-Ferdinand Destouches)	berkeley	1081
Ah! mon ami, je m'en vais enfin de ce monde, où il faut que le coeur se brise ou se bronze.	CHAMFORT Nicolas-Sébastien de			110     entropie	1740/1794. Ac. Française	berkeley	1104
Les succès produisent les succès, comme l'argent produit l'argent.	CHAMFORT Nicolas-Sébastien de	Maximes et pensées		140     rapport à la cosmogonie	1740/1794. Ac. Française	berkeley	1108
...j'ai eu sous les yeux le spectacle de la trahison et, dans le coeur, le refus dégoûté de lui reconnaître la victoire... Voil à tout.	DE GAULLE Charles		1940	430     paradoxal émotionnel		berkeley	1834
Le prix d'Amour, c'est seulement Amour, ...  Il faut aimer si l'on veut être aimé.	URFé Honoré d"	La Sylvanire ou la Morte vive, I, 1		531     communication amoureuse	1567-1625.	berkeley	5233
Tout le progrès de l'homme, toute l'histoire des sciences est l'histoire de la lutte de la raison contre le sacré.	VAILLAND Roger	Le Surréalisme et la Révolution.		440     courage		berkeley	5234
La connaissance vient mais la sagesse traîne.	TENNYSON	Locksley Hall.		520     ironie de soi		berkeley	5196
Ce que nous appelons le hasard ne peut être que la cause ignorée d'un effet connu.	VOLTAIRE			370     esprit		berkeley	5329
La Provence n'est qu'une gueuse parfumée.	BROSSES Président de	Voyage En Italie  		120     grégarité	1709-1777. De Brosses reprend l"expression même de Godeau :	berkeley	870
Sois familier, mais aucunement vulgaire.	SHAKESPEARE William	Hamlet.		234     communication		berkeley	5048
Les seuls traités qui valent d'être signés sont ceux entre des arrières-pensées.	VALERY Paul			234     communication	cité par Claude Guillaumain le 10/09/93 dans sa revue de presse de 8 h 30 sur France-Inter.	berkeley	5236
On verra, sans doute, se développer les entreprises de peu d'hommes choisis, agissant par équipes, produisant en quelques instants, à une heure, dans un lieu prévu, des évènements écrasants.	VALERY Paul	oute		390     création	épigraphe à l"un des chapitres de l"Armée de Métier de Ch. de G.	berkeley	5240
La vie est faite de marbre et de boue.  Life is made up of marble and mud.	HAWTHORNE Nathaniel	The House of the Seven Gables, 2		441     sang-froid	1804-1864. (Américain)	berkeley	3088
Il est agréable d'oublier la sagesse à propos.  Dulce est desipere in loco.	Horace	Odes, IV, XII, 28		460     plaisir	65-8 av. J.-C. (Quintus Horatius Flaccus)	berkeley	3260
Et ne vois-tu pas que changer sans cesse  Nous rend doux et chers les plaisirs passés? 	MUSSET Alfred de	Premières Poésies, Chanson		540     mémoire	1810-1857.	berkeley	4551
Il avait raison celui qui a dit que l'agriculture est la mère et la nourrice des autres arts.	Xénophon	Economique, V, 17		392     création économique	v. 430-v. 355 av. J.-C.	berkeley	5502
Toute tête est un entrepôt, où dorment des statues de dieux et de démons de toute taille et de tout âge, dont l'inventaire n'est jamais dressé.	BUTOR Michel	Passage de Milan		520     ironie de soi	1926-.	berkeley	936
Monsieur Churchill et moi-même tombâmes modestement d'accord [sur] cette conclusion banale mais définitive: en fin de compte, l'Angleterre est une île ; la France le cap d'un continent ; l'Amérique, un autre monde.	DE GAULLE Charles.	Mémoires de guerre,1.		510     ironie		berkeley	1862
Charles est très intelligent, mais il n'a aucun bon sens...	DE GAULLE Henri		1901	370     esprit	se confiant parfois à ses intimes. (rapport. par Jean Lacouture)	berkeley	1863
L'art est le plus beau des mensonges.	DEBUSSY Claude	Monsieur Croche, antidilettante		393     création artistique	1862-1918.	berkeley	1869
On parle peu quand la vanité ne fait pas parler.	LA ROCHEFOUCAULD François de	Maximes		221     vanité	1613-1680.	berkeley	3823
La République des camarades.  	JOUVENEL Robert de			120     grégarité	1881-1924.   Titre d"un ouvrage que Robert de Jouvenel publia en 1914. Ce journaliste y critique l"influence de la "camaraderie" sur la vie politique de la IIIe République.	berkeley	3498
La mémoire est souvent la qualité de la sottise.	CHATEAUBRIAND François-René de	Mémoires d"outre-tombe		540     mémoire	1768-1848.	berkeley	1314
Pas trop de citations2 d'anglais, d'italien, d'espagnol. Tu as l'air d'un larbin d'hôtel qui colle des étiquettes sur des bagages.	FARGUE Léon-Paul			221     vanité		berkeley	2654
La qualité, c'est de la quantité assimilée.	FARGUE Léon-Paul	Sous la lampe		390     création	1876-1947.	berkeley	2656
Tel fleurit aujourd'hui qui demain flétrira,  Tel flétrit aujourd'hui qui demain fleurira.	RONSARD Pierre de	Le Second Livre des poèmes		441     sang-froid	1524-1585.	berkeley	4856
J'ai fini par acquérir durablement le sentiment de l'éphémère.	ROSTAND Jean	Carnets d"un biologiste.		432     expérience	ce	berkeley	4870
Il ne suffit pas d'avoir de l'esprit. Il faut en avoir encore assez pour s'abstenir d'en avoir trop.	MAUROIS André	De La Conversation.		370     esprit	Emile Herzog, dit André Maurois	berkeley	4262
Comment pouvez-vous prétendre vendre ou acheter le ciel, la chaleur de la terre ? Pour nous, cette idée est absurde... la fraicheur de l'air et le scintillement de l'eau n'appartiennent à personne. Comment pourrions-nous les acheter ?... La moindre aiguille de pin, la moindre grève sablonneuse, la moindre brume dans les sous-bois obscurs, chaque insecte qui bourdonne, est sacré à nos yeux, dans la mémoire et la tradition de mon peuple. La sève qui coule dans les arbres porte la mémoire de l'homme rouge... Les morts de l'homme blanc oublient leur terre natale lorsqu'ils partent pour le grand voyage dans les étoiles. Nos morts à nous n'oublient jamais cette Terre de beauté, car elle est la mère de l'homme rouge. Nous faisons partie de la terre comme elle fait partie de nous... Les fleurs parfumées sont nos sïurs. Le cerf, le cheval, l'aigle royal sont nos frères. Les crêtes rocailleuses, la rosée des prés, la chaleur du corps du poney et l'homme lui-même, tous appartiennent à la même famille... Nous savons que l'homme blanc ne comprend pas notre vision des choses. Pour lui, toutes les parcelles de terre se ressemblent, car il est comme un étranger qui vient, au coeur de la nuit, voler à la Terre ce dont il a besoin. La Terre n'est pas sa sïur mais son ennemie. Une fois conquise, il la délaisse pour aller plus loin. Indifférent, il prive ses enfants de leur terre. Il oublie la tombe de son père et l'héritage naturel de ses enfants... Sa voracité lui fera dévorer la Terre et il ne laissera derrière lui qu'un désert... Le destin de la Terre, c'est le destin de l'homme. Ce n'est pas l'homme qui a tissé la toile de la vie, il n'en est lui-même qu'un simple fil. tout ce qu'il fait à cette toile, c'est à lui-même qu'il le fait. Et même l'homme blanc qui chemine et converse avec son Dieu en ami ne peut échapper à ce destin.	SEATTLE		1854	140     rapport à la cosmogonie	Extrait d"une lettre (citée dans "The Faber Book of Letters" Londres 1988) attribuée à Seattle, indien d"Amérique du Nord, chef des Dwamish, des Suquamish et d"autres tribus alliées, et qui aurait été écrite en 1854 avec l"aide, dit-on, d"un écrivain public et adressée au président des Etats-Unis, Franklin Pierce, qui voulait acquérir certaines terres indiennes. in Le Piège de Jimmy Goldsmith 1993.	berkeley	4989
Ce qui fait que la plupart des petits enfants plaisent, c'est qu'ils sont encore renfermés dans cet air et dans ces manières que la nature leur a donnés, et qu'ils n'en connaissent point d'autres.	LA ROCHEFOUCAULD François de	Réflexions diverses		420     capital affectif	1613-1680.	berkeley	3864
L'on veut faire tout le bonheur, ou, si cela ne se peut ainsi, tout le malheur de ce qu'on aime.	LA BRUYERE Jean de	Les Caractères		433     perversion	1645-1696.	berkeley	3620
Tout comprendre rend très indulgent.	STAEL Madame de	Corinne ou l"Italie		365     discernement	1766-1817. (Germaine Necker, baronne de Staël-Holstein)	berkeley	5125
Heureux les coeurs purs,  car ils verront Dieu.	Evangiles	Evangile selon saint Matthieu, V, 8		215     mystifications	De l"art de récupérer au profit de la mystification Déiste de l"immanence la quête spirituelle de l"individu.	berkeley	2412
La grégarité est la drogue favorite des entropates.	FAIRGAGNETR Oscar	Vitalités.	1993	120     grégarité		berkeley	2481
En amour on plaît plutôt par d'agréables défauts que par des qualités essentielles ...	LENCLOS Ninon de	Lettres		235     séduction	1620-1705. (Anne)	berkeley	4105
Je crains ce que je veux et veux ce que je crains.	CORNEILLE Thomas	Camma et Pyrrhus		520     ironie de soi	1625-1709.	berkeley	1691
Ce qui nous empèche souvent de nous abandonner à un seul vice est que nous en avons plusieurs.	LA ROCHEFOUCAULD François de	Maximes.		520     ironie de soi		berkeley	3914
Il est plus aisé d'être sage pour les autres que de l'être pour soi-même.	LA ROCHEFOUCAULD François de	Maximes		520     ironie de soi	1613-1680.	berkeley	3915
Il y a une folie organisatrice qui est l'ennemie jurée de l'ordre.	DUHAMEL Georges	Vie des martyrs		560     sagesse	1884-1966.	berkeley	2225
C'est en se découvrant soi-même que l'on perd sa misère.	Dictons et Proverbes	Aphorisme.		421     initiation		berkeley	2025
Amis sont comme le melon, De dix souvent pas un n'est bon.	Dictons et Proverbes	Dicton.		120     grégarité		berkeley	1990
Les Fremen avaient au degré suprême cette qualité que les anciens appelaient le 'spannungs-bogen' qui est le délai que l'on s'impose soi-même entre le désir que l'on éprouve pour une chose et le geste que l'on fait pour se l'approprier.	HERBERT Franck	Dune	1965	441     sang-froid		berkeley	3150
C'est à l'heure du commencement qu'il faut tout particulièrement veiller à ce que les équilibres soient précis.	HERBERT Franck	Dune	1965	441     sang-froid		berkeley	3152
Sommes-nous trente-neuf, on est à nos genoux, Et sommes-nous quarante, on se moque de nous.	FONTENELLE Bernard le Bovier de			120     grégarité	1657/1757. sur l"Académie française.	berkeley	2817
Quand l'esclave trouve une occasion de devenir tyran, il ne la rate pas.	DUVERNOIS Henri	Cruautés		110     entropie	1875-1937.	berkeley	2250
L'âge où l'on se décide à être jeune importe peu.	DUVERNOIS Henri	La Brebis galeuse		320     intuition	1875-1937.	berkeley	2251
Ce sont les peuples qui font les rois et les rois sont faits pour les peuples et les peuples ne sont pas faits pour les rois.	LAMENNAIS Félicité Robert de	Paroles d"un croyant		539     ironie sociale	1782-1854.	berkeley	4027
Apprendre par l'expérience et en s'amusant.	EARHART Amélia			421     initiation	Devise de l"aviatrice.	berkeley	2255
La Loi de la Jungle (qui est, de loin, la plus vieille loi du monde) couvre à peu près toutes les situations susceptibles de se présenter au Peuple de la Jungle ; et désormais son code a la perfection conférée par l'usage et le temps.	KIPLING Rudyard	Le second livre de la jungle.	1894	421     initiation		berkeley	3559
Il n'y a pour l'homme que trois événements: naître, vivre et mourir. Il ne se sent pas naître, il souffre à mourir, et il oublie de vivre.	LA BRUYERE Jean de	Les Caractères		510     ironie	1645-1696.	berkeley	3625
Tout est dit, et l'on vient trop tard depuis plus de sept mille ans qu'il y a des hommes et qui pensent.	LA BRUYERE Jean de	Les Caractères		520     ironie de soi	1645-1696.	berkeley	3627
Tout de même, Akela m'a débité bien des sottises avant de mourir ; car au moment de mourir on change... Il a dit... N'empêche, je suis de la Jungle !	KIPLING Rudyard	Le second livre de la jungle.	1894	423     solitude		berkeley	3563
Je n'ai peur de rien... quand il s'agit de manger des vermisseaux.	KIPLING Rudyard	Le second livre de la jungle.	1894	520     ironie de soi		berkeley	3568
Les délicats sont malheureux,  Rien ne saurait les satisfaire.	LA FONTAINE Jean de	Fables, Contre ceux qui ont le goût difficile		110     entropie	1621-1695.	berkeley	3643
La fourmi n'est pas prêteuse:  C'est l à son moindre défaut.	LA FONTAINE Jean de	Fables, la Cigale et la Fourmi		110     entropie	1621-1695.	berkeley	3644
Quand ils ont tant d'esprit, les enfants vivent peu.	DELAVIGNE Casimir	Les Enfants d"Edouard.		423     solitude		berkeley	1888
Madeleine n'était pas une amante, mais une courtisane, au sens classique du terme. Elle savait donner du plaisir. Mais c'est tout ce qu'elle donnait. Ensuite, si vous la laissiez faire, elle vous dévorait. Pas pour l'argent, mais pour se sentir rassurée. Elle était prisonnière, enfermée dans une chambre vide, cherchant toujours à s'échapper, avec n'importe qui, à n'importe quel risque...	WEST Morris	De main de Maître.	1988	433     perversion		berkeley	5425
C'est un peu, dans chacun de ces hommes, Mozart assassiné.	SAINT-EXUPERY Antoine de	Terre des Hommes	1939	550     grandeur		berkeley	4922
Oh combien l'homme qui pense le plus est encore automate.	DIDEROT Denis	Discours sur la Poésie Dramatique		510     ironie		berkeley	2112
Ce sont les passions et non les intérêts qui mènent le monde.	CHARTIER Emile	Mars Ou La Guerre Jugée.		430     paradoxal émotionnel	alias Alain (1868-1951)	berkeley	1257
Réfugie-toi dans l'étude, tu échapperas à tous les dégouts de l'existence. L'ennui du jour ne te fera pas soupirer après la nuit et tu ne seras pas à charge de toi-même et inutile aux autres.	SENEQUE			421     initiation		berkeley	5004
Ce ne sont point les hommes qui mènent la révolution, c'est la révolution qui emploie les hommes.	MAISTRE Joseph de	Considérations sur la France		221     vanité	1753-1821.	berkeley	4184
C'est l'imagination qui perd les batailles.	MAISTRE Joseph de	Les Soirées de Saint-Pétersbourg		433     perversion	1753-1821.	berkeley	4185
La guerre est donc divine en elle-même, puisque c'est une loi du monde.	MAISTRE Joseph de	Les Soirées de Saint-Pétersbourg.		510     ironie		berkeley	4186
Ne vous servez donc pas de ce terme élevé d'idéal quand nous avons pour cela, dans le langage usuel, l'excellente expression de mensonge.	IBSEN Henrik	Le canard sauvage.		215     mystifications		berkeley	3377
C'est par la crainte et le respect que vous devez d'abord prendre de l'empire sur leurs esprits; c'est par l'amour et l'amitié que vous devez plus tard les conserver.	LOCKE John	Quelques pensées sur l"éducation.		391     commandement		berkeley	4144
Les expériences des autres ne peuvent pas vous profiter directement.	MOREAU Jeanne		1992	421     initiation		berkeley	4496
La découverte de l'irrationnel permet une véritable humilité	MOREAU Jeanne	Qu"avez-vous fait de vos 20 ans ?		560     sagesse	F3, entretien avec Christine Ockrent le 8/07/94	berkeley	4497
(...) des hommes sont contents d'endurer du mal pour en faire, non pas à celui qui leur en fait, mais à ceux qui en endurent comme eux, et qui n'en peuvent mais.	LA BOéTIE Etienne de	Le discours de la servitude volontaire.		433     perversion	1530/1563. ami de Montaigne.	berkeley	3583
Devine, si tu peux, et choisis, si tu l'oses.	CORNEILLE Pierre	Héraclius, IV, 4, Léontine		320     intuition	1606-1684.	berkeley	1654
Le profond amour a la véritable connaissance.	SUARES André			140     rapport à la cosmogonie		berkeley	5159
J'aime le travail; il me fascine et je peux rester assis des heures à le considérer. J'adore l'avoir sous la main, et la seule idée de m'en débarrasser me fend le coeur.  I like work; it fascinates me, I can sit and look at it for hours. I love to keep it by me; the idea of getting rid of it nearly breaks my heart.	JEROME Jerome K.	Trois Hommes dans un bateau, XV		380     travail	1859-1927. (Anglais)	berkeley	3436
Un jour vient où vous manque une seule chose et ce n'est pas l'objet de votre désir, c'est le désir.	JOUHANDEAU Marcel	Réflexions sur la vieillesse et la mort		442     démission	1888-1979.	berkeley	3481
Les vertus sont sujettes à des vices particuliers qui les rendent inutiles.	JOUHANDEAU Marcel	Algèbre des valeurs morales		515     tragédie	1888-1979.	berkeley	3485
Ce n'est ni l'amitié ni la bonté qui nous manquent, mais nous qui manquons à l'amitié et à la bonté 	JOUHANDEAU Marcel	Chroniques maritales		520     ironie de soi	1888-1979.	berkeley	3487
Nous ne nous ennuyons jamais ensemble [avec Elise]. C'est la meilleure façon d'aimer.	JOUHANDEAU Marcel	Réflexions sur la vieillesse et la mort.		530     ironie amoureuse		berkeley	3490
L'art est fait pour troubler. La science rassure.	BRAQUE Georges	Le Jour Et La Nuit.		545     épistémologie	1882/1963	berkeley	833
Dès sa première proie, quel Rejeton ne lance : 'C'est bien moi le meilleur !' ? Mais la Jungle est immense ; Petit, le Rejeton. Mieux vaut donc qu'il commence Par réfléchir un peu et garder le silence.	KIPLING Rudyard	Le livre de la jungle	1894	421     initiation		berkeley	3561
Première étape : il fallait s'arroger un privilège exclusif sur la science et en refuser l'accès au vulgaire.	WEST Morris	Kaloni le navigateur.	1972	230     pouvoir		berkeley	5366
Pour dominer, il fallait être indifférent... Ne pas trembler en infligeant la douleur, en refusant le plaisir, en diminuant les droits de l'autre.	WEST Morris	De main de Maître.	1988	232     servitudes du pouvoir		berkeley	5368
A Paris, le métier est un art, et l'art une philosophie.  And trade is art, and art's philosophy in Paris.	BROWNING Elizabeth Barrett	Aurora Leigh, VI		120     grégarité	1806-1861. (Anglaise)	berkeley	876
Les étreintes des retours sont maladroites. Les mains, les bras croient serrer des épaules qu'ils reconnaisent, alors que ce sont des morceaux de glace, transis de peur et d'étrangeté qui se laissent enlacer. Il y a une habitude des gestes qui semble se retrouver à la seconde, comme si le temps n'avait pas existé, mais c'est en plus d'un corps, du temps et un espace qu'il faut étreindre, l'espace d'un exil avec des forêts, des kilomêtres de forêts et de routes mêlés à des rêves d'absence, et tout cela ne peut être embrassé par un seul geste. Cette étreinte des gares où un homme et une femme se retrouvent est le plus terrifiant des gestes que chacun ait un jour à vivre. Les bras ressemblent à deux rames qui essayent de franchir la mer en un seul mouvement... Mais l'émotion ne peut, à elle seule, remplacer les distances parcourues par deux mondes qui ont si longtemps dérivé l'un de l'autre...	SIMON Yves		1991	530     ironie amoureuse		berkeley	5087
Le bonheur conjugal, c'est d'être aussi heureux à deux qu'on l'aurait été tout seul.	SOUBIRAN André	e aussi heur\\001ÇØ@\\001ÇØ à		530     ironie amoureuse		berkeley	5097
La peur est la petite mort qui conduit à l'oblitération totale. J'affronterai ma peur. Je lui permettrai de passer sur moi, au travers de moi. Et lorsqu'elle sera passée, je tournerai mon oeil intérieur sur son chemin. Et l à où elle sera passée, il n'y aura plus rien. Rien que moi.	HERBERT Franck	Dune	1965	440     courage		berkeley	3147
Curiosité, discernement, foi et énergie font la vitalité et l'homme.	FAIRGAGNETR Oscar	Vitalités.	1992	140     rapport à la cosmogonie	\\010zrê\\020	berkeley	2493
Une affection, qui est une passion, cesse d'être une passion sitôt que nous nous en formons une idée claire et distincte.	SPINOZA Baruch	L"Ethique.		420     capital affectif		berkeley	5103
Chanter ne peut guère valoir  Si au-dedans du coeur ne se lève le chant;  Ni le chant ne peut du coeur s'élever  Si n'y réside l'amour pur.  Chantar no pot gaire valer  Si d'ins del cor no mov lo chans,  Ni chans no pot del cor mover 	VENTADOUR Bernard de	Si no i es fin" amors corans.		330     coeur	XIIe siècle (Provençal)	berkeley	5271
Il existe infiniment plus d'hommes qui acceptent la civilisation en hypocrites que d'hommes vraiment et réellement civilisés.  Es gibt also ungleich mehr Kulturheuchler als wirklich kulturelle Menschen.	FREUD Sigmund	Considérations actuelles sur la guerre et la mort		510     ironie	1856-1939. (Autrichien)	berkeley	2891
Il faut et il suffit de ne jamais accepter de se laisser agresser par l'existence.	FAIRGAGNETR Oscar	Vitalités.	1994	130     liberté		berkeley	2488
Le vendeur est celui qui négocie sa confiance en lui.	FAIRGAGNETR Oscar	Aphorismes.	1992	234     communication		berkeley	2521
Etre de Gaulle, c'est cela aussi. A force d'incarner, on incorpore tout, les miasmes sont présents au plus fort du bonheur. Intolérable d'être le symbole... [...] Le Sacre est fait. Le rebelle est devenu le souverain.	LACOUTURE Jean	De Gaulle.	1984	550     grandeur		berkeley	3984
Les gens ne sont des héros que quand ils ne peuvent pas faire autrement.	CLAUDEL Paul	Journal		520     ironie de soi	1868-1955.	berkeley	1463
Les fantassins qui y ont pris part et qui y ont survécu se rappelent avec tristesse et amertume ces terrains d'attaque lamentables où chaque jour de nouveaux cadavres s'entassaient dans la boue im- monde ; ces ordres d'assaut, coûte que coûte donnés par téléphone par un commandement si lointain, après des préparations d'artillerie dérisoires et peu ou point réglées; ces assauts sans illusion exé- cutés contre des réseaux de fils de fer intacts et profonds où les meilleurs officiers et les meilleurs soldats allaient se prendre et se faire tuer comme des mouches dans des toiles d'araignée [...]. La défaillance ultérieure de certaines unités dont vous avez tous entendu parler n'a guère, à mon humble avis, d'autre motif que la démoralisation résultant de ces expériences lamentables où l'infanterie qui en fut l'instrument toucha, je vous l'assure, le fond du désespoir. Prise chaque fois entre la certitude de la mort sans aucun résultat à 10 mètres de la tranchée de départ, et l'accusation de lâcheté qu'un commandement trop nerveux et du reste sans illusion lui-même lui prodiguait aussitôt si ses pertes n'étaient pas jugées suffisantes pour que l'on pût se couvrir avec ces morts vis- à-vis des échelons supérieurs.	DE GAULLE Charles	Conférences d"Ingolstadt.	1917	221     vanité	évoquant les offensives de Champagne, de "la percée de 1915".	berkeley	1800
Le génie est fait de un pour cent d'inspiration et de quatre-vingt-dix-neuf pour cent de transpiration. Genius is one per cent inspiration and ninety-nine per cent perspiration.	EDISON Thomas Alva	Interview in Life, 1932		390     création	1847-1931. (Américain)	berkeley	2281
L'absence de pensée et l'idiotie morale ne sont pas des attributs caractéristiques de l'espèce humaine. Ce sont des symboles d'empoisonnement grégaire.	HUXLEY Aldous	Retour au Meilleur des Mondes	1958	120     grégarité		berkeley	3353
On a fait une vertu de la modération, pour borner l'ambition des grands hommes et pour consoler les gens médiocres de leur peu de fortune et de leur peu de mérite.	LA ROCHEFOUCAULD François de	Maximes.		120     grégarité		berkeley	3787
Nous plaisons plus souvent dans le commerce de la vie par nos défauts que par nos bonnes qualités.	LA ROCHEFOUCAULD François de	Maximes		120     grégarité	1613-1680.	berkeley	3789
Dans toutes les existences, on note une date où bifurque la destinée, soit vers une catastrophe, soit vers le succès.	LA ROCHEFOUCAULD François de	Marie Leczinska.		140     rapport à la cosmogonie		berkeley	3790
La maladie du scrupule est un des fléaux de la vie spirituelle.	BILLY André	L"Approbaniste		510     ironie	1882-1971.	berkeley	749
Gare aux fidèles dociles qui ne sont que des ambitieux roublards et sans valeur.	BINGEN Jacques		1943	120     grégarité	Délégué des FFL pour la zone Sud, pris par la Gestapo en mai 44.	berkeley	750
La clémence des princes n'est souvent qu'une politique pour gagner l'affection des peuples.	LA ROCHEFOUCAULD François de	Maximes		215     mystifications	1613-1680.	berkeley	3793
Le mariage de Madi était un désastre. Ed Bayard n'a jamais été assez intelligent ni assez fort pour avoir barre sur elle. Il s'est transformé en tyran, un tyran querelleur et amer. Si elle ne l'a pas quitté, c'est parcequ'il constituait une excuse pour ses propres aberrations.	WEST Morris	De main de Maître.	1988	530     ironie amoureuse		berkeley	5450
C'est toujours un grand trait de médiocrité que de ne pas savoir associer la méfiance et la clairvoyance.	BONNARD Abel			370     esprit		berkeley	787
Il faut quitter la vie comme Ulysse quitta Nausicaa, en la bénissant et non amoureux d'elle.	NIETZSCHE Friedrich			510     ironie	510     iron\\010n#`\\010n&	berkeley	4594
Ce qui est accompli par amour se situe par-del à le bien et le mal.	NIETZSCHE Friedrich	situe par-d\\003ï\tp\\003ï\\0320		530     ironie amoureuse		berkeley	4595
Bénis soient les oublieux, car ils l'emporteront même sur leurs bévues.	NIETZSCHE Friedrich	Au-del à du Bien et du Mal.		540     mémoire		berkeley	4596
Ne vous mettez pas en souci du lendemain, car le lendemain aura souci de lui-même : à chaque jour suffit sa peine.	Nouveau Testament	Matthieu. VI,34 (Oltramare).		441     sang-froid		berkeley	4608
Presque tous les hommes sont médiocres et superficiels pour le mal comme pour le bien.	Fénelon	Lettre à l"Académie		510     ironie	1651-1715. (François de Salignac de La Mothe-)	berkeley	2697
Ce qu'Alexandre appelle son 'espérance', César 'sa fortune', Napoléon 'son étoile', n'est-ce pas simplement la certitude qu'un don particulier les met, avec les réalités, en rapport assez étroit pour les dominer toujours ?	DE GAULLE Charles	Le Fil de l"Epée.		440     courage		berkeley	1844
Vous qui entrez, laissez toute espérance.  Lasciate ogni speranza, voi ch'entrate.  Divina Commedia, L'Inferno, III  	Dante Alighieri			441     sang-froid	1265-1321. (Italien). Paroles que Dante suppose gravées au sommet de la porte de l"enfer.	berkeley	1755
Tant que tu reste debout et que tu continues à te battre, il y a toujours de l'espoir. C'est pour cela qu'ils te traquent. Ils ont peur de toi.	CLANCY Tom	La somme de toutes les peurs. I.	1991	120     grégarité		berkeley	1401
LINDT, quelques grammes de finesse dans un monde de brutes.	Dictons et Proverbes	slogan pub TV, septembre 91	1991	510     ironie		berkeley	2047
Il faut d'abord bien savoir le latin. Ensuite il faut l'oublier.	MONTESQUIEU Charles de	Mes pensées		421     initiation	1689-1755. (C. de Secondat, baron de La Brède et de M.)	berkeley	4439
Le plus sage se tait.	GRINGORE Pierre	Notables Enseignements, adages et proverbes		441     sang-froid	v. 1475-v. 1538.	berkeley	3030
Nous restons au bord de nous-mêmes.	GUéHENNO Jean	La Foi difficile		510     ironie	1890-1978.	berkeley	3038
L'homme... un être en quête d'un sens.	PLATON			510     ironie	427?/347 av.J.C.	berkeley	4718
La guerre révèle à un peuple ses faiblesses, mais aussi ses vertus.	LE BON Gustave	Hier et Demain.		440     courage		berkeley	4066
L'oisiveté est la mère de la philosophie.  Leisure is the mother of philosophy.	HOBBES Thomas	Leviathan, IV, 46		221     vanité	1588-1679. (Anglais)	berkeley	3198
Dieu est une réponse aux embarras de l'intelligence.	SCHWARTZENBERG Léon		1990	110     entropie	entretien TV A2 avec Christine OCKRENT le 26/02/90	berkeley	4985
A raconter ses maux, souvent on les soulage.	CORNEILLE Pierre	Polyeucte, I, 3, Stratonice		430     paradoxal émotionnel	1606-1684.	berkeley	1662
On se forme sur des déchets de sagesse.	ECO Umberto	Le Pendule de Foucault	1988	421     initiation		berkeley	2272
Il est peu d'hommes enclins à rendre hommage, sans quelques mouvements d'envie, au succès d'un ami.	Eschyle	Agamemnon, 832		433     perversion	v. 525-45 av. J.-C.	berkeley	2373
Comment veux-tu que je te comprenne!.. Tu me parles à contre-jour.	FEYDEAU Georges	Le Dindon, II, 15		234     communication	1862-1921.	berkeley	2704
Dans ce monde, il faut être un peu trop bon pour l'être assez.	MARIVAUX Pierre Carlet de Chamblain de	Le jeu de l"amour e du hasard.		530     ironie amoureuse		berkeley	4236
Mon cher Ami, ... ni moi ni ma famille [FFL] - qui est maintenant la plus nombreuse de France - n'acceptons ce qui s'est passé ni ce qui se passe. Nous voulons que l'on fasse son devoir, quelles qu'en puissent être les conséquences, et il n'y a qu'un seul devoir. Toutes les finasseries, tergiversations, cotes mal taillées sont, pour nous, odieuses et condamnables. Ce que Philippe [Pétain] a été auttrefois ne change rien à la façon dont nous jugeons ce qu'est Philippe dans le présent. Nous aiderons tous ceux qui voudront faire ce qu'ils doivent faire. Nous laissons tomber (et ils tombent très bas) ceux qui ne font pas ce qu'ils doivent...	DE GAULLE Charles		1941	546     éthique	lettre de réponse à Loustaunau-Lacau qui tente le "petit pont"	berkeley	1857
Mais dans l'action, plus de censeurs ! Les volontés, les espoirs s'orientent vers lui comme le fer vers l'aimant. Vienne la crise, c'est lui que l'on suit, qui lève le fardeau de ses propres bras, dussent-ils s'y rompre, et le porte sur les reins, quand même ils en seraient brisés. Vis- à-vis de ses supérieurs, le train ordinaire des choses le favorise mal. Assuré dans ses jugements et conscient de sa force, il ne concède rien au désir de plaire. Le fait qu'il tire de lui-même, et non point d'un ordre, sa décision et sa fermeté l'éloigne souvent de l'obéissance passive. Il prétend qu'on lui donne sa tache et qu'on le laisse maître à son bord, exigence insupportable à beaucoup de chefs qui, faute d'embrasser les ensembles cultivent les détails et se nourrissent de formalités. 'Orgueilleux, indiscipliné', disent de lui les médiocres, traitant le pur-sang dont la bouche est sensible comme la bourrique qui refuse d'avancer, ne discernant point que l'âpreté est le revers ordinaire des puissantes natures, qu'on s'appuie seulement sur ce qui résiste et qu'il faut préférer les coeurs fermes et incommodes aux âmes faciles et sans ressort. Mais, que les évènements deviennent graves, le péril pressant, que le salut commun exige tout à coup l'initiative, le goût du risque, la solidité, aussitôt change la perspective et la justice se fait jour. Une sorte de lame de fond pousse au premier plan l'homme de caractère. Mais ce qu'il doit réaliser est l'éloignement moral... Il doit garder sur lui-même l'empire suffisant pour ne point laisser voir les mouvements de son âme...	DE GAULLE Charles	Le fil de l"Epée.		391     commandement		berkeley	1820
Et je médite, obscur témoin, Pendant que, déployant ses voiles, L'ombre où se mêle une rumeur, Semble élargir jusqu'aux étoiles Le geste auguste du semeur.	HUGO Victor	Saison de Semailles ; Le Soir.		520     ironie de soi		berkeley	3341
Laisse la peur à l'extérieur, le danger y restera aussi et il te suffira de les surveiller, bien en face.	FAIRGAGNETR Oscar	Vitalités.	1993	441     sang-froid	le 12/07/93, en sortant de la projection de "L"Enfant Lion".	berkeley	2608
Il n'est pas aussi intelligent que je le pensais, ou alors il se laisse trop influencer par ses sentiments. Le résultat est le même.	LENTERIC Bernard	La nuit des enfants rois.	1981	433     perversion		berkeley	4111
Flatteuse illusion! doux oubli de nos peines! Oh! qui pourrait compter les heureux que tu fais ?	COLLIN D"HARLEVILLE	Les Chateaux en Espagne.		510     ironie		berkeley	1569
Il n'y a pas de genres inférieurs ; il n'y a que des productions ratées, et le bouffon qui divertit prime le tragique qui n'émeut pas.	COURTELINE Georges	La philosophie de G. Courteline.		390     création		berkeley	1701
- L'amour est la seule chose qui croisse au fur et à mesure qu'on    la dépense. - L'amour, mais pas la vie. Pas le temps. Si tu ne l'emploies pas     comme il faut, un beau jour, tu te retournes et tu contemples     avec désespoir le gachis derrière toi.	WEST Morris	Kaloni le navigateur.	1976	330     coeur		berkeley	5388
Que dix coupables échappent à la justice, plutôt que souffre un seul innocent.  It is better that ten guilty persons escape than that one innocent suffer.	BLACKSTONE Sir	Commentaries on the Laws of England, IV		330     coeur	1723-1780. (Anglais)	berkeley	755
Rien de grand ne s'est accompli dans le monde sans passion.	HEGEL Friedrich	Introduction à la philosophie de l"Histoire.		430     paradoxal émotionnel		berkeley	3098
La loi du juste avenir se trouve dans les consciences solitaires et libres et ne se trouve nulle part ailleurs.	CHARTIER Emile	Correspondance...		423     solitude	alias Alain (1868-1951). Correspondance avec Romain Rolland	berkeley	1252
L'univers, ce qui est l'exception de soi.	JARRY Alfred	Gestes et opinions du Dr. Faustroll, pataphysicien		140     rapport à la cosmogonie	1873-1907.	berkeley	3423
Les institutions sont faites pour servir les dessins de ceux qui les dirigent, avec l'ambition première de rassembler la grégarité sociale autour de la légitimité de leur action.	FAIRGAGNETR Oscar		1990	238     servitudes du pouvoir politique	es d	berkeley	2528
Qu'est-ce qu'un don sincère ? Celui pour lequel on n'attend rien en retour.	PRASNOTTARAMALIKA			330     coeur	330     coeu\\010mw`\\010mzP	berkeley	4731
Ah! si mon coeur osait encor se renflammer!  Ne sentirai-je plus de charme qui m'arrête?  Ai-je passé le temps d'aimer? 	LA FONTAINE Jean de	Fables		530     ironie amoureuse	1621-1695.	berkeley	3756
On est rarement maître de se faire aimer, on l'est toujours de se faire estimer.	FONTENELLE Bernard le Bovier de	Entretiens sur la pluralité des mondes		440     courage	1657-1757.	berkeley	2823
Si faire était aussi aisé que savoir ce qu'il est bon de faire, les chapelles seraient des églises, et les chaumières des pauvres gens des palais de princes.	SHAKESPEARE William	Le marchand de Venise.		510     ironie		berkeley	5060
Je ne trempe pas ma plume dans un encrier, mais dans la vie.	CENDRARS Blaise	L"Homme foudroyé		393     création artistique	1887-1961. (Frédéric Sauser)	berkeley	1086
Si l'individu, en effet, accepte de mourir et meurt à l'occasion, dans le mouvement de sa révolte, il montre l à qu'il se sacrifie au bénéfice d'un bien dont il estime qu'il déborde sa propre destinée.	CAMUS Albert	L"homme révolté.	1951	331     altruisme	1913/1960	berkeley	1000
Que Dieu me protège ! s'écria Sancho, n'avais-je pas prévenu Votre Grace de bien prendre garde ? Ne l'avais-je pas avertie que c'étaient des moulins à vent et que, pour s'y tromper, il fallait en avoir d'autres dans la tête ?	CERVANTES SAAVEDRA Miguel de	Don Quichotte.		360     bon sens	1547-1616. (Espagnol)	berkeley	1088
Une vocation est un miracle qu'il faut faire avec soi-même.	JOUVET Louis	Ecoute mon ami.		421     initiation		berkeley	3502
Le sein de Dorine est un accessoire métaphysique.	JOUVET Louis	Ecoute mon ami.		430     paradoxal émotionnel		berkeley	3503
Mes actes, je les ai subis et non commis.  Oedipe à Colone, 266-267 (traduction Mazon)  	Sophocle	C"est Oedipe qui se justifie.		520     ironie de soi	v. 495-40 av. J.-C.	berkeley	5096
Il y a quelque chose de faible et d'infini dans le coeur des vieilles gens à quoi l'on ne devrait jamais toucher, devant quoi l'on devrait trembler comme avant d'enseigner une religion à des enfants.	CASSOU Jean	Les Harmonies viennoises		515     tragédie	1897-1986.	berkeley	1049
La plupart font vivre les choses dans l'aisance ; d'aucuns les inspirent dans la difficulté.	FAIRGAGNETR Oscar	vivr	1991	390     création		berkeley	2558
L'inventivité : comment faire de ce qui existe ce qui n'existe pas encore ? La création artistique : comment faire de ce qui existe ce qui n'avait jamais été dit ni offert à l'imagination et au plaisir, auparavant.	FAIRGAGNETR Oscar		1990	390     création	après la lecture du TBA de R. MORENO	berkeley	2560
L'artiste est celui qui embellit le monde de ses espérances et de ses désespoirs.	FAIRGAGNETR Oscar	Vitalités.	1992	393     création artistique		berkeley	2562
Les femmes détestent un jaloux qui n'est point aimé, mais elles seraient fâchées qu'un homme qu'elles aiment ne fût pas jaloux.	LENCLOS Ninon de	tent		530     ironie amoureuse		berkeley	4106
Les raisonnables ont duré ; les passionnés ont vécu.	CHAMFORT Nicolas-Sébastein de			510     ironie	1740/1794. Ac. Française	berkeley	1102
L'être humain a besoin d'être flatté, sinon il ne devient pas ce qu'il est destiné à devenir, pas même à ses propres yeux.	LAGERKVIST Pär	Le Nain.		420     capital affectif		berkeley	3985
La culture est ce qui subsiste quand on a oublié tout ce qu'on avait appris.	LAGERLOF Selma			130     liberté		berkeley	3986
La jalousie est le plus grand de tous les maux, et celui qui fait le moins de pitié aux personnes qui le causent.	LA ROCHEFOUCAULD François de	Maximes.		221     vanité		berkeley	3814
Les chefs-d'oeuvre ne sont jamais que des tentatives heureuses.	SAND George	François le Champi.		390     création		berkeley	4950
Où l'on fait appel au talent, c'est que l'imagination fait défaut.	BRAQUE Georges	Le Jour Et La Nuit.		350     imagination	1882/1963	berkeley	829
Quand on n'a pas de quoi payer son terme,  Il faut avoir une maison à soi.	DéSAUGIERS Marc-Antoine	Monsieur Vautour		510     ironie	1772-1827.	berkeley	1907
Il ne faut pas compter sur la pitié des hommes quand ils peuvent se donner l'importante joie de punir.	DESBORDES-VALMORE Marceline	Correspondance, à Prosper Valmore, 17 novembre 1839		221     vanité	1786-1859.	berkeley	1908
L'amour vrai, c'est le plaisir que me donne le plaisir de l'autre, le bonheur que je trouve à le savoir heureux.	TOURNIER Michel	Gaspars, Melchior et Balthazar.		531     communication amoureuse		berkeley	5219
Dans la vie courante, dans ses relations avec ses pareils, l'homme doit se servir de sa raison, mais il commettra moins d'erreurs s'il écoute son coeur.	LECOMTE DU NOÜY Pierre	L"Homme et sa destinée		421     initiation	1883-1947.	berkeley	4092
Il n'existe pas d'autre voie vers la solidarité humaine que la recherche et le respect de la dignité individuelle.	LECOMTE DU NOÜY Pierre	L"Homme et sa destinée		546     éthique	1883-1947.	berkeley	4093
Mourir confortablement coûte très cher.  It costs a lot of money to die comfortably.	BUTLER Samuel	A Luxurious Death		442     démission	1835-1902. (Anglais)	berkeley	927
Un coeur est une richesse qui ne se vend pas, qui ne s'achète pas, mais qui se donne.	FLAUBERT Gustave	L"amour de l"art.	1915	330     coeur	(1821/1880) édition posthume	berkeley	2733
Les meilleurs savent bien que le pouvoir associé à la politique n'est qu'une illusion. Les servitudes sont bien plus importantes.	CLANCY Tom	La somme de toutes les peurs. I.	1991	238     servitudes du pouvoir politique		berkeley	1415
On pourrait s'étonner que les pensées profondes se trouvent dans les écrits des poètes plutôt que des philosophes. La raison en est que les poètes écrivent par les moyens de l'enthousiasme et de la force de l'imagination: il y a en nous des semences de science, comme dans le silex, que les philosophes extraient par les moyens de la raison, tandis que les poètes, par les moyens de l'imagination, les font jaillir et davantage étinceler.	DESCARTES René	Cogitationes privatae		393     création artistique	1596-1650.	berkeley	1929
... son père lui avait donné du courage.	CLANCY Tom	La somme de toutes les peurs. I.	1991	420     capital affectif		berkeley	1427
Jamais ce qu'ils appellent de la chance ne viendra frapper à leur porte s'ils ne s'y préparent pas eux-mêmes.	VINCENT Raymond	La Passion du succès		321     volonté		berkeley	5305
On s'enrichit sur tous les plans lorsqu'on est en recherche.	VINCENT Raymond	La passion du succès.		421     initiation		berkeley	5307
Quand l'eau courbe un bâton, ma raison le redresse.  La raison décide en maîtresse.	LA FONTAINE Jean de	Fables, Un Animal dans la Lune		321     volonté	1621-1695.	berkeley	3690
S'il y a une laideur, une tristesse affreuse de la vie ordinaire, elle est dans sa résignation.	SALLENAVE Danielle			110     entropie		berkeley	4947
La seule qualité que l'on connaisse à notre chef et qui n'ait jamais été prise en défaut est sa volonté.	LUDENDORFF Erich	Mes Mémoires de Guerre	1919	321     volonté		berkeley	4151
...le choix des hommes a une importance extrême, et ce bon choix, minutieux, révisable, patient, est le devoir n° 1 et la charge principale d'un vrai chef. Un homme n'en vaut pas un autre. Tous ne sont pas également méprisables. La 'fidélité' n'est pas toujours un signe de dévouement.	BINGEN Jacques		1944	391     commandement	délégué des FFL pour la zone Sud, pris par la Gestapo en mai 44.	berkeley	751
J'appris des rythmes, des manières de laisser aller le corps et l'esprit.	ECO Umberto	Le Pendule de Foucault	1988	140     rapport à la cosmogonie		berkeley	2263
Celui qui excelle ne discute pas,  Il maîtrise sa science et se tait.	LAO TSEU	Tao tö King, LXXXI		441     sang-froid		berkeley	4036
Ceux qui aiment vraiment la justice n'ont pas droit à l'amour.	CAMUS Albert	Les Justes		510     ironie	1913-1960.	berkeley	1019
Dix contre un!.. Dix manants contre un gentilhomme, c'est cinq de trop.	DUMAS Alexandre	La Tour de Nesle, I, 2		441     sang-froid	1802-1870. (père)	berkeley	2236
Les erreurs sont souvent la garantie de notre succès.	VINCENT Raymond	La passion du succès.		432     expérience		berkeley	5309
Le démon ne peut rien sur la volonté, très peu sur l'intelligence, et tout sur l'imagination.	HUYSMANS Joris-Karl	L"Oblat		441     sang-froid	1848-1907.	berkeley	3371
Les personnes faibles ne peuvent être sincères.	LA ROCHEFOUCAULD François de	Maximes.		440     courage		berkeley	3887
A nu; toutes choses mises d'abord au pire.	DUBUFFET Jean	Prospectus et tous Ecrits suivants		441     sang-froid	1901-1985.	berkeley	2188
Ce qu'un homme pense de lui-même, voil à ce qui règle ou plutôt indique son destin.	THOREAU Henry David	Walden.		422     confiance en soi		berkeley	5200
Si vous fermez la porte à toutes les erreurs, la vérité restera dehors.	TAGORE Rabindranath			432     expérience		berkeley	5183
Notre bonheur n'est qu'un malheur plus ou moins consolé.  	DUCIS Jean-François	Cité par Sainte-Beuve: Consolations I.		510     ironie	1733-1816.	berkeley	2194
On n'a jamais bien jugé le romantisme; qui l'aurait jugé ? Les critiques ! Les romantiques qui prouvent si bien que la chanson est si peu souvent l'oeuvre, c'est à dire la pensée chantée et comprise du chanteur ? Car Je suis un autre. Si le cuivre s'éveille clairon, il n'y a rien de sa faute. Cela m'est évident : j'assiste à l'éclosion de ma pensée : je la regarde, je l'écoute : je lance un coup d'archet : la symphonie fait son remuement dans les profondeurs, ou vient d'un bond sur la scène.	RIMBAUD Arthur	lettre à Paul Dumeny	1871	393     création artistique		berkeley	4823
Robert [dyslexique de treize ans] est un adolescent encore immature qui se réfugie dans ses 'rêves' et n'ose affronter la réalité, c'est- à-dire les conflits.	LAMBRICHS Louise L.	La Dyslexie en question.	1989	410     santé		berkeley	4017
La faim, l'occasion, l'herbe tendre, et, je pense,  Quelque diable aussi me poussant,  Je tondis de ce pré la largeur de ma langue.	LA FONTAINE Jean de	Fables		520     ironie de soi	1621-1695.	berkeley	3754
La solitude est essentielle à la fraternité.	MARCEL Gabriel	La Dignité humaine		234     communication	1889-1973.	berkeley	4219
C'est ici un livre de bonne foi, lecteur.	MONTAIGNE Michel Eyquem de	Essais, Au lecteur		234     communication	1533-1592.	berkeley	4333
Nul ne peut être veritablement maître des autres sans être d'abord maitre de soi.	Dictons et proverbes	dicton		230     pouvoir		berkeley	2062
L'histoire du neuf thermidor n'est pas longue: quelques scélérats firent périr quelques scélérats.	MAISTRE Joseph de	Considérations sur la France		214     guerre du savoir	1753-1821.	berkeley	4179
L'intellectuel est celui qui tourne autour du pôt sans jamais y mettre la main.	FAIRGAGNETR Oscar	Vitalités.	1995	221     vanité		berkeley	2462
Le plus souvent les bêtises se disent à pleine voix.	DOLENT Jean	Amoureux d"art		510     ironie	1835-1909. (Charles Antoine Fournier)	berkeley	2129
L'ordre social ne vient pas de la nature. Il est fondé sur des conventions.	ROUSSEAU Jean-Jacques	Du Contrat Social.		232     servitudes du pouvoir		berkeley	4885
Seuls des individus motivés sécrètent progrès et avancées : cette motivation est à fort contenu économique et matériel, la réprimer c'est la détruire et finir par détruire l'innovation : l'innovation est génératrice de progrès, mais au coeur d'une innovation il y a toujours un individu.	LATTES Robert	Le Risque et la Fortune.	1990	392     création économique		berkeley	4043
C'est quand on est vaincu qu'on devient chrétien.  It is in defeat that we become Christian.	HEMINGWAY Ernest Miller	L"Adieu aux armes		442     démission	1898-1961. (Américain)	berkeley	3114
S'il est ordinaire d'être vivement touché des choses rares, pourquoi le sommes-nous si peu de la vertu ? 	LA BRUYERE Jean de	Les Caractères, Du mérite personnel		520     ironie de soi	1645-1696.	berkeley	3628
Le laisser-aller laisse tout aller, même le coeur.	VILMORIN Louise de	La Lettre dans un taxi		442     démission	1902-1969.	berkeley	5302
A brebis tondue Dieu mesure le vent.	ESTIENNE Henri	Les Prémices		210     violence	1531-1598.	berkeley	2384
Habituellement, les gens recherchent ton assurance, non ton coeur.	FAIRGAGNETR Oscar	Aphorismes.	1992	120     grégarité		berkeley	2483
C'est une amphore que l'on a commencé à faire; la roue tourne.  Pourquoi en sort-il une cruche?  ... Amphora coepit  Institui: currente rota, cur urceus exit? 	Horace	Art poétique, 21-22  		442     démission	65-8 av. J.-C. (Quintus Horatius Flaccus)  Inexactement cité par V. Hugo dans Notre-Dame de Paris: "... ce potier dont parle Horace, lequel méditait des amphores et produisait des marmites. Currit rota, urceus exit."	berkeley	3257
Ne rien vouloir et ne rien chercher d'autre, sinon, en toutes choses et par tous les moyens, une plus grande louange et gloire de Dieu Notre Seigneur.  Non volendo neque quaerendo quidquam aliud, nisi in omnibus et per omnia majorem laudem et gloriam Dei Domini Nostri.  Exercices spirituels, 89  	St. Ignace de Loyola			215     mystifications	1491-1556.   On reconnaît une devise des Jésuites: "Ad majorem Dei gloriam": pour une plus grande gloire de Dieu.	berkeley	5108
J'aurais cru que la gloire de pardonner à ses ennemis valait bien l'honneur de les haïr toujours.	MARIVAUX Pierre Carlet de Chamblain de	Le Triomphe de l"amour, III, 3		221     vanité	1688-1763.	berkeley	4221
Chacun de nous a dans le coeur une chambre royale; je l'ai murée, mais elle n'est pas détruite.	FLAUBERT Gustave	Correspondance, 1842, à Amélie Bosquet, 1859  		330     coeur	1821-1880.   En évoquant les "chambres royales" des Pyramides, Flaubert songeait à son amour secret et constant pour Elisa Schlésinger.	berkeley	2735
Le dandysme, forme moderne du stoïcisme, est finalement une religion dont le seul sacrement est le suicide.	BUTOR Michel	Une histoire extraordinaire		221     vanité	1926-.	berkeley	933
De tous les pays du monde, la France est peut-être celui où il est le plus simple d'avoir une vie compliquée et le plus compliqué d'avoir une vie simple.	DANINOS Pierre	Les Carnets du major W. Marmaduke Thompson		539     ironie sociale	1913-.	berkeley	1752
L'homme ne progresse pas de l'erreur vers la vérité, mais de vérités en vérités, d'une vérité moindre en une vérité plus grande.	VIVEKANANDA	Jnana yoga.		432     expérience		berkeley	5319
Celui qui sait ne parle pas ; celui qui parle ne sait pas.	LAO TZU	lui qui parl\\010}b@\\010}lÄ		510     ironie		berkeley	4040
Nourris toujours ton esprit des vérités assez fortes pour le convaincre.	FAIRGAGNETR Oscar	Vitalités.	1994	370     esprit		berkeley	2551
Les intellectuels, étant les plus forts, trouvent leur bonheur l à où d'autres périraient : dans le labyrinthe, dans la dureté envers soi-même et les autres, dans la tentation : leur joie, c'est de se vaincre eux-mêmes.	NIETZSCHE Friedrich	Le Crépuscule des aurores.		130     liberté		berkeley	4584
(la métaphysique) Elle est cette présence constante de l'homme à lui-même. Elle n'est pas aspiration, elle est sans espoir. Cette révolte n'est que l'assurance d'un destin écrasant, moins la résignation qui devrait l'accompagner.	CAMUS Albert	Le mythe de Sisyphe.	1942	550     grandeur		berkeley	1029
En temps de révolution, prenez garde à la première tête qui tombe. Elle met le peuple en appétit.	HUGO Victor	Le Dernier Jour d"un condamné, Préface de 1832		120     grégarité	1802-1885.	berkeley	3278
L'amour-propre est une curieuse bête, qui peut dormir sous les coups les plus cruels et puis s'éveille, blessé à mort, par une simple égratignure.	MORAVIA A.	La belle romaine.		520     ironie de soi		berkeley	4495
Il y a des honnêtes gens, et leur cas n'est pas très clair.	TRUC Gonzague	Immortalité de la morale.		510     ironie		berkeley	5224
Serments d'amour n'entrent pas dans l'oreille des dieux.	Callimaque	Epigrammes, XXV, 3-4		530     ironie amoureuse	v. 310-v. 235 av. J.-C.	berkeley	971
A chaque fleur qui s'ouvre Aux branches du prunier, Le printemps un peu plus s'attiédit.	RANTSETSU	Haïkaï.		110     entropie		berkeley	4797
Si l'on peut en finir du passé avec l'oubli, on n'en finit pas de l'avenir avec l'imprévoyance.	LAMENNAIS Félicité Robert de	Mélanges religieux et philosophiques		440     courage	1782-1854.	berkeley	4025
Je viens de passer une année effrayante : ma Pensée s'est pensée et est arrivée à une Conception pure. Tout ce que, par contre-coup, mon être a souffert, pendant cette longue agonie, est inénarrable, mais heureusement, je suis parfaitement mort, et la région la plus impure où mon esprit puisse s'aventurer est l'Eternité. (...) Je suis maintenant impersonnel et non plus Stéphane que tu as connu, - mais une aptitude qu'a l'Univers spirituel à se voir et à se dévelop- per, à travers ce qui fut moi.	MALLARME Stéphane de	lettre à Henri Cazalis.	1867	430     paradoxal émotionnel	(Lazare)	berkeley	4197
Il est bon de suivre sa pente pourvu que ce soit en montant.	GIDE André	Les Faux-Monnayeurs.		440     courage		berkeley	2942
Depuis le jour fatal que je quittai ma dame,  Un enfer portatif j'ai toujours eu dans l'âme.	SCUDéRY Georges de	Ligdamon et Lidias, II, 1		420     capital affectif	1601-1667.	berkeley	4988
Tout ce qui peut être est.	BUFFON Georges-Louis Leclerc de	Histoire Naturelle, Premier Discours.		510     ironie	1707-1788	berkeley	899
Je veux être maître de moi, à tout sens. La sagesse a ses excès et n'a pas moins besoin de modération que la folie.	MONTAIGNE Michel Eyquem de			441     sang-froid	\\010j&#254;P\\020	berkeley	4361
On n'imagine pas combien il faut d'esprit pour n'être pas ridicule.	CHAMFORT Nicolas-Sébastien de	Maximes et pensées		520     ironie de soi	1740/1794. Ac. Française	berkeley	1146
Il faut se prêter à autrui et ne se donner qu' à soi-même.	MONTAIGNE Michel Eyquem de	Essais.		441     sang-froid		berkeley	4363
Il avait du bon sens; le reste vient ensuite.	LA FONTAINE Jean de	Fables, le Berger et le Roi		360     bon sens	1621-1695.	berkeley	3698
L'homme est à la mesure de toute chose.	PLATON	Théétète.		510     ironie		berkeley	4719
On passe souvent de l'amour à l'ambition, mais on ne revient guère de l'ambition à l'amour.	LA ROCHEFOUCAULD François de	Maximes		530     ironie amoureuse	1613-1680.	berkeley	3928
Où dois-je recourir ô ciel, s'il faut toujours aimer, souffrir, mourir ?	CORNEILLE Pierre	Suréna.		510     ironie	1606-1684.	berkeley	1676
Le temps est un grand maître, il règle bien des choses.	CORNEILLE Pierre	Sertorius, II, 4, Viriate		510     ironie	1606-1684.	berkeley	1677
Il n'y a que les imparfaits qui regardent plus au don qu'au donateur.	SIENNE Catherine de	La divine miséricorde.		330     coeur		berkeley	5079
... la civilisation libérale tire sa force, on pourrait dire sa substance, de l'hostilité qu'elle rencontre. Elle est la première civilisation de l'Histoire qui ne sollicite aucun consentement volontaire, qui tolère et encourage les plus radicales oppositions. Elle a le singulier privilège de se nourrir de ce qui s'oppose à elle, de convertir en énergie pour son fonctionnement toutes les forces qui se présentent afin de la briser, au point qu'on la verra parfois créer ses propres ennemis, les soutenir secrètement pour avoir par la suite le bonheur d'en tirer profit.	RUFIN Jean-Christophe	La Dictature Libérale.		231     légitimité du pouvoir	Le secret de la toute-puissance des démocraties au 20e siècle	berkeley	4893
C'est dans le silence des lois que naissent les grandes actions.	SADE Marquis de	Juliette		390     création	1740-1814.	berkeley	4907
Un fonds de modestie rapporte un très gros intérêt.	MONTESQUIEU Charles de	Mes pensées		365     discernement	1689-1755. (C. de Secondat, baron de La Brède et de M.)	berkeley	4432
Ne forçons point notre talent;  Nous ne ferions rien avec grâce.	LA FONTAINE Jean de	Fables, l"Ane et le Petit Chien		311     distinction	1621-1695.	berkeley	3688
Je suis chose légère et vole à tout sujet;  Je vais de fleur en fleur, et d'objet en objet.	LA FONTAINE Jean de	Fables		311     distinction	1621-1695.	berkeley	3689
Il devint gros et gras: Dieu prodigue ses biens  A ceux qui font voeu d'être siens.	LA FONTAINE Jean de	Fables, Le Rat qui s"est retiré du monde		330     coeur	1621-1695.	berkeley	3694
La solitude apporte tout, sauf le caractère.	STENDHAL			423     solitude		berkeley	5153
La liberté, pour l'homme, consiste à faire ce qu'il veut dans ce qu'il peut, comme sa raison consiste à ne pas vouloir tout ce qu'il peut.	RIVAROL Antoine de	Discours sur l"homme intellectuel et moral		130     liberté	1753-1801. (Antoine Rivarol)	berkeley	4824
Lorsque, dans le silence de l'abjection, l'on n'entend plus retentir que la chaîne de l'esclave ou la voix du délateur; lorsque tout tremble devant le tyran, et qu'il est aussi dangereux d'encourir sa faveur que de mériter sa disgrâce, l'historien paraît, chargé de la vengeance des peuples. C'est en vain que Néron prospère. Tacite est déj à né dans l'empire; il croît inconnu auprès des cendres de Germanicus, et déj à l'intègre Providence a livré à un enfant obscur la gloire du maître du monde.	CHATEAUBRIAND François-René de	Article Du Mercure.		231     légitimité du pouvoir	1768-1848.   Cet article du Mercure, que Chateaubriand dirigeait alors, suscita la fureur de Napoléon et précipita la disgrâce de l"écrivain.	berkeley	1292
Les hommes sont toujours sincères. Ils changent de sincérité, voil à tout.	BERNARD Tristan	Ce que l"on dit aux femmes		433     perversion	1866-1947. (Paul Bernard)	berkeley	715
Ceux qui ne font pas l'amour ont mauvaise conscience et voudraient la coller à ceux qui le font.	CHAPELAN Maurice			530     ironie amoureuse		berkeley	1173
Poser des règles, n'y pas croire, mais en prescrire l'application sans ignorer qu'elles seront lettre morte.	GOBINEAU	, mais en pr\\010W\\025&#240;\\010W!\\020		215     mystifications		berkeley	2969
Ainsi l'essentiel, l'élément décisif, dans les choses morales, comme dans les choses intellectuelles et physiques, c'est l'inné : l'art ne peut venir qu'en sous-ordre.	SCHOPENHAUER Arthur	Le fondement de la morale.	1840	320     intuition	n	berkeley	4977
La joie est en tout ; il faut savoir l'extraire.	CONFUCIUS			312     foi		berkeley	1595
Les feux de l'aurore ne sont pas si doux que les premiers regards de la gloire.	VAUVENARGUES Marquis de	Pensées et Maximes.		510     ironie	CLAPIER Luc de	berkeley	5268
Un nain est toujours petit, eût-il une montagne pour piédestal.  Magnus non est pumilio, licet in monte constiterit.	Sénèque	Lettres à Lucilius, LXXVI		221     vanité		berkeley	5019
La patience est la moelle de la charité.  La pazienzia è il midollo della carit à.	STE.CATHERINE DE SIENNE	Lettere, A frère Filippo di Vannuccio		330     coeur	1347-1380. (Italienne)	berkeley	5140
Il arrive que l'erreur se trompe.	DUHAMEL Georges	Défense des lettres		510     ironie	1884-1966.	berkeley	2214
La vérité est trop nue, elle n'excite pas les hommes.	COCTEAU Jean	Le Rappel à l"ordre		515     tragédie	1889-1963.	berkeley	1530
Le grand homme discerne ce qui est bien, le médiocre ce qui se vendra bien.	CONFUCIUS			510     ironie	551/479 av.J.C.	berkeley	1603
S'habiller à sa taille, et se chausser à son pied: voil à la sagesse.  Metiri se quemque suo modulo ac pede verum est.	Horace	Epîtres, I, VII, 98		441     sang-froid	65-8 av. J.-C. (Quintus Horatius Flaccus)	berkeley	3251
Quand la pensée se tait, les révolutions parlent.  Cuando el pensamiento calla, las revoluciones hablan.	CASTELAR Y RIPOLL Emilio	En el discurso defendiendo al periodico, La Soberanía nacional		210     violence	1832-1899. (Espagnol)	berkeley	1050
Je m'en vais promener tantôt parmi la plaine, Tantôt en un village et tantôt en un bois, Et tantôt par les lieux solitaires et cois.	RONSARD	Oeuvres.		130     liberté		berkeley	4848
L'opinion est la reine du monde, parce que la sottise est la reine des sots.	CHAMFORT Nicolas-Sébastien de	Maximes et Pensées.		214     guerre du savoir	1740/1794. Ac. Française	berkeley	1109
Sortir des limites de notre sensibilité et de notre vision mentale, et atteindre à une liberté plus vaste, telle est la signification de l'immortalité.	TAGORE Rabindranath	L"Inde et son âme.		550     grandeur		berkeley	5184
La gravité finit toujours par vous rattraper.	MONEROE Marylin			441     sang-froid		berkeley	4307
L'effort d'unir sagesse et pouvoir aboutit rarement et seulement très brièvement.	EINSTEIN Albert	Comment je vois le Monde	1934	232     servitudes du pouvoir	rééd.corr. en 1952 et 1978.	berkeley	2302
Il ne faut pas se décourager quand on doit s'exposer au danger pour une cause juste.	ISOCRATE			546     éthique		berkeley	3390
Aimer et haïr, ce n'est qu'éprouver avec passion l'être d'un être.	JOUHANDEAU Marcel	Algèbre des valeurs morales.		530     ironie amoureuse		berkeley	3491
Tant que les hommes pourront mourir et qu'ils aimeront à vivre, le médecin sera raillé et bien payé.	LA BRUYERE Jean de	Les Caractères.		510     ironie		berkeley	3622
Le criminel, au moment où il accomplit son crime, est toujours un malade.	DOSTOIEVSKI Fiodor Mikhaïlovitch	Crime et Châtiment, III, 5		210     violence	1821-1881. (Russe)	berkeley	2149
Voix de l'orgueil : un cri puissant, comme d'un cor, Des étoiles de sang sur des cuirasses d'or.	VERLAINE Paul	Sagesse.		520     ironie de soi		berkeley	5284
Car si je me trompe, je suis. Si enim fallor, sum.	St.AUGUSTIN	La Cité De Dieu, XI, 26.		520     ironie de soi	354-430. Raisonnement (ou intuition) repris par Descartes dans ses Méditations métaphysiques.	berkeley	5113
On se fie à un honnête homme, comme on se fie à un banquier riche.	MONTESQUIEU Charles de	Mes pensées		510     ironie	1689-1755. (C. de Secondat, baron de La Brède et de M.)	berkeley	4447
Les moeurs font toujours de meilleurs citoyens que les lois.	MONTESQUIEU Charles de	Lettres persanes		238     servitudes du pouvoir politique	1689-1755. (C. de Secondat, baron de La Brède et de M.)	berkeley	4426
En politique, il faut toujours laisser un os à ronger aux frondeurs.	JOUBERT Joseph	Carnets		238     servitudes du pouvoir politique	1754-1824.	berkeley	3454
C'est avant tout la poursuite de l'expérience qui importe: la raison suivra toujours, son bandeau phosphorescent sur les yeux.	BRETON André	Le Surréalisme et la Peinture		432     expérience	1896-1966.	berkeley	853
La haine est toujours plus clairvoyante et plus ingénieuse que l'amitié 	LACLOS Pierre Choderlos de	Les Liaisons dangereuses		210     violence	1741-1803.	berkeley	3960
Il se mettait toujours en colère contre la méchanceté et jamais contre la faiblesse.	WEST Morris	Les bouffons de Dieu.	1981	550     grandeur		berkeley	5459
La croyance élémentaire de la philosophie en sa genèse assigne à  la pensée pure la possibilité de découvrir toute connaissance nécés- saire. C'était une illusion, chacun peut aisément le comprendre, s'il oublie provisoirement les acquis ultérieurs de la philosophie et de la science physique. Pourquoi s'en étonner quand Platon accorde à l''Idée' une réalité supérieure à celle des objets empiriquement expérimentés. Spinoza, Hegel s'inspirent du même sentiment et raisonnent fondamentalement de même.	EINSTEIN Albert	Comment je vois le Monde	1934	221     vanité	rééd.corr. en 1952 et 1978.	berkeley	2297
La raison, c'est l'intelligence en exercice; l'imagination c'est l'intelligence en érection.	HUGO Victor	Tas de pierres		370     esprit	1802-1885.	berkeley	3314
L'art est le véhicule de la magie.	BRETON André			393     création artistique		berkeley	851
(...) le paradis terrestre est notre illusion la plus ancienne : c'est aussi la plus profonde. Même s'il existait, nous l'abîmerions. Si bas que pendent les fruits, nous pleurerons toujours pour avoir ceux qui sont hors de notre portée...	WEST Morris	Kaloni le navigateur	1976	510     ironie		berkeley	5446
Et l'espoir, malgré moi, s'est glissé dans mon coeur.	RACINE Jean	Phèdre.		330     coeur		berkeley	4777
Au théâtre les spectateurs veulent être surpris. Mais avec ce qu'ils attendent.	BERNARD Tristan	Contes, Répliques et Bons Mots		234     communication	1866-1947. (Paul Bernard)	berkeley	713
Défiez-vous des premiers mouvements, parcequ'ils sont bons.	TALLEYRAND			320     intuition		berkeley	5187
Quand on a besoin des bras, les secours en paroles ne servent de rien.	Esope	Fables, 1161, la Vipère et l"Hydre		441     sang-froid	VIe s. av. J.-C.	berkeley	2377
Si le vase n'est pas propre, tout ce qu'on y verse aigrit.  Sincerum est nisi vas, quodcumque infundis acescit.	Horace	Epîtres, I, II, 54	54	510     ironie	65-8 av. J.-C. (Quintus Horatius Flaccus)	berkeley	3262
En Art, j'aime la simplicité; de même, en cuisine.	SATIE Erik	Cahiers d"un mammifère		365     discernement	1866-1925.	berkeley	4962
Si la pilule avait bon gout, on ne la dorerait pas dehors.	Dictons et Proverbes	Dicton.		510     ironie		berkeley	2045
Quittez le long espoir et les vastes pensées.	LA FONTAINE Jean de	Fables		441     sang-froid	1621-1695.	berkeley	3723
La grande erreur des gens d'esprit est de ne croire jamais le monde assez bête.  	TENCIN Marquise de	Cité par Chamfort dans Caractères et Anecdotes.		365     discernement	1682-1749.	berkeley	5195
Nous vivons avec nos défauts comme avec les odeurs que nous portons : nous ne les sentons plus ; elles n'incommodent que les autres.	LAMBERT Marquise de	de		520     ironie de soi		berkeley	4016
La tristesse est un mur élevé entre deux jardins.	GIBRAN Kahlil	Sable et Ecume.		420     capital affectif		berkeley	2927
On n'oublie rien de rien, on s'habitue c'est tout.	BREL Jacques			420     capital affectif		berkeley	841
Le tout est de changer.	COLETTE Sidonie Gabrielle	Mes apprentissages		510     ironie	1873-1954.	berkeley	1564
On a arraché à Hanlon des êtres qu'il aimait : c'est pourquoi il se retourne contre vous pour se venger. Il croit vous haïr, mais cette haine ne lui apporte aucune satisfaction. Il méprise cette impulsion, alors même qu'il y cède. Il est vide, perdu, solitaire ; et pourtant son orgueil ne lui laisse pas admettre son besoin. Mais cet orgueil même n'est pas entièrement mauvais, car il ne lui permettra pas de tirer vengeence d'un homme sans défense qui est venu se livrer à lui. Ne le combattez pas. Ne le méprisez pas. Ne dressez pas votre orgueil contre le sien. Il est plus pauvre qu'il ne le sait, et vous, malgré tout ce que vous avez perdu, vous êtes singulièrement fortuné.	WEST Morris	La seconde victoire.	1972	433     perversion		berkeley	5424
...en se concentrant sur une pensée particulière, on libère un véritable pouvoir qui se traduit au niveau de l'action.	OECH Roger von	Créatif de choc.	1983	321     volonté		berkeley	4620
Qu'il puisse nuire aux autres, c'est assez, il oubliera tout. (de ses propres turpitudes)	SENEQUE	De Ira, I,1.		433     perversion		berkeley	5005
Le vrai moyen d'être trompé, c'est de se croire plus fin que les autres.	LA ROCHEFOUCAULD François de	Maximes		221     vanité	1613-1680.	berkeley	3804
La violence qu'on se fait pour demeurer fidèle à ce qu'on aime ne vaut guère mieux qu'une infidélité 	LA ROCHEFOUCAULD François de	Maximes		221     vanité	1613-1680.	berkeley	3805
Qui aime, attend.	MONTHERLANT Henry Millon de	Carnets		330     coeur	1896-1973.	berkeley	4475
L'opposition est une très mauvaise école de gouvernement, et les politiques avisés, qui se poussent par ce moyen aux affaires, ont grand soin de gouverner par des maximes tout à fait opposées à celles qu'ils professaient auparavant.	FRANCE Anatole	Les Opinions de Jérôme Coignard		238     servitudes du pouvoir politique	1844-1924. (Anatole François Thibault)	berkeley	2858
C'est par des artifices dialectiques qu'on a pu rendre l'idée de progrès solidaire du développement des sciences mécaniques, chimiques ou biologiques. Le vrai progrès n'intéresse que l'âme, il demeure indépendant des expédients et des pratiques de la science.	DUHAMEL Georges			546     éthique		berkeley	2224
La vie est l'art de tirer des conclusions suffisantes de prémisses insuffisantes.  Life is the art of drawing sufficient conclusions from insufficient premises.	BUTLER Samuel	Notebooks		510     ironie	1835-1902. (Anglais)	berkeley	930
Les vrais amis sont les solitaires ensemble.	BONNARD Abel	L"amitié.		423     solitude		berkeley	788
Ce que disent les femmes et ce qu'elles font sont deux choses différentes, Kaloni, tu le sais bien, et si tu l'ignores, mieux vaut l'apprendre une fois pour toutes. Mais en fin de compte, c'est elles qui décideront.	WEST Morris	Kaloni le navigateur.	1976	510     ironie		berkeley	5443
Ne rien devoir à personne : un simple fait qui n'attire aucun mérite.	FAIRGAGNETR Oscar	r	1992	515     tragédie		berkeley	2633
Qui n'aime point le vin, les femmes ni les chants,  Restera un sot toute sa vie durant.  Wer nicht liebt Wein, Weib und Gesang,  Der bleibt ein Narr sein Lebelang.	LUTHER Martin			460     plaisir		berkeley	4152
Il y a plus d'aventures sur un échiquier que sur toutes les mers du globe.	MAC ORLAN			510     ironie		berkeley	4155
Notre passé et notre avenir sont solidaires. Nous vivons dans notre race, et notre race vit en nous.	NERVAL Gérard de	Aurélia		415     atavisme	1808-1855. (Gérard Labrunie)	berkeley	4574
Le style est la poésie dans la prose, je veux dire une manière d'exprimer que la pensée n'explique pas.	CHARTIER Emile	Avec Balzac.		370     esprit	alias Alain (1868-1951)	berkeley	1233
Le plus difficile au monde est de dire en y pensant ce que tout le monde dit sans y penser.	CHARTIER Emile	Histoire De Mes Pensées.		370     esprit	alias Alain (1868-1951)	berkeley	1234
Qu'on remonte jusqu'au berceau des nations; qu'on descende jusqu' à nos jours ; qu'on examine les peuples dans toutes les positions possibles, depuis l'état de barbarie jusqu' à celui de civilisation la plus raffinée : toujours on trouvera la guerre.	MAISTRE Joseph de	Considérations sur la France.	1796	211     guerre		berkeley	4177
Il ne tient pas à vous de devenir riche, d'obtenir des emplois ou des honneurs, mais rien ne vous empèche d'être bon, généreux et sage.	VAUVENARGUES Marquis de	Conseils à un jeune homme.		520     ironie de soi	CLAPIER Luc de	berkeley	5269
Sur les sommets, il n'y a pas foule.	DE GAULLE Charles			440     courage		berkeley	1838
A moins d'être un génie, il vaut mieux s'efforcer d'être intelligible.  Unless one is a genius, it is best to aim at being intelligible.	HOPE Anthony	The Dolly Dialogues		234     communication	1863-1933. (Anglais)	berkeley	3228
Sac à vin! oeil de chien et coeur de cerf! 	Homère	L"Iliade, I, 225		210     violence	IXe ou VIIIe s. av. J.-C.	berkeley	3215
L'art fait qu'une copie offre souvent plus de charme que la nature elle-même.  Die Kunst ist es, welche macht, daß oft eine Kopie mehr reizt, als die Natur selbst.	WINCKELMANN Johann Joachim	Pensées sur l"imitation des Grecs dans la peinture et la sculpture		393     création artistique	1717-1768. (Allemand)	berkeley	5490
Fais ce qui te rend plus parfait, toi et ton prochain, et abstiens-toi de l'opposé.	VON WOLF Christian			390     création		berkeley	5338
Chaque homme doit rejoindre ses propres dieux par sa propre voie ; mais tous les dieux sont les images d'un seul...	WEST Morris	Kaloni le navigateur.	1976	140     rapport à la cosmogonie		berkeley	5355
Le devoir, l'honneur! Des mots à qui on fait dire ce qu'on veut, comme aux perroquets.	CAPUS Alfred	Mariage bourgeois		215     mystifications	1858-1922.	berkeley	1032
Or, quand on lève le handicap de la dylexie, il semble que dans de nombreux cas, cela provoque comme une libération des facultés intellectuelles et une plus grande facilité sur tous les plans - ce qui au fond est assez logique dans la mesure où un handicap est par définition inhibiteur.	LAMBRICHS Louise L.	La Dyslexie en question.	1989	410     santé		berkeley	4018
La Justice n'a rien à voir avec la Loi qui n'en est que la déformation, la charge et la parodie. Ce sont l à deux demi-soeurs qui, sorties de deux pères, se crachent à la figure en se traitant de bâtardes et vivent à couteaux tirés, tandis que les honnêtes gens, menacés des gendarmes, se tournent les pouces et les sangs en attendant qu'elles se mettent d'accord.	COURTELINE Georges	La Philosophie de G. Courteline		215     mystifications	1860-1929. (Georges Moinaux)	berkeley	1697
Tous les drapeaux ont été tellement souillés de sang et de m... qu'il est temps de n'en plus avoir du tout.	FLAUBERT Gustave	Correspondance, 1842, à George Sand, 1869		215     mystifications	1821-1880.	berkeley	2715
Il n'arrive jamais de grands évènements intérieurs à ceux qui n'ont rien fait pour les appeler à eux.	MAETERLINCK Maurice	La Sagesse et la Destinée.		321     volonté		berkeley	4164
Il vaut mieux être homme mécontent qu'un pourceau satisfait, être Socrate malheureux plutôt qu'un imbécile content, et si l'imbécile et le pourceau sont d'un autre avis, c'est qu'ils ne connaissent qu'un côté de la question. Les autres connaissent les deux côtés.	MILL John Stuart	Pour la Liberté.		520     ironie de soi		berkeley	4284
Les fausses opinions ressemblent à la fausse monnaie qui est frappée d'abord par de grands coupables, et dépensée ensuite par d'honnêtes gens qui perpétuent le crime sans savoir ce qu'ils font.	MAISTRE Joseph de	Les Soirées de Saint-Pétersbourg		215     mystifications	1753-1821.	berkeley	4183
Et ne voyais-tu pas dans mes emportements, Que mon coeur démentait ma bouche à tout moments ?	RACINE Jean	Andromaque		530     ironie amoureuse		berkeley	4789
Pour vous seuls, fils de la doctrine et de la science, nous avons écrit cette oeuvre. Scrutez le livre, recueillez-vous dans cette intention que nous avons dispersée et placée en plusieurs endroits ; ce que nous avons occulté dans un endroit, nous l'avons manifesté dans un autre, afin que votre sagesse puisse le comprendre.	VON NETTESHEIM Heinrich Cornélius A.	De Occulta Philosophia. 3/65.		421     initiation		berkeley	5337
Nous ne sommes pas autre chose que l'image que nous donnons de nous-mêmes. Alors mieux vaut y regarder à deux fois avant de choisir son image.	VONNEGUT Kurt	Nuit noire.		120     grégarité		berkeley	5339
Vivent mes ennemis! Eux du moins ne peuvent pas me trahir.	MONTHERLANT Henry Millon de	Malatesta, I, 8, Malatesta		222     fourberie	1896-1973.	berkeley	4468
Qu'est-ce qu'un blocage, sinon cette illusion que l'immobilité fera disparaitre le danger.	VOUTSINAS Andréas		1991	441     sang-froid	id	berkeley	5341
Il n'y a ni regard, ni paysage, ni fait divers qui ne recèle le reste du monde, en toute propriété.	CAYROL Jean	Histoire d"une prairie		140     rapport à la cosmogonie	1911-.	berkeley	1064
L'homme humble ne s'agenouille pas, il s'asseoit.	CLAUDEL Paul	Journal		441     sang-froid	1868-1955.	berkeley	1455
Il (Jean-Jacques Rousseau) m'a toujours paru un charlatan de vertu.	CHOISEUL Duchesse de	Lettres		221     vanité	1736-1801.	berkeley	1352
Une langue est une logique.	ZOLA Emile	Les Romanciers naturalistes, les Romanciers contemporains		365     discernement	1840-1902.	berkeley	5522
Seuls les artistes et les enfants voient la vie telle qu'elle est.  Nur Künstler und Kinder sehen das Leben wie es ist.	HOFMANNSTHAL Hugo von	Le Livre de Peter Altenberg		510     ironie	1874-1929. (Allemand)	berkeley	3200
L'art est de cacher l'art.	JOUBERT Joseph	Correspondance, à Mme Beaumont, 12 sept. 1801		393     création artistique	1754-1824.	berkeley	3458
Jean Todt passe 80% de son temps à aplanir les différends entre ses principaux collaborateurs. C'est ainsi que l'entreprise conserve son unité et son efficacité.	NICOLAS Jean-Pierre		1994	391     commandement	in "L"Equipe" du 2/08/94	berkeley	4582
Je suis très excessif. Je déteste les gens modérés. Je suis excessif par enthousiasme, par orgueil aussi. Mais après quinze ans de métier, je me rends compte que l'excès m'a autant servi qu'il m'a desservi.	CLUZET François	dossier de presse du film "DEUX".	1989	520     ironie de soi	comédien, metteur en scène.	berkeley	1485
L'Histoire et en particulier l'Histoire de l'Eglise a toujours été écrite pour justifier les survivants.	WEST Morris	Les bouffons de Dieu.	1981	215     mystifications	\\010q¥	berkeley	5362
Il n'y a pas d'horreur qui n'ait été divinisée, pas une vertu qui n'ait été flétrie.	SADE Marquis de	La Philosophie dans le boudoir		215     mystifications	1740-1814.	berkeley	4903
Il faut à une communauté une trentaine d'années environ pour intégrer à sa vie quotidienne un nouveau moyen de communication. C'est le temps qu'il avait fallu au 15ème siècle pour transformer la technique de l'imprimerie en production de livres. Le téléphone a été inventé en 1870 mais n'a pas affecté notre mode de vie avant les années 1900. Le cinématographe est né en 1890 mais l'industrie du cinéma ne devint une réalité qu'après 1920. La télévision, inventée dans les années 20, ne réussit à nous coller à nos fauteuils qu' à partir du milieu des années 50. On peut faire remonter la naissance du micro à une date située quelque part entre l'invention du microprocesseur en 1971 et l'introduction de l'ordinateur d'amateurs Altair en 1975.	CRINGELY Robert X.	Batisseurs d"empires par accident	1992	421     initiation		berkeley	1721
Heureux, tu ne le seras jamais tranquillement, le bonheur prenant sa source dans le déséquilibre paradoxal inhérent au passage d'un état d'esprit de moindre gratification à celui d'une gratification accrue.	FAIRGAGNETR Oscar	Vitalités.	1994	421     initiation		berkeley	2574
Nous aimons toujours ceux qui nous admirent, et nous n'aimons pas toujours ceux que nous admirons.	LA ROCHEFOUCAULD François de	Maximes		221     vanité	1613-1680.	berkeley	3800
On habite avec un coeur plein un monde vide, et sans avoir usé de rien, on est désabusé de tout.	CHATEAUBRIAND François-René de	monde vide,\\010b\\004p\\010b\\010p		442     démission		berkeley	1307
La seule politique que veuille la France, c'est une politique incolore, insipide, flasque; elle est prête à payer n'importe quoi pour avoir cette politique-l à; et elle paye, et elle l'a.	DARIEN Georges	La Belle France		221     vanité	1862-1921. (Georges Adrien)	berkeley	1763
Insectes bourdonnants, assembleurs de nuages,  Vous prendrez-vous toujours au piège des images? 	LAMARTINE Alphonse de	Cours familier de littérature* 		221     vanité	1790-1869.  *In Méditations poétiques.	berkeley	3995
Il faut qu'un maître apparaisse, indépendant en ses jugements, irrécusable dans ses ordres, crédité par l'opinion. Serviteur du seul Etat, dépouillé de préjugés, dédaigneux des clientèles ; commis enfermé dans sa tâche, pénétré de longs dessins, au fait des gens et des choses du ressort ; [...]dévoué à ceux qu'il commande, avide d'être responsable ; homme assez fort pour s'imposer, assez habile pour séduire, assez grand pour une grande oeuvre, tel sera le mini- stre, soldat ou politique, à qui la patrie devra l'économie prochaine de sa force.	DE GAULLE Charles	Vers l"armée de métier.	1934	391     commandement		berkeley	1823
[...] plus on se dispose à trahir son camp, mieux il faut le dominer.	RUFIN Jean-Christophe	La Dictature Libérale.		239     servitudes du pouvoir autoritaire	Le secret de la toute-puissance des démocraties au 20e siècle	berkeley	4897
La superstition porte malchance.	SMULLYAN Raymond	5000 B.C., 1.3.8.		441     sang-froid		berkeley	5090
Il y a deux Midi. Le Midi bourgeois, le Midi paysan. L'un est comique, l'autre est splendide.	DAUDET Alphonse	Les Carnets inédits		539     ironie sociale	1840-1897.	berkeley	1767
Le moment d'être sage est voisin du tombeau.	CHéNIER André de	Elégies		510     ironie	1762-1794.	berkeley	1337
Mais l'homme, quand il le faut, peut demeurer sans peur seul devant Dieu. Sa candeur le protège. Et il n'a besoin ni d'armes ni de ruses jusqu' à l'heure où l'absence de Dieu vient à son aide.	HÖLDERLIN Friedrich	peut demeure\\010t"∞\\010t&#236; 		441     sang-froid		berkeley	3210
Il n'est pas de pacte loyal entre les hommes et les lions.	Homère	L"Iliade, XXII, 262		232     servitudes du pouvoir	IXe ou VIIIe s. av. J.-C.	berkeley	3216
Que le plaisir se goûte au sortir des supplices! 	CORNEILLE Pierre	La Veuve, III, 8, Clarice		510     ironie	1606-1684.	berkeley	1675
Un homme doit savoir braver l'opinion ; une femme s'y soumettre.	STAEL Madame de	Delphine (épigraphe).		510     ironie		berkeley	5129
L'imaginaire est ce qui tend à devenir réel.	BRETON André	Le Revolver à cheveux blancs		350     imagination	1896-1966.	berkeley	848
Passer pour un idiot aux yeux d'un imbécile est une volupté de fin gourmet.	COURTELINE Georges	La Philosophie de G. Courteline		441     sang-froid	1860-1929. (Georges Moinaux)	berkeley	1702
Il* mourut, poursuivant une haute aventure,  Le Ciel fut son désir, la Mer sa sépulture;  Est-il plus beau dessein, ou plus riche tombeau? 	DESPORTES Philippe	Amours d"Hippolyte 		140     rapport à la cosmogonie	1546-1606.  *Icare.	berkeley	1963
De l'intuition de savoir s'arrêter avant de traverser le miroir.	FAIRGAGNETR Oscar	Vitalités.	1994	441     sang-froid	le 2 mai 1994, au soir de la disparition de Ayrton Senna, mort des suites de son accident du grand prix d"Imola.	berkeley	2613
Valéry est avant tout un voluptueux et tout son art est une attention voluptueuse.	CLAUDEL Paul	L"Oiseau noir dans le soleil levant		393     création artistique	1868-1955.	berkeley	1448
Plus haute est la faveur et plus prompte est la chute.	Destouches	L"Ambitieux, I, 7		539     ironie sociale	1680-1754. (Philippe Néricault)	berkeley	1970
Pour comprendre une autre culture, il faut se préparer respecter la façon de vivre dans laquelle elle trouve son expression, accepter cette conception de vie comme valable en soi et appropriée aux peuples en question.	DHINGRA Baldoon0	L"Orient par lui-même.		370     esprit		berkeley	1973
Qu'est-ce qui nous rend forts et persévérants? L'oraison humble et continuelle faite dans la cellule de la connaissance de soi-même et de la bonté de Dieu en soi.  Quale è quella cosa che ci fa forti e perseveranti? E l'orazione umile e continua, fatta nella casa del cognoscimento di sé e della bont à di Dio in sé.	STE.CATHERINE DE SIENNE	Lettere, A frère Filippo di Vannuccio		421     initiation	1347-1380. (Italienne)	berkeley	5141
Le mana, tu l'auras ; mais tu en patiras. Les gens s'appuieront sur toi et tu succomberas sous le poids. Ils te porteront au pinacle... et tu essayeras de les fuir, mais ils ne te laisseront pas échapper. Ce que tu feras à ce moment-l à, Dieu seul le sait. Et tu mourras en Le suppliant de te parler ; ou tu vivras en le suppliant de te laisser mourir, car le fardeau sera intolérable...	WEST Morris	Kaloni le navigateur	1976	232     servitudes du pouvoir		berkeley	5369
N'ayant jamais eu besoin de mentir à la maison, je me suis lancée dans le monde avec l'habitude de dire la vérité, ce qui a automati- quement éliminé de mon existence l'assomante monotonie que doivent ressentir les menteurs.	BROOKS Louise	Louise Brooks Par Louise Brooks.	1983	420     capital affectif	Autobiographie.	berkeley	869
L'unique garantie des citoyens contre l'arbitraire, c'est la publicité.	CONSTANT Benjamin			231     légitimité du pouvoir	1767-1830. (Henri-B. de Rebecque). Observations sur le Discours prononcé par S. E. le ministre de l"Intérieur.	berkeley	1623
Il faut se faire aimer, car les hommes ne sont justes qu'envers ceux qu'ils aiment.	JOUBERT Joseph	Pensées.		430     paradoxal émotionnel		berkeley	3465
Le remariage est le triomphe de l'espérance sur l'expérience.	JOHNSON Samuel			420     capital affectif		berkeley	3447
Deux ordres en sens contraires émanant d'officiers égaux en grade s'annulent. Mais, par contre, tout ordre provenant d'un officier supérieur à tous les autres a une autorité qui, non seulement est égale à sa masse multipliée par le carré de sa vitesse, mais en plus, du fait de l'accélération de la gravité, va en augmentant à mesure que l'ordre descend dans la hiérarchie.	SULITZER Paul-Loup	Cartel.	1990	391     commandement		berkeley	5162
Tous d'animalité grégaire avant que d'être humains...	FAIRGAGNETR Oscar	que d"être h\\010P\\025 à\\010P\\030ê		120     grégarité		berkeley	2478
Trouver d'abord. Chercher après.	COCTEAU Jean	Journal d"un inconnu		320     intuition	1889-1963.	berkeley	1501
Plus vous prétendez comprimer (la presse), plus l'explosion sera violente. Il faut donc vous résoudre à vivre avec elle.	CHATEAUBRIAND François-René de	Mémoires d"outre-tombe		214     guerre du savoir	1768-1848.	berkeley	1288
Le vice appuyé sur le bras du crime* 	CHATEAUBRIAND François-René de	Mémoires d"outre-tombe 		215     mystifications	1768-1848.  *Talleyrand au bras de Fouché, en 1815.	berkeley	1289
L'ordre est le plaisir de la raison: mais le désordre est le délice de l'imagination.	CLAUDEL Paul	Le Soulier de satin, Avertissement		430     paradoxal émotionnel	1868-1955.	berkeley	1453
Il y a trop de choses à comprendre en même temps.	CéLINE L.-F.	Voyage au bout de la nuit		442     démission	1894-1961. (Louis-Ferdinand Destouches)	berkeley	1079
Au moment où la foi sort du coeur, la crédulité entre dans l'esprit.	LAMENNAIS Félicité Robert de	Mélanges religieux et philosophiques		330     coeur	1782-1854.	berkeley	4024
On dit que pour apprécier pleinement les joies du paradis, il faut d'abord avoir passé par l'enfer.	COCHRAN Jacqueline	Aviatrice.	1955	421     initiation	Aviatrice américaine. Compétition et records. Edition condensée pour la jeunesse de son livre "Les Etoiles de Midi. France-Empire Ed.	berkeley	1487
Ce que j'ai accompli, moi qui n'étais privilégiée en rien, d'autres le peuvent aussi.	COCHRAN Jacqueline	Aviatrice.	1955	520     ironie de soi	Aviatrice américaine. Compétition et records. Edition condensée pour la jeunesse de son livre "Les Etoiles de Midi. France-Empire Ed.	berkeley	1488
Avant que de se jeter dans le péril, il faut le prévoir et le craindre; mais quand on y est, il ne reste plus qu' à le mépriser.	Fénelon	Les Aventures de Télémaque		441     sang-froid	1651-1715. (François de Salignac de La Mothe-)	berkeley	2696
Nous ne sommes parfaits sur rien, non pas même sur le mal.	FONTENELLE Bernard le Bovier de	Réflexions sur la poétique		510     ironie	1657-1757.	berkeley	2829
Pour agir, il faut une forte dose de défauts. Un homme sans défauts n'est bon à rien.	CHARDONNE Jacques	Propos comme ça.		520     ironie de soi	1884-1968	berkeley	1201
[...]  Herbe et miel, palme et feuille, Contre bleus et blessures, Contre maux et brûlures, protègent les petits [...]	KIPLING Rudyard	Le second livre de la Jungle.	1895	421     initiation	La dernière chanson, Baloo à Mowgli	berkeley	3557
On apprend plus par ce que les gens disent entre eux ou par ce qu'ils sous-entendent, qu'on pourrait le faire en posant bien des questions.	KIPLING Rudyard	Souvenirs.		421     initiation		berkeley	3558
Un fait n'est rien par lui-même, il ne vaut que par l'idée qui s'y rattache ou par la preuve qu'il fournit.	BERNARD Claude	Introduction à l"étude de la médecine expérimentale		432     expérience	1813-1878.	berkeley	704
On finit toujours par avoir la chance qu'on mérite.	FAIRGAGNETR Oscar	Vitalités.	1994	441     sang-froid		berkeley	2606
- Il n'y a pas d'honnêtes femmes, alors?  - Si! plus qu'on ne le croit, mais pas tant qu'on le dit.	DUMAS Alexandre	L"Ami des femmes, I, 5, Madame Leverdet puis De Ryons		539     ironie sociale	1824-1895. (fils)	berkeley	2238
L'art de la peinture ne peut être bien compris que par ceux qui eux-mêmes sont de bons peintres.  Die Kunst des Malens kann nicht wohl beurteilt werden denn allein durch die, die da selber gute Maler sind.	DÜRER Albrecht	Théorie des proportions		393     création artistique	1471-1528. (Allemand)	berkeley	2239
Lisez et relisez les campagnes d'Alexandre, d'Hannibal, de César, de Gustave-Adolphe, de Turenne, d'Eugène et de Frédéric. Faites-en vos modèles. C'est la seule façon de devenir un grand capitaine et de maitriser les secrets de l'art de la guerre.	Napoléon I	Maximes de Guerre	1831	211     guerre		berkeley	4555
L'authentique méchant, le vrai, le pur, l'artiste, il est rare qu'on le rencontre même une fois dans sa vie.	COLETTE Sidonie Gabrielle	La Naissance du jour		432     expérience	1873-1954.	berkeley	1554
Je vois, je sais, je crois, je suis désabusée.	CORNEILLE Pierre	Polyeucte, V, 5, Pauline		442     démission	1606-1684.	berkeley	1674
Notre salut et notre perte sont en dedans de nous-mêmes.	EPICTETE	Entretiens.		440     courage		berkeley	2348
...Les teintes inimitables du blanc qui fuient à perte de vue dans le blanc.	BERNARDIN DE SAINT-PIERRE Jacques-Henri	Etudes de la nature		510     ironie	1737-1814.	berkeley	722
Le plus haut degré de la sagesse humaine est de savoir plier son caractère aux circonstances et de se faire un intérieur calme en dépit des orages extérieurs.	DEFOE Daniel	Robinson Crusoë		550     grandeur		berkeley	1877
Thomas Edison trouva 1800 manières de ne pas fabriquer une ampoule.	OECH Roger von	Créatif de choc.	1983	380     travail	380     trav\\010r	berkeley	4621
Si vous n'avez pas de problème, prenez quand même le temps de jouer. Il se peut que vous trouviez de nouvelles idées.	OECH Roger von	Créatif de choc.	1983	390     création		berkeley	4622
Si la nécéssité est mère de l'invention, le jeu en est le père.	OECH Roger von	Créatif de choc.	1983	390     création		berkeley	4623
Qui vit esclave est né pour l'être.	LAGRANGE-CHANCEL François Joseph de	Odes		515     tragédie	1677-1758.	berkeley	3988
C'est la cendre des morts qui créa la patrie.	LAMARTINE Alphonse de	La Chute d"un ange		215     mystifications	1790-1869.	berkeley	3992
Un pas en divin, deux pas en humain ...	FARGUE Léon-Paul	Sous la lampe		510     ironie	1876-1947.	berkeley	2670
La faveur est la grande divinité des Français.	MONTESQUIEU Charles de	Lettres persanes		539     ironie sociale	1689-1755. (C. de Secondat, baron de La Brède et de M.)	berkeley	4455
Ainsi ils ne sont plus deux, mais une seule chair. Eh bien! ce que Dieu a uni, l'homme ne doit point le séparer.	Evangiles	Evangile selon saint Matthieu, XIX, 6		215     mystifications		berkeley	2420
Les destins sont jaloux de nos prospérités,  Et laissent plus durer les chardons que les roses.	RACAN Honorat de Bueil, marquis de	Sonnet, A Mgr le duc de Guise		510     ironie	1589-1670.	berkeley	4765
A ma connaissance, la seule manière de se débarrasser définitivement d'une fourmi de six mètres est de lancer contre elle une fourmi de dix-huit mètres.	SULITZER Paul-Loup	Cartel.	1990	441     sang-froid		berkeley	5164
Celui qui met un frein à la fureur des flots Sait aussi des méchants arrêter les complots.	RACINE Jean	Andromaque		441     sang-froid		berkeley	4785
Seigneur, dans cet aveu dépouillé d'artifice, J'aime à voir que du moins vous vous rendiez justice.	RACINE Jean	Andromaque		510     ironie		berkeley	4786
Puisse le vent être toujours derrière vous.	Dictons et Proverbes	Proverbe irlandais		140     rapport à la cosmogonie		berkeley	1996
Aucun de nous ne réussit dans toutes ses entreprises et notre existence à tous comporte quelques faillites. L'essentiel, c'est de ne pas flancher au moment d'une tentative et de soutenir jusqu'au bout l'effort de notre vie.	CONRAD Joseph	Le Duel		440     courage		berkeley	1617
Presque tous les hommes, frappés par l'attrait d'un faux bien ou d'une vaine gloire, se laissent séduire, volontairement ou par ignorance, à l'éclat trompeur de ceux qui méritent le mépris plutôt que la louange.	MACHIAVEL Nicolas	Discours sur Tite-Live.		221     vanité		berkeley	4159
Joyce fit en sorte que son texte soit un véritable champ de mines, se délectant à l'avance à l'idée que, longtemps après sa mort, l'un de ses engins exploserait de temps à autre et causerait quelques dégats dans le paysage littéraire.	GIRARD René			393     création artistique		berkeley	2961
Toute oeuvre d'opposition est une oeuvre négative et la négation, c'est le néant. Il ne faut pas renverser, il faut batir.	GOETHE Johann Wolfgang von	Conversations.	1825	110     entropie	1749/1832.	berkeley	2970
On doit appeler machine, dans le sens le plus étendu, toute idée sans penseur.	CHARTIER Emile	Propos Sur La Religion.		370     esprit	alias Alain (1868-1951)	berkeley	1231
A la question toujours posée : 'Pourquoi écrivez-vous ?', la réponse du poète sera toujours la plus brève : 'Pour mieux vivre'.	SAINT-JOHN PERSE	Pour Dante.		393     création artistique		berkeley	4936
La grande peinture est une peinture où les intervalles sont chargés d'autant d'énergie que les figures qui les déterminent.	MASSON André			393     création artistique		berkeley	4245
Eugène s'amusa de cette scène ; avec son insolente santé, l'enfant ne s'en était pas laissé conter comme lui. Il n'avait pas succombé à la fascination de la force et avait conservé son impertinence. Eugène songea au prix du précieux pouvoir d'irrespect, condition première de toute lucidité.	COMBESCOT Pierre	Les Chevaliers du Crépuscule.	1975	370     esprit		berkeley	1576
[ ] ils avaient encore le visage de l'ombre ; la lande et la montagne étaient leur refuge [ ].	COMBESCOT Pierre	Les Chevaliers du Crépuscule		421     initiation		berkeley	1577
S'engager dans le chemin ? Au fond, pourquoi pas ? Quitte si la route est mauvaise, à se jeter dans le premier chemin de traverse et suivre son humeur buissonnière.	COMBESCOT Pierre	Les Chevaliers du Crépuscule.		510     ironie		berkeley	1578
La civilisation n'est autre chose que le mode de végétation propre à l'humanité 	HUGO Victor	Tas de pierres		539     ironie sociale	1802-1885.	berkeley	3347
Chacun de nous ment à propos de ce qui est particulièrement important pour lui.	WEST Morris	Toute la vérité.	1957	215     mystifications		berkeley	5363
Vous ne pouvez jamais enterrer la vérité si profondément qu'on ne puisse la déterrer.	WEST Morris	L"Avocat du diable.	1959	222     fourberie		berkeley	5364
Opposition. En politique, le parti qui empêche le gouvernement de s'emballer en lui coupant les jarrets.  Opposition. In politics the party that prevents the Government from running amuck by hamstringing it.	BIERCE Ambrose	The Devil"s Dictionary		510     ironie	1842-1914. (Américain)	berkeley	744
Journal intime. Relation quotidienne de la partie de notre existence que nous pouvons nous raconter sans rougir.  Diary. A daily record of that part of one's life which he can relate to himself without blushing.	BIERCE Ambrose	The Devil"s Dictionary		510     ironie	1842-1914. (Américain)	berkeley	745
Erudition. Poussière tombée d'un livre dans un crâne vide.  Erudition. Dust shaken out of a book into an empty skull.	BIERCE Ambrose	The Devil"s Dictionary		510     ironie	1842-1914. (Américain)	berkeley	746
La philosophie ne sert qu' à réfuter la philosophie.	BILDERDIJK Willem	Lettre à Kinter		370     esprit	1756-1831. (Néerlandais)	berkeley	747
Il y a un pays natal dans le temps comme il y en a un dans l'espace.	BILLY André	Le Pont des Saints-Pères		420     capital affectif	1882-1971.	berkeley	748
Le feu n'a plus de fumée quand il est devenu flamme.	Djalal Al-Dîn Rûmi	Mathnawi		310     énergie	1210-1273. Persan.	berkeley	2128
Un homme bas fait un peuple bas ; seul un grand est digne du mana !	WEST Morris	Kaloni le navigateur	1976	391     commandement		berkeley	5395
Si le Seigneur ne construit pas la maison, les ouvriers travaillent en vain.	WEST Morris	Les bouffons de Dieu.	1981	391     commandement		berkeley	5396
[...] je me suis rendu compte, au fil des années, qu'il vaut mieux persuader qu'imposer.	WEST Morris	Lazare.	1990	432     expérience		berkeley	5422
Il y a une limite à ce que le corps et l'esprit humain sont capables d'endurer.	WEST Morris	La seconde victoire.	1972	520     ironie de soi		berkeley	5447
On en use ainsi chez les grands:  La raison les offense; ils se mettent en tête  Que tout est né pour eux, quadrupèdes et gens  Et serpents.	LA FONTAINE Jean de	Fables, l"Homme et la Couleuvre		221     vanité	1621-1695.	berkeley	3661
Ne soyons pas si difficiles:  Les plus accommodants, ce sont les plus habiles.	LA FONTAINE Jean de	Fables, le Héron		221     vanité	1621-1695.	berkeley	3662
Le plus âne des trois n'est pas celui qu'on pense.	LA FONTAINE Jean de	Fables, Le meunier, son fils et l"âne.		221     vanité		berkeley	3663
Ce loup ne savait pas encor bien son métier.	LA FONTAINE Jean de	Fables, le Loup et le Chien maigre		510     ironie	1621-1695.	berkeley	3745
Il n'y a rien de plus beau qu'une clé, tant qu'on ne sait pas ce qu'elle ouvre.	MAETERLINCK Maurice	Aglavaine et Sélysette.		510     ironie	1862/1949	berkeley	4170
Rien ne vaut rien, Il ne se passe rien, Et cependant tout arrive, Mais cela est indifférent...	NIETZSCHE Friedrich	Zarathoustra		433     perversion	Inévitable conclusion de la la réflexion de l"intelligence sans la foi.	berkeley	4591
L'homme est une corde tendue entre l'animal et le Surhomme, une corde au-dessus d'un abîme.	NIETZSCHE Friedrich	Ainsi parlait Zarathoustra		510     ironie		berkeley	4593
L'art de peindre n'est que l'art d'exprimer l'invisible par le visible.	FROMENTIN Eugène	Les Maîtres d"autrefois		393     création artistique	1820-1876.	berkeley	2893
Selon la stratégie classique des guerres d'autrefois, il avait visé les hautes terres et les avait conquises. [...] Il n'était plus un homme dépendant, ne faisait plus partie des amateurs, mais des profes- sionnels qu'on respectait. Il n'y aurait plus d'examens de passage. Sa position ne serait plus remise en question.	WEST Morris	De main de Maître.	1988	230     pouvoir		berkeley	5365
Quand on tappe juste et qu'on tappe fort, on peut aller jusqu'au bout de son action.	SAPIN Michel	ppe fort, on\\010}ö∞\\010}û@\\020	1994	230     pouvoir	Ministre du budget du dernier gouvernement Bérégovoy, promoteur de la loi réformant le commerce de la communication et de la publicité portant son nom. Décryptages, F3 le 27/04/94.	berkeley	4951
Le remède le plus honteux à l'affliction chez un homme raisonnable, c'est de guérir par lassitude.  Turpissimum est in homine prudenti remedium moeroris lassitudo moerendi.	Sénèque	Lettres à Lucilius, LXIII		110     entropie		berkeley	5026
Mais si on veut les séparer Le coudrier meurt promptement, Le chèvrefeuille mêmement. Belle amie, ainsi de nous : Ni vous sans moi, ni moi sans vous.	FRANCE Marie de	Poésies.		531     communication amoureuse		berkeley	2874
Qui boit le vin du prince doit subir la migraine du prince - et s'estimer heureux si le prince ne lui envoie pas le bourreau pour l'en guérir !	WEST Morris	Toute la vérité.	1957	441     sang-froid		berkeley	5430
La vérité ne fait pas tant de bien dans le monde que ses apparences y font de mal.	LA ROCHEFOUCAULD François de	Maximes		215     mystifications	1613-1680.	berkeley	3792
..Ce qui domine et qui apparait au premier contact, c'est une probité intellectuelle qui lui interdit de se contenter de l'  à-peu-près, qui refuse de s'endormir sur la sécurité d'une formule [...]. Sans égard pour les conséquences de sa sincérité [...] il reconnait hautement la valeur de ses adversaires comme il dénonce les insuffisances de ses amis. Il avoue sans gêne son ignorance. [...] Ce trait est encore accentué par une rigidité morale qui ne transige pas... Il est pour lui-même d'une extrème sévérité. L'injustice, l'intolérance, l'inconduite, le manque de courage lui font horreur. Ses scrupules se manifestent dans son exactitude, le soin qu'il apporte à sa toilette, son souci des nuances, son application à rédiger d'une écriture nette, lisible, bien ponctuée.	MARTIN DU GARD Roger		1922	550     grandeur	sur Emile MAYER	berkeley	4240
Le romancier est l'historien du présent, alors que l'historien est le romancier du passé.	DUHAMEL Georges	Le Notaire du Havre		540     mémoire	1884-1966.	berkeley	2221
Les dangers dont je vous ai parlé commenceront dès votre premier contact, car vous n'avez aucune couverture diplomatique et le langage politique est fait pour dissimuler la vérité.	WEST Morris	Les bouffons de Dieu.	1981	238     servitudes du pouvoir politique		berkeley	5374
Si Dieu pouvait tout à coup être condamné à vivre de la vie qu'il inflige à l'homme, il se tuerait.	DUMAS Alexandre	Pensée d"album		510     ironie	1824-1895. (fils)	berkeley	2237
Le public est extraordinairement tolérant. Il pardonne tout sauf le génie.	WILDE Oscar	The Critic As An Artist.		120     grégarité		berkeley	5465
Il faut plus d'une île verte Sur la mer profonde et vaste...	SHELLEY			234     communication		berkeley	5075
Enfin, je crois avoir compris une chose, une grande chose,  c'est que le bonheur pour les gens de notre race est dans l'idée et pas ailleurs.	FLAUBERT Gustave	L"amour de l"art.	1915	320     intuition	(1821/1880) édition posthume	berkeley	2730
L'extrême civilisation engendre l'extrême barbarie.	DRIEU LA ROCHELLE Pierre	Les Chiens de paille		210     violence	1893-1945.	berkeley	2155
Nous saurons qui nous sommes quand nous verrons ce que nous avons fait.	DRIEU LA ROCHELLE Pierre	Le Chef		390     création	1893-1945.	berkeley	2156
Nous marier? Des gens qui s'aiment! 	MARIVAUX Pierre Carlet de Chamblain de	Le Petit Maître corrigé, II, 6		531     communication amoureuse	1688-1763.	berkeley	4237
Je suis homme avant d'être Français.	MONTESQUIEU Charles de	Mes pensées		365     discernement	1689-1755. (C. de Secondat, baron de La Brède et de M.)	berkeley	4433
Mais ne dit-on point que le fils n'est jamais que l'extension du père?	HERBERT Franck	Dune	1965	420     capital affectif		berkeley	3137
Les dieux existent: c'est le diable.	COCTEAU Jean	La Machine infernale		215     mystifications	1889-1963.	berkeley	1493
La vérité c'est qu'on est jamais seul et qu'on n'est jamais avec les autres.	WOOLF Virginia	La Traversée des Apparences.		423     solitude		berkeley	5492
Ecrit, bien écrit: Mot de portiers pour désigner les romans-feuilletons qui les amusent.	FLAUBERT Gustave	Dictionnaire des idées reçues		221     vanité	1821-1880.	berkeley	2720
L'ordre est le plaisir de la raison : mais le désordre est le délice de l'imagination.	CLAUDEL Paul	Le soulier de satin.		390     création		berkeley	1446
Quand le fou du roi en vint à le perdre, il lui fallut devenir un guerrier pour ne pas le suivre dans la tombe.	FAIRGAGNETR Oscar		1990	210     violence	"Toutes considérations égales par ailleurs"	berkeley	2495
Ah! frappe-toi le coeur, c'est l à qu'est le génie.	MUSSET Alfred de	Premières Poésies, A mon ami Ed. Boucher		330     coeur	1810-1857.	berkeley	4529
Personne ne rougit d'être bas à la cour.	Holbach	Morale universelle		120     grégarité	1723-1789. (Paul Henri Dietrich, baron d")	berkeley	3201
Il y a une mélancolie qui tient à la grandeur de l'esprit.	CHAMFORT Nicolas-Sébastien de	Maximes et pensées		510     ironie	1740/1794. Ac. Française	berkeley	1140
Ton affaire, c'est de jouer correctement le personnage qui t'a été confié; quant à le choisir, c'est celle d'un autre.	EPICTETE	Manuel, XVII		425     charisme	v. 50-v. 125.	berkeley	2351
Qui apprend une nouvelle langue acquiert une nouvelle âme.  El que aprende una nueva lengua, adquiere una nueva alma.	JIMéNEZ Juan Ramon	Primeras prosas, En la alameda verde		370     esprit	1881-1958. (Espagnol)	berkeley	3437
Solitude, énergie et bonne mine sont les recettes du succès qui préserve et fait rêver.	FAIRGAGNETR Oscar		1992	423     solitude		berkeley	2578
Il nous dit : 'La vision du temps est vaste mais lorsque vous le traversez, le temps devient une porte étroite.' Et il luttait toujours contre la tentation d'emprunter les voies dégagées, sures, disant : 'Ce chemin n'aboutit qu' à la stagnation.'	HERBERT Franck	Dune	1965	440     courage		berkeley	3148
Je détermine l'authentique valeur d'un homme d'après une seule règle : à quel degré et dans quel but l'homme s'est libéré de son moi ?	EINSTEIN Albert	Comment je vois le Monde	1934	441     sang-froid	rééd.corr. en 1952 et 1978.	berkeley	2318
La liberté est le droit de faire tout ce que les lois permettent.	MONTESQUIEU Charles de	L"Esprit des Lois.		130     liberté		berkeley	4397
Le langage est de la poésie fossile.  Language is fossil poetry.	EMERSON Ralph Waldo	Essays, The Poet		234     communication	1803-1882. (Américain)	berkeley	2339
Je ne vois partout que des gens qui font le bien et qui le font mal.	LA BEAUMELLE Laurent Angliviel de	Mes pensées ou le Qu"en-dira-t-on		510     ironie	1726-1773.	berkeley	3581
La liberté n'existe que l à où l'intelligence et le courage parviennent à mordre sur la fatalité.	CAILLOIS Roger	L"Incertitude qui vient des rêves		130     liberté	1913-1978.	berkeley	953
L'homme est le seul animal à refuser d'être ce qu'il est.	CAMUS Albert			430     paradoxal émotionnel		berkeley	1006
L'homme pense son propre chant, et ne pense rien d'autre.	CHARTIER Emile	Propos De Littérature.		520     ironie de soi	alias Alain (1868-1951)	berkeley	1278
Le plus bel amour ne va pas loin si on le regarde courir. Mais plutôt il faut le porter à bras comme un enfant chéri.	CHARTIER Emile	Esquisses De L"homme.		531     communication amoureuse	alias Alain (1868-1951)	berkeley	1279
Les princes ont un pouvoir infini sur ceux qui les approchent; et ceux qui les approchent ont une faiblesse infinie en les approchant.	Fénelon	Examen de conscience sur les devoirs de la royauté		232     servitudes du pouvoir	1651-1715. (François de Salignac de La Mothe-)	berkeley	2688
Il ne suffit point de montrer la vérité, il faut la peindre aimable.	Fénelon	Les Aventures de Télémaque		234     communication	1651-1715. (François de Salignac de La Mothe-)	berkeley	2689
Toute vue de choses qui n'est pas étrange est fausse. Si quelque chose est réelle, elle ne peut que perdre de sa réalité en devenant familière. Méditer en philosophie, c'est revenir du familier à l'étrange, et dans l'étrange affronter le réel.	VALERY Paul	Choses Vues.		370     esprit	(îuvres, II, p. 501, Biblio. de la Pléiade, Gallimard)	berkeley	5238
Il se faut entraider, c'est la loi de nature.	LA FONTAINE Jean de	Fables, l"Ane et le Chien		331     altruisme	1621-1695.	berkeley	3696
La seule liberté, les hommes ne la désirent point.	LA BOéTIE Etienne de	Le discours de la servitude volontaire.		110     entropie	1530/1563. ami de Montaigne.	berkeley	3582
L'esprit n'est que le sel de la conversation, non sa nourriture.	HAZLITT William	Conférences sur les écrivains comiques anglais.		234     communication		berkeley	3090
Mieux vaut ne savoir ni lire ni écrire que d'être incapable de rien faire d'autre.  It is better to be able neither to read nor write than to be able to do nothing else.	HAZLITT William	On the Ignorance of the Learned		433     perversion	1778-1830. (Anglais)	berkeley	3091
Il n'y a pas de mal plus grand, et des suites plus funestes, que la tolérance d'une tyrannie qui la perpétue dans l'avenir.	MONTESQUIEU Charles de	Mes pensées		239     servitudes du pouvoir autoritaire	1689-1755. (C. de Secondat, baron de La Brède et de M.)	berkeley	4429
Dépasser les limites n'est pas un moindre défaut que de rester en deç à.	CONFUCIUS	Entretiens, VI, 11		510     ironie	551-479 av. J.-C. (Chinois)	berkeley	1604
Celui qui ne sait pas ce que c'est que la vie, comment saura-t-il ce que c'est que la mort? 	CONFUCIUS	Entretiens, VI, 11		510     ironie	551-479 av. J.-C. (Chinois)	berkeley	1605
... entre nos ennemis  Les plus à craindre sont souvent les plus petits.	LA FONTAINE Jean de	Fables, le Lion et le Moucheron		441     sang-froid	1621-1695.	berkeley	3735
Plutôt souffrir que mourir,  C'est la devise des hommes.	LA FONTAINE Jean de	Fables, la Mort et le Bûcheron		510     ironie	1621-1695.	berkeley	3739
Nous n'écoutons d'instincts que ceux qui sont les nôtres,  Et ne croyons le mal que quand il est venu.	LA FONTAINE Jean de	Fables, l"Hirondelle et les Petits Oiseaux		520     ironie de soi	1621-1695.	berkeley	3751
Ouvrez les yeux! Le monde est encore intact; il est vierge comme au premier jour, frais comme le lait! 	CLAUDEL Paul	Art poétique		321     volonté	1868-1955.	berkeley	1441
... Ce n'est pas l'esprit qui est dans le corps, c'est l'esprit qui contient le corps, et qui l'enveloppe tout entier.	CLAUDEL Paul	Le Soulier de satin, I, 6, le roi		321     volonté	1868-1955.	berkeley	1442
Celui qui aime beaucoup ne pardonne pas facilement.	CLAUDEL Paul	L"Otage, I, 1, Coûfontaine		330     coeur	1868-1955.	berkeley	1443
Le malheur revêt toujours le visage de la guerre. Parfois elle est réelle avec des bruits de bombes, des morts et concerne des millions d'autres personnes, parfois - et le résultat est identique - une seule personne est concernée, vous, et c'est le même deuil. Un monde ancien qui se brise, le ventre et le cerveau qui se déchirent et il faut alors apprendre à exister avec son corps, rien que cette machine à vivre, nu, sans rien qui relie à un quelqu'autre objet du monde, sinon cette brûlure incessante qui réveille la nuit, et veille le jour à embellir le souvenir de ce qui a désormais disparu.	SIMON Yves	La Dernière Passion. (Les Séductions de l"Existence)	1990	440     courage		berkeley	5085
Les tourterelles se fuyaient:  Plus d'amour, partant plus de joie.	LA FONTAINE Jean de	Fables		110     entropie	1621-1695.	berkeley	3642
On est plus heureux dans la solitude que dans le monde. Cela ne viendrait-il pas de ce que, dans la solitude, on pense aux choses et que dans le monde on est forcé de penser aux hommes.	CHAMFORT Nicolas-Sébastien de	Maximes et pensées		423     solitude	1740/1794. Ac. Française	berkeley	1123
La poésie demande un génie particulier, qui ne s'accommode pas trop avec le bon sens. Tantôt, c'est le langage des dieux, tantôt c'est le langage des fous, rarement celui d'un honnête homme.	SAINT-EVREMOND Charles de	Sur les caractères des tragédies, De la poésie		393     création artistique	v. 1614-1703 	berkeley	4915
Le goût, tel un canal artificiel, traverse une belle contrée ; mais ses bords sont bornés et son étendue, limitée. La connaissance navigue sur l'océan, et elle est perpétuellement en voyage de découverte.	DISRAELI Benjamin	Curiosités de la littérature.		341     étonnement	Lord BEACONSFIELD (1804/1881)	berkeley	2126
L'artiste n'est pas l à pour être en accord avec le monde, il est l à pour le transformer.	NIN Anaïs	Journal.		234     communication		berkeley	4597
Nous sommes des serviteurs inutiles ; nous n'avons fait que ce que nous devions faire.	Nouveau Testament	Luc, XVII, 10 (Segond)		520     ironie de soi		berkeley	4610
Pour une conscience aux abois, le salut réside dans l'action.	VALTIN Jan	Sans patrie ni frontières		441     sang-froid	alias Richard KREBS, ex-agent du Komintern	berkeley	5252
A la guerre ... il n'y a pas de gagnants, il n'y a que des perdants.  In war ... there are no winners, but all are losers.	CHAMBERLAIN Sir	Speech at Kettering, 3 juillet 1938	1938	211     guerre	1869-1940. (Anglais)	berkeley	1101
La peur de la solitude, c'est dans la foule, à Paris, que je l'ai connue, jamais en mer.	MOITESSIER Bernard			120     grégarité		berkeley	4292
L'imagination est la force motrice de la recherche.	REEVES Hubert			390     création		berkeley	4801
Nous n'aurons jamais trop de ces fiers esprits qui jugent, critiquent et résistent. Ils sont le sel de la cité.	CHARTIER Emile	Propos D"un Normand, T. I.		130     liberté	alias Alain (1868-1951)	berkeley	1210
Le Français? Un être qui est avant tout le contraire de ce que vous croyez.	DANINOS Pierre	Les Carnets du major W. Marmaduke Thompson		539     ironie sociale	1913-.	berkeley	1748
Reprends la route qui va où tu dors ...	LAUTRéAMONT Comte de	Les Chants de Maldoror		560     sagesse	1846-1870. (Isidore Ducasse)	berkeley	4054
On a le pied fait à sa chaîne.	CORBIERE Tristan	Ça		520     ironie de soi	1845-1875. (Edouard Joachim Corbière)	berkeley	1646
Si tu es sage, ne le dis pas et n'en montre pas les raisons, car on dira que tu veux tromper.	NERVAL Gérard de	Sur un carnet		120     grégarité	1808-1855. (Gérard Labrunie)	berkeley	4565
L'homme qui est poète à vingt ans n'est pas poète, il est homme ; s'il est poète après vingt ans, alors il est poète.	PEGUY Charles	Clio.		421     initiation		berkeley	4664
Le génie est une question de muqueuses. L'art est une question de virgules.	FARGUE Léon-Paul	Sous la lampe		390     création	1876-1947.	berkeley	2657
La Grèce conquise conquit son farouche vainqueur et porta les arts au sein du Latium rustique.  Graecia capta ferum victorem cepit, et artes intulit agresti Latio.	Horace	Epîtres, II, I, 156	156	425     charisme	65-8 av. J.-C. (Quintus Horatius Flaccus)	berkeley	3247
Si tu veux être aimé, aime.  Si vis amari, ama.  Lettres à Lucilius, IX  	Sénèque			330     coeur	Même pensée dans le Panégyrique de Trajan de Pline le Jeune: "Habes amicos, quia amicus ipse es": Tu as des amis, parce que tu es toi-même leur ami. Ainsi que dans les Epigrammes de Martial.	berkeley	5025
A chaque époque, les lois du commerce ont été édictées par la nation industrielle dominante. Au XIXe siècle, c'était la Grande-Bretagne ; au XXe siècle, cela aura été les Etats-Unis.	GOLDSMITH Jimmy	Le Piège.	1993	212     guerre économique		berkeley	2987
Sur les ailes du Temps la tristesse s'envole.	LA FONTAINE Jean de	Fables. La Jeune Veuve.		540     mémoire	1621-1695.	berkeley	3761
La guigne n'aime que les maigres.	CROMMELYNCK Fernand	Chaud Et Froid.		410     santé	1886-1970	berkeley	1723
La vie est doute,  et la foi sans le doute n'est autre que la mort.  La vida es duda,  y la fe sin la duda es solo muerte.	UNAMUNO Miguel de	Salmo, II		221     vanité	1864-1936. (Espagnol)	berkeley	5227
L'homme, par le fait d'être homme, d'avoir conscience, est déj à, par rapport à l'âne ou au crabe, un animal malade. La conscience est une maladie.	UNAMUNO Miguel de			510     ironie		berkeley	5230
La lune se soucie-t-elle de l'aboiement d'un chien?  Doth the moon care for the barking of a dog? 	BURTON Robert	The Anatomy of Melancholy, II		510     ironie	1577-1640. (Anglais)	berkeley	919
Il faut souffler sur quelques lueurs pour faire de la bonne lumière.	CHAR René	Les Matinaux		390     création	1907-1988.	berkeley	1178
Au plus fort de l'orage, il y a toujours un oiseau pour nous rassurer. C'est l'oiseau inconnu. Il chante avant de s'envoler.	CHAR René	Les Matinaux		432     expérience	1907-1988.	berkeley	1179
Je n'ai rien à offrir que du sang, du labeur, des larmes et de la sueur.  I have nothing to offer but blood, toil, tears and sweat.  	CHURCHILL Sir Winston Leonard Spencer			440     courage	1874-1965.   Paroles prononcées par Winston Churchill le 13 mai 1940 devant la Chambre des Communes, au moment de l"attaque allemande en Belgique et en France.	berkeley	1370
Dans la mesure où vous parvenez à dépasser l'intellect, le conscient qui résonne, vous libérez la puissance intérieure qui vous habite.	KRAMER Edward L.	Chemins vers la puissance.		140     rapport à la cosmogonie		berkeley	3573
La divinité qui s'amuse A me demander mon secret, Si j'étais Apollon, ne serait point ma Muse ; Elle serait Thétis, et le jour finirait.	SAINT-AULAIRE Marquis de			530     ironie amoureuse	 à la duchesse du Maine.	berkeley	4914
Toute beauté est joie qui demeure.  A thing of beauty is a joy for ever.  Endymion	KEATS John	e.		420     capital affectif	1795-1821. (Anglais)	berkeley	3541
Le bonheur est l'essor intégral de toutes les passions.	FOURIER			110     entropie		berkeley	2850
Défie toi toujours, avec courtoisie, des 'miss Paramount system'é	FAIRGAGNETR Oscar	Vitalités.	1998	240     débauche		berkeley	2457
Défie toi de la faute d'élégance; elle est violence.	FAIRGAGNETR Oscar	Vitalités.	1998	210     violence		berkeley	2458
Ne cherche jamais ton bonheur dans l'approbation collective.	FAIRGAGNETR Oscar	Vitalités.	1998	140     rapport à la cosmogonie		berkeley	2459
La cour est un théâtre où l'on voit à la fin  Le pauvre venir riche et le riche coquin.	TRELLON Claude de	Le Portrait de la cour		120     grégarité	v. 1560-? 	berkeley	5221
Quand il n'y a pas assez d'amour, il n'y a jamais assez de temps [...]	WEST Morris	Toute la vérité.	1957	420     capital affectif		berkeley	5403
Drape d'orgueil la misère de sa solitude... Bien sensible mais à ce qui le touche... Il n'a jamais entrepris rien que le résultat n'ait payé... Les traverses de sa carrière lui avaient conservé intact cet esprit critique dont la faveur et la réussite dépouillent souvent les plus avancés Trop assuré pour renoncer trop ambitieux pour être arriviste trop personnel pour faire fi des autres trop prudent pour ne point risquer Sa philosophie, c'est l'ajustement Impénétrable et même une ombre d'ironie dont il fait un rempart pour sa pensée et son repos Ayant par nature et par réflexion le goût de l'action longuementmûrie et préparée où la méthode se déploie... Plus de grandeur que de vertu.	DE GAULLE Charles	Lettres, notes et carnets.		110     entropie	portrait de Philippe Pétain.	berkeley	1784
Le temps est l'étoffe de la Réalité.	DE GAULLE Charles			432     expérience		berkeley	1835
En quelque manière qu'on se puisse mettre à l'abri des coups, fût-ce sous la peau d'un veau, je ne suis pas homme qui y reculasse.	MONTAIGNE Michel Eyquem de	Essais, I, 20		442     démission	1533-1592.	berkeley	4371
Tous les jours vont à la mort, le dernier y arrive.	MONTAIGNE Michel Eyquem de	Essais, I, 20		510     ironie	1533-1592.	berkeley	4373
Il était un chevalier qui cherchait dans ce monde ce qui n'est pas usé, quotidien, éculé.	GIRAUDOUX Jean	Ondine.		440     courage		berkeley	2965
Ceux qui se contentent de demeurer dans la vallée ne recevront rien des montagnes.	KRAMER Edward L.	Chemins vers la puissance.		321     volonté		berkeley	3575
La rubrique petites annonces d'un journal vous en apprend beaucoup plus sur la mentalité des gens que la page de 'une'. Dans les petites annonces, il y a tout ce que les gens désirent, et cela me donne des idées.	OECH Roger von	Créatif de choc.	1983	214     guerre du savoir	\\010l≤ \\020	berkeley	4619
Quel esprit ne bat la campagne?  Qui ne fait châteaux en Espagne? 	LA FONTAINE Jean de	Fables		433     perversion	1621-1695.	berkeley	3717
Rien de précieux n'est transmissible. Une vie heureuse est un secret perdu.	CHARDONNE Jacques	Claire		432     expérience	1884-1968.	berkeley	1194
L'homme, quoi qu'on dise, est le maître de son destin. De ce qu'on lui a donné, il peut toujours faire quelque chose.	GRENIER Jean	Inspirations méditerranéennes		441     sang-froid	1898-1971.	berkeley	3017
Toute chose naît pour périr,  Et tout ce qui périt retourne  Pour une autre fois refleurir.	GARNIER Robert	Cornélie		510     ironie	v. 1545?-1590 	berkeley	2916
Tout ce qui fait mouche est parfait, il n'existe rien d'autre.	PEREZ-REVERTE Arturo	Le Maître d"escrime	1985	441     sang-froid	id	berkeley	4678
La porte de l'invisible doit être visible.	DAUMAL René	Le Mont Analogue		320     intuition	1908-1944.	berkeley	1773
Les confidences de fous, je passerais ma vie à les provoquer. Ce sont gens d'une honnêteté scrupuleuse, et dont l'innocence n'a d'égale que la mienne.	BRETON André	Manifeste du surréalisme		510     ironie	1896-1966.	berkeley	856
Croire au mal c'est croire.	PETIT Henri	Les Justes Solitudes.		546     éthique	1900/1978	berkeley	4691
L'ironie, c'est la gaieté et la joie de la sagesse.	FRANCE Anatole	La Vie littéraire		510     ironie	1844-1924. (Anatole François Thibault)	berkeley	2865
Le mensonge adoucit les moeurs.	PORTO-RICHE Georges de	Le Passé, I, 5, Bracony		539     ironie sociale	1849-1930.	berkeley	4730
Homme, enfant tragique  qui n'en finis pas...	FRéNAUD André	Il n"y a pas de paradis		510     ironie	1907-.	berkeley	2885
Le meilleur moyen de persuader consiste à ne pas persuader.	LAUTREAMONT Comte de	Poésies		234     communication		berkeley	4045
Un bon mariage, s'il en est, refuse la compagnie et conditions* de l'amour. Il tâche à représenter celles de l'amitié 	MONTAIGNE Michel Eyquem de	Essais, III, 5 		530     ironie amoureuse	1533-1592.  *La nature.	berkeley	4386
On trouve innocent de désirer et atroce que l'autre désire.	PROUST Marcel	La Prisonnière.		530     ironie amoureuse		berkeley	4738
Le vice, c'est le mal qu'on fait sans plaisir.	COLETTE Sidonie Gabrielle	Claudine en ménage		433     perversion	1873-1954.	berkeley	1556
Les plus grandes âmes sont capables des plus grands vices aussi bien que des plus grandes vertus.	DESCARTES René			510     ironie		berkeley	1950
Hélas, ai-je pensé, malgré ce grand nom d'hommes, Que j'ai honte de nous, débiles que nous sommes. Comment on doit quitter la vie et tous ses maux, C'est vous qui le savez, sublimes animaux. A voir ce que l'on fut sur terre et ce qu'on laisse Seul le silence est grand ; tout le reste est faiblesse.	VIGNY Alfred de	La mort du Loup.		510     ironie		berkeley	5299
Ne croire que ce qui est possible, ce n'est pas foi, mais simple philosophie.  To believe only possibilities is not faith, but mere philosophy.	BROWNE Sir	Religio Medici, I, 9		370     esprit	1605-1682. (Anglais)	berkeley	874
Quand un jour, tôt ou tard, il faut qu'on disparaisse, Quand on a plus ou moins vécu, souffert, aimé Il ne reste de soi que les enfants qu'on laisse Et le champ de l'Effort qu'on aura semé.	DE GAULLE Charles	Poème inédit	1924	540     mémoire		berkeley	1856
Choisir c'est se priver.	GIDE André			440     courage		berkeley	2943
Pas sages. Encore capables de cultiver l'attente. Sans le sentiment de l'attente il n'existe pas même de paradis, ne nous l'avez-vous pas enseigné vous, Européens ? - Moi, je serais l'européenne ? - Ce n'est pas la couleur de la peau qui compte, c'est la foi dans la tradition. Pour redonner le sentiment de l'attente à un Occidental paralysé par le bien-être, ceux-l à payent, ils souffrent peut-être, mais ils connaissent encore le langage des esprits de la nature, des airs, des eaux, des vents.	ECO Umberto	Le Pendule de Foucault	1988	140     rapport à la cosmogonie		berkeley	2262
Le despote doit apprendre à dormir à ses sujets. Gare à lui s'il leur apprend à mourir: c'est une leçon qui bientôt se retournera contre lui.  Il despota bisogna che insegni a dormire. Guai a lui se insegna a morire: è una lezione che ben tosto gli torner à contro.	BINI Carlo	Manoscritto d"un prigioniero, XXII		231     légitimité du pouvoir	1806-1842. (Italien)	berkeley	752
Je réputais presque pour faux tout ce qui n'était que vraisemblable.	DESCARTES René	Discours de la méthode		365     discernement	1596-1650.	berkeley	1922
Notre défiance justifie la tromperie d'autrui.	LA ROCHEFOUCAULD François de	Maximes		222     fourberie	1613-1680.	berkeley	3830
L'intérêt parle toutes sortes de langues et joue toutes sortes de personnages, même celui de désintéressé 	LA ROCHEFOUCAULD François de	Maximes		225     cynisme	1613-1680.	berkeley	3831
Heureux les miséricordieux,  car ils obtiendront miséricorde.	Evangiles	Evangile selon saint Matthieu, V, 7		215     mystifications		berkeley	2416
Généralement, les gens qui savent peu parlent beaucoup, et les gens qui savent beaucoup parlent peu.	ROUSSEAU Jean-Jacques	Emile ou De l"éducation.		510     ironie		berkeley	4888
Malheureusement il y a des vertus qu'on ne peut exercer que quand on est riche.	RIVAROL Antoine de	Fragments et pensées politiques		510     ironie	1753-1801. (Antoine Rivarol)	berkeley	4834
La joie est une brûlure qui ne se savoure pas.	CAMUS Albert	La Peste		430     paradoxal émotionnel	1913-1960.	berkeley	1005
La révolte est une ascèse, quoique aveugle. Si le révolté blasphème alors, c'est dans l'espoir d'un nouveau Dieu.	CAMUS Albert	L"Homme révolté		433     perversion	1913-1960.	berkeley	1009
Tirez le rideau, la farce est jouée.	RABELAIS François			510     ironie	dernier mot avant sa mort.	berkeley	4757
Le passé ne meurt jamais complètement pour l'homme. L'homme peut bien l'oublier, mais il le garde toujours en lui.	FUSTEL DE COULANGES Numa Denis	La Cité antique		420     capital affectif	1830-1889.	berkeley	2897
Il a tous les courages, sauf celui de douter...	MAYER Emile		1907	440     courage	jugeant ainsi, en toute amitié, du caractère du futur Ml. FOCH.	berkeley	4268
Nous faisons tous l'expérience de la peur, de l'injustice, de la confusion et de la mort. Même si nous échouons, nous essayons de sauver notre moi du naufrage. Nous ne pouvons pas y arriver seuls. Nous avons besoin d'aide et de davantage encore, d'un modèle, d'un exemple qui nous montre à quoi ressemble un être humain dans son intégralité.	WEST Morris	Les bouffons de Dieu.	1981	421     initiation	on	berkeley	5408
On ne conçoit pas des armes en fonction d'une doctrine. On construit une doctrine en fonction des armes existantes.	MESSMER Pierre			365     discernement		berkeley	4273
La raison veut décider ce qui est juste; la colère veut qu'on trouve juste ce qu'elle a décidé.  Ratio id judicare vult quod aequum est: ira id aequum videri vult quod judicavit.	Sénèque	De la colère, I, 18		433     perversion		berkeley	5012
La vraie difficulté est de savoir ce que l'on veut prouver.	CHARTIER Emile	Oeuvres complètes.		421     initiation	alias ALAIN	berkeley	1250
L'Etat est gouverné par le rebut de toutes les carrières honorables.	DUHAMEL Georges	Les Maîtres		238     servitudes du pouvoir politique	1884-1966.	berkeley	2205
Le charme : une manière de s'entendre répondre 'oui' sans avoir posé aucune question claire.	CAMUS Albert	La Chute		235     séduction	1913-1960.	berkeley	992
Trop de culture épuise un champ fertile.	BERNIS DE PIERRES François Joachim de	Poésies diverses		433     perversion	1715-1794.	berkeley	724
... frotter et limer notre cervelle contre celle d'autrui* 	MONTAIGNE Michel Eyquem de	Essais, I, 26 		421     initiation	1533-1592.  *En voyageant à l"étranger.	berkeley	4353
L'exil est une espèce de longue insomnie.	HUGO Victor			430     paradoxal émotionnel	\\010uÑ	berkeley	3328
Quand il se retrouva sur l'estrade, sans aucune note en main, il comprit que les fauves étaient bien l à : jeunes, bondissants et affamés de chair fraîche. La première question donna tout de suite le ton.	WEST Morris	De Main De Maître	1988	110     entropie		berkeley	5349
Dans tous les pays où il y aura de la vanité, le goût sera mis au premier rang parcequ'il sépare les classes et qu'il est le signe de ralliement entre tous les individus de la première.	STAEL Madame de	De l"Allemagne.		214     guerre du savoir		berkeley	5122
Un livre est une bouteille jetée en pleine mer sur laquelle il faut coller cette étiquette: attrape qui peut.	VIGNY Alfred de	Journal d"un poète		393     création artistique	1797-1863.	berkeley	5293
(Le style) est une façon très simple de dire des choses compliquées.	COCTEAU Jean	Le Secret professionnel		311     distinction	1889-1963.	berkeley	1500
Les hommes qui croient réellement en eux-mêmes sont tous dans des asiles d'aliénés.  The men who really believe in themselves are all in lunatic asylums.	CHESTERTON Gilbert Keith	Orthodoxy, II		520     ironie de soi	1874-1936. (Anglais)	berkeley	1350
Qu'est-ce que 'longtemps' pour une vie d'homme?  Quid est in hominis vita diu? 	Cicéron	De la vieillesse, XIX, 69		510     ironie	106-43 av. J.-C. (Marcus Tullius Cicero)	berkeley	1381
Il est aisé d'être 'profond': on n'a qu' à se laisser submerger par ses propres tares.	CIORAN Emile-Michel	Syllogismes de l"amertume		221     vanité	1911-.	berkeley	1387
Ce qui apparait comme un défaut de notre nature est en fait un encouragement à dominer ce qui nous entoure.	St.GREGOIRE de NYSSE	De la création de l"homme.		441     sang-froid		berkeley	5117
Mon idéal politique est l'idéal démocratique. Chacun doit être respecté en tant que personne, et personne ne doit être divinisé.  Mein politisches Ideal ist das demokratische. Jeder soll als Person respektiert und keiner vergöttert werden.	EINSTEIN Albert	Comment je vois le monde		546     éthique	1879-1955. (Allemand, naturalisé Américain)	berkeley	2323
Je n'admire que ceux qui persistent à créer tout comme si notre monde avait devant lui un millénaire de paix.	ELIADE Mircea	Fragments de journal II.		390     création		berkeley	2326
Renonce à cet air sombre qui même à moi me fait peur !	KIPLING Rudyard	Le second livre de la jungle.	1894	234     communication		berkeley	3556
La science et le temps ont de l'imagination ; les hommes sont des radoteurs.	CHARDONNE Jacques	Propos comme ça		520     ironie de soi	1884-1968.	berkeley	1202
Le couple, c'est autrui à bout portant.	CHARDONNE Jacques	L"Amour, c"est beaucoup plus que l"amour		531     communication amoureuse	1884-1968.	berkeley	1203
C'est la profonde ignorance qui inspire le ton dogmatique.	LA BRUYERE Jean de	Les Caractères.		110     entropie		berkeley	3590
'Tu regere império populos, Romane, memento.' Souviens-toi, Romain, de mener les peuples avec autorité.	VIRGILE			391     commandement		berkeley	5317
Car non seulement les choses incommodes, mais il n'en est aucune si laide et vitieuse et évitable qui ne puisse devenir acceptable par quelque condition et accident : tant l'humaine posture est vaine.	MONTAIGNE Michel Eyquem de			510     ironie		berkeley	4375
Il se trouve plus de différence de tel homme à tel homme que de tel animal à tel homme.	MONTAIGNE Michel Eyquem de	Essais, II, 12		510     ironie	1533-1592.	berkeley	4376
C'est aux chrétiens une occasion de croire, que de rencontrer une chose incroyable.	MONTAIGNE Michel Eyquem de	Essais, II, 12		510     ironie	1533-1592.	berkeley	4378
Certes, c'est un sujet merveilleusement vain, divers, et ondoyant, que l'homme.	MONTAIGNE Michel Eyquem de	Essais, I, 1		510     ironie	1533-1592.	berkeley	4379
Peu d'hommes ont été admirés par leurs domestiques.	MONTAIGNE Michel Eyquem de	Essais, III, 2		520     ironie de soi	1533-1592.	berkeley	4381
L'orgueil est une bête féroce qui vit dans les cavernes et dans les déserts, la vanité au contraire, comme un perroquet, saute de branche en branche et bavarde en pleine lumière.	FLAUBERT Gustave	L"amour de l"art.	1915	423     solitude	(1821/1880) édition posthume	berkeley	2762
Tout art tire son origine d'un défaut exceptionnel.	BLANCHOT Maurice	Le Livre à venir		393     création artistique	1907-.	berkeley	769
L'esprit et le courage défaillent,... la vanité triomphe, s'affole, disparait.	FAIRGAGNETR Oscar	Vitalités.	1993	110     entropie		berkeley	2473
On est dédommagé de la perte de son innocence par celle de ses préjugés.	DIDEROT Denis	Le Neveu de Rameau		421     initiation	1713-1784.	berkeley	2104
Mon Dieu, que ces gens d'esprit sont bêtes ! 	LACLOS Pierre Choderlos de	Les Liaisons dangereuses		515     tragédie	1741-1803.	berkeley	3967
Rien ne réussit comme le succès.	DUMAS Alexandre	Ange Pitou		422     confiance en soi	1802-1870. (père)	berkeley	2230
Le bonheur n'est pas un luxe; il est en nous comme nous-mêmes.	CLAUDEL Paul	La Ville		420     capital affectif	1868-1955.	berkeley	1451
Non, je ne pleure point, Madame, mais je meurs.	CORNEILLE Pierre	Suréna, V, 5, Eurydice		530     ironie amoureuse	1606-1684.	berkeley	1685
Tel menace qui a grand peur.	BEZE Théodore de	Comédie du pape malade		210     violence	1519-1605.	berkeley	738
Paris vaut bien une messe.  	HENRI IV			225     cynisme	1553-1610.   Ce mot est attribué à Henri IV. En réalité, il a son origine dans une réflexion de François d"O au roi, qui nous est rapportée par d"Aubigné. Il lui dit qu"il ne s"agissait que d"entendre la messe, qu"avec une heure de messe le roi gagnerait plus qu"en remportant vingt batailles.	berkeley	3117
Le naturel des Français est de n'aimer point ce qu'ils voient.	Henri IV	Lettres		539     ironie sociale	1553-1610.	berkeley	3120
La culture c'est ce qui demeure dans un homme, lorsqu'il a tout oublié.	HENRIOT Emile	Notes et maximes.		421     initiation	1889/1961. chroniqueur littéraire et écrivain.	berkeley	3121
Prétentieux comme ceux qui ont manié des idées sans toucher aux réalités.	MADELIN			221     vanité		berkeley	4163
Etre heureux, c'est avoir dépassé l'inquiétude du bonheur.	MAETERLINCK Maurice	La Sagesse et la destinée.		420     capital affectif	1862/1949	berkeley	4166
'L'état habituel du genre humain' : La guerre.	MAISTRE Joseph de	Considérations sur la France.	1796	211     guerre		berkeley	4178
On a toujours tendance à tout vouloir ramener à des choses connues ; je cherche, moi, à faire au contraire l'apprentissage de ce que je ne connais pas.	CHEREAU Patrice	Les secrets de la création, in Téléarama 2175 (21 sept.91)	1991	421     initiation		berkeley	1343
Tout argot est métaphore, et toute métaphore est poésie.  All slang is metaphor, and all metaphor is poetry.	CHESTERTON Gilbert Keith	The Defendant, A Defence of Slang		390     création	1874-1936. (Anglais)	berkeley	1346
Si une chose vaut d'être faite, elle vaut d'être mal faite.  If a thing is worth doing, it is worth doing badly.	CHESTERTON Gilbert Keith	What"s Wrong with the World		380     travail	1874-1936. (Anglais)	berkeley	1347
Cela indique une période de crise dans votre vie. La raison et l'intelligence ne joueront aucun rôle - seuls vos instincts vous tireont d'affaire. Vous devez à tout moment vous laisser porter par vos intuitions. Par vos impressions personnelles. C'est cela seul qui pourra vous sauver.	HIGGINS Jack	Opération Cornouailles.	1990	320     intuition		berkeley	3186
Il y a des sottises bien habillées comme il y a des sots très bien vêtus.	CHAMFORT Nicolas-Sébastien de	Maximes et pensées		510     ironie	1740/1794. Ac. Française	berkeley	1141
L'humilité consiste à transiger  avec le mensonge.  La humildad consiste en transigir  con la mentira.	UNAMUNO Miguel de			442     démission	1864-1936. (Espagnol)  "Vae victoribus!", article publié dans Los Lunes de El Imparcial, 15 décembre 1913	berkeley	5229
On entre, on crie  Et c'est la vie!  On crie, on sort  Et c'est la mort.	CHANCEL Ausone de	Quatrain inscrit en tête d"un album		510     ironie	1808-1878.	berkeley	1159
Il n'y a d'autre enfer pour l'homme que la bêtise ou la méchanceté de ses semblables.	SADE Marquis de	Juliette		221     vanité	1740-1814.	berkeley	4906
L'homme qui aime normalement sous le soleil, adore frénétiquement sous la lune.	MAUPASSANT Guy de	Sur l"eau		460     plaisir	1850-1893.	berkeley	4255
Quelqu'un disait d'un homme très personnel: il brûlerait votre maison pour se faire cuire deux oeufs.	CHAMFORT Nicolas-Sébastien de	Caractères et anecdotes		223     cupidité	1740/1794. Ac. Française	berkeley	1113
Comme le lierre, je meurs ou je m'attache.	Dictons et Proverbes	Proverbe anglais		440     courage		berkeley	2034
Il faut beaucoup d'imagination au coeur pour mesurer ce que l'amour compte d'engagement entre les êtres qui en partagent le privilège.	FAIRGAGNETR Oscar	Vitalités.	1993	234     communication		berkeley	2523
Vivre et ne jamais céder à la violence ou à la douleur.	FAIRGAGNETR Oscar	Vitalités.	1993	310     énergie		berkeley	2530
Dans la vie, des principes rigoureux donnent, dit-on, plus de déceptions que de joies.	Euripide	Hippolyte, 261-262	62	433     perversion	480-406 av. J.-C.	berkeley	2391
L'homme a deux faces : il ne peut pas aimer sans s'aimer.	CAMUS Albert	La Chute		420     capital affectif	1913-1960.	berkeley	1004
Les passions peuvent me conduire, mais elles ne sauraient m'aveugler.	LA FAYETTE M.-M.	La Princesse de Clèves		430     paradoxal émotionnel	1634-1693. (Pioche de la Vergne, comtesse de)	berkeley	3637
Un homme qui se trouve bien assis, qu'a-t-il besoin de se mettre debout? 	MARIVAUX Pierre Carlet de Chamblain de	Le Prince travesti, I, 13		560     sagesse	1688-1763.	berkeley	4238
Le désespoir est une affaire d'entêtement... Il est dans la nature du sentimntal de la meilleure espèce.	MEREDITH George	Sandra Belloni.	1988	433     perversion	cité par Morris West dans De main de Maître, 1988.	berkeley	4270
... Et le désir s'accroît quand l'effet se recule.	CORNEILLE Pierre	Polyeucte, I, 1, Polyeucte		431     désir	1606-1684.	berkeley	1663
Il y a de méchantes qualités qui font de grands talents.	LA ROCHEFOUCAULD François de	Maximes		390     création	1613-1680.	berkeley	3862
Sur quelque préférence une estime se fonde, Et c'est n'estimer rien qu'estimer tout le monde.	MOLIERE	Le Misanthrope.		120     grégarité		berkeley	4293
Quand une femme blâme son mari, elle demande la danse de son voisin.	Dictons et Proverbes	Dicton.		530     ironie amoureuse		berkeley	2052
Ce que les hommes appellent civilisation, c'est l'état actuel des moeurs et ce qu'ils appellent barbarie, ce sont les états antérieurs.	FRANCE Anatole	Sur la pierre blanche		539     ironie sociale	1844-1924. (Anatole François Thibault)	berkeley	2871
J'aime la vérité. Je crois que l'humanité en a besoin; mais elle a bien plus grand besoin encore du mensonge ...	FRANCE Anatole	La Vie en fleur		539     ironie sociale	1844-1924. (Anatole François Thibault)	berkeley	2872
Comme la magie, la poésie est noire ou blanche, selon qu'elle sert le sous-humain ou le surhumain.	DAUMAL René	Poésie noire et poésie blanche		393     création artistique	1908-1944.	berkeley	1775
Comme la magie, la poésie est noire ou blanche, selon qu'elle sert le sous-humain ou le surhumain.	DAUMAL René	Poésie noire et poésie blanche		393     création artistique	1908-1944.	berkeley	1776
La nuit de vérité nous coupe la parole.	DAUMAL René	Le Contre-ciel		430     paradoxal émotionnel	1908-1944.	berkeley	1777
Privez-vous. La révélation est fille du refus.	BRETON André	Le Surréalisme et la Peinture		441     sang-froid	1896-1966.	berkeley	855
Croire un mensonge ne signifie pas qu'on est dupe mais qu'on a les idées larges.	BRASSEUR Pierre			341     étonnement		berkeley	838
Pour bien écrire, il faut une facilité naturelle et une difficulté acquise.	JOUBERT Joseph	Pensées		393     création artistique	1754-1824.	berkeley	3461
[...] le temps change les canailles en saints.	WEST Morris	Le Loup Rouge.	1971	215     mystifications		berkeley	5360
Redouter l'ironie, c'est craindre la raison.	GUITRY Sacha	in l"Esprit de Guitry		510     ironie	1885-1957.	berkeley	3065
Va, crois-moi, le plaisir est toujours légitime.	PARNY évariste Désiré de	élégies.		460     plaisir		berkeley	4636
Le désir de la connaissance est le seul auquel s'offre une matière pratiquement inépuisable. Et il est développable.	VIAN Boris	En Verve.	1970	341     étonnement		berkeley	5289
Il faut mépriser l'argent, surtout la petite monnaie.	CAVANNA François			510     ironie		berkeley	1063
Il faut avoir le courage d'abandonner ses enfants ; leur sagesse n'est pas la nôtre.	CHARDONNE Jacques	L"Amour, c"est beaucoup plus que l"amour		441     sang-froid	1884-1968.	berkeley	1198
Nos peurs reflètent, avant toute autre chose, les énergies qui nous manquent.	FAIRGAGNETR Oscar	Vitalités.	1993	433     perversion	\\010vAP\\020	berkeley	2591
Toute contrainte, positive, négative, nous est une occasion de nous défier de l'entropie.	FAIRGAGNETR Oscar	Vitalités.	1993	440     courage		berkeley	2596
Car quiconque a une volonté ferme et constante d'user toujours de la raison le mieux qu'il est en son pouvoir, et de faire en toutes ses actions ce qu'il juge être le meilleur, est véritablement sage autant que sa nature permet qu'il le soit.	DESCARTES René	Principes de la philosophie.		560     sagesse		berkeley	1954
La nécessité donne de l'industrie, et souvent les inventions les plus utiles ont été dues aux hommes les plus misérables.	BERNARDIN DE SAINT-PIERRE Jacques-Henri	Paul et Virginie		390     création	1737-1814.	berkeley	721
Celui qui n'a jamais saisi - fût-ce en rêve ! - le dessin d'une entreprise qu'il est le maître d'abandonner, l'aventure d'une construction finie quand les autres voint qu'elle commence et qui n'a pas connu l'enthousiasme brûlant d'une minute de lui-même, le poison de la conception, le scrupule, la froideur des objections intérieures et cette lutte des pensées alternatives où la plus forte et la plus universelle devrait triompher même de l'habitude, même de la nouveauté ; - celui qui n'a pas regardé dans la blancheur de son papier une image troublée par le possible, et par le regret de tous les signes qui ne seront pas choisis, - ni vu dans l'air limpide une bâtisse qui n'y est pas ; - celui que n'ont pas hanté le vertige de l'éloignement d'un but, l'inquiétude des moyens, la précision des lenteurs et des désespoirs, le calcul des phases progressives, le raisonnement projeté sur l'avenir, y désignant même ce qu'il ne faudra pas raisonner alors, celui-l à ne connaît pas davantage, quel que soit d'ailleurs son savoir, la richesse et la ressource de l'étendue spirituelle qu'illumine le fait conscient de construire.	VALéRY Paul	Introduction à la méthode de Léonard de Vinci		390     création		berkeley	5248
Volonté, ordre, temps : tels sont les éléments de l'art d'apprendre.	PREVOST Marcel	L"Art d"apprendre.		421     initiation		berkeley	4734
Il n'a manqué à Molière que d'éviter le jargon et le barbarisme, et d'écrire purement: quel feu, quelle naïveté, quelle source de la bonne plaisanterie, quelle imitation des moeurs, quelles images et quel fléau du ridicule! 	LA BRUYERE Jean de	Les Caractères		393     création artistique	1645-1696.	berkeley	3614
La vanité fait plus d'heureux que l'orgueil.	RIVAROL Antoine de	Discours sur l"homme intellectuel et moral		510     ironie	1753-1801. (Antoine Rivarol)	berkeley	4835
Un peintre ne vend pas : il peint. A chacun son office.	KAHNWEILER Daniel-Heinrich	attribué  à		380     travail	littéralement de Pierre Assouline in "L"Homme de l"Art".	berkeley	3519
O mathématiques sévères, je ne vous ai pas oubliées, depuis que vos savantes leçons, plus douces que le miel, filtrèrent dans mon coeur, comme une onde rafraîchissante.	LAUTRéAMONT Comte de	Les Chants de Maldoror		421     initiation	1846-1870. (Isidore Ducasse)	berkeley	4050
C'est dans l'enfance brisée que nait la volonté de construire plutôt que d'aimer, de regagner sa propre confiance plutôt que de donner sa joie, de trouver sa jeunesse dans la maturité plutôt que de vivre la tranquilité de l'instant ou de la colère qui passe.	FAIRGAGNETR Oscar	Aphorismes.	1992	420     capital affectif		berkeley	2569
Il est plus difficile de bien faire l'amour que de bien faire la guerre.	LENCLOS Ninon de	Lettres		531     communication amoureuse	1620-1705. (Anne)	berkeley	4107
Dans la prière les lèvres ne jouent jamais la partie gagnante Sans la douce concurrence du coeur.	HERRICK R.	Le Coeur.		330     coeur		berkeley	3170
La politique, c'est comme l'andouillette. Il faut que ça sente la merde mais pas trop.	HERRIOT Edouard			231     légitimité du pouvoir		berkeley	3171
La pensée n'est qu'un éclair au milieu de la nuit. Mais c'est cet éclair qui est tout.	POINCARE Henri	La valeur de la science.		390     création	1854/1912	berkeley	4724
La délicatesse est à l'esprit ce que la saveur est au fruit.	POINCELOT A.	Etudes de l"homme ou Réflexions morales.		370     esprit		berkeley	4725
Notre âme est transitive. Il lui faut un objet, qui l'affecte, comme son complément direct, aussitôt.	PONGE Francis			430     paradoxal émotionnel	\\010rΩê\\020	berkeley	4727
... cette dictature de la liberté [la civilisation libérale] se distingue de toutes les dictatures de la contrainte, bien faibles en comparaison [...] Cette différence tient en ceci que la dictature de la liberté permet tout. Non seulement elle n'interdit pas l'utopie mais elle s'en nourrit.	RUFIN Jean-Christophe	La Dictature Libérale.		231     légitimité du pouvoir	Le secret de la toute-puissance des démocraties au 20e siècle	berkeley	4894
C'est dingue : même quand tout va mal, les choses peuvent encore devenir infiniment piresê!	CALVIN Jean			442     démission		berkeley	976
Mais qui peut vivre infâme est indigne du jour.	CORNEILLE Pierre	Le Cid, I, 5, Don Diègue		515     tragédie	1606-1684.	berkeley	1683
La puissance ne se montre que si l'on en use avec injustice.	RADIGUET Raymond	Le Diable Au Corps.		231     légitimité du pouvoir		berkeley	4795
Nos femmes ne se doutent pas combien le chagrin que nous leur faisons peut nous les faire aimer davantage.	FLERS Robert de	L"Amour veille		433     perversion	1872-1927. (et Gaston Arman de Caillavet)	berkeley	2795
Si vertueuse que soit une femme, c'est sur sa vertu qu'un compliment lui fait le moins de plaisir.	FLERS Robert de	L"Amour veille		510     ironie	1872-1927. (et Gaston Arman de Caillavet)	berkeley	2796
Le plus grand des biens est la volupté des sens ; l'art le plus nécéssaire au bonheur est de savoir jouir, et de savoir s'abstenir pour jouir mieux et plus longtemps.	SENAC de MEILHAN Gabriel	L"Emigré.		460     plaisir		berkeley	4997
Réfléchis avec lenteur, mais exécute rapidement tes décisions.	Isocrate	A Démonicos, 34		441     sang-froid	436-338 av. J.-C.	berkeley	3396
Ils ne savent pas que ce n'est que la chasse, et non la prise qu'ils recherchent. Ils s'imaginent que, s'ils avaient obtenu cette charge, ils se reposeraient ensuite avec plaisir, et ne sentent pas la nature insatiable de leur cupidité. Ils croient chercher sincèrement le repos, et ne cherchent en effet que l'agitation.	PASCAL Blaise	Pensées.		110     entropie	1623/1662	berkeley	4637
Qui m'aima généreux me haïrait infâme.	CORNEILLE Pierre	Le Cid, III, 4, Rodrigue		330     coeur	1606-1684.	berkeley	1656
On n'a guère de défauts qui ne soient plus pardonnables que les moyens dont on se sert pour les cacher.	LA ROCHEFOUCAULD François de	Maximes.		221     vanité	1613/1680	berkeley	3795
Sois fidèle à ton impression première.	COLETTE Sidonie Gabrielle	Lettres, au petit corsaire		320     intuition	1873-1954.	berkeley	1542
Les vieillards aiment à donner de bons préceptes pour se consoler de n'être plus en état de donner de mauvais exemples.	LA ROCHEFOUCAULD François de	Maximes		221     vanité	1613-1680.	berkeley	3806
C'est dans le mouvement que vous trouverez des techniques et des moyens de vous améliorer et atteindre vos buts.	VINCENT Raymond	La Passion du succès.		432     expérience		berkeley	5310
Il y a peut-être un moyen de traverser le monde autrement qu'en suivant le fil du réel.	MUSIL			320     intuition		berkeley	4514
Ecrire, c'est mettre en ordre ses obsessions.	GRENIER Jean	Albert Camus		510     ironie	1898-1971.	berkeley	3018
Le marteau de la porte s'enrouille quand le maitre est mort.	Dictons et Proverbes	Dicton.		120     grégarité		berkeley	1989
Quand on n'est pas intelligible c'est qu'on n'est pas intelligent.	HUGO Victor	Tas de pierres		234     communication	1802-1885.	berkeley	3298
L'homme est un vieillard clandestin.	BUZZATI Dino			130     liberté		berkeley	939
C'est d'âme qu'il faut changer, non de climat.  Animum debes mutare, non caelum.	Sénèque	Lettres à Lucilius, XXVIII		321     volonté		berkeley	5016
Je chéris l'Arioste et j'estime le Tasse;  Plein de Machiavel, entêté de Boccace,  J'en parle si souvent qu'on en est étourdi;  J'en lis qui sont du Nord et qui sont du Midi.	LA FONTAINE Jean de	Epître à Huet		370     esprit	1621-1695.	berkeley	3702
Nous avons fait l'art afin de ne pas mourir de la vérité.	NIETZSCHE Friedrich			393     création artistique		berkeley	4589
Les tentations de se trop bien connaître seront autant de portes potentiellement ouvertes sur de vaines perversions chaque fois que l'échec d'un questionnement risquera de devenir 'insupportable'.	FAIRGAGNETR Oscar	Vitalités.	1994	433     perversion		berkeley	2595
Si tu veux connaître le meilleur, donne et reçois la vitalité, jusqu' à vaincre le dernier prétexte.	FAIRGAGNETR Oscar	Bonheurs.	1992	440     courage		berkeley	2597
La nouvelle apparition de l'enfant qui dort au fond de nous-mêmes, recouvert par une si épaisse nappe de déceptions et d'oublis, exige attention et silence.	BUTOR Michel	Répertoire		560     sagesse	1926-.	berkeley	938
Vivre, connaître la vie, c'est le plus léger, le plus subtil des apprentissages. Rien à voir avec le savoir.	LE CLéZIO Jean-Marie Gustave	L"Inconnu sur la terre.		421     initiation		berkeley	4075
Quiconque court après la grandeur voit la grandeur le fuir ; quiconque fuit la grandeur, voit la grandeur courir après lui.	Le Talmud	Eroubin		441     sang-froid		berkeley	4078
Le gain de notre étude, c'est en être devenu meilleur et plus sage.	MONTAIGNE Michel Eyquem de	Essais, I, 26		560     sagesse	1533-1592.	berkeley	4391
Le repos? le repos, trésor si précieux  Qu'on en faisait jadis le partage des dieux! 	LA FONTAINE Jean de	Fables		510     ironie	1621-1695. Fables, L"Homme qui court après la fortune et l"Homme qui l"attend dans son lit	berkeley	3742
La jeunesse se flatte, et croit tout obtenir;  La vieillesse est impitoyable.	LA FONTAINE Jean de	Fables, le Vieux Chat et la Jeune Souris		510     ironie	1621-1695.	berkeley	3743
Ils ne mouraient pas tous, mais tous étaient frappés.	LA FONTAINE Jean de	Fables		515     tragédie	1621-1695.	berkeley	3748
Les disciples de la lumière n'ont jamais inventé que des ténèbres peu opaques.	DESNOS Robert	Corps et biens		221     vanité	1900-1945.	berkeley	1958
Tel, comme dit Merlin, cuide engeigner* autrui,  Qui souvent s'engeigne soi-même.	LA FONTAINE Jean de	Fables, la Grenouille et le Rat 		222     fourberie	1621-1695.  *Duper, abuser.	berkeley	3676
Le bruit est pour le fat, la plainte pour le sot, L'honnête homme trompé s'éloigne et ne dit mot.	LA NOUE François de	La Coquette corrigée.		421     initiation		berkeley	3782
Où est le droit il n'y a plus d'affection.	CLAUDEL Paul	L"Otage, I, 2, Coûfontaine		530     ironie amoureuse	1868-1955.	berkeley	1465
L'imagination ! Elle fait plus de victimes que toutes les maladies réunies ! Elle engendre des maladies ! C'est une forme de folie.	O"NEILL Eugène	L"étrange intermède.		110     entropie		berkeley	4613
L'arrogance du fort s'éteint comme une braise  Quand il n'est plus certain de filer à l'anglaise.	OBALDIA René de	Innocentines, Petite Ritournelle impériale		221     vanité	1918-.	berkeley	4614
Il y a deux sortes de personnes ici-bas : ceux qui divisent tout en deux groupes et ceux qui ne le font pas.	OECH Roger von	Créatif de choc.	1983	110     entropie		berkeley	4617
L'envie, à plus qu' à nuls autres, s'attaque à ceux Qui de leurs propres ailes se sont envolés, Et fuient loin de la cage commune.	PETRARQUE	Parerga.		120     grégarité		berkeley	4693
L'ignorance et l'insécurité sont deux oreillers fort doux, mais, pour les trouver tels, il faut avoir la tête aussi bien faite que Montaigne.	DIDEROT Denis	Pensées Philosophiques.		370     esprit		berkeley	2099
Vanité. Hommage d'un sot au premier imbécile venu.  Vanity. The tribute of a fool to the worth of the nearest ass.	BIERCE Ambrose	The Devil"s Dictionary		510     ironie	1842-1914. (Américain)	berkeley	741
L''acte hostile' du 7 mars a montré quelle méthode va suivre désormais la force pour accomplir son oeuvre : surprise, brutalité, vitesse.	DE GAULLE Charles	lettre à Jean Auburtin.	1936	210     violence	en commentaire de la réoccupation par Hitler de la Rhénanie.	berkeley	1788
Les chars... doivent être mis en oeuvre rassemblés et non dispersés.	DE GAULLE Charles	Rapport sur l"armée polonaise.	1921	211     guerre		berkeley	1790
Qui sait si la raison de l'existence de l'homme ne serait pas dans son existence même? 	LA METTRIE Julien Offroy de	L"Homme machine		440     courage	1709-1751.	berkeley	3776
A quoi bon vivre quand on peut être enterré pour dix dollars ?	FREUD Sigmund			510     ironie		berkeley	2892
Si vous ressentez de la pitié et de la compassion vous n'êtes pas loin de l'amour. Ces choses se communiquent même à travers les mots les plus hésitants.	WEST Morris	L"Avocat du diable.	1959	531     communication amoureuse		berkeley	5453
Je crains Dieu, cher Abner, et n'ai point d'autre crainte.	RACINE Jean	Andromaque		440     courage		berkeley	4784
L'hypocrisie est un hommage que le vice rend à la vertu.	LA ROCHEFOUCAULD François de	Maximes		510     ironie	1613-1680.	berkeley	3906
L'enseignement doit être résolument retardataire.	CHARTIER Emile	Propos Sur L"éducation.		421     initiation	alias Alain (1868-1951)	berkeley	1251
L'homme est quelque chose d'immense, d'infini, de mystérieux. L'homme est plus illimité que le Sahara ou le Pacifique, que tout notre univers. Il y a en nous des soleils, des maelströms affreux.	VERGES Jacques	Le Salaud lumineux.	1990	130     liberté	entretiens avec Jean-Louis Remilleux	berkeley	5275
Chaque ministricule français se prend pour Gorbatchev.	VERGES Jacques	Le salaud lumineux.	1990	221     vanité	entretiens avec Jean-Louis Remilleux	berkeley	5276
La solitude est un bain de jouvence.	VERGES Jacques		1991	423     solitude	entretien TV TFI avec Patrick Sabatier.	berkeley	5277
Sur cette planète, on arrive seul, mon fils, et on repart seul. La vie durant on essaye d'échapper à la solitude. On n'y parvient jamais tant qu'on ne l'a pas acceptée. Un jour on s'installe à l'écart dans un coin tranquille et on se met à siffler un petit air ou à le chantonner pour soi, ou peut-être simplement à réciter des vers enfantins pour se réconforter. Puis, peu à peu, on n'est plus seul. Il y a des gens aussi solitaires que toi qui écoutent la petite musique, qui se joignent à toi, qui prennent le rythme. Tu marches... ils suivent. Cela n'aide pas beaucoup parce que leurs têtes, comme la tienne, sont encore encombrées par leurs propres affaires. Mais tu n'es plus seul. Tu seras peut-être solitaire, tu ne seras jamais seul.	WEST Morris	De main de Maître.	1988	423     solitude		berkeley	5413
La jalousie, c'est un manque d'estime pour la personne qu'on aime.	BOUNINE Ivan	Le Sacrement de l"amour, II		221     vanité	1870-1953. (Russe).	berkeley	816
Un verset du Coran affirme qu'il y a plus de vérité dans une épée que dans dix mille mots.	HIGGINS Jack	Saison en enfer.	1989	230     pouvoir		berkeley	3183
Accepter l'idée d'une défaite, c'est être vaincu.	FOCH Ferdinand			110     entropie	1851/1929	berkeley	2812
Il n'y a pas d'homme cultivé, il n'y a que des hommes qui se cultivent.	FOCH Ferdinand			370     esprit	1851-1929.	berkeley	2813
Du chagrin le plus noir elle écarte les ombres, Et fait des jours sereins de mes jours les plus sombres.	RACINE Jean	Esther.		531     communication amoureuse		berkeley	4793
Depuis cinq ans entiers chaque jour je la vois, Et crois toujours la voir pour la première fois.	RACINE Jean	Bérénice		531     communication amoureuse		berkeley	4794
L'âme, c'est ce qui refuse le corps.	CHARTIER Emile			433     perversion		berkeley	1259
Le fou on le reconnait tout de suite. C'est un stupide qui ne connait pas les trucs. Le stupide, sa thèse il cherche à la démontrer, il a une logique biscornue mais il en a une. Le fou par contre ne se soucie pas d'avoir une logique, il procède par court-circuits. Tout pour lui démontre tout. Le fou a une idée fixe, et tout ce qu'il trouve lui va pour la confirmer. Le fou, on le reconnait à la liberté qu'il prend par rapport au devoir de preuve, à sa disponibilité à trouver des illuminations.	ECO Umberto	Le Pendule de Foucault	1988	360     bon sens		berkeley	2269
En vérité, tu ne sais rien de la sagesse  Tant que tu n'as pas fait l'expérience des ténèbres.  Wahrlich, keiner ist weise,  Der nicht das Dunkel kennt.	HESSE Hermann	Maler Freude		560     sagesse	1877-1962. (Allemand)	berkeley	3180
Soyez-vous à vous-même un sévère critique.	BOILEAU Nicolas	L"Art poétique.		441     sang-froid		berkeley	783
Je n'aime pas les maisons neuves : Leur visage est indifférent.	SULLY-PRUDHOMME	Les Solitudes.		540     mémoire		berkeley	5168
Le fait est que nous sommes devenus trop intelligents pour pouvoir croire en Dieu et pas assez forts pour pouvoir croire en nous-mêmes.	BLOK A.			510     ironie		berkeley	775
Le bonheur est vide, le malheur est plein.	HUGO Victor	Tas de pierres		420     capital affectif	1802-1885.	berkeley	3323
Toute théorie physique est toujours provisoire en ce sens qu'elle n'est qu'une hypothèse : vous ne pourrez jamais la prouver. Peu importe le nombre de fois où les résultats d'une expérience s'accorderont avec une théorie donnée ; vous ne pourrez jamais être sûr que, la fois suivante, ce résultat ne la contredira pas.	HAWKING Stephen W.	Une Brève Histoire Du Temps.	1988	545     épistémologie	\\010sñÄ\\020	berkeley	3086
C'est un vieux proverbe que celui-ci: un gladiateur se décide dans l'arène.  Vetus proverbium est gladiatorem in arena capere consilium.	Sénèque	Lettres à Lucilius, XXII		432     expérience		berkeley	5029
La majorité des gens se porteraient mieux s'ils n'avaient pas à résoudre des conflits qu'ils ont eux-mêmes créés.	SENNA Ayrton		1991	433     perversion		berkeley	5038
La vie est une cellule qui a un projet.	LEGRAND Michel		1992	140     rapport à la cosmogonie	in émission TV diffusée le 22/2/93	berkeley	4098
Si tu es riche, tu es pauvre : Car, pareil à l'âne dont le dos fléchit sous les lmingots, Tu portes tes lourdes richesses, mais seulmement pour un trajet, Et la mort t'en soulage.	SHAKESPEARE William			232     servitudes du pouvoir		berkeley	5046
Personne ne s'impose une discipline d'oisiveté, mais c'est indispensable. La vie n'est oas le travail : travailler sans cesse rend fou. (...) Vouloir le faire est mauvais signe.	MALRAUX André			380     travail		berkeley	4204
Il faut être perdu dans le désert, ô Dâssîne, pour savoir ce qu'est la solitude, où ne chante ni un arbre ni un oiseau, dans l'aridité des pierres ou du sable. Celui qui ne connaît pas cela ne peut pas dire qu'il soit jamais resté seul.	MARAVAL-BERTHOIN	Chant du Hoggar.		423     solitude		berkeley	4214
Je me suis remis à travailler, car l'existence n'est tolérable que si on oublie sa misérable personne.	FLAUBERT Gustave	L"amour de l"art.	1915	380     travail	(1821/1880) édition posthume	berkeley	2740
Je suis chrétien par l'histoire et la géographie.	DE GAULLE Charles			510     ironie		berkeley	1853
Tout doit pouvoir être libéré de sa coque... Ne vous croyez pas à l'intérieur d'une caverne, mais à la surface d'un oeuf.	BRETON André	Le Surréalisme et la Peinture		422     confiance en soi	1896-1966.	berkeley	852
Quand la loi et le devoir ne font qu'un sous la religion, nul n'est  plus vraiment conscient. Alors, on est toujours un peu moins qu'un individu.	HERBERT Franck	Dune	1965	214     guerre du savoir		berkeley	3133
Lutter avec des rêves Ou contenir des ombres ? Et marcher dans l'ombre d'un sommeil ?	HERBERT Franck	Dune	1965	310     énergie		berkeley	3135
La philosophie épicurienne, ce lit étroit, mais propre.	YOURCENAR Marguerite	Mémoires d"Hadrien		221     vanité	1903-1987. (Marguerite de Crayencour)	berkeley	5508
Une multitude est sans doute plus facile à leurrer qu'un seul homme.	Hérodote	Histoires, V, 97		120     grégarité	v. 484-v. 420 av. J.-C.	berkeley	3166
Faut-il tant de fois vaincre avant que triompher? 	CORNEILLE Pierre	Polyeucte, V, 3, Polyeucte		421     initiation	1606-1684.	berkeley	1659
Allons, par-dessus les tombeaux, en avant!	GOETHE Johann Wolfgang von	us l	1831	440     courage	 à son ami Zelter.	berkeley	2977
Quand on lui* demandait son avis de quelques mots français, il renvoyait ordinairement aux crocheteurs du Port-au-Foin, et disait que c'étaient ses maîtres pour le langage.	RACAN Honorat de Bueil, marquis de	Mémoires pour la vie de M. de Malherbe 		221     vanité	1589-1670.  *Malherbe.	berkeley	4763
Les mots peuvent ressembler aux rayons X si l'on s'en sert convenablement - ils transpercent n'importe quoi.  Words can be like X-rays, if you use them properly - they'll go through anything.	HUXLEY Aldous	Brave New World, 4.		234     communication	1894-1963 (Anglais)	berkeley	3359
De plus, aucun peuple végétant dans des conditions économiques précaires n'a de chances raisonnables de pouvoir se gouverner démocratiquement.	HUXLEY Aldous	Retour au Meilleur des Mondes	1958	392     création économique		berkeley	3360
Faire l'amour comme un devoir, écrire comme un métier, des deux côtés : néant.	LEAUTAUD Paul			390     création		berkeley	4079
Dans les grandes actions il faut uniquement songer à bien faire, et laisser venir la gloire après la vertu.	BOSSUET Jacques Bénigne	Oraison funèbre de Louis de Bourbon, Prince de Condé.		550     grandeur		berkeley	812
Les dépositaires du pouvoir ont une disposition fâcheuse à considérer tout ce qui n'est pas eux comme une faction. Ils rangent quelquefois la nation même dans cette catégorie.	CONSTANT Benjamin	De la doctrine politique qui peut réunir les partis en France		232     servitudes du pouvoir	1767-1830. (Henri-B. de Rebecque)	berkeley	1624
Il y a des gens qui ont la susceptibilité de l'huitre, on ne peut y toucher sans qu'ils se contractent.	CONSTANT Benjamin	Monsieur Du Paur, Homme Public.		420     capital affectif	1767-1830. (Henri-B. de Rebecque)	berkeley	1625
J'éprouve un charme inexprimable à marcher en aveugle au-devant de ce que je crains.	CONSTANT Benjamin	Lettre, à Mrs. Lindsay, 22 novembre 1800		422     confiance en soi	1767-1830. (Henri-B. de Rebecque)	berkeley	1626
C'est un grand avantage dans les affaires de la vie que de savoir prendre l'offensive : l'homme attaqué transige toujours.	CONSTANT Benjamin	Journal Intime.		422     confiance en soi	1767-1830. (Henri-B. de Rebecque)	berkeley	1627
Les précautions qu'il prit pour que ce pressentiment ne se réalisât point furent précisément ce qui le fit se réaliser.	CONSTANT Benjamin	Cécile		430     paradoxal émotionnel	1767-1830. (Henri-B. de Rebecque)	berkeley	1628
Nous sommes des créatures tellement mobiles que les sentiments que nous feignons, nous finissons par les éprouver.	CONSTANT Benjamin	Adolphe		433     perversion	1767-1830. (Henri-B. de Rebecque)	berkeley	1629
Ne soyez ni obstinés dans le maintien de ce qui s'écroule, ni trop pressés dans l'établissement de ce qui semble s'annoncer.	CONSTANT Benjamin	De l"esprit de conquête		441     sang-froid	1767-1830. (Henri-B. de Rebecque)	berkeley	1630
J'ai remarqué qu'il fallait remercier les hommes le moins possible, parce que la reconnaissance qu'on leur témoigne les persuade aisément qu'ils en font trop.	CONSTANT Benjamin	Journal Intime.		441     sang-froid	1767-1830. (Henri-B. de Rebecque)	berkeley	1631
Personne ne garde un secret comme un enfant.	HUGO Victor	Les Misérables		420     capital affectif	1802-1885.	berkeley	3322
Lord Byron, gentleman-vampire,  Hystérique du ténébreux;  Anglais sec, cassé par son rire,  Son noble rire de lépreux.	CORBIERE Tristan	Les Amours jaunes		510     ironie	1845-1875. (Edouard Joachim Corbière)	berkeley	1644
Une des qualités les plus méconnues de l'homme d'action est l'ingéniosité. L'homme qui s'impose dans les situations difficiles est celui qui invente une solution l à où les autres étaient dans l'impasse.	BOURBON BUSSET Jacques de	Tu ne mourras pas.		390     création		berkeley	818
Pour ceux qui ont une mission à remplir, l'existence corporelle se prolonge aussi longtemps qu'il est nécéssaire.	Brahma-Sûtras			430     paradoxal émotionnel		berkeley	827
Une armée ne vaut que par les forces morales. C'est à nous, cadres, qu'il appartient de les créer.	DE GAULLE Charles		1914	211     guerre	conférence devant les cadres du 3e bataillon du 33e RI d"Arras.	berkeley	1789
Je ne sais ce qu'est la vie d'un coquin, je ne l'ai jamais été; mais celle d'un honnête homme est abominable.	MAISTRE Joseph de	Lettres et Opuscules inédits		520     ironie de soi	1753-1821.	berkeley	4187
Nous arrivons tout nouveaux aux divers âges de la vie, et nous y manquons souvent d'expérience, malgré le nombre des années.	LA ROCHEFOUCAULD François de	Maximes.		432     expérience	1613/1680	berkeley	3875
Jamais homme sage on vit buveur de vin sans appétit.	Dicton et Proverbes	Dicton.		560     sagesse		berkeley	1981
Avoir du coeur n'est qu'un presque rien sans l'exigence de soi.	FAIRGAGNETR Oscar		1991	440     courage		berkeley	2603
Pour une chose bien conçue, les mots s'offriront et couleront d'eux-mêmes.  Verbaque provisam rem non invita sequentur.	Horace	Art poétique, 311		370     esprit	65-8 av. J.-C. (Quintus Horatius Flaccus)	berkeley	3242
L'art se situe dans l'intervalle, mince comme la peau, qui sépare la vérité du mensonge.	CHIKAMATSU Monzaemon	Entretiens avec Hozumi Ikkan		393     création artistique	1653-1724. (Japonais)	berkeley	1351
S'il n'est nul médecin près de votre personne, Qui dans l'occasion puisse être consulté, En voici trois que l'on vous donne : Un fonds de belle humeur, un repos limité, Et surtout la sobriété.	Ecole de Salerne	L"Ecole de Salerne.	1749	410     santé		berkeley	2278
En réalisant ses désirs, autrement dit en se réalisant soi-même, l'homme réalise l'absolu.	MONTHERLANT Henry Millon de	La Petite Infante de Castille.		390     création		berkeley	4477
Car les sots et les fous disent généralement la vérité.  For fools and mad men tell commonly truth.	BURTON Robert	The Anatomy of Melancholy, II		510     ironie	1577-1640. (Anglais)	berkeley	920
Les malheureux qu'on accable ont si grand-peur qu'on ne les méprise, qu'ils en sont moins modestes.	BUSSY-RABUTIN Roger de Rabutin	Lettres, au P. Raquin, octobre 1677		433     perversion	1618-1693. comte de Bussy	berkeley	921
Ce n'est pas l'esprit qui fait les opinions, c'est le coeur.	MONTESQUIEU Charles de	Essai sur les causes qui peuvent affecter les esprits et les caractères		430     paradoxal émotionnel	1689-1755. (C. de Secondat, baron de La Brède et de M.)	berkeley	4441
Les desseins qui ont besoin de beaucoup de temps pour être exécutés ne réussissent presque jamais.	MONTESQUIEU Charles de	Réflexions sur la monarchie universelle en Europe		432     expérience	1689-1755. (C. de Secondat, baron de La Brède et de M.)	berkeley	4443
Il n'y a pas de solution car il n'y a pas de problème.	DUCHAMP Marcel	n"y a pas de\\010ÄXÄ\\010Ä[		441     sang-froid		berkeley	2192
... Quoi de plus commun que de se croire deux nez au visage, et de se moquer de celui qui se croit deux trous au cul ? 	DIDEROT Denis	Les Bijoux indiscrets		221     vanité	1713-1784.	berkeley	2086
C'est lorsqu'il doit abandonner son oeuvre que l'artiste a besoin de courage.	BOSELLI Elisabeth			390     création	Aviatrice française.	berkeley	800
Exister, c'est dépendre, c'est être battu du flot extérieur.	CHARTIER Emile	Entretiens Au Bord De La Mer.		234     communication	alias Alain (1868-1951)	berkeley	1218
Nous devrions enseigner aux futurs chefs de nos armées qu'ils entreront en campagne sans savoir d'après quelles règles la guerre se fera... Il faut improviser sur le théâtre même des opérations à la demande des circonstances et sous la pression de la nécéssité... ce qui implique une intelligence libre et ouverte, du jugement et de la décision.	MAYER Emile	article donné à "l"Opinion".	1909	391     commandement	commandant, ami de réflexion de Ch. de Gaulle & de Lucien Nachin	berkeley	4267
Il ne me paraît pas assez intelligent pour être fou.	GUITRY Sacha	Une folie		370     esprit	1885-1957.	berkeley	3059
Je crois que la médiocrité, si nous la cultivons volontairement, peut devenir une forme d'orgueil intellectuel. Et l'humilité aussi.	MORGAN Charles	Défi à Vénus.		510     ironie		berkeley	4505
Tous les malheurs des hommes, tous les revers funestes dont les histoires sont remplies, les bévues des politiques, et les manquements des grands capitaines, tout cela n'est venu que faute de savoir danser.	MOLIERE	Le Bourgeois Gentilhomme.		221     vanité		berkeley	4296
Partir, c'est mourir un peu;  C'est mourir à ce qu'on aime.  On laisse un peu de soi-même  En toute heure et dans tout lieu.	HARAUCOURT Edmond	Rondel de l"adieu		420     capital affectif	1857-1941.	berkeley	3084
Il y a toujours quelque niaiserie à trop respecter les femmes.	NERVAL Gérard de	Lettres		433     perversion	1808-1855. (Gérard Labrunie)	berkeley	4576
Celui qui ressent sa propre vie et celle des autres comme dénuées de sens est fondamentalement malheureux, puisqu'il n'a aucune raison de vivre.	EINSTEIN Albert	Comment je vois le Monde	1934	140     rapport à la cosmogonie	rééd.corr. en 1952 et 1978.	berkeley	2295
Tant qu'on est redoutable on n'est point innocent.	DELAVIGNE Casimir	Les Vêpres siciliennes		210     violence	1793-1843.	berkeley	1883
Selon que vous serez puissant ou misérable,  Les jugements de cour vous rendront blanc ou noir.	LA FONTAINE Jean de	Fables.		120     grégarité	1621-1695	berkeley	3645
Femme tentée et femme vaincue, c'est tout un.	MARIVAUX Pierre Carlet de Chamblain de	Arlequin poli par l"amour, 1		321     volonté	1688-1763.	berkeley	4226
Le bonheur n'est rien d'autre que l'amour ; seul l'amour est bonheur.	VON CHAMISSO Adalbert	Poésies.		420     capital affectif		berkeley	5336
On se lasse d'être héros et on ne se lasse pas d'être riche.	FONTENELLE Bernard le Bovier de	Lettres galantes du chevalier d"Her...		510     ironie	1657-1757.	berkeley	2830
Les rêves sont les dents du dragon. Il y pousse parfois des fleurs, parfois des guerriers armés de pied en cap...	WEST Morris	Le Loup Rouge.	1971	350     imagination		berkeley	5390
Il faut juger un homme et ses actes en fonction de son milieu et de sa condition sociale.	WEST Morris	Toute la vérité.	1957	365     discernement		berkeley	5391
Les murs et les portes ne créent aucun véritable intimité. Si on peut y assurer une température agréable, pourquoi casser l'espace ?	WEST Morris	De main de Maître.	1988	370     esprit	370     espr\\010b2&#240;\\010biê	berkeley	5392
Mon coeur bondit quand je contemple Un arc-en-ciel dans les nues : Il en était ainsi au début de ma vie ; Ainsi en est-il maintenant que je suis homme ;Et puisse-t-il en être ainsi quand je prendrai de l'âge, Ou alors autant mourir ! L'Enfant est le père de l'Homme, Et je souhaite que mes jours Restent liés les uns aux autres par cette dévotion à la nature.	WORDSWORTH William	L"Arc en Ciel, poème.		312     foi		berkeley	5494
Chaque tableau impose des moments et des difficultés particulières. Heureusement, il y a ce besoin toujours renouvelé de créer, d'inventer. Si vous entrez dans un système, alors, l à, il n'y a plus d'aventure...	WOU-KI Zao	Les secrets de la création, in Télérama 2175 (21/09/91)	1991	390     création	peintre, né d"une famille issue de la dynastie Song, vit à Paris	berkeley	5498
Les devins, ... tout en annonçant aux autres l'avenir, ne prévoient pas ce qui les attend eux-mêmes.	Xénophon	Le Banquet, III, 5		215     mystifications	v. 430-v. 355 av. J.-C.	berkeley	5500
L'homme qui pense avec sa tête à lui est un homme libre. L'homme qui lutte pour ce qu'il croit juste est un homme libre. On ne va pas mendier sa liberté aux autres. La liberté, il faut la prendre.	SILONE I.	Le pain et le vin.		130     liberté		berkeley	5081
C'est ainsi que meurent les villes, et aussi les empires, songea Hanlon avec mélancolie. Non pas sous l'effet de cataclysmes spo- radiques : guerres, tremblements de terre, incendies, inondations - mais par un lent recul de la vie qui se retire des membres vers le coeur dont les ventricules sont le marché, les boutiques, les cafés, l'église. Au bout d'un certain temps, le coeur cesse de battre, car, lorsque les membres sont morts, le corps inerte devient inutile, et la vie n'est plus qu'une série de pulsations vainement répétées : énergie perdue, mouvement sans but !	WEST Morris	La seconde victoire.	1972	240     débauche		berkeley	5381
Un scandale commence à devenir scandaleux lorsque, de salubre, de vif qu'il était, il en arrive au dogme et, dirai-je, lorsqu'il rapporte.	COCTEAU Jean	Les Parents terribles		510     ironie	1889-1963.	berkeley	1519
Que la jeunesse avance par injustice, c'est justice. Car promptement arrive l'âge du recul.	COCTEAU Jean	La Difficulté d"être		510     ironie	1889-1963.	berkeley	1520
Quand on peut accomplir sa promesse sans manquer à la justice, il faut tenir sa parole.	CONFUCIUS	Entretiens, I, 1		546     éthique	551-479 av. J.-C. (Chinois)	berkeley	1608
Et conter pour conter me semble peu d'affaire.	LA FONTAINE Jean de	Fables, le Pâtre et le Lion		221     vanité	1621-1695.	berkeley	3670
Celui qui désire, mais n'agit point, engendre la peste.	BLAKE William	Le Mariage du Ciel et de l"Enfer.		110     entropie	1757-1827 (Anglais). The Marriage of Heaven and Hell	berkeley	756
Celui dont le visage ne reflète pas la lumière ne sera jamais une étoile.	BLAKE William			110     entropie		berkeley	757
Cïur gros n'efface pas faute.	KIPLING Rudyard	Le livre de la Jungle	1894	433     perversion		berkeley	3564
Quiconque choisit le juste milieu, précieux comme l'or...  Auream quisquis mediocritatem  Diligit...	Horace	Odes, II, X, 5  		441     sang-froid	65-8 av. J.-C. (Quintus Horatius Flaccus)  Ces vers, souvent abrégés en "aurea mediocritas", sont parfois mal entendus. Il ne s"agit pas de "médiocrité dorée", les deux mots étant contradictoires. Mediocritas est la juste mesure, le juste milieu (medius), et aurea signifie, par métaphore, excellente, l"or étant le roi des métaux.	berkeley	3255
Du succès les mortels ne se rassasient jamais.	Eschyle	Agamemnon, 1331		440     courage	v. 525-45 av. J.-C.	berkeley	2374
Ces choses (quantité et qualité des connaissances, nouvauté et singularité des initiatives ndr) sont hors de l'homme même : le style ne peut donc ni s'enlever, ni se transporter, ni s'altérer : s'il est élevé, noble, sublime, l'auteur sera également admiré dans tous les temps ; car il n'y a que la vérité qui soit durable et même éternelle.	BUFFON Comte de	Discours sur le style.	1753	370     esprit	discours de réception à l"Académie Française.	berkeley	888
... tâcher toujours plutôt à me vaincre que la fortune, et à changer mes désirs que l'ordre du monde: et généralement de m'accoutumer à croire qu'il n'y a rien qui soit entièrement en notre pouvoir que nos pensées ...	DESCARTES René	Discours de la méthode 		421     initiation	1596-1650.	berkeley	1934
Je ne désire que la tranquillité et le repos, qui sont des biens que les plus puissants Rois de la terre ne peuvent donner à ceux qui ne les savent prendre d'eux-mêmes.	DESCARTES René	Correspondance		421     initiation	1596-1650.	berkeley	1935
Raconte-toi donc des histoires, si tu penses que celles qui te viennent de la vie sont, par trop, compliquées, voire ininteressantesé	FAIRGAGNETR Oscar	Vitalités.	1998	520     ironie de soi	L"épisode P.	berkeley	2460
[L'homme est généreux quand] Il sent en soi-même une ferme et constante résolution de bien user [de son libre arbitre] c'est à dire de ne jamais manquer de volonté pour entreprendre et exécuter toutes les choses qu'il jugera être les meilleures : ce qui est suivre parfaitement la vertu.	DESCARTES René			422     confiance en soi	1596/1650	berkeley	1936
Nous voyons (... que les passions) sont toutes bonnes de leur nature, et que nous n'avons rien à éviter que leurs mauvais usages ou leurs excès.	DESCARTES René	Les Passions de l"âme		430     paradoxal émotionnel	1596-1650.	berkeley	1937
Les hommes (que les passions) peuvent le plus émouvoir sont capables de goûter le plus de douceur en cette vie.	DESCARTES René	Les Passions de l"âme		430     paradoxal émotionnel	1596-1650.	berkeley	1938
Il faut que chaque mot qui tombe soit le fruit bien mûr de la succulence intérieure, la goutte qui glisse du bec de la bécasse à point.	FARGUE Léon-Paul	Sous la lampe		393     création artistique	1876-1947.	berkeley	2660
La poésie veut quelque chose d'énorme, de barbare et de sauvage.	DIDEROT Denis			393     création artistique		berkeley	2103
Presque toujours, en politique, le résultat est contraire à la prévision.	CHATEAUBRIAND François-René de	Mémoires d"outre-tombe		238     servitudes du pouvoir politique	1768-1848.	berkeley	1293
Il écrivait par jeu mécanique, pour réfléchir en solitaire sur ses propres erreurs, il s'imaginait ne pas 'créer' parceque la création, même si elle produit l'erreur, se donne toujours pour l'amour de quelqu'un qui n'est pas nous.	ECO Umberto	Le Pendule de Foucault	1988	393     création artistique		berkeley	2271
Il était victime des pénombres où les sens rencontrent le coeur.	COCTEAU Jean	Le Grand Ecart		420     capital affectif	1889-1963.	berkeley	1508
Prend-on la vie autrement que par les épines? 	CHAR René	Retour amont		510     ironie	1907-1988.	berkeley	1186
Ah! On peut s'enfuir, mais les souvenirs vous suivent dans le fourgon, et les regrets, et les remords.	STRINDBERG	Mlle Julie.		540     mémoire		berkeley	5158
Toute chose est le rêve d'un rêve.	LECONTE de LISLE			510     ironie		berkeley	4094
Il ne suffit pas de dire : Je me suis trompé; il faut dire comment on s'est trompé.	BERNARD Claude	Introduction à l"étude de la médecine expérimentale		441     sang-froid	1813-1878.	berkeley	705
Vous ne pourrez renouveler vos ressources qu'en les partageant. Il ne faut pas vous imaginer que vous allez passer tout votre temps de guérison dans un monde hermétique et en sortir ensuite comme un animal social.	WEST Morris	Les bouffons de Dieu.	1981	234     communication		berkeley	5372
Le détachement de tout n'est jamais si complet que quelque rêve encore ne survive à la mort des rêves.	CéARD Henry	Préface à Snob de Paul Gavault		420     capital affectif	1851-1924.	berkeley	1067
On ne doit pas attendre de l'éclair une clarté qui permette la contemplation.	CAILLOIS Roger	Les Impostures de la poésie		321     volonté	1913-1978.	berkeley	960
Je rends grâce à cette terre qui exagère tant la part du ciel.	CAILLOIS Roger	Les impostures de la poésie.	1945	380     travail	Académie Française	berkeley	962
L'extrême faiblesse impose l'extrême intransigeance.	DE GAULLE Charles			441     sang-froid		berkeley	1849
L'idéal permanent de l'évolution humaine n'est pas douteux. Ce qui manque à l'humanité, c'est la force de s'imposer à elle-même la poursuite constante de cet idéal.	ROMAINS Jules	Le Problème n° Un.		321     volonté		berkeley	4845
La démission et la violence n'enfantent qu'un état de nature dépourvu en tout du courage, de l'amour et de la foi qui font l'humanité de l'être.	FAIRGAGNETR Oscar	Vitalités.	1994	110     entropie		berkeley	2477
Le ciel s'étend tout autour de nous pendant notre enfance ! Les ombres de la prison commencent à entourer l'enfant qui grandit, mais il voit la lumière et sait d'où elle vient ;  il la voit et il est heureux ; le jeune homme, qui chaque jour s'éloigne davantage de l'orient, est encore le prêtre de la Nature, et la vision splendide l'accompagne sur son chemin ; enfin l'homme le voit s'évanouir et disparaître dans la lumière crue du jour.	WORDSWORTH William	Odes. Intuitions d"immortalité.		140     rapport à la cosmogonie	1770/1850	berkeley	5493
Il faudrait convaincre les hommes du bonheur qu'ils ignorent, lors même qu'ils en jouissent.	MONTESQUIEU Charles de	Mes pensées.		130     liberté		berkeley	4398
[L'oeuvre présente une] indivision du sensible et de l'intelligible.	HEGEL Friedrich			393     création artistique	1770/1831	berkeley	3092
L'oeuvre d'art est un moyen à l'aide duquel l'homme extériorise ce qu'il est, c'est à dire prend conscience de ce qu'il est.	HEGEL Friedrich			393     création artistique	1770/1831	berkeley	3093
Chaque  Oiseau  A la couleur  De son cri.	CHAZAL Malcolm de	Poèmes		370     esprit	1902-1981.	berkeley	1324
C'est pur suicide que de communiquer avec un être dévoré par le mépris.	FAIRGAGNETR Oscar	Vitalités.	1993	110     entropie		berkeley	2476
L'Etat, c'est le plus froid de tous les monstres froids. Il ment froidement et voici le mensonge qui rampe de sa bouche : 'Moi, l'Etat, je suis le Peuple.'	NIETZSCHE Friedrich	Ainsi parlait Zarathoustra.	1883	215     mystifications		berkeley	4585
Nous commettons tous des erreurs. Les fous seuls croient en être exempts - et les politiciens parfois.	SULITZER Paul-Loup	Cartel.	1990	510     ironie		berkeley	5165
Les femmes sont toujours des écrivains qui ne ressemblent pas à leurs oeuvres et toutes leurs lettres d'amour ne valent jamais ce qu'elles vous disent à leurs heures d'amour et de trahison, de joie et de tristesse.	DONNAY Maurice	Pensées.		531     communication amoureuse		berkeley	2134
Les amants sincères, qui savent ne point se devoir à leurs milieux mais à eux-mêmes et l'un à l'autre, trouveront toujours matière à revitaliser leur flamme.	FAIRGAGNETR Oscar	Vitalités.	1994	531     communication amoureuse	\\002é\\026 à	berkeley	2641
Le coeur d'aimer nait d'une intuition, croit dans l'intention et vit dans la passion physique et morale.	FAIRGAGNETR Oscar		1991	531     communication amoureuse		berkeley	2642
Pour les prédicateurs ..., ce n'est pas la religion mais leur bel esprit qu'ils ont intérêt de persuader au monde.	Fénelon	Lettre à l"Académie		215     mystifications	1651-1715. (François de Salignac de La Mothe-)	berkeley	2683
Il est entre l'ambition et la dignité une porte étroite qui, tôt ou tard, se présente à l'itinéraire des hommes en formation. Au narcissisme de l'être succèdera possiblement la tranquilité de l'ambition de faire, de la dignité de l'être et du respect de l'autre.	FAIRGAGNETR Oscar		1990	550     grandeur		berkeley	2651
On s'accoutume à tout dans l'abondance, il n'y a guère de dégoût dont elle ne console.	MARIVAUX Pierre Carlet de Chamblain de	La Vie de Marianne		510     ironie	1688-1763.	berkeley	4233
Faut-il réagir contre la paresse des voies ferrées entre deux passages de trains? 	DUCHAMP Marcel	Marchand du sel		365     discernement	1887-1968.	berkeley	2190
Le meilleur des gouvernements, n'est pas celui qui fait les hommes les plus heureux, mais celui qui fait le plus grand nombre d'heureux.	DUCLOS Charles Pinot	Considérations sur les moeurs de ce siècle		238     servitudes du pouvoir politique	1704-1772.	berkeley	2195
L'esprit d'égalité extrême, conduit au despotisme d'un seul.	MONTESQUIEU Charles de	De l"esprit des lois		120     grégarité	1689-1755. (C. de Secondat, baron de La Brède et de M.)	berkeley	4395
C'est Paris qui fait les Français.	MONTESQUIEU Charles de	Mes pensées		120     grégarité	1689-1755. (C. de Secondat, baron de La Brède et de M.)	berkeley	4396
Il suffit d'un très petit degré d'espérance pour causer la naissance de l'amour.	STAEL Madame de			530     ironie amoureuse	fille de NECKER, directeur des finances de Louis XVI.	berkeley	5131
La gloire elle-même ne saurait être, pour une femme, qu'un deuil éclatant du bonheur.	STAEL Madame de	Corinne ou l"Italie		539     ironie sociale	1766-1817. (Germaine Necker, baronne de Staël-Holstein)	berkeley	5133
Il est finalement assez peu de manières originales de faire l'amour et toutes se rapportent peu ou prou à l'ironie d'aimer se partager ou à l'instrumentalisation des êtres aux seules fins de satisfaire les fantasmes les plus solitaires.	FAIRGAGNETR Oscar		1991	430     paradoxal émotionnel		berkeley	2585
Le pessimisme est d'humeur ; l'optimisme est de volonté.	CHARTIER Emile	Propos sur le bonheur.		321     volonté	alias ALAIN	berkeley	1221
La guerre est un mal qui déshonore le genre humain.	FENELON	Dialogue des morts.		211     guerre		berkeley	2679
Le plus sot s'instruit par l'événement.	Homère	L"Iliade, XVII, 32		360     bon sens	VIIIe s. av. J.-C.	berkeley	3218
Le grand but de l'éducation n'est pas le savoir, mais l'action.	SPENCER Herbert			421     initiation		berkeley	5100
Mieux vaut souffrir en silence d'une passion cachée que de se confier à un compagnon. Il est de tels secrets qu'on ne dépose pas en des coeurs pleins de malice.	HAFIZ	Les Ghazels.		423     solitude		berkeley	3078
L'imbécile, c'est Mac-Mahon qui passe en revue ses officiers et en voit un couvert de décorations, de la Martinique. 'Vous êtes nègre ?' lui demande-t-il. Et l'autre : 'Oui, mon général !' Et Mac-Mahon : 'Bravo, bravo, continuez !' Et ainsi de suite. Vous me suivez ?	ECO Umberto	Le Pendule de Foucault	1988	120     grégarité		berkeley	2258
Je ne suis pas heureux dans l'affrontement, mais je pense que l'histoire, comme la vie, est un conflit.	VERGES Jacques	Le Salaud lumineux.	1990	432     expérience	entretiens avec Jean-Louis Remilleux.	berkeley	5278
Chaque instant de la vie est un pas vers la mort.	CORNEILLE Pierre	Tite et Bérénice, V, 1, Tite		510     ironie	1606-1684.	berkeley	1681
Ne dédaignons pas trop la gloire : rien n'est plus beau qu'elle si ce n'est la vertu.	CHATEAUBRIAND François-René de	Mes pensées.		441     sang-froid		berkeley	1305
La liberté qui capitule, ou le pouvoir qui se dégrade, n'obtient point merci de ses ennemis.	CHATEAUBRIAND François-René de	Mémoires d"outre-tombe		442     démission	1768-1848.	berkeley	1308
Pour bien dire un texte, il faut le rêver.	DEPARDIEU Gérard			234     communication	cité, en sa présence, par JM Cavada sur le plateau de la Marche du Siècle du 16/11/94	berkeley	1901
Savoir vouloir avec le sourire et agir utilement.	MARVINGT Marie	Devise De...		441     sang-froid	1881/1963. Aérostière (traversée de la Manche), aviatrice, sportive éclectique, conférencière.	berkeley	4241
Notre vie vaut ce qu'elle nous a couté d'effort.	MAURIAC François	Le Jeune Homme.		380     travail		berkeley	4260
C'est le devoir qui crée le droit et non le droit qui crée le devoir.	CHATEAUBRIAND François-René de	Mémoires d"outre-tombe		546     éthique	1768-1848.	berkeley	1318
... Ne possédait pas l'or, mais l'or le possédait.	LA FONTAINE Jean de	Fables, L"Avare qui a perdu son trésor		433     perversion	1621-1695.	berkeley	3721
Le sage dit, selon les gens:  Vive le roi, vive la ligue! 	LA FONTAINE Jean de	Fables		441     sang-froid	1621-1695.	berkeley	3726
... mais dans cet antre  Je vois fort bien comme l'on entre,  Et ne vois pas comme on en sort.	LA FONTAINE Jean de	Fables, le Lion malade et le Renard		441     sang-froid	1621-1695.	berkeley	3733
La raison et le sentiment se conseillent et se suppléent tour à tour. Quiconque ne consulte qu'un des deux et renonce à l'autre, se prive inconsidérément d'une partie des secours qui nous ont été accordés pour nous conduire.	VAUVENARGUES Marquis de	Réflexions et Maximes.		441     sang-froid	CLAPIER Luc de	berkeley	5267
Rendons aux grands ce qui leur est dû; mais tenons-nous-en loin le plus que nous pourrons.	COURIER Paul-Louis			441     sang-froid	1772-1825.   Simple discours... à l"occasion d"une souscription proposée par S. Ex. le ministre de l"Intérieur, pour l"acquisition de Chambord	berkeley	1696
Le mot, il faut le manger très très lentement, tu ne peux le dissoudre et le recombiner que si tu le laisse fondre sur la langue, et attention à ne pas baver sur ton cafetan, car si une lettre s'éva- pore, le fil qui est sur le point de t'unir aux séfirots supérieurs se casse.( ) Logique mystique, le monde des lettres et de leur tourbil- lonnement en permutations infinies est le monde de la béatitude, la science de la combinaison est une musique de la pensée, mais attention à te mouvoir avec lenteur, et avec prudence, parceque ta machine pourrait te donner le délire et non l'extase.	ECO Umberto	Le Pendule de Foucault	1988	393     création artistique		berkeley	2270
Chacun de nous de temps à autre est crétin, imbécile, stupide ou fou. Disons que la personne normale est celle qui mêle en une mesure raisonnable toutes ces composantes, ces types idéaux.	ECO Umberto	Le Pendule de Foucault	1988	510     ironie	510     iron\\010Yâ0\\010Yé à	berkeley	2274
Si ma théorie de la relativité est prouvée, l'Allemagne me revendiquera comme Allemand et la France déclarera  que je suis un citoyen du monde. Mais si ma théorie est fausse, la France dira que je suis un Allemand et l'Allemagne déclarera que je suis un juif.	EINSTEIN Albert	Discours en Sorbonne.		225     cynisme		berkeley	2300
Dans les premières passions les femmes aiment l'amant, et dans les autres elles aiment l'amour.	LA ROCHEFOUCAULD François de	Maximes		530     ironie amoureuse	1613-1680.	berkeley	3927
Fiez-vous aux personnes jalouses du soin de vous connaître.	MARIVAUX Pierre Carlet de Chamblain de	La Vie de Marianne		234     communication	1688-1763.	berkeley	4222
Je ne veux avoir ni amour, ni haine, ni pitié, ni colère. Quant à la sympathie, c'est différent : jamais on n'en a assez.	FLAUBERT Gustave	L"amour de l"art.	1915	330     coeur	(1821/1880) édition posthume	berkeley	2734
La confiance de plaire est souvent un moyen de plaire infailliblement.	LA ROCHEFOUCAULD François de	Maximes.		422     confiance en soi		berkeley	3870
Quelle que soit la chose qu'on veut dire, il n'y a qu'un mot pour l'exprimer, qu'un verbe pour l'animer et qu'un adjectif pour la qualifier.	MAUPASSANT Guy de	Pierre et Jean		545     épistémologie	1850-1893.	berkeley	4258
Une monstrueuse aberration fait croire aux hommes que le langage est né pour faciliter leurs relations mutuelles.	LEIRIS Michel	Glossaire, j"y serre mes gloses.	1939	510     ironie	illustré par lithos de Masson, édité par DHK.	berkeley	4102
La puissance dépend de l'empire de l'onde ; Le trident de Neptune est le spectre du monde.	LEMIERRE Antoine-Marin	Le Commerce.		230     pouvoir	1723/1793	berkeley	4104
A partir d'un potentiel intellectuel et physique initial donné, l'avenir de l'enfant sera essentiellement déterminé par la structuration de son rapport affectif et rationnel à l'autorité et au système d'organisation personnelle que l'exemplarité et la contrainte lui suggèreront d'adopter. S'il peut tirer avantage du modèle proposé pour comprendre et accepter les termes de l'échange qui le relient à son environnement, il produira les efforts de volonté (d'intention) propres à lui permettre de mesurer sa force, affirmant en cel à son individualité et son assurance.	FAIRGAGNETR Oscar	Vitalités.	1992	421     initiation		berkeley	2575
Les katas ont un vrai pouvoir d'apaisement sur l'esprit. Quand on les pratique correctement, l'intellect - la surface du psychisme - se met en veilleuse, les actions s'enracinent dans le cerveau reptilien, qui laisse le pouvoir aux réflexes et aux instincs.	CAMP John	Trajectoire de fou	1989	441     sang-froid	*Nom des mouvements du Dojo, sport d"art martial oriental.	berkeley	982
Le sage donne son principal soin à la racine.	CONFUCIUS	Entretiens, I, 1		560     sagesse	551-479 av. J.-C. (Chinois)	berkeley	1612
La poésie est une religion sans espoir.	COCTEAU Jean	Journal d"un inconnu		393     création artistique	1889-1963.	berkeley	1506
Le Maître ne parlait pas des choses extraordinaires, ni des actes de violence, ni des troubles, ni des esprits.	CONFUCIUS	Entretiens, IV, 7		560     sagesse	551-479 av. J.-C. (Chinois)	berkeley	1613
On ne fait rien de grand sans le fanatisme.	FLAUBERT Gustave	Correspondance		321     volonté		berkeley	2731
Sur les définitions de l'apprentissage de mémorisation et de l'apprentissage de conceptualisation... Pourquoi le premier est innaccessible au 'mauvais lecteur'... Pourquoi le second est le seul à même de permettre à celui-ci de reconstituer 'le chemin de la connaissance' par interrogation, reconstitution et réindexation conceptuelle des 'cases de savoir' non spontanément décriptées, faute d'un processeur de lecture naturellement performant.	FAIRGAGNETR Oscar	Vitalités.	1994	365     discernement	le 1/07/94, en réflexion sur les tenants et les aboutissants d"une certaine instabilité professionnelle.	berkeley	2547
C'est comme lorsqu'on fabrique une corde de chanvre. Chacune des fibres est faible, si faible qu'un enfant peut la casser. Mais si tu les tresses ensemble, elles sont capables de faire tenir un mât contre un ouragan... Après une épreuve longue et ardue, je suis comme une corde sur laquelle on a tiré trop fort et qui s'est usée. Alors je m'assieds et je me tresse à nouveau, avec de nouveaux fils. Je regarde et je rêve et je me souviens des conseils de mon père et des mots des faiseurs de chansons et des cris de tous les oiseaux. Je ne parle pas, car chaque mot est un fil qu'on arrache. Personne ne doit me toucher car chaque effleurement me vole un morceau de moi-même. Tu dois apprendre à en faire autant. Apprends à être silencieux. Trace un cercle autour de toi-même et ne laisse personne y pénétrer...	WEST Morris	Kaloni le navigateur.	1976	441     sang-froid		berkeley	5435
Le pire danger qu'il y a à tromper autrui, c'est qu'on finit toujours par se tromper soi-même.	DUSE Eleonora	er autrui, c\\010Y£@\\010Yß`		433     perversion	\\010sô∞\\020	berkeley	2240
Seul est esclave celui qui espère quelque chose des autres. Peut-être est-ce cela l'erreur. Celui qui n'attend rien de personne demeure libre, comme Diogène dans son tonneau.	PEREZ-REVERTE Arturo	Le Maître d"escrime	1985	423     solitude		berkeley	4671
Les imbéciles ont dans la fourberie des grâces inimitables.	FRANCE Anatole	L"Ile des pingouins		222     fourberie	1844-1924. (Anatole François Thibault)	berkeley	2857
L'avenir est un lieu commode pour y mettre des songes.	FRANCE Anatole	Les Opinions de Jérôme Coignard		433     perversion	1844-1924. (Anatole François Thibault)	berkeley	2863
Les joies du monde sont notre seule nourriture. La dernière petite goutte nous fait encore vivre.	GIONO Jean	Que ma joie demeure		312     foi		berkeley	2950
Il n'y a pas d'amour de la part d'un être sans liberté. Ce qu'il appelle son amour n'est que la passion de cette liberté.	BOUSQUET Joë	Langage Entier.		530     ironie amoureuse		berkeley	825
La gloire des grands hommes tient pour un quart à leur audace, pour deux quarts au hasard, pour le dernier quart à leurs crimes.	FOSCOLO Ugo	Les dernières lettres de Jacques Ortis.		510     ironie	Les dernières lettres de Jacques Ortis.	berkeley	2843
La richesse de l'homme est dans son coeur. C'est dans son coeur qu'il est le roi du monde. Vivre n'exige pas la possession de tant de choses.	GIONO Jean	Les Vraies Richesses.		420     capital affectif		berkeley	2954
[Face à une foule dominée par des passions qui menacent la stru- cture et l'équilibre de la collectivité], j'aime mieux commettre une injustice que de souffrir un désordre.	GOETHE Johann Wolfgang von	Le siège de Mayence.	1793	120     grégarité	1749/1832	berkeley	2971
Autrefois, je considérais que chaque original était un malade et un anormal, mais à présent, je considère que l'état normal d'un homme est d'être un original.	TCHEKOV A.P.	L"oncle Vania.		560     sagesse		berkeley	5193
Ils (les Français) veulent l'égalité dans la liberté et, s'ils ne peuvent l'obtenir, ils la veulent encore dans l'esclavage.	TOCQUEVILLE Alexis de	L"Ancien Régime et la Révolution		221     vanité	1805-1859.	berkeley	5203
Roland est preux, et Olivier est sage.  Rollant est proz e Oliver est sage.	Chanson de Roland			440     courage	v. 1100 	berkeley	1165
J'ai remarqué que plus on est envahi par le doute, plus on s'attache à une fausse lucidité d'esprit avec l'espoir d'éclaircir par le raison- nement ce que le raisonnement a rendu trouble et obscur.	MORAVIA A.	Le Mépris.		433     perversion		berkeley	4494
Tant que l'on aime quelqu'un pour ses qualités, ce n'est pas grave, mais quand on commence à l'aimer pour ses défauts, attention danger : c'est l'aimer.	GUITRY Sacha			530     ironie amoureuse		berkeley	3070
Le développement intellectuel et moral des individus ne marche pas aussi vite que le développement de leur existence matérielle.	GUIZOT François	Histoire parlementaire de la France		365     discernement	1787-1874.	berkeley	3073
Les événements sont plus grands que ne le savent les hommes.	GUIZOT François	Essais sur l"histoire de France		510     ironie	1787-1874.	berkeley	3074
Dieu aime les adverbes.  God loveth adverbs.	HALL évêque	Holy Observations, 1607		215     mystifications	1574-1656. (Anglais)	berkeley	3080
Aucun homme n'a reçu de la nature le droit de commander les autres.	DIDEROT Denis	Encyclopédie		391     commandement	1713-1784.	berkeley	2102
N'attendez pas le Jugement dernier. Il a lieu tous les jours.	CAMUS Albert	La Chute		560     sagesse	1913-1960.	berkeley	1030
Descartes, ce mortel dont on eût fait un dieu  Chez les païens, et qui tient le milieu  Entre l'homme et l'esprit ...	LA FONTAINE Jean de	Fables, les Deux Rats, le Renard et l"Oeuf		370     esprit	1621-1695.	berkeley	3703
Le monde est la maison du fort.	DIDEROT Denis	Eléments de physiologie		422     confiance en soi	1713-1784.	berkeley	2105
Un homme d'esprit me disait un jour que le gouvernement de France était une monarchie absolue tempérée par des chansons.	CHAMFORT Nicolas-Sébastien de	Caractères et anecdotes		215     mystifications	1740/1794. Ac. Française	berkeley	1110
Ne savez-vous que l'amitié n'a point d'autre moisson que l'amitié, et que tout ce qu'elle sème, c'est seulement pour en recueillir le fruit? 	URFé Honoré d"	L"Astrée		234     communication	1567-1625.	berkeley	5232
Nos laborieux efforts pour amadouer le gouvernement de Vichy pourraient faire penser à ceux d'une personne bien intentionnée qui voudrait donner de la laitue à un lapin alors que celui-ci est poursuivi par une hermine qui vient d'entrer dans sa cage. C'est pour le moins un gâchis de laitue, car même si le lapin était reconnaissant - ce qui ne parait guère vraisemblable - il resterait malgré tout à la merci de l'hermine.	SPEARS Sir Edward	mémorandum à Churchill sur les moyens d"amadouer Pétain.	1940	239     servitudes du pouvoir autoritaire	quant à négociation sur ralliement éventuel de l"Afrique du nord	berkeley	5099
Les morts avec les morts, les vivants avec les vivants!  Les mors as mors, les vis as vis! 	Chrétien de Troyes	Le Conte Du Graal.		440     courage	Seconde moitié du XIIe siècle. Proverbe dit par Perceval alors qu"il vient d"apprendre la mort de sa mère.	berkeley	1360
Celui qui vante le temps jadis.  Laudator temporis acti.	Horace	Art poétique, 173  	3  	215     mystifications	65-8 av. J.-C. (Quintus Horatius Flaccus)  Horace fait ressortir ce défaut ordinaire aux vieillards de dénigrer le présent au profit du passé: "Difficilis, querulus, Laudator temporis acti/Se puero... Difficile, grincheux, vantant le temps jadis lorsqu"il était enfant..."	berkeley	3234
Le bonheur n'est jamais grandiose.  Happiness is never grand.	HUXLEY Aldous	Brave New World, 16.		420     capital affectif	1894-1963 (Anglais)	berkeley	3361
Les jours sont des fruits et notre rôle est de les manger.	GIONO Jean	Que ma joie demeure		312     foi		berkeley	2949
Dans l'espoir de mériter le ciel en faisant de la terre un enfer.  In hope to merit heaven by making earth a hell.	BYRON George Gordon lord	Childe Harold"s Pilgrimage, I, 20		221     vanité	1788-1824. (Anglais)	berkeley	941
Solitude où je trouve une douceur secrète,  Lieux que j'aimai toujours, ne pourrai-je jamais,  Loin du monde et du bruit, goûter l'ombre et le frais? 	LA FONTAINE Jean de	Fables		520     ironie de soi	1621-1695.	berkeley	3749
On nait toujours sous un signe erroné, et être dignement au monde veut dire corriger jour après jour son horoscope.	ECO Umberto	Le Pendule de Foucault	1988	421     initiation		berkeley	2273
L'étude de l'homme physique est également intéressante pour le médecin et pour le moraliste.	CABANIS Pierre-Jean-Georges	Rapports du physique et du moral de l"homme		546     éthique	1757-1808.	berkeley	949
J'estime par-dessus tout d'abord le style, et ensuite le vrai.	FLAUBERT Gustave	Correspondance, 1842, à Louis Bonenfant, 1856		311     distinction	1821-1880.	berkeley	2727
On n'est idéal qu' à la condition d'être réel, et on n'est vrai qu' à force de généraliser.	FLAUBERT Gustave	L"amour de l"art.	1915	320     intuition	(1821/1880) édition posthume	berkeley	2728
Il n'existe pas d'opération militaire plus dangereuse qu'une marche de nuit.	CHURCHILL Sir Winston Leonard Spencer	The River War. XII	1899	211     guerre		berkeley	1365
Ceux qui sont incapables de commettre de grands crimes n'en soupçonnent pas facilement les autres.	LA ROCHEFOUCAULD François de	Maximes.		320     intuition		berkeley	3841
Au dernier jour on ne vous demandera pas ce que vous avez su mais ce que vous avez fait.	GERSON Jean	L"imitation de Jésus-Christ.		520     ironie de soi		berkeley	2925
Totalement indépendant, boule lisse...  In seipso totus teres atque rotundus...  Satires, II, 7, 86  	Horace			560     sagesse	65-8 av. J.-C. (Quintus Horatius Flaccus)  C"est la définition du sage dans la philosophie stoïcienne. Il ne demande rien aux objets extérieurs; c"est une boule sur laquelle glissent les événements.	berkeley	3266
Les plus pessimistes d'aujourd'hui ont été les plus optimistes autrefois. Ils poursuivaient de vaines illusions. L'échec les a découragés.	Hou Che	Traduction D. Tsan		433     perversion	1891-1962. (Chinois)	berkeley	3267
Agis au plus tôt pour éviter le mirage de raisonnements qui n'éclairent que les idées.	Houang Tsong-Hi			441     sang-froid	1610-1695. (Chinois) Traduction D. Tsan	berkeley	3270
Rien de grand ne se fait sans chimères.	RENAN Ernest	L"avenir de la science.		390     création		berkeley	4808
Les hommes ne vivraient pas longtemps en société s'ils n'étaient les dupes les uns des autres.	LA ROCHEFOUCAULD François de	Maximes		222     fourberie	1613-1680.	berkeley	3829
Quand sur une personne on prétend se régler, C'est par les beaux côtés qu'il lui faut ressembler.	MOLIERE	Les Femmes savantes.		510     ironie		berkeley	4300
Bon droit a besoin d'aide.	MOLIERE	La Comtesse d"Escarbagnas.		510     ironie		berkeley	4302
Les lois se maintiennent en crédit non parce qu'elles sont justes, mais parce qu'elles sont lois.	MONTAIGNE Michel Eyquem de	Essais, III, 13		215     mystifications	1533-1592.	berkeley	4318
Je me fais plus d'injure* en mentant que je n'en fais à celui à qui je mens.	MONTAIGNE Michel Eyquem de	Essais, II, 17 		221     vanité	1533-1592.  *Injustice.	berkeley	4324
Les vulgaires ne se sentent jamais forts que sur les déchets de la misère d'autrui.	FAIRGAGNETR Oscar	Vitalités.	1998	221     vanité		berkeley	2455
Voir une fille qu'on aurait pu aimer se comporter comme une poupée de cire, se rappeler à l'ironie de l'amouré	FAIRGAGNETR Oscar	Vitalités.	1998	530     ironie amoureuse		berkeley	2456
Quoique les hommes se flattent de leurs grandes actions, elles ne sont pas souvent les effets d'un grand dessein, mais des effets du hasard.	LA ROCHEFOUCAULD François de	Maximes		221     vanité	1613-1680.	berkeley	3813
Toujours nous trouverons qu'on se fait du tort en ne voulant pas faire simplement ce qui est juste et que telle est l'origine de tous les malheurs.	Démosthène	Pour les Mégalopolitains, 24		546     éthique	384-322 av. J.-C.	berkeley	1899
Quand on est mort, c'est pour longtemps.	DéSAUGIERS Marc-Antoine	Chansons		442     démission	1772-1827.	berkeley	1906
Le peuple n'a guère d'esprit et les grands n'ont point d'âme: celui-l à a un bon fond et n'a point de dehors; ceux-ci n'ont que des dehors et qu'une simple superficie. Faut-il opter? Je ne balance pas, je veux être peuple.	LA BRUYERE Jean de	Les Caractères, Des grands		510     ironie	1645-1696.	berkeley	3623
Le regret de n'avoir pas fait une mauvaise action profitable est bien plus commun que le remords.	LéVIS Duc de	Maximes et réflexions sur divers sujets		222     fourberie	1764-1830.	berkeley	4122
Les hommes font les lois ; les femmes font les moeurs.	LIGNE Prince Ch. de	Mémoire pour mon coeur accusé.		510     ironie		berkeley	4131
J'aime les gens distraits; c'est une marque qu'ils ont des idées et qu'ils sont bons: car les méchants et les sots ont toujours de la présence d'esprit.	LIGNE Prince de	Mes écarts		234     communication	1735-1814.	berkeley	4134
Je connais des gens qui n'ont d'esprit que ce qu'il leur faut pour être des sots.	LIGNE Prince de	Mes écarts		360     bon sens	1735-1814.	berkeley	4136
Le noir souci monte en croupe derrière le cavalier.  Post equitem sedet atra cura.	Horace	Odes, III, I, 40		420     capital affectif	65-8 av. J.-C. (Quintus Horatius Flaccus)	berkeley	3245
L'insolence est seulement l'alibi d'une belle médiocrité...	CHANCEL Jacques		1993	215     mystifications	Décryptages 06/10/93	berkeley	1160
Une chose qu'on connaît bien pour l'avoir possédée, on n'en est jamais tout à fait privé.	COLETTE Sidonie Gabrielle	Le Pur et l"impur		432     expérience	1873-1954.	berkeley	1552
N'aimer guère en amour est un moyen assuré pour être aimé 	LA ROCHEFOUCAULD François de	Maximes		530     ironie amoureuse	1613-1680.	berkeley	3930
Qu'il est triste de tout aimer  sans savoir ce que l'on aime!  &#225; Qué triste es amarlo todo  sin saber lo que se ama! 	JIMéNEZ Juan Ramon	Rimas		433     perversion	1881-1958. (Espagnol)	berkeley	3438
L'exploitation des imbéciles ? Mais les imbéciles ont toujours été exploités, et c'est justice. Le jour où ils cesseront de l'être, ils triompheront, et le monde sera perdu.	CAPUS Alfred	Mariage bourgeois.		230     pouvoir		berkeley	1033
L'un disait: 'Il est mort; je l'avais bien prévu.  - S'il m'eût cru, disait l'autre, il serait plein de vie.' 	LA FONTAINE Jean de	Fables, les Médecins		221     vanité	1621-1695.	berkeley	3666
Personne ne t'empêchera de vivre selon la raison de ta propre nature ; rien ne t'arrivera qui soit en opposition avec la raison de la nature universelle.	MARC AURELE	Pensées.		140     rapport à la cosmogonie		berkeley	4215
Chacun de nous a sa lunette  Qu'il retourne suivant l'objet:  On voit l à-bas ce qui déplaît,  On voit ici ce qu'on souhaite.	FLORIAN Jean-Pierre Claris de	Fables, le Chat et la Lunette		520     ironie de soi	1755-1794.	berkeley	2808
Le mélange de l'admiration et de la pitié est une des plus sûres recettes de l'affection.	MAUROIS André	Ariel ou la Vie de Shelley		420     capital affectif	1885-1967. (Emile Herzog)	berkeley	4263
L'homme est de glace aux vérités,  Il est de feu pour les mensonges.	LA FONTAINE Jean de	Fables, le Statuaire et la Statue de Jupiter		433     perversion	1621-1695.	berkeley	3719
Tous mes biens sont avec moi.  Omnia bona mea mecum sunt.	Sénèque	Lettres à Lucilius, IX		365     discernement		berkeley	5023
De loin, c'est quelque chose: et de près ce n'est rien.	LA FONTAINE Jean de	Fables, le Chameau et les Bâtons flottants		215     mystifications	1621-1695.	berkeley	3657
Se croire un personnage est fort commun en France.	LA FONTAINE Jean de	Fables, le Rat et l"Eléphant		221     vanité	1621-1695.	berkeley	3659
Celui qui entreprend de se singulariser dans ce monde de la vérité et de la connaissance, celui qui se voudrait un oracle, échoue piteusement sous l'éclat de rire des dieux.	EINSTEIN Albert	Comment je vois le Monde	1934	221     vanité	rééd.corr. en 1952 et 1978.	berkeley	2299
Il y a plus d'une sagesse, et toutes sont nécessaires au monde; il n'est pas mauvais qu'elles alternent.	YOURCENAR Marguerite	Mémoires d"Hadrien		560     sagesse	1903-1987. (Marguerite de Crayencour)	berkeley	5517
Le plus grand dérèglement de l'esprit, c'est de croire les choses parce qu'on veut qu'elles soient, et non parce qu'on a vu qu'elles sont en effet.	BOSSUET Jacques Bénigne	Traité de la connaissance de Dieu et de soi-même.		360     bon sens		berkeley	803
L'amour est un égoïsme à deux.  	STAEL Madame de	L"attribution à Mme de Staël n"est pas certaine.		531     communication amoureuse	1766-1817. (Germaine Necker, baronne de Staël-Holstein)	berkeley	5132
Qui cherche dans la liberté autre chose qu'elle-même est fait pour servir.	TOCQUEVILLE Alexis de	L"Ancien Régime et la Révolution		130     liberté	1805-1859.	berkeley	5202
La force, en vertu de laquelle l'homme persévère dans l'existence, est limitée, et infiniment surpassée par la puissance des causes extérieures.	SPINOZA Baruch	L"Ethique.		310     énergie		berkeley	5102
La liberté consiste à pouvoir faire tout ce qui ne nuit pas à autrui ...	Déclaration des Droits de l"Homme	Article IV	1789	215     mystifications	1789. (et du Citoyen)	berkeley	1874
A mesure que s'envolaient les mots irrévocables, je sentais en moi-même se terminer une vie, celle que j'avais menée dans le cadre d'une France solide et d'une indivisible armée. A 49 ans, j'entrais dans l'aventure comme un homme que le destin jetait hors de toutes les séries.	DE GAULLE Charles	Mémoires de guerre.		430     paradoxal émotionnel	lançant, de Londres, l"appel du 18 juin.	berkeley	1832
Il ne faut pas mépriser l'homme, si l'on veut obtenir des autres et de soi de grands efforts.	TOCQUEVILLE Alexis de	Correspondance		312     foi	1805-1859.	berkeley	5207
Devant le vide effrayant du renoncement général, ma mission  m'apparut, d'un seul coup, claire et terrible. En ce moment, le pire de son histoire, c'était à moi d'assumer la France.	DE GAULLE Charles	Mémoires de guerre.		391     commandement		berkeley	1825
Le petit coeur de votre enfant est tout débordant de tendresse. Prenez mes baisers mes caresses Et tous les voeux tendres et doux Qu'au Jour de l'An je fais pour vous.	DE GAULLE Philippe et Yvonne		1927	420     capital affectif	compliment versé de Ph. de Gaulle à son père par le Nouvel An.	berkeley	1864
Si j'ai lancé dans le monde des idées, et bientôt dans celui des faits, la conception que vous savez, ce n'est pas seulement pour des raisons de pure technique [...]. Il faut que l'armée ait en elle une fraction au moins modèle dont tout le reste recevra le rayonnement.	DE GAULLE Charles	lettre au colonel de Ruffray.(in lettres, notes et carnets, II)	1936	421     initiation		berkeley	1827
- Si je l'ai découvert, c'est que je le cherchais. - Comment ?... Vous espériez peut-être le trouver ? - J'ai pensé que ce n'était pas improbable.	DOYLE Sir Arthur Conan	Les aventures de Sherlock Holmes		320     intuition		berkeley	2153
Quand vous avez épuisé toutes les possibilités, alors l'impossible doit être la réponse.	DOYLE Sir Arthur Conan	Les aventures de Sherlock Holmes		441     sang-froid		berkeley	2154
L'homme ne peut pas vivre sans feu, et l'on ne fait pas de feu sans brûler quelque chose.	DAUMAL René	Chaque fois que l"aube paraît		140     rapport à la cosmogonie	1908-1944.	berkeley	1770
Privée d'amour, la vie devient une maîtresse indécise, dangereuse et passionnée.	FAIRGAGNETR Oscar	Vitalités.	1992	420     capital affectif		berkeley	2567
On ne peut exprimer le trouble qu'apporta la jalousie dans un coeur où l'amour ne s'était pas encore déclaré 	LA FAYETTE M.-M.	Zaïde		530     ironie amoureuse	1634-1693. (Pioche de la Vergne, comtesse de)	berkeley	3640
Fuyez un ennemi qui sait votre défaut.	CORNEILLE Pierre	Polyeucte, I, 1, Néarque		441     sang-froid	1606-1684.	berkeley	1672
Faites votre devoir, et laissez faire aux dieux.	CORNEILLE Pierre	Horace, II, 8, le vieil Horace		441     sang-froid	1606-1684.	berkeley	1673
J'ose croire que la joie intérieure a quelque secrète force pour se rendre la fortune plus favorable.	DESCARTES René	Correspondance, à Elisabeth, octobre ou novembre 1646		312     foi	1596-1650.	berkeley	1915
Il faut de plus grandes vertus pour soutenir la bonne fortune que la mauvaise.	LA ROCHEFOUCAULD François de	Maximes		370     esprit	1613-1680.	berkeley	3858
La plupart des hommes emploient la meilleure partie de leur vie à rendre l'autre misérable.	LA BRUYERE Jean de			433     perversion		berkeley	3619
Le monde est le théâtre de changements, et être constant dans la nature serait une inconstance.  The world's a scene of changes and to be constant in Nature were inconstancy.	COWLEY Abraham	Inconstancy		140     rapport à la cosmogonie	1618-1667. (Anglais)	berkeley	1708
... S'il est vrai qu'il y ait peu de héros pour les gens qui les voient de près, je puis dire aussi qu'il y a, pour leur sopha, bien peu de femmes vertueuses.	CRéBILLON fils	Le Sopha		215     mystifications	1707-1777. (Claude-Prosper Jolyot de Crébillon)	berkeley	1711
La culture de l'esprit s'identifiera à la culture du désir.	DALI Salvador	Le Surréalisme au service de la révolution, n° 3		431     désir	1904-1989.	berkeley	1744
Une profonde ignorance avec beaucoup de modestie serait à la vérité fort incommode, mais, avec une extrême présomption, je puis vous assurer qu'elle n'a rien de gênant.	CRéBILLON fils	Les Egarements du coeur et de l"esprit		221     vanité	1707-1777. (Claude-Prosper Jolyot de Crébillon)	berkeley	1712
De toutes les vertus, celle qui, dans le monde, m'a toujours paru réussir le moins à celui qui la pratique, c'est la modestie.	CRéBILLON fils	Les Egarements du coeur et de l"esprit		221     vanité	1707-1777. (Claude-Prosper Jolyot de Crébillon)	berkeley	1713
La vertu n'irait pas si loin si la vanité ne lui tenait compagnie.	LA ROCHEFOUCAULD François de	Maximes		221     vanité	1613-1680.	berkeley	3807
Un homme d'esprit serait souvent bien embarrassé sans la compagnie des sots.	LA ROCHEFOUCAULD François de	Maximes		221     vanité	1613-1680.	berkeley	3808
Tout le monde se plaint de sa mémoire, et personne ne se plaint de son jugement.	LA ROCHEFOUCAULD François de	Maximes		221     vanité	1613-1680.	berkeley	3809
L'homme n'a de connaissance des choses naturelles que par les moyens de la correspondance avec ce qui tombe sous les sens.	DESCARTES René	Cogitationes privatae		340     sensibilité	1596-1650.	berkeley	1917
La gravité est le bonheur des imbéciles.	MONTESQUIEU Charles de			221     vanité		berkeley	4410
La même fermeté qui sert à résister à l'amour sert aussi à le rendre violent et durable ; Et les personnes faibles, qui sont toujours agi- tées des passions, n'en sont presque jamais véritablement remplies.	LA ROCHEFOUCAULD François de	Maximes.		530     ironie amoureuse		berkeley	3920
La jalousie naît toujours avec l'amour mais elle ne meurt pastoujours avec lui.	LA ROCHEFOUCAULD François de	D"amour mais		530     ironie amoureuse		berkeley	3921
Il y a des gens si remplis d'eux-mêmes, que lorsqu'ils sont amoureux ils trouvent le moyen d'être occupés de leur passion sans l'être de la personne qu'ils aiment.	LA ROCHEFOUCAULD François de	Maximes.		530     ironie amoureuse	1613/1680	berkeley	3922
Ne crois pas à celui qui vient de la foire, mais à celui qui y retourne.	Dictons et Proverbes	Dicton.		440     courage		berkeley	2032
Le progrès : la machine à lire les pensées qu'on n'a pas eues.	LEC Stanislas	Pensées Echevelées.		390     création		berkeley	4084
Lynx envers nos pareils, et taupes envers nous,  Nous nous pardonnons tout, et rien aux autres hommes.	LA FONTAINE Jean de	Fables		520     ironie de soi	1621-1695.	berkeley	3752
Si un cannibale mange avec une fourchette et un couteau, est-ce un progrès ?	LEC Stanislas	Pensées Echevelées.		510     ironie		berkeley	4089
Il avait bonne conscience. Elle n'avait pas beaucoup servi.	LEC Stanislas	Pensées Echevelées.		510     ironie		berkeley	4091
Il y a plus de fous que de sages, et, dans le sage même, il y a plus de folie que de sagesse.	CHAMFORT Nicolas-Sébastien de	Maximes et pensées		560     sagesse	1740/1794. Ac. Française	berkeley	1152
Soyons justes pour être habiles.	CHATEAUBRIAND François-René de	Mémoires d"outre-tombe		546     éthique	1768-1848.	berkeley	1315
Ce n'est pas la souffrance de l'enfant qui est révoltante en elle-même, mais le fait que cette souffrance ne soit pas justifiée.	CAMUS Albert	L"Homme révolté		210     violence	1913-1960.	berkeley	987
Le temps passé n'est plus, l'autre encore n'est pas,  Et le présent languit entre vie et trépas.	CHASSIGNET Jean-Baptiste	Le Mespris de la vie et consolation contre la mort		510     ironie	v. 1570-v. 1635.	berkeley	1286
Je connus mon bonheur, et qu'au monde où nous sommes Nul ne peut se vanter de se passer des hommes, Et depuis ce jour-l à, je les ai tous aimés.	SULLY-PRUDHOMME	Les épreuves.		140     rapport à la cosmogonie		berkeley	5167
L'avantage et le désavantage ont l'un sur l'autre une action réciproque. Le chef éclairé délibère. Celui qui se fait craindre de ses voisins y parvient en leur causant du tord.	SUN TZU	L"art de la guerre	-350	391     commandement	4e siècle av.J.C.	berkeley	5169
Le monde est plein de voix qui perdirent visage Et tournent dans la nuit pour en demander un.	SUPERVIELLE Jules	Les Amis inconnus.		110     entropie	1884/1960. Uruguay.	berkeley	5170
Les poètes nous aident à aimer : ils ne servent qu' à cela. Et c'est un assez bel emploi de leur vanité délicieuse.	FRANCE Anatole	Le jardin d"Epicure.		393     création artistique		berkeley	2861
La confiance est une des possibilités divines de l'homme.	MONTHERLANT Henry Millon de	Service inutile		234     communication	1896-1973.	berkeley	4473
Un savoir multiple n'enseigne pas la sagesse.	Héraclite	Fragment, 40		560     sagesse	fin du VIe-Ve s. av. J.-C.	berkeley	3125
A mesure qu'on s'avance dans la vie, on s'aperçoit que le courage le plus rare est celui de penser.	FRANCE Anatole	La Vie littéraire		440     courage	1844-1924. (Anatole François Thibault)	berkeley	2864
La jeunesse a cela de beau qu'elle peut admirer sans comprendre.	FRANCE Anatole	La Vie littéraire		510     ironie	1844-1924. (Anatole François Thibault)	berkeley	2866
Même s'il est mauvais (votre fief), ne le dites jamais ni aux gens, ni à votre seigneur. Si vous dites et si vous répétez qu'il est bon, vous obtiendrez davantage. Si vous dites 'mon fief est mauvais et il n'a aucune valeur', même le ciel et les hommes vous abandonneront.	Gosho Zen Shu			440     courage	gosho : corrrespondance privée entre penseurs japonais bouddist.	berkeley	3001
Prenez Versailles, et mêlez-y Anvers, et vous avez Bordeaux.	HUGO Victor			120     grégarité		berkeley	3280
Un grand homme est une relation particulièrement exacte entre des idées et une exécution.	VALERY Paul	Mauvaises pensées et autres.		550     grandeur		berkeley	5247
Elle était de ces êtres exceptionnels qui ignorent la haine, le mépris, l'indifférence même. De ces êtres qui ne savent qu'aimer. Et pour elle, aimer c'était donner. Pas autre chose.	CLAVEL Bernard	L"ouvrier de la nuit.	1956	330     coeur	hommage à la mère de l"auteur.	berkeley	1476
C'est très beau, une amitié qui a la forme d'une route, surtout si cette route est tortueuse. Au fond, ce qui importe, c'est la sincérité et la fidélité.	CLAVEL Bernard	L"ouvrier de la nuit.	1956	330     coeur		berkeley	1477
Mais je tiens que rien ne peut être réalisé sans le coeur. Je mesure bien l'importance de l'intelligence, toutefois on ne m'enlèvera jamais cette certitude que l'intelligence sans émotion est un glaçon. Or nous avons besoin de bonté tout autant que de beauté.	CLAVEL Bernard			390     création		berkeley	1478
J'étais né pour rester jeune, et j'ai eu l'avantage de m'en apercevoir, le jour où j'ai cessé de l'être.	COURTELINE Georges	La Philosophie de G. Courteline		442     démission	1860-1929. (Georges Moinaux)	berkeley	1703
Il vaut mieux gâcher sa jeunesse que de n'en rien faire du tout.	COURTELINE Georges	La Philosophie de G. Courteline		560     sagesse	1860-1929. (Georges Moinaux)	berkeley	1705
Conscient de ma fragilité physique, que je n'arrivais à dominer qu' à force de volonté, je savais bien que j'avais besoin, auprès de moi, d'un enthousiaste plus robuste que moi, capable de partager mes rêves et de m'aider à les réaliser.	COUSTEAU Jacques-Yves	Capitaine de la Calypso. Préface.	1990	370     esprit	en hommage à Albert Falco, compagnon et ami.	berkeley	1706
Les chants désespérés sont toujours les plus beaux Et j'en sais d'éternels qui sont de purs sanglots.	MUSSET Alfred de			510     ironie		berkeley	4539
Doutez, si vous voulez, de celui qui vous aime, D'une femme ou d'un chien, mais non de l'amour même.	MUSSET Alfred de	La Coupe et les Lèvres.		530     ironie amoureuse		berkeley	4545
Si vous refusez, madame, ne le dites pas; si vous cédez, je me tairai.	DOLENT Jean	Amoureux d"art		530     ironie amoureuse	1835-1909. (Charles Antoine Fournier)	berkeley	2130
Etre le premier amant d'une femme ne signifie rien ; il faut être son dernier amant ; tout est l à.	DONNAY Maurice	Pensées.		530     ironie amoureuse		berkeley	2133
Aucun homme n'est une île, complet en soi-même; chaque humain est une partie du continent, une partie du tout.  No man is an island, entire of itself; every man is a piece of the continent, a part of the main.	DONNE John	Devotions		140     rapport à la cosmogonie	1573-1631. (Anglais)	berkeley	2135
L'essentiel est que le tableau vous regarde. Ce n'est pas à l'amateur de le regarder - surtout avec des idées ou une sensation préconçues - il doit se contenter de le voir, c'est- à-dire à croiser son regard avec le sien, afin de soupçonner la pensée ou mieux l'émotion profonde et intime de l'artiste. Deux êtres vivants qui communiquent tant bien que mal.	DUTILLEUL Roger		1947	393     création artistique	cité in "L"homme de l"art" par Pierre Assouline, note 49 p 679.	berkeley	2241
Une dupe, c'est un homme trompé, bien sûr, mais non pas tant trompé par les autres que par lui-même.	DUTOURD Jean	Les Dupes		433     perversion	1920-.	berkeley	2245
En art comme ailleurs, il faut vivre au-dessus de ses moyens.	DUTOURD Jean	Le Fond et la forme		440     courage	1920-.	berkeley	2246
Les parents d'aujourd'hui veulent être aimés de leurs enfants. Cette erreur les entraîne à toutes sortes de faiblesses et de facilités.	DUTOURD Jean	Le Fond et la forme		442     démission	1920-.	berkeley	2248
Se calomnier soi-même est la grande tentation des âmes nobles.	DUTOURD Jean	L"Ame sensible		520     ironie de soi	1920-.	berkeley	2249
Le bonheur, c'est peut-être ça : l'imagination. Quand on en manque, il ne reste que les platitudes de la vie.	DUVERNOIS Henri	Un gentleman-farmer.		350     imagination		berkeley	2252
Quand on suit l'intime désir de son coeur, les problèmes accessoires trouvent d'eux-mêmes meur solution.	EARHART Amélia			312     foi	1898-1937	berkeley	2254
Les gens devraient penser moins à ce qu'ils devraient faire, et davantage à ce qu'ils devraient être.	ECKHART Maitre	Oeuvres.		550     grandeur		berkeley	2256
Quand on veut rester pur, il ne faut point se mêler d'agir sur les hommes.	VIGNY Alfred de	Cinq-Mars.		539     ironie sociale	1797-1863	berkeley	5300
Pour batir un spectacle symbolique capable de flatter l'émotion du plus grand nombre, il faut créer un 'décalage surprenant' entre l'état d'entropie dans lequel se trouve le public consommant et le degré d'entropie caractéristique du discours symbolique servant de fondement à l'intrigue scénarisée et mise en scène. Il faut, en outre, amorcer l'émotivation du public consommant en créant un 'trait d'union' entre son état d'entropie et le degré entropique du discours véhiculé. Ce mécanisme fait, généralement, appel à la mise en oeuvre de un, voire plusieurs 'héros' (homme, femme, enfant ou animal) qui permettent l'implication du consommateur dans le décalage spectaculaire, par voie d'identification au héros et appropriation des émotions qui lui sont prêtées. Ce type de spectacle 's'achève' par épuisement spontané de l'entropie de décalage (des 'méchants') et la victoire, automatiquement induite, des héros d'identification, ce qui permet, corrélativement, de légitimer à postériori l'état d'entropie du 'consommateur', voire l'héroïsme qu'il se réapproprie proprement sous la pression d'une identification frôlant le psychopathique. Généralement, une phase de consolidation dédramatisante et même 'désentropisante' est ménagée dans les toutes dernières minutes du spectacle par appel à quelque maxime morale, voire 'assagisante'.	FAIRGAGNETR Oscar	Recettes cinématographiques de démagogie entropique.	1991	234     communication	suite au visionnage du film "INDIANA JONES". S.SPIELBERG - 1984.	berkeley	2520
Seuls ceux qui sont habités d'une formidable force d'espérance donneront finalement un sens à la vie. Les autres l'acceptent comme ils la trouvent, abandonnée à portée de main. Tous seront finalement contentés.	FAIRGAGNETR Oscar		1991	320     intuition		berkeley	2533
Pour que la matière ait tant de pouvoir, il faut qu'elle contienne un esprit.	FLAUBERT Gustave	La Tentation de saint Antoine		390     création	1821-1880.	berkeley	2747
Sans morale, il n'y a plus de vin de Bordeaux, ni de style. La morale, c'est le goût de ce qui est pur et défie le temps.	CHARDONNE Jacques	L"Amour, c"est beaucoup plus que l"amour		546     éthique	1884-1968.	berkeley	1205
Je n'ay bouche qui puisse rire  Que les yeulx ne l'en dementissent.	CHARTIER Alain	La Belle Dame sans mercy		222     fourberie	1385-1433.	berkeley	1206
On peut défaire n'importe quel bonheur par la mauvaise volonté.	CHARTIER Emile	Minerve Ou De La Sagesse.		110     entropie	alias Alain (1868-1951)	berkeley	1208
Fondez une Société des honnêtes gens, tous les voleurs en seront.	CHARTIER Emile	Propos D"un Normand, T. III.		120     grégarité	alias Alain (1868-1951)	berkeley	1209
Nous éprouvons l'or dans le feu, nous discernons nos amis dans l'adversité.	Isocrate	A Démonicos, 25		234     communication	436-338 av. J.-C.	berkeley	3392
Je suis jeune, il est vrai; mais aux âmes bien nées  La valeur n'attend point le nombre des années.	CORNEILLE Pierre	Le Cid, II, 2, Rodrigue		510     ironie	1606-1684.	berkeley	1678
Je n'avais pas quinze ans que les monts et les bois  Et les eaux me plaisaient plus que la cour des rois.	RONSARD Pierre de	Hymne de l"automne		140     rapport à la cosmogonie	1524-1585.	berkeley	4851
Chasse la nature à coups de fourche, elle reviendra toujours au pas de course.  Naturam expellas furca, tamen usque recurret.	Horace	Epîtres, I, X, 24		510     ironie	65-8 av. J.-C. (Quintus Horatius Flaccus)	berkeley	3261
Méfie-toi des souvenirs comme d'une montre arrêtée.	SCHéHADé Georges	Monsieur Bob"le		441     sang-froid	1907-1989.	berkeley	4966
Un poète est un rossignol qui, assis dans l'obscurité, chante pour égayer de doux sons sa propre solitude.	SHELLEY P.-B.	Défense de la Poésie.		393     création artistique		berkeley	5077
Parodies et caricatures sont les plus pénétrantes des critiques.  Parodies and caricatures are the most penetrating of criticisms.	HUXLEY Aldous	Point Counter Point, 28.		234     communication	1894-1963 (Anglais)	berkeley	3358
La race irritable des poètes.  Genus irritabile vatum.	Horace	Epîtres, II, II, 102  		350     imagination	65-8 av. J.-C. (Quintus Horatius Flaccus)  Ces trois mots servent à caractériser l"extrême susceptibilité des poètes et des gens de lettres.	berkeley	3238
Sur les flots, sur les grands chemins, nous poursuivons le bonheur. Mais il est ici, le bonheur.  ... Navibus atque  Quadrigis petimus bene vivere. Quod petis, hic est.	Horace	Epîtres, I, XI, 28		365     discernement	65-8 av. J.-C. (Quintus Horatius Flaccus)	berkeley	3240
La lecture de tous bons livres est comme une conversation avec les plus honnêtes gens des siècles passés qui en ont été les auteurs, et même une conversation étudiée, en laquelle ils ne nous découvrent que les meilleures de leurs pensées.	DESCARTES René	Discours de la méthode		421     initiation	1596-1650.	berkeley	1932
C'est quasi le même de converser avec ceux des autres siècles que de voyager.	DESCARTES René	Discours de la méthode		421     initiation	1596-1650.	berkeley	1933
J'ai eu longtemps une incapacité à mentir qui était une infirmité véritable. En vieillissant, cel à s'améliore.	CHAPELAN Maurice	Main courante		423     solitude		berkeley	1170
Le développement de la civilisation libérale suppose un équilibre entre mécanismes conservateurs et mécanismes perturbateurs. [...] L'utopie écologique a détourné la machine industrielle de sa voie destructrice ; l'utopie tiers-mondiste maintient l'exigence du développement. L'utopie libératrice de 1968 a permis la diversification et la dédisciplinarisation du système social. La civilisation libérale doit autant sinon plus à ceux qui la menacent qu' à ceux qui ont entrepris de la préserver.	RUFIN Jean-Christophe	La Dictature Libérale.		231     légitimité du pouvoir	Le secret de la toute-puissance des démocraties au 20e siècle	berkeley	4890
Tu cesseras de craindre en cessant d'espérer.  Desines timere, si sperare desieris.  Lettres à Lucilius, V  	Sénèque	Parole du philosophe Hécaton, citée par Sénèque.		312     foi	v. 4 av. J.-C. (Lucius Annaeus Seneca)	berkeley	5017
Vous me pardonnerez cette façon de parler, la moitié du mysticisme de pacotille dans le monde vient d'une mauvaise digestion, du surmenage, du manque de sommeil ou de satisfaction sexuelle.	WEST Morris	L"Avocat du Diable.	1959	433     perversion		berkeley	5423
Le monde des amants déchus est une jungle où sévit toujours la saison du rut. Il n'est nulle trêve dans la fuite désespérée, impétueuse de la solitude.	WEST Morris	L"Avocat du diable.	1959	530     ironie amoureuse		berkeley	5449
Et il faut une même grande Peur à planer sur nos têtes, comme c'est le cas en ce moment, pour que nous autres dans la Jungle renoncions à nos petites peurs et nous rassemblions en un même lieu, comme aujourd'hui.	KIPLING Rudyard	Le second livre de la jungle.	1894	120     grégarité		berkeley	3547
'Tout pour les dames', ça se dit, mais 'l'art avant tout', ça se pratique.	FLAUBERT Gustave	L"amour de l"art.	1915	370     esprit	1821/1880, édition posthume	berkeley	2739
On peut faire le sot partout ailleurs, mais non en la poésie.	MONTAIGNE Michel Eyquem de	Essais, II, 17		393     création artistique	1533-1592.	berkeley	4346
[...] Le hasard sait toujours trouver ceux qui savent s'en servir.	ROLLAND Romain	Jean-Christophe.		320     intuition		berkeley	4843
Si ces pensées* ne plaisent à personne, elles pourront n'être que mauvaises; mais je les tiens pour détestables si elles plaisent à tout le monde.	DIDEROT Denis	Pensées philosophiques 		234     communication	1713-1784.  *Sur Dieu.	berkeley	2088
Ne vaut-il pas mieux encore faire des ingrats, que de manquer à faire le bien? 	DIDEROT Denis	Discours sur la poésie dramatique		330     coeur	1713-1784.	berkeley	2091
En vain le Roi sera aux armes invincible,  S'il n'est juste et ne fait la justice garder.	DU BELLAY Joachim	Ample discours au Roi, sur le fait des quatre états du Royaume de France		231     légitimité du pouvoir	1522-1560.	berkeley	2161
En vain le Roi sera aux armes invincible,  S'il n'est juste et ne fait la justice garder.	DU BELLAY Joachim			231     légitimité du pouvoir	1522-1560.   Ample discours au Roi, sur le fait des quatre états du Royaume de France	berkeley	2162
Si de la vie tu supprimes la trahison, qu'y laisseras-tu ?  Si de la vida suprimes la traicion,  àqué dejarAs de ella ? 	ZAMACOIS Eduardo	Memorias de un vagon de ferrocarril, 8		221     vanité	1876-1971. (Cubain)	berkeley	5518
S'il n'y a pas de viande, il faut se contenter de poisson salé! 	Zénobios	Corpus paraemiographorum graecorum, I, 84		410     santé	IIe siècle	berkeley	5519
Garde cette pensée dans ton coeur, jusqu' à la mort : il n'y a rien au monde d'aussi rare qu'un bon juge.	ZIMMERMANN	De la solitude.		110     entropie		berkeley	5521
Le romancier est fait d'un observateur et d'un expérimentateur.	ZOLA Emile	Le Roman expérimental		393     création artistique	1840-1902.	berkeley	5523
Dans le doute, abstiens-toi.	ZOROASTRE			441     sang-froid	attribué à Zoroastre (660?-583 av. J.-C.)	berkeley	5525
Nous construisons le monde  Qui nous le rendra bien.	GUILLEVIC Eugène	Terraqué		312     foi	1907-.	berkeley	3050
Il faut bonne mémoire après qu'on a menti.	CORNEILLE Pierre	Le Menteur, IV, 5, Cliton		222     fourberie	1606-1684.	berkeley	1652
Source délicieuse, en misères féconde,  Que voulez-vous de moi, flatteuses voluptés? 	CORNEILLE Pierre	Polyeucte, IV, 2, Polyeucte		240     débauche	1606-1684.	berkeley	1653
Nos vrais ennemis sont en nous-mêmes.	BOSSUET Jacques Bénigne	Oraison funèbre de Marie-Thérèse d"Autriche, reine de France		433     perversion	1627-1704.	berkeley	807
La possession des richesses a des filets invisibles où le coeur se prend insensiblement.	BOSSUET Jacques Bénigne	Sermon sur la providence		433     perversion	1627-1704.	berkeley	809
En matière d'art, l'esthétique est presque toujours une domestique pudibonde chargée de policer les élans intempestifs de la foi et de la douleur.	FAIRGAGNETR Oscar	Vitalités.	1993	393     création artistique	\\010P¥	berkeley	2563
La philosophie que je cultive n'est pas si barbare ni si farouche qu'elle rejette l'usage des passions; au contraire, c'est en lui seul que je mets toute la douceur et la félicité de cette vie.	DESCARTES René	Correspondance, à l"abbé Picot, 28 février 1648		430     paradoxal émotionnel	1596-1650.	berkeley	1939
Que serions-nous devenus si Kahnweiler n'avait pas eu le sens des affaires.	PICASSO Pablo			393     création artistique		berkeley	4701
La popularité? C'est la gloire en gros sous.	HUGO Victor	Ruy Blas, III, 5, Don Salluste		539     ironie sociale	1802-1885.	berkeley	3346
Je ne suis point d'opinion ... qu'on doive s'exempter d'avoir des passions; il suffit qu'on les rende sujettes à la raison, et lorsqu'on les a ainsi apprivoisées, elles sont quelquefois d'autant plus utiles qu'elles penchent plus vers l'excès.	DESCARTES René	Correspondance		430     paradoxal émotionnel	1596-1650.	berkeley	1940
En art, il faut que la mathématique se mette aux ordres des fantômes.	FARGUE Léon-Paul	Sous la lampe		393     création artistique	1876-1947.	berkeley	2661
Chateaubriand, pédicure pour reines barrées, tueur de rats musqués dans sa chambre.	FARGUE Léon-Paul	Sous la lampe		393     création artistique	1876-1947.	berkeley	2663
L'art ne sera que l à où vous saurez percevoir, et faire apercevoir, la solidarité haineuse qui lie l'être et le vivre.	FARGUE Léon-Paul	Sous la lampe		393     création artistique	1876-1947.	berkeley	2666
Ne fais donc jamais de citations2 classiques: tu exhumes ta grand-mère en présence de ta maîtresse.	FARGUE Léon-Paul	Sous la lampe		441     sang-froid	1876-1947.	berkeley	2667
Sache souffrir. Mais ne dis rien qui puisse troubler la souffrance des autres.	FARGUE Léon-Paul	Poèmes		441     sang-froid	1876-1947.	berkeley	2668
J'appelle bourgeois quiconque renonce à soi-même, au combat et à l'amour, pour sa sécurité.	FARGUE Léon-Paul	Sous la lampe		442     démission	1876-1947.	berkeley	2669
- Préparez-vous à faire votre entrée, maintenant. Et souriez, souriez toujours. C'est ce que les gens attendent de vous.	HIGGINS Jack	Opération Cornouailles.	1990	235     séduction		berkeley	3184
En amour on s'imagine que la seule prétention donne un titre.	MONTESQUIEU Charles de	Mes pensées		530     ironie amoureuse	1689-1755. (C. de Secondat, baron de La Brède et de M.)	berkeley	4450
Votre passé vous entraîne plus loin chaque jour, et il vous change. Il vous modifie à tous égards.	HIGGINS Jack	Saison en enfer.	1989	420     capital affectif		berkeley	3187
La vraie liberté est de pouvoir toute chose sur soi.	MONTAIGNE Michel Eyquem de	Essais		130     liberté		berkeley	4311
Quelques fois, il vaut mieux ne pas réfléchir du tout que de ne pas réfléchir assez.	Dictons et Proverbes	Dicton		441     sang-froid		berkeley	2036
Que ton pied ne laisse aucune trace que tu ne puisse effacer.	Dictons et Proverbes	Dicton des Appalaches.		441     sang-froid		berkeley	2037
Quand d'autre parler voudras, Regarde-toi et te tairas.	Dictons et Proverbes	Dicton.		441     sang-froid		berkeley	2038
Qu'est-ce en effet que le pari, sinon une manière de poser enfin de vraies certitudes et de les étayer ?	MORENO Roland	Théorie du Bordel Ambiant	1990	232     servitudes du pouvoir	Inventeur de la carte à mémoire, vendue cash.	berkeley	4500
Certaines règles de sincérité sont donc susceptibles de passer avant toutes les règles sociales : celles qui demeurent après que les règles sociales se sont effondrées.	MORENO Roland	Théorie du Bordel Ambiant	1990	232     servitudes du pouvoir	Inventeur de la carte à mémoire, vendue cash.	berkeley	4501
Celui qui se connaît est seul maître de soi.	RONSARD Pierre de	Discours		422     confiance en soi	1524-1585. , Institution pour l"adolescence du roi très chrétien, Charles neuvième du nom	berkeley	4855
Dans les affaires humaines, il faut offrir du drame au public...	ROOSEVELT Franklin D.	s hu	1943	215     mystifications	 à de Gaulle, sur les compromis algérois.	berkeley	4857
Rien n'étonne quand tout étonne: c'est l'état des enfants.	RIVAROL Comte de	Maximes et pensées		341     étonnement	1753-1801. (Antoine Rivarol)	berkeley	4840
Ceux qui ont beaucoup à espérer et rien à perdre seront toujours dangereux.  Those who have much to hope and nothing to lose will always be dangerous.	BURKE Edmund	Letters, to a Noble Lord, 1796		432     expérience	1729-1797. (Irlandais)	berkeley	912
Les tyrans manquent rarement de prétextes.  Tyrants seldom want pretexts.	BURKE Edmund	Letters, to a Noble Lord, 1796		433     perversion	1729-1797. (Irlandais)	berkeley	913
La superstition est la religion des âmes faibles.  Superstition is the religion of feeble minds.	BURKE Edmund	Reflections on the Revolution in France		433     perversion	1729-1797. (Irlandais)	berkeley	914
Ne haïr que la haine.	COCTEAU Jean	Poésie critique		330     coeur	1889-1963.	berkeley	1502
La force sans l'intelligence s'effondre sous sa propre masse.  Vis consilii expers mole ruit sua.	Horace	Odes, III, IV, 65	5	110     entropie	65-8 av. J.-C. (Quintus Horatius Flaccus)	berkeley	3231
Aux yeux de la Loi, un gredin qui la tourne est moins à craindre en son action qu'un homme de bien qui la discute avec sagesse et clairvoyance.	COURTELINE Georges	La Philosophie de G. Courteline		215     mystifications	1860-1929. (Georges Moinaux)	berkeley	1698
Si je savais quelque chose qui me fût utile et qui fût préjudiciable à ma famille, je le rejetterais de mon esprit. Si je savais quelque chose utile à ma famille et qui ne le fût pas à ma patrie, je chercherais à l'oublier. Si je savais quelque chose utile à ma patrie et qui fût préjudiciable à l'Europe, ou bien qui fût utile à l'Europe et préjudiciable au genre humain, je la regarderais comme un crime.	MONTESQUIEU Charles de	Mes pensées		546     éthique	1689-1755. (C. de Secondat, baron de La Brède et de M.)	berkeley	4459
La guerre et l'intégrisme religieux sont les deux exultoires naturels de la folie ordinaire. Quand les deux se rejoignent au paroxysme de la révulsion entropique, la folie devient épique.	FAIRGAGNETR Oscar	Aphorismes.	1992	110     entropie		berkeley	2472
Le peu que je sais, c'est à mon ignorance que je le dois.	GUITRY Sacha	Toutes réflexions faites.		320     intuition		berkeley	3056
Ne faisons pas comme ces âmes chancelantees, qui disent tous les jours : A demain, à demain !	FENELON	Sermon.		110     entropie		berkeley	2678
La plus méprisable des nations est aujourd'hui la nôtre, parce qu'elle n'a nulle espèce d'honneur et qu'elle ne songe qu' à l'argent et au repos.	BERNIS François Joachim de Pierres de	Lettre, au comte de Choiseul, 1758		240     débauche	1715-1794.	berkeley	725
Sans le rêve, il n'y a pas de poésie possible.	VALLERY-RADOT Pasteur			350     imagination		berkeley	5250
Dans le monde, il n'existe aucune sauce comparable à la faim.	CERVANTES SAAVEDRA Miguel de	Don Quichotte.		510     ironie	1547-1616. (Espagnol)	berkeley	1093
N'importe quel imbécile peut faire cuire du riz, mais pour les gateaux de lune, il faut un bon cuisinier.	Dictons et proverbes	Proverbe chinois.		370     esprit	cité dans Kaloni le navigateur. Morris  1976.	berkeley	2063
Le tact dans l'audace c'est de savoir jusqu'où on peut aller trop loin.	COCTEAU Jean	Le Rappel à l"ordre		441     sang-froid	1889-1963.	berkeley	1516
Le mouvement dort au milieu d'une roue qui tourne.	COCTEAU Jean	Poésie critique		441     sang-froid	1889-1963.	berkeley	1517
L'amour a beau s'élancer tout d'abord, en mille impulsions, au hasard, comme s'éparpille une poignée de grains, il ne peut croître que si l'homme et la femme ont les mêmes planètes dans leur ciel subconscient.	MORGAN Charles	Sparkenbroke.		531     communication amoureuse		berkeley	4506
J'étais seul, l'autre soir, au Théâtre-Français,  Ou presque seul; l'auteur n'avait pas grand succès.  Ce n'était que Molière ...	MUSSET Alfred de	Poésies, Une soirée perdue		539     ironie sociale	1810-1857.	berkeley	4548
Alors s'assit sur un monde en ruines une jeunesse soucieuse.	MUSSET Alfred de	La Confession d"un enfant du siècle		539     ironie sociale	1810-1857.	berkeley	4549
Une bonne confession vaut mieux qu'une mauvaise excuse.	HAMON Jean	Lettre à un ami		234     communication	1617-1687.	berkeley	3081
L'humanité n'avance qu' à travers des symboles.	HAMSUN Knut	Mystères		545     épistémologie	1859-1952. (Knut Pedersen) (Norvégien)	berkeley	3082
Qui s'assied au fond d'un puits pour contempler le ciel le trouvera petit.	Han Yu	Traduction D. Tsan		442     démission	768-824. (Chinois)	berkeley	3083
Science sans conscience n'est que ruine de l'âme.	RABELAIS François	Pantagruel.	1532	546     éthique		berkeley	4758
L'expérience ne se trompe jamais. C'est votre jugement seul qui s'égare en se promettant des résultats qui ne découlent pas directement de votre expérimentation.	VINCI Léonard de		1510	365     discernement	(vers 1510)	berkeley	5313
Etudiez comme si vous deviez vivre toujours ; vivez comme si vous deviez mourir demain.	St.ISIDORE (de Séville)			440     courage		berkeley	5118
Très cher, je souhaite que tu prospères à tous égards et que ton corps se porte aussi bien que ton âme.	St.JEAN	Epître de Jean.		330     coeur		berkeley	5119
Le souvenir du bonheur n'est plus du bonheur;  le souvenir de la douleur est de la douleur encore.  Joy's recollection is no longer joy,  While sorrow's memory is a sorrow still.	BYRON George Gordon lord	Marino Falieri, II, 1		420     capital affectif	1788-1824. (Anglais)	berkeley	943
Les moyens qui rendent un homme propre à faire fortune sont les mêmes qui l'empêchent d'en jouir.	RIVAROL Antoine de	Discours sur l"homme intellectuel et moral		510     ironie	1753-1801. (Antoine Rivarol)	berkeley	4836
Quelle triste chose que sur toute la terre les gouvernements soient toujours précisément aussi coquins que les moeurs de leurs sujets peuvent leur permettre de l'être! 	TOCQUEVILLE Alexis de	Correspondance		539     ironie sociale	1805-1859.	berkeley	5210
Car la jeunesse sait ce qu'elle ne veut pas avant de savoir ce qu'elle veut.	COCTEAU Jean	La Difficulté d"être		421     initiation	1889-1963.	berkeley	1509
Ce grand ressort méconnu de tant de conduites humaines, le désoeuvrement.	MONTHERLANT Henry Millon de	Carnets		110     entropie	1896-1973.	berkeley	4460
La liberté existe toujours. Il suffit d'en payer le prix.	MONTHERLANT Henry Millon de	Carnets		130     liberté	1896-1973.	berkeley	4461
Les révolutions font perdre beaucoup de temps.	MONTHERLANT Henry Millon de	Malatesta, I, 4, Porcellio		215     mystifications	1896-1973.	berkeley	4465
Un rêveur est toujours mauvais poète.	COCTEAU Jean	Le Rappel à l"ordre		433     perversion	1889-1963.	berkeley	1512
A force de plaisirs notre bonheur s'abîme.	COCTEAU Jean	Vocabulaire		433     perversion	1889-1963.	berkeley	1513
Un homme pur doit être libre et suspect.	COCTEAU Jean	Essai de critique indirecte		441     sang-froid	1889-1963.	berkeley	1514
On croit toujours que c'est plus facile de réussir dans ce qu'on n'a pas appris que dans ce qu'on a appris, c'est naturel.	COLETTE Sidonie Gabrielle	Mitsou ou Comment l"esprit vient aux filles		433     perversion	1873-1954.	berkeley	1555
Il n'y a pas d'homme plus malheureux que celui chez qui n'est habituelle que l'indécision.  There is no more miserable human being than one in whom nothing is habitual but indecision.	JAMES William	Principles of Psychology		433     perversion	1842-1910. (Américain)	berkeley	3419
La libéralité consiste moins à donner beaucoup qu' à donner à propos.	LA BRUYERE Jean de	Les Caractères		330     coeur	1645-1696.	berkeley	3610
On ne juge pas un vainqueur.  	CATHERINE II impératrice de Russie	Phrase attribuée à Catherine II, à propos du général Souvorov.		232     servitudes du pouvoir	1729-1796. (Russe)	berkeley	1055
Dans une bataille, ce sont les plus terrifiés qui courent le plus grave danger.	CATILINA		-63	210     violence	exhortant ses troupes devant Pistoia.	berkeley	1056
Tout est sauvé si l'on demeure capable d'étonnement.	GUéHENNO Jean	La Foi difficile		341     étonnement	1890-1978.	berkeley	3036
La passion comblée a son innocence, presque aussi fragile que toute autre.	YOURCENAR Marguerite	Mémoires d"Hadrien		430     paradoxal émotionnel	1903-1987. (Marguerite de Crayencour)	berkeley	5510
Un homme comme Montaigne est un Latin, de sentiments, de pensée et même de style; un homme comme Rabelais est un Grec, de sentiments et de pensée au moins; de langue parfois.	FAGUET Emile	Etudes littéraires du seizième siècle		393     création artistique	1847-1916.	berkeley	2447
Le succès de l'être grégaire tient tout entier dans son aptitude à ne jamais porter un regard extérieur sur le monde qui le nourrit. Il lui suffit de savoir courir après son assiette.	FAIRGAGNETR Oscar	Vitalités.	1993	120     grégarité		berkeley	2480
Quand tu prends le large, partant seul cueillir la force des éléments, n'oublie pas que c'est sur la terre ferme, parmi tes contemporains, qu'il faudra ramener le butin pour en jouir.	FAIRGAGNETR Oscar	Vitalités.	1993	140     rapport à la cosmogonie	\\010zl@\\020	berkeley	2489
Quand mes amis sont borgnes, je les regarde de profil.	JOUBERT Joseph	Pensées		441     sang-froid	1754-1824.	berkeley	3466
L'amour est cette merveilleuse chance qu'un autre vous aime encore quand vous ne pouvez plus vous aimer vous-même.	GUéHENNO Jean	Aventures de l"esprit		530     ironie amoureuse	1890-1978.	berkeley	3040
L'avis de la majorité ne peut être que l'expression de l'incompétence.	GUéNON René	La Crise du monde moderne		120     grégarité	1886-1951.	berkeley	3041
Les rois peuvent voir tomber leurs palais, les fourmis auront toujours leur demeure.	GUéRIN Eugénie de	Lettre, à la baronne Almaury de Maistre		232     servitudes du pouvoir	1805-1848.	berkeley	3042
On dirait que l'âme des justes donne, comme les fleurs, plus de parfums vers le soir.	STAEL Madame de	Corinne ou l"Italie		560     sagesse	1766-1817. (Germaine Necker, baronne de Staël-Holstein)	berkeley	5135
Si j'avais à revivre, je revivrais comme j'ai vécu; ni je ne plains* le passé, ni je ne crains l'avenir.	MONTAIGNE Michel Eyquem de	Essais, III, 2 		560     sagesse	1533-1592.  *Regrette.	berkeley	4389
Quand bien nous pourrions être savants du savoir d'autrui, au moins sages ne pouvons-nous être que de notre propre sagesse.	MONTAIGNE Michel Eyquem de	Essais, I, 15		560     sagesse	1533-1592.	berkeley	4390
Ce n'est jamais dans l'anarchie que les tyrans naissent, vous ne les voyez s'élever qu' à l'ombre des lois ou s'autoriser d'elles.	SADE Marquis de			215     mystifications		berkeley	4902
Faible, la civilisation libérale le paraît parce qu'elle laisse s'exprimer ses plus violents adversaires ; mais c'est dans la capacité de s'en repaître que gît sa force. Le matériau grâce auquel elle se construit est l'opposition.	RUFIN Jean-Christophe	La Dictature Libérale.		231     légitimité du pouvoir	Le secret de la toute-puissance des démocraties au 20e siècle	berkeley	4892
Ce qu'il y a de plus important, voire d'essentiel dans l'existence, ce dont tout le reste dépend, sa signification véritable, sa phase critique, sa pointe, se trouve dans la moralité du comportement humain.	SCHOPENHAUER Arthur	Le Fondement de la Morale.	1840	546     éthique		berkeley	4982
Pensez-vous être saint et juste impunément.	RACINE Jean	Andromaque		221     vanité		berkeley	4770
Ce que l'homme a fait de plus grand, il le doit au sentiment douloureux de l'incomplet de sa destinée.	STAEL Madame de			390     création		berkeley	5126
Le bon goût en littérature est, à quelques égards, comme l'ordre sous le despotisme, il importe d'examiner à quel prix on l'achète.	STAEL Madame de	De l"Allemagne		393     création artistique	1766-1817. (Germaine Necker, baronne de Staël-Holstein)	berkeley	5127
Est authentiquement révolutionnaire celui qui est prêt à protéger et à défendre l'Union soviétique sans réserve, ouvertement, inconditionnellement. Celui qui pense défendre le mouvement révolutionnaire mondial sans ou contre l'Union soviétique agit en réalité contre la Révolution.	STALINE Joseph			215     mystifications	cité par JC Rufin, la Dictature libérale, Lattès 1994, p. 49.	berkeley	5137
Le seigneur ne vous donne pas plus que vous ne pouvez supporter.	Dictons et Proverbes	Dicton Noir Américain.		550     grandeur		berkeley	2057
Les imparfaits* regardent plus au don qu' à Moi, le donateur.  Questi imperfetti ... più raguardano al dono che a me donatore.	STE.CATHERINE DE SIENNE	Dialogo della Divina Provvidenza, VI 		223     cupidité	1347-1380. (Italienne) *Ceux qui n"ont pas atteint le dernier degré de l"union avec la Trinité.	berkeley	5139
La Vérité est entièrement et absolument une affaire de style.	WILDE Oscar	La Décadence du Mensonge	1889	510     ironie	1854/1900	berkeley	5481
Rengaine ton épée : tous ceux qui useront de l'épée périront par l'épée.	Nouveau Testament	Matthieu, XXVI, 52 (Maredsous)		210     violence		berkeley	4604
Celles et ceux qui recherchent votre compagnie quand vous oeuvrez à leur rendre leurs propres insuffisances supportables se fourvoient dans la complaisance et la grégarité. Celles et ceux qui sont curieux de votre compagnie, par del à l'ironie de soi et du monde, s'offrent à l'indiscible vitalité de la communication.	FAIRGAGNETR Oscar	Vitalités.	1994	234     communication		berkeley	2525
Un poète est un monde enfermé dans un homme.	HUGO Victor	La Légende des siècles, Un poète		350     imagination	1802-1885.	berkeley	3306
Guerre à la rhétorique et paix à la syntaxe! 	HUGO Victor	Les Contemplations, Réponse à un acte d"accusation, I, 7		365     discernement	1802-1885.	berkeley	3307
L'affection ou la haine changent la justice de face.	PASCAL Blaise	Pensées, 82		539     ironie sociale	1623-1662.	berkeley	4653
Les idées, une fois nées, ne s'anéantissent plus; elles peuvent être accablées sous les chaînes, mais, prisonnières immortelles, elles usent les liens de leur captivité.	CHATEAUBRIAND François-René de	Histoire de France		370     esprit	1768-1848.	berkeley	1297
Tout arrive par les idées; elles produisent les faits, qui ne leur servent que d'enveloppe.	CHATEAUBRIAND François-René de	Histoire de France		390     création	1768-1848.	berkeley	1298
Levez-vous, orages désirés, qui devez emporter René dans les espaces d'une autre vie !	CHATEAUBRIAND François-René de			422     confiance en soi		berkeley	1303
Tous ceux qui connaissent leur esprit ne connaissent pas leur coeur.	LA ROCHEFOUCAULD François de	Maximes		370     esprit	1613-1680.	berkeley	3855
Les vrais maîtres sont ceux qui ne donnent pas de leçons.	LAVOINE Marc		1995	550     grandeur	in "Faut pas rêver" du 28/04/95, à propos des sculpteurs et de l"ancien fermier de Rhodésie.	berkeley	4055
La vie n'est supportable que si l'esprit et le corps sont en harmonie et que chacun des deux à pour l'autre un respect naturel.	LAWRENCE D.H.			140     rapport à la cosmogonie		berkeley	4056
La guerre de harcèlement est beaucoup plus intellectuelle qu'une charge à la baïonnette.	LAWRENCE T.E.	The Science of Guerrilla Warfare		211     guerre		berkeley	4057
Dès qu'un sentiment s'exagère, la faculté de raisonner disparaît.	LE BON Gustave	Hier et Demain.		430     paradoxal émotionnel		berkeley	4063
Arthur Rimbaud fut un mystique à l'état sauvage, une source perdue qui ressort d'un sol saturé.	CLAUDEL Paul	Accompagnements		433     perversion	1868-1955.	berkeley	1454
Il ne faut point juger des gens sur l'apparence.	LA FONTAINE Jean de	Fables, le Paysan du Danube		441     sang-froid	1621-1695.	berkeley	3727
Il faut, autant qu'on peut, obliger tout le monde:  On a souvent besoin d'un plus petit que soi.	LA FONTAINE Jean de	Fables, le Lion et le Rat		441     sang-froid	1621-1695.	berkeley	3728
Garde-toi, tant que tu vivras  De juger des gens sur la mine.	LA FONTAINE Jean de	Fables, le Cochet, le Chat et le Souriceau		441     sang-froid	1621-1695.	berkeley	3729
En toute chose il faut considérer la fin.	LA FONTAINE Jean de	Le Renard et le Bouc.		441     sang-froid		berkeley	3730
Aucun chemin de fleurs ne conduit à la gloire.	LA FONTAINE Jean de	Fables, les Deux Aventuriers et le Talisman		441     sang-froid	1621-1695.	berkeley	3731
... Fi du plaisir  Que la crainte peut corrompre.	LA FONTAINE Jean de	Fables, le Rat de ville et le Rat des champs		441     sang-froid	1621-1695.	berkeley	3734
Mais ici ce n'en était pas le moment.  Sed nunc non erat his locus.	Horace	Art poétique, 19  		441     sang-froid	65-8 av. J.-C. (Quintus Horatius Flaccus)  Horace blâme les digressions. On cite ces mots (en omettant souvent, et à tort, sed nunc; en remplaçant his par hic) à propos d"une chose faite à contretemps.	berkeley	3249
Nous aimons toujours ceux qui nous admirent, et nous n'aimons pas toujours ceux que nous admirons.	LA ROCHEFOUCAULD François de	Maximes		221     vanité	1613-1680.	berkeley	3827
Nos vertus ne sont le plus souvent que des vices déguisés.	LA ROCHEFOUCAULD François de	Maximes		221     vanité	1613-1680.	berkeley	3828
L'homme qui n'a plus de chemise est un homme perdu.	VALLES Jules			510     ironie		berkeley	5251
Une silhouette est un mouvement, non une forme.	DUFY Raoul	Carnet		311     distinction	1877-1953.	berkeley	2199
Les péchés que vous faites deux à deux, vous devez les payer un à un.	KIPLING Rudyard	Tomlinson.		210     violence		berkeley	3549
La dictature est la forme la plus complète de la jalousie.	MALAPARTE C.	Technique du coup d"Etat.		110     entropie		berkeley	4189
Il faut vivre sa vie comme si le monde nous appartenait.	MALHOUF Amin			440     courage	invité de "Faut pas rêver", France 3 le 14 janvier 1994.	berkeley	4194
La chair est triste, hélas! Et j'ai lu tous les livres... Fuir! L à bas... Fuir.	MALLARME Stéphane de			110     entropie		berkeley	4195
Ah ! Malheur à celui qui laisse la débauche Planter le premier clou sous sa mamelle gauche !	MUSSET Alfred de	La Coupe et les Lèvres.		110     entropie		berkeley	4516
Que les hommes entre eux soient égaux sur la terre,  Je n'ai jamais compris que cela pût se faire.	MUSSET Alfred de	Poésies, la Loi sur la presse		215     mystifications	1810-1857.	berkeley	4518
Les dons les plus précieux de l'esprit ne résistent pas à la perte d'une parcelle d'honneur.	BRETON André	Manifeste du surréalisme		546     éthique	1896-1966.	berkeley	858
Une circonstance imaginaire qu'il nous plaît d'ajouter à nos afflictions, c'est de croire que nous serons inconsolables.	FONTENELLE Bernard le Bovier de	Du bonheur		433     perversion	1657-1757.	berkeley	2822
Chaque fois que la flamme semble vaciller, nous retrouvons la mesure de ce que les hommes payent pour un peu de confiance et de liberté empruntées à l'adversité.	FAIRGAGNETR Oscar	Vitalités.	1992	510     ironie	510     iron\\010v{P\\010v~Ä	berkeley	2627
C'est abuser bien dangereusement de la volonté que de la donner en caution d'un emprunt fait au courage.	FAIRGAGNETR Oscar		1991	510     ironie		berkeley	2628
Avoir du coeur, souffrir la difficulté de l'éthique : une seule et même misère de grandeur.	FAIRGAGNETR Oscar	Aphorismes.	1992	510     ironie		berkeley	2629
Toute la philosophie n'est fondée que sur deux choses: sur ce qu'on a l'esprit curieux et les yeux mauvais.	FONTENELLE Bernard le Bovier de	Entretiens sur la pluralité des mondes		510     ironie	1657-1757.	berkeley	2831
On ne s'occupe pas assez de l'histoire des familles. L'humanité fut faite par un certain nombre de familles énergiques.	BUFFON Comte de			420     capital affectif		berkeley	889
L'esprit humain n'a pas de bornes, il s'étend à mesure que l'univers se déploie.	BUFFON Georges-Louis Leclerc de	Histoire naturelle, De l"homme		140     rapport à la cosmogonie	1707-1788.	berkeley	890
J'aime mieux, en soucis et pensers élevés,  Etre un aigle abattu d'un grand coup de tonnerre  Qu'un cygne vieillissant ès jardins cultivés.	BERTAUT Jean	Stances		441     sang-froid	1552-1611.	berkeley	734
Il y a dans la sensualité une sorte d'allégresse cosmique.	GIONO Jean	Jean Le Bleu.		460     plaisir		berkeley	2958
Marcher main dans la main avec le Pape n'a jamais fait de mal à personne.	Dictons et Proverbes	Proverbe romain.		510     ironie	cité par Morris West dans De main de Maître, 1988.	berkeley	2046
Dans le monde primitif, le rapport de l'homme à la nature n'est pas celui de l'exploitant à l'exploité, mais une relation d'harmonie. Pour l'homme moderne, en revanche, la nature est un terrain d'investiga- tion, d'analyse et, en fin de compte, d'exploitation.	GOLDSMITH Jimmy	Le Piège.	1993	140     rapport à la cosmogonie	\\010i\\030∞\\020	berkeley	2984
Tircis, il faut penser à faire la retraite:  La course de nos jours est plus qu' à demi faite ...  Il est temps de jouir des délices du port.	RACAN Honorat de Bueil, marquis de	Poésies diverses, Stances à Tircis sur la retraite		140     rapport à la cosmogonie	1589-1670.	berkeley	4762
Qu'on rencontre peu de gens dont on souhaiterait fouiller les valises !	GIDE André	Les Caves Du Vatican.		341     étonnement		berkeley	2929
Je regarde comme un des bonheurs de ma vie de ne pas écrire dans les journaux. Il en coûte à ma bourse - mais ma conscience s'en trouve bien.	FLAUBERT Gustave	Correspondance, 1842, à la princesse Mathilde, 1866		546     éthique	1821-1880.	berkeley	2789
Les hautes idées poussent à l'ombre et au bord des précipices comme les sapins.	FLAUBERT Gustave	L"amour de l"art.	1915	550     grandeur	(1821/1880) édition posthume	berkeley	2790
Démocratie est le nom que nous donnons au peuple chaque fois que nous avons besoin de lui.	FLERS Robert de	L"Habit vert, I, 11, Durand		215     mystifications	1872-1927. (et Gaston Arman de Caillavet)	berkeley	2792
... Les loups ne craignent guère  Les pasteurs amoureux qui chantent leur bergère.	FLORIAN Jean-Pierre Claris de	Fables, le Roi et les Deux Bergers		225     cynisme	1755-1794.	berkeley	2800
Aidons-nous mutuellement,  La charge de nos maux en sera plus légère.	FLORIAN Jean-Pierre Claris de	Fables, l"Aveugle et le Paralytique		234     communication	1755-1794.	berkeley	2801
Moi, disait un dindon, je vois bien quelque chose;  Mais je ne sais pour quelle cause  Je ne distingue pas très bien.	FLORIAN Jean-Pierre Claris de	Fables		365     discernement	1755-1794.	berkeley	2802
La peinture abstraite fait très souvent braire les ânes, se pâmer les poules et baîller les singes.	FLORIOT René			510     ironie		berkeley	2810
Le flatteur n'a pas assez bonne opinion de soi ni des autres.	LA BRUYERE Jean de	Les Caractères		433     perversion	1645-1696.	berkeley	3618
Le ciel étoilé au-dessus de ma tête et la loi morale au fond de mon coeur.  Der bestirnte Himmel über mir und das moralische Gesetz in mir.	KANT Immanuel	Critique de la raison pratique		140     rapport à la cosmogonie	1724-1804. (Allemand)	berkeley	3537
L'Europe n'est devenue l'Europe que par l'art. Ce n'est pas Napoléon qui a fait l'Europe, c'est Goya.	KANTOR Tadeusz			393     création artistique		berkeley	3538
Comprenez bien ceci : il n'y a pas d'obligations. Vous et moi, nous savons que les affaires sont les affaires. Mais, nous ne sommes pas toujours en affaires. Nous sommes aussi des êtres humains. Nous aimons sentir que nous pouvons rendre un service et réparer un tort. Nous en avons besoin, ne serait-ce que pour maintenir notre dignité.	WEST Morris	La seconde victoire.	1972	330     coeur		berkeley	5386
Tous les mystiques parlent le même langage, parce qu'ils viennent du même pays.	SAINT-MARTIN Louis Claude de			510     ironie		berkeley	4939
La discipline se résume en un mot : obéissance.	SAINT-VINCENT Lord			230     pouvoir	1735/1823	berkeley	4940
A quarante ans les uns se font aigres, les autres fades ; d'autres tournent au porc. Moi, je me fais loup. Je dis NON, je rode et je me maintiens inattaquable dans les grands bois enneigés.	SAINTE-BEUVE Charles Augustin	Nouveaux lundis.		110     entropie	1804/1869	berkeley	4941
On est orgueilleux quand on a quelque chose à perdre, et humble quand on a quelque chose à gagner.	JAMES Henry	L"américain à Paris.		520     ironie de soi		berkeley	3413
L'habitude est l'énorme volant d'entraînement de la société, son plus précieux agent de conservation.  Habit is the enormous fly-wheel of society, its most precious conservative agent.	JAMES William	Principles of Psychology, I		110     entropie	1842-1910. (Américain)	berkeley	3414
La philosophie [ici synonyme de science] est écrite dans ce très vaste livre qui constamment se tient ouvert devant nos yeux - je veux dire l'univers - mais on ne peut le comprendre si d'abord on n'apprend pas à comprendre la langue et à connaître les caractères dans lesquels il est écrit. Or il est écrit en langage mathématique [ici synonyme de conceptuel] et ses caractères sont les triangles, les cercles, et autres figures géométriques, sans lesquels il est absolument impossible d'en comprendre un mot, sans lesquels on erre vraiment dans un labyrinthe obscur. (de la méthode, de l'expérience physique à la conceptualisation)	GALILEE	L"Essayeur.	1623	545     épistémologie	confirme la thèse de COPERNIC selon laquelle ce n"est pas le Soleil qui tourne autour de la Terre, mais la Terre qui tourne autour du Soleil, et sur elle-même.	berkeley	2901
Voil à la vraie question fondamentale : comment imposer une disci- pline à ces deux demi-dieux modernes, la science et l'économie ? Seulement en acceptant qu'il existe quelque chose de plus impor- tant, le sacré. Ne me demandez pas de le définir, car chacun doit posséder sa propre définition du sacré, qu'elle soit formellement religieuse ou non. Mais toutes les sociétés humaines ont besoin d'un engagement spirituel. Sinon, elle ne sont que des machines à calculer.	GOLDSMITH Jimmy	Le Piège.	1993	546     éthique		berkeley	2994
Ne jamais parler de soi aux autres et leur parler toujours d'eux-mêmes ; c'est tout l'art de plaire. Chacun le sait et tout le monde l'oublie.	GONCOURT Edmond et Jules de	Idées et Sensations		120     grégarité		berkeley	2997
L'homme n'est rien d'autre que la série de ses actes.	HEGEL Friedrich	Encyclopédie.		432     expérience		berkeley	3099
L'hérédité est comme une diligence dans laquelle tous nos ancêtres voyageraient. De temps en temps, l'un d'eux met la tête à la portière et vient nous causer toutes sortes d'ennuis.	Holmes Olivier W.			415     atavisme		berkeley	3213
C'est l'idée qui fait le bon bûcheron, ce n'est pas la force.	Homère	L"Iliade, XXIII, 315		370     esprit	IXe ou VIIIe s. av. J.-C.	berkeley	3219
Avoir trop de chefs ne vaut rien: qu'un seul soit chef, qu'un seul soit roi.	Homère	L"Iliade, II, 204-205		391     commandement	IXe ou VIIIe s. av. J.-C.	berkeley	3220
Car les chemins du jour côtoient ceux de la nuit.	Homère	L"Odyssée, X, 86		420     capital affectif	IXe ou VIIIe s. av. J.-C.	berkeley	3221
Car le Fils de l'homme est venu chercher et sauver ce qui était perdu.	Evangiles	Evangile selon saint Luc, XIX, 10		215     mystifications		berkeley	2425
L'homme cherche en lui-même ce qu'il ne trouve pas dans les autres, et cherche chez les autres ce qu'il y a de trop en lui.	CHAZAL Malcolm de	Sens plastique		423     solitude	1902-1981.	berkeley	1328
La liberté d'être soi est la plus haute forme de justice envers les autres.	CHAZAL Malcolm de	Sens plastique		440     courage	1902-1981.	berkeley	1329
Les larmes ne sont un aphrodisiaque qu' à vingt ans.	CHAZAL Malcolm de	Sens plastique		441     sang-froid	1902-1981.	berkeley	1330
Ah! sans doute Madame, vous possédiez trop d'avantages pour qu'un mortel osât vous aimer pour vous-même ; il aurait fallu qu'il se décidât entre votre esprit et vos charmes ; qu'il quittât sans cesse vos ouvrages pour vos yeux, vos yeux pour vos ouvrages ; et le poids de tant de prodiges était au-dessus des forces humaines. [...] Qu'il est beau, Madame, d'éteindre ainsi l'amour en se prodiguant soi-même, et de faire de la jouissance un frein redoutable au lieu d'une vile récompense. [...]  Mais je m'arrête, Madame, à force de vous louer, je pourrais oublier et qui vous êtes et ce que je vous dois ; et je serais inconsolable si en recevant mon hommage, vous vous trompiez sur son intention. Je l'abrège donc de peur de l'affaiblir, et je finis, Madame, par joindre au respect invincible et général que vous inspirez, celui de                                      Votre très humble et très honteux admirateur,                                                                  L'auteur du Petit Dictionnaire.	RIVAROL Antoine de	Petit Dictionnaire des Grands Hommes de la Révolution	1790	221     vanité	dédicace de l"ouvrage à Madame de STAEL.	berkeley	4826
Si une nation compte être ignorante et libre, elle compte sur ce qui n'a jamais été et ne sera jamais... Le peuple ne peut être en sureté sans informations. L à où la presse est libre et chaque citoyen capable de lire, tout est sauvé.	JEFFERSON	nte et libre\\010X&#250;		214     guerre du savoir	cité par Aldous HUXLEY in Retour au Meilleur des Mondes	berkeley	3432
J(ean)-J(acques) Rousseau. Faux misanthrope rococo.	HUGO Victor	Tas de pierres		221     vanité	1802-1885.	berkeley	3295
La modestie n'est qu'une sorte de pudeur de l'orgueil	JOUHANDEAU Marcel	De La Grandeur.		520     ironie de soi		berkeley	3486
Il n'y a pas de péché sinon la stupidité.	WILDE Oscar	The Critic As An Artist.		221     vanité		berkeley	5470
Tout ce qui n'est que suffisant ne suffit jamais.	MARIVAUX Pierre Carlet de Chamblain de	Le Paysan parvenu		442     démission	1688-1763.	berkeley	4231
Le vice est comme l'amant chéri de l'âme.	MARIVAUX Pierre Carlet de Chamblain de	Lettre sur les habitants de Paris		510     ironie	1688-1763.	berkeley	4234
Il faut avoir bien du jugement pour sentir que nous n'en avons point.	MARIVAUX Pierre Carlet de Chamblain de	L"Ile de la raison, Prologue		520     ironie de soi	1688-1763.	berkeley	4235
Pardonner dans le vide ne sert qu' à entretenir le mal. S'il n'est pas la contrepartie d'une cessation de la violence et de sa réparation, le pardon est vain.	CHOURAKI André		1992	331     altruisme	in "La Marche du Siècle" 22/04/92	berkeley	1356
C'est le fait d'un ignorant d'accuser les autres de ses propres échecs; celui qui a commencé de s'instruire, s'en accuse soi-même; celui qui est instruit n'en accuse ni autrui ni soi-même.	EPICTETE	Manuel		441     sang-froid	v. 50-v. 125.	berkeley	2359
Chaque jour est un bien du ciel que je reçois ; Je jouis aujourd'hui de celui qu'il me donne : Il n'appartient pas plus aux jeunes gens qu' à moi Et celui de demain n'appartient à personne.	MAUCROIX Chanoine F. de			140     rapport à la cosmogonie		berkeley	4247
- Pourquoi les femmes charmantes épousent-elles toujours des   hommes insignifiants ? - Parce que les hommes intelligents n'épousent pas les femmes   charmantes.	MAUGHAM Somerset	L"envoûte.		530     ironie amoureuse		berkeley	4248
L'un d'entre nous parfois se tient debout près de la mer. Il demeure l à longtemps, fixant le bleu, immobile et raide comme dans une église, ne sachant rien de ce qui pèse sur ses épaules et le retient, si frêle, médusé par le large. Il se souvient peut-être de ce qui n'a jamais eu lieu. Il traverse à la nage sa propre vie. Il palpe ses contours. Il explore ses lointains. Il laisse en lui se déplier la mer...	MAULPOIX Jean-Michel			140     rapport à la cosmogonie		berkeley	4249
Dans ce monde dur, il faut accueillir avec reconnaissance les brefs moments de grâce et garder toujours une place au coin du feu pour l'hôte inattendu.	WEST Morris	De main de Maître.	1988	560     sagesse		berkeley	5460
Agis en toute justice et ne crains aucun homme. N'écris jamais et ne crains aucune femme.	West Morris	De main de Maître.	1988	441     sang-froid		berkeley	5461
Si les Anglais viennent avec quatre divisions, je leur tire dessus. S'ils viennent avec vingt, je les embrasse.	WEYGAND général		1940	211     guerre	pressé  par Churchill de rallier l"Afrique du nord aux FFL.	berkeley	5462
Il n'est de pires ravages que ceux qui naissent de la vanité.	FAIRGAGNETR Oscar	Vitalités.	1993	221     vanité		berkeley	2506
J'embrasse mon rival, mais c'est pour l'étouffer.	RACINE Jean	Britannicus		225     cynisme		berkeley	4773
Ce qu'on doit être, on l'est. On l'est avant le fruit, avant la fleur, avant même la graine close.	BOSCO Henri	Un oubli moins profond		140     rapport à la cosmogonie	1888-1976.	berkeley	793
Quiconque commet un péché le commet contre lui-même.	Coran	Coran, IV, 111		546     éthique		berkeley	1640
Créer, c'est vivre deux fois. Créer, aussi, c'est donner une forme à son destin.	CAMUS Albert	Le Mythe de Sisyphe.		390     création		berkeley	1002
Les grandes récompenses dans une monarchie et dans une république sont un signe de leur décadence, parce qu'elles prouvent que leurs principes sont corrompus.	MONTESQUIEU Charles de	De l"esprit des lois		215     mystifications	1689-1755. (C. de Secondat, baron de La Brède et de M.)	berkeley	4402
Si son âme était sereine, le monde entier ligué contre lui ne lui causerait pas la moindre peine.	PEREZ-REVERTE Arturo	Le Maître d"escrime	1985	441     sang-froid	id	berkeley	4680
... la vie est une espèce de restaurant coûteux où l'on finit toujours par vous remettre l'addition, sans qu'il faille pour autant renier ce qu'on a savouré avec bonheur ou plaisir.	PEREZ-REVERTE Arturo	Le Tableau du Maître flamand	1990	510     ironie		berkeley	4681
Et vous vous trompez quand vous dites que je ne semble pas être de ceux qui s'enfuient ; nous fuyons tous un jour ou l'autre. Même moi.	PEREZ-REVERTE Arturo	Le Maître d"escrime	1985	520     ironie de soi		berkeley	4682
Où il n'y a point de maître, tout le monde est maître ; où tout le monde est maître, tout le monde est esclave.	BOSSUET Jacques Bénigne	Politique tirée des propres paroles de l"Ecriture Sainte		238     servitudes du pouvoir politique	1627-1704.	berkeley	801
Quand je peins, j'essaye toujours de donner une image à laquelle les gens ne s'attendent pas et qui soit assez écrasante pour être inacceptable. C'est cela qui m'intéresse. Et en ce sens, je veux être subversif. C'est- à-dire que je donne aux gens une image de la nature et d'eux-mêmes.	PICASSO Pablo			234     communication	in "Vivre avec Picasso" de F. Gilot & C. Lake.	berkeley	4696
J'ai fait le tableau, ça suffit. Je ne peux m'occuper du reste.	PICASSO Pablo			320     intuition	rapporté par DHK dans une lettre à Douglas Cooper (1939).	berkeley	4698
Les bons artistes plagient. Les grands artistes pillent.	PICASSO Pablo			390     création	citée in "Batisseurs d"Empires par accident" de Robert X. Cringely qui l"entendit prononcée pour la première fois par Steve Jobs.	berkeley	4699
Qu'est-ce au fond qu'un peintre ? C'est un collectionneur qui veut se constituer une collection en faisant lui-même les tableaux qu'il aime chez ls autres. C'est comme ça que je commence et puis ça devient autre chose.	PICASSO Pablo		1934	393     création artistique	cité par Pierre Assouline in DHK.	berkeley	4703
Diversité, c'est ma devise.	LA FONTAINE Jean de	Contes, le Pâté d"anguilles		341     étonnement	1621-1695.	berkeley	3697
Le stupide ne se trompe pas dans son comportement. Il se trompe dans son raisonnement. C'est celui qui dit que tous les chiens sont des animaux domestiques et que tous les chiens aboient, mais que les chats aussi sont des animaux domestiques et donc qu'ils aboient. (..) Le stupide est des plus insideux. L'imbécile, on le reconnait tout de suite (sans parler du crétin), tandis que le stupide raisonne presque comme vous et moi, sauf un écart infinitésimal. C'est un maitre en paralogismes.	ECO Umberto	Le Pendule de Foucault	1988	360     bon sens		berkeley	2268
Foi, énergie, travail, confiance.	FAIRGAGNETR Oscar	Vitalités.	1992	440     courage		berkeley	2602
L'ordre ne crée pas la vie.	SAINT-EXUPéRY Antoine de	Carnets		390     création	1900-1944.	berkeley	4930
Ce que nous dénommons vérité n'est qu'une élimination d'erreurs.	CLEMENCEAU Georges	Aux embuscades de la vie		421     initiation	1841-1929.	berkeley	1484
L'essentiel n'est pas ce que l'on fait de l'homme mais ce qu'il fait de ce que l'on a fait de lui.	SARTRE Jean-Paul			421     initiation		berkeley	4956
L'homme s'est toujours servi de l'art comme d'un moyen de prendre conscience des idées et des intérêts les plus élevés de son esprit, les peuples ont déposé leurs conceptions les plus hautes dans les productions de l'art, les ont exprimées et en ont pris conscience par le moyen de l'art.	HEGEL Friedrich	Esthétique.		393     création artistique	1770/1831	berkeley	3094
Toute chose est contradictoire en soi.  Alle Dinge sind an sich selbst widersprechend.	HEGEL Georg Wilhelm Friedrich	Science de la logique		365     discernement	1770-1831. (Allemand)	berkeley	3101
Tant il est aisé d'écraser, au nom de la liberté extérieure, la liberté intérieure de l'homme.	TAGORE Radindranath	L"appel de la Vérité.		211     guerre		berkeley	5185
L'homme qui attente à ses jours montre moins la vigueur de son âme que la défaillance de sa nature.	CHATEAUBRIAND François-René de	Mémoires d"outre-tombe		442     démission	1768-1848.	berkeley	1309
[...] le tableau naît dans la conscience du spectateur 'lettré' qui le reconstitue en le lisant, comme il le ferait d'une page imprimée.	KAHNWEILER Daniel-Heinrich	"L"art crée le monde".	1968	393     création artistique	article donné à "Galerie des Arts", en février 1968.	berkeley	3522
Rien n'est jamais sûr dans la vie, il n'y a que des probabilités [...]	CLANCY Tom	La somme de toutes les peurs. I.	1991	510     ironie		berkeley	1430
Il est des paroles qui ne devraient servir qu'une fois.	CHATEAUBRIAND François-René de	Mémoires d"outre-tombe		560     sagesse	1768-1848.	berkeley	1319
C'est toujours l'âne qui brait le plus fort qui est le plus racé; la bêtise est tonitruante.	CHAZAL Malcolm de	Sens plastique		120     grégarité	1902-1981.	berkeley	1320
Tu es en fin de compte... ce que tu es. Mets-toi sur la tête une perruque à un million de marteaux, Chausse un cothurne haut d'une aune : Tu n'en demeures pas moins ce que tu es.	GOETHE Johann Wolfgang von	Faust,I.		520     ironie de soi		berkeley	2979
Et ses mains ourdiraient les entrailles du prêtre,  A défaut d'un cordon, pour étrangler les rois.  Poésies diverses   Diderot interprète ici le testament du curé Meslier. La Harpe, dans son Cours de littérature ancienne et moderne (troisième partie, livre IV, chapitre III), donne de ces deux vers une version différente, qu'il attribue également à Diderot.  ... Et des boyaux du dernier prêtre / Serrons le cou du dernier roi.	DIDEROT Denis			215     mystifications	1713-1784.   Le texte de Chamfort semble plus proche de cette seconde version que de la première.	berkeley	2078
C'est peut-être l à que naît la légende des chevaliers du Temple, qui encore hante les esprits pleins de déceptions et de désirs, l'histoire d'une puissance sans bornes laquelle, désormais ne sait plus sur quoi s'exercer...	ECO Umberto	Le Pendule de Foucault	1988	510     ironie		berkeley	2275
Je crains plus la réputation que je ne la désire, estimant qu'elle diminue toujours en quelque façon la liberté et le loisir de ceux qui l'acquièrent.	DESCARTES René	Correspondance, à Mersenne, 15 avril 1630		441     sang-froid	1596-1650.	berkeley	1947
Un Etat sans religion est comme un navire sans boussole.	Napoléon I			232     servitudes du pouvoir	(Athée)	berkeley	4558
On n'est pas un amant parce qu'on a une maîtresse. Ce serait trop facile.	FLERS Robert de	Les Vignes du Seigneur		530     ironie amoureuse	1872-1927. (et Francis de Croisset)	berkeley	2798
A mes yeux, la tolérance est la plus belle et la plus noble des vertus. Rien n'est possible sans cette disposition de l'âme. Elle est une question préalable à tout contact humain. La tolérance ne fait renoncer à aucune idée et ne fait pas pactiser avec le mal. Elle implique simplement qu'on accepte que d'autres ne pensent pas comme vous sans les haïr pour cela.	SPAAK Paul-Henri		1955	546     éthique	2e Congrès de "Fraternité Mondiale".	berkeley	5098
Le plaisir du bien-être et du confort acquiert la valeur et les nuances d'une véritable joie esthétique.	ROMAINS Jules			460     plaisir		berkeley	4846
La mer est aussi profonde dans le calme que dans la tempête.  The sea is as deepe in a calme as in a storme.	DONNE John	Sermons, Mundus Mare		441     sang-froid	1573-1631. (Anglais)	berkeley	2136
Si je viens à te prendre en rêve, tu es mienne, Car il n'est de plaisir qui ne soit figuré.	DONNE John	Poèmes, Le Rêve.		530     ironie amoureuse		berkeley	2137
La vertu est comme la punaise: pour qu'elle exhale son odeur, il faut l'écraser.  La virtù è come la cimice: perchè esali il suo odore bisogna schiacciarla.	DOSSI Carlo	Note Azzurre, 5513		520     ironie de soi	1849-1910. (Italien)	berkeley	2141
Le tort de nombreux voleurs, aux yeux du public et de la justice, c'est de ne pas avoir volé suffisamment pour dissimuler leur larcin.  Il torto di molti ladri in faccia al pubblico e alla giustizia è quello di non aver rubato abbastanza per celare il furto.	DOSSI Carlo	Note Azzurre, 5446	46	539     ironie sociale	1849-1910. (Italien)	berkeley	2143
A notre époque, tout homme comme il faut est et doit être lâche et servile.	DOSTOIEVSKI Fiodor Mikhaïlovitch	Mémoires écrits dans un souterrain		120     grégarité	1821-1881. (Russe)	berkeley	2147
Rien de tel qu'un type en colère pour vous donner les meilleurs tuyaux.	CLANCY Tom	La somme de toutes les peurs. I.	1991	441     sang-froid		berkeley	1429
L'esprit n'est que la vérité rendue amusante.	BULWER-LYTTON	Les Parisiens.		370     esprit		berkeley	903
Notre planète connait une population prodigieusement accrue, si je la compare aux chiffres du passé. Ainsi l'Europe accueille trois fois plus d'habitants qu'il y a un siècle. mais le nombre des personnalités créatrices a décru. Et la communauté ne découvre plus ces êtres dont elle a essentiellement besoin. L'organisation mécanique s'est substituée partiellement à l'homme novateur.	EINSTEIN Albert	Comment je vois le Monde	1934	110     entropie	rééd.corr. en 1952 et 1978.	berkeley	2284
La majorité des imbéciles reste invincible et satisfaite en toute circonstance. La terreur provoquée par leur tyrannie se dissipe simplement par leur divertissement et leur inconséquence.	EINSTEIN Albert	Comment je vois le Monde	1934	110     entropie	rééd.corr. en 1952 et 1978.	berkeley	2285
Il est dur d'être gueux, tandis qu'il y a tant de sots opulents aux dépens desquels on peut vivre.	DIDEROT Denis	Le Neveu de Rameau		225     cynisme	1713-1784.	berkeley	2087
Les contrastes et les contradictions peuvent coexister en permanence dans une tête sans déclancher nul conflit. Cette évidence bouleverse ou détruit tout système politique pessimiste ou optimiste.	EINSTEIN Albert	Comment je vois le Monde	1934	430     paradoxal émotionnel	rééd.corr. en 1952 et 1978.	berkeley	2315
Rares sont les esprits assez maitres d'eux-mêmes pour voir les faiblesses de leurs contemporains sans tomber dans les mêmes pièges.	EINSTEIN Albert	Comment je vois le Monde	1934	441     sang-froid	rééd.corr. en 1952 et 1978.	berkeley	2316
Nous aurons le destin que nous aurons mérité.  Unser Schicksal wird so sein, wie wir es verdienen.	EINSTEIN Albert	Comment je vois le monde		441     sang-froid	1879-1955. (Allemand, naturalisé Américain)	berkeley	2317
Il n'est pas possible, Athéniens, non, il n'est pas possible de constituer par l'injustice, par le parjure, par le mensonge, une puissance qui dure.	Démosthène	Olynthiennes		110     entropie	384-322 av. J.-C.	berkeley	1895
Tous l'écoutaient avec joie parcequ'ils comprenaient qu'il ne cherchait pas à s'imposer mais à servir.	EINSTEIN Albert	Comment je vois le Monde	1934	331     altruisme	rééd. augm. en 1952 et 1978.	berkeley	2303
Passé un certain âge, lire détourne trop l'esprit de ses activités créatrices. Un homme qui lit trop et qui fait trop peu d'efforts cérébraux prend vite des habitudes de paresse d'esprit.	EINSTEIN Albert			380     travail		berkeley	2310
Si l'homme est créé libre, il doit se gouverner ; Si l'homme a des tyrans, il doit les détrôner.	VOLTAIRE	Epitres.		130     liberté		berkeley	5324
- Jouer n'est pas rire forcément. Nietzsche, dans Zarathoustra, disait que l'homme passe par trois stades. Le premier, c'est le stade du chameau, l'animal obéissant : on lui met n'importe quel colis sur le dos, les oeuvres complètes de tel penseur moderne, les discours de Me Jouffa [président de la Ligue des droits de l'Homme], les promesses de M. Mitterand, toutes sortes de tables de la loi et il accepte tout. Le deuxième stade, c'est le lion rugissant. L'homme n'accepte plus d'être traité comme une bête de trait, il se révolte contre tout. Et le troisième stade, c'est celui de l'enfant qui joue. Il n'est même plus révolté, il a tout jeté par-dessus bord, il s'amuse de tout dans la plus parfaite innocence.	VERGES Jacques	Le Salaud lumineux.	1990	510     ironie	entretiens avec Jean-Louis Rumilleux	berkeley	5280
Dis qu'as-tu fait, toi que voil à Pleurant sans cesse Qu'as-tu fait, Dis, toi que voil à De ta jeunesse !	VERLAINE Paul			110     entropie		berkeley	5281
- C'est un vieille illusion, Ashley, de croire que les hommes de bien font de bons chefs, que des êtres gouvernent par la foi, l'espérance, la charité et une série d'encycliques papales. Un gouvernement a pour fonction de fournir une structure forte et sûre dans le cadre de laquelle les gens puissent vivre et accéder, par une lente évolution, à de meilleures conditions d'existence. La vertu du chef n'a rien à faire l à-dedans. Ce qui importe, c'est sa force, sa sagesse, et sa capacité d'utiliser la corruption et la faiblesse de ses semblables au profit du corps politique. Le progrès exige la sécurité. La sécurité repose sur la force. Je ne suis pas un homme de bien, tant s'en faut; mais je suis un homme fort. Je m'entends bien à la politique.	WEST Morris	Toute la vérité.	1957	238     servitudes du pouvoir politique		berkeley	5376
Avant d'entamer une révolution, pensez à ce que vous mettrez à la place de ce que vous détruisez - sinon vous créerez un vide que sept démons s'empresseront de remplir !	WEST Morris	Lazare.	1990	239     servitudes du pouvoir autoritaire		berkeley	5377
Vous trouverez une vérité au fond de la bouteille, mais vous ne pouvez pas être certain que ce soit la vérité que l'ivrogne croit connaître ou la vérité telle qu'elle est.	WEST Morris	Le Loup Rouge.	1971	240     débauche		berkeley	5378
Vous êtes le berger suprême, mais vous ne voyez pas vos brebis - vous ne voyez qu'un immense tapis de dos laineux s'étendant jusqu' à l'horizon.	WEST Morris	Lazare.	1990	240     débauche		berkeley	5379
Si vous pouvez le rêver, nous pouvons le faire.	Dictons et proverbes			390     création		berkeley	2064
Notre existence quotidienne est un mauvais feuilleton par lequel nous nous laissons envoûter.	BUTOR Michel	Répertoire		520     ironie de soi	1926-.	berkeley	937
Et quand tes fils sont condamnés aux fers Et plongés dans l'obscurité du cachot humide, Ils sauvent leur patrie par leur martyre Et la gloire de la liberté ouvre l'aile à tous les vents.	BYRON George Gordon lord	Le Prisonnier du Chillon.		130     liberté		berkeley	940
Il n'y a que le sentiment qui nous puisse donner des nouvelles un peu sûres de nous.	MARIVAUX Pierre Carlet de Chamblain de	La Vie de Marianne		320     intuition	1688-1763.	berkeley	4225
Vous savez qui sont les critiques? Les hommes qui ont échoué en littérature et en art.  You know who the critics are? The men who have failed in literature and art.	DISRAELI Benjamin	Lothair, 35		221     vanité	1804-1881. (Anglais)	berkeley	2123
Il faut cultiver notre jardin.	VOLTAIRE	CANDIDE	1759	390     création		berkeley	5331
Faire de l'instant présent quelque chose de permanent.	WOOLF Virginia	La promenade au Phare.		321     volonté		berkeley	5491
Le réalisme, socialiste ou pas, est en deç à de la réalité 	IONESCO Eugène	Notes et Contre-notes		221     vanité	1912-.	berkeley	3384
Les affaires ..., c'est l'argent des autres.	DUMAS Alexandre	La Question d"argent, II, 7, Jean		212     guerre économique	1824-1895. (fils)	berkeley	2226
Les hommes croient qu'ils sont jaloux de certaines femmes parce qu'ils en sont amoureux; ce n'est pas vrai; ils en sont amoureux parce qu'ils en sont jaloux, ce qui est bien différent.	DUMAS Alexandre	Une visite de noces		221     vanité	1824-1895. (fils)	berkeley	2227
Il est troublant de découvrir combien de gens pensent qu'ils ne peuvent apprendre et combien plus encore croient que c'est l à chose difficile. Muad'Dib savait que chaque expérience porte en elle sa leçon.	HERBERT Franck	Dune	1965	110     entropie		berkeley	3131
Et le prix que nous avons payé est celui que les hommes ont toujours payé pour jouir du paradis durant le temps de leur vie : nous sommes devenus fragiles, notre fil s'est émoussé.	HERBERT Franck	Dune	1965	120     grégarité		berkeley	3132
Nous faisons de la parole précise le témoignage le plus sûr de la pensée juste.	Isocrate	Sur l"échange, 255		365     discernement	436-338 av. J.-C.	berkeley	3393
Pour nuire, nous sommes puissants.  Ad nocendum potentes sumus.	Sénèque	De la colère, I, 3		515     tragédie		berkeley	5011
Entre toutes les différentes expressions qui peuvent rendre une seule de nos pensées, il n'y en a qu'une qui soit la bonne.	LA BRUYERE Jean de	Les Caractères		370     esprit	1645-1696.	berkeley	3612
Les grands artistes n'ont pas de patrie.	MUSSET Alfred de	Lorenzaccio, I, 5, l"orfèvre		421     initiation	1810-1857.	berkeley	4535
Le plus libre de tous les hommes est celui qui peut être libre dans l'esclavage même.	Fénelon	Les Aventures de Télémaque		433     perversion	1651-1715. (François de Salignac de La Mothe-)	berkeley	2695
Il faut toujours espérer quand on désespère, et douter quand on espère.	FLAUBERT Gustave	L"amour de l"art.	1915	321     volonté	(1821/1880) édition posthume	berkeley	2732
La prose doit être un vers qui ne va pas à la ligne.	RENARD Jules	Journal		393     création artistique		berkeley	4812
Les peuples les plus civilisés sont aussi voisins de la barbarie que le fer le plus poli l'est de la rouille.	RIVAROL Antoine de	Fragments et pensées politiques		539     ironie sociale	1753-1801. (Antoine Rivarol)	berkeley	4837
Le coeur de deux chambres se compose Dans lesquelles habitent Joie et Chagrin. Lorsque Joie dans l'une s'éveille, Dans l'autre s'endort Chagrin. O Joie, prenez garde! Parlez donc bas, De crainte d'éveiller Chagrin.	NEUMAN H.	Le Coeur.		430     paradoxal émotionnel		berkeley	4581
Rendez donc à César ce qui est à César, et à Dieu ce qui est à Dieu.	Evangiles	Evangile selon saint Matthieu, XXII, 21		215     mystifications		berkeley	2406
Qui veut en effet sauver sa vie la perdra, mais celui qui perd sa vie à cause de moi la trouvera.	Evangiles	Evangile selon saint Matthieu, XVI, 25		215     mystifications		berkeley	2407
Quiconque s'élèvera sera abaissé, et quiconque s'abaissera sera élevé.	Evangiles	Evangile selon saint Matthieu, XXIII, 12		215     mystifications		berkeley	2408
Efforcez-vous d'entrer par la porte étroite.	Evangiles	Evangile selon saint Luc, XIII, 24		440     courage	La Porte étroite est le titre d"un roman d"André Gide.	berkeley	2437
Nul ne peut servir deux maîtres. Ou il haïra l'un et aimera l'autre, ou il s'attachera à l'un et méprisera l'autre. Vous ne pouvez servir Dieu et l'Argent.	Evangiles	Evangile selon saint Matthieu, VI, 24		215     mystifications		berkeley	2409
Ne vous inquiétez donc pas du lendemain: demain s'inquiétera de lui-même. A chaque jour suffit sa peine.	Evangiles	Evangile selon saint Matthieu, VI, 34		215     mystifications		berkeley	2410
La Grande-Bretagne elle-même est une île flottante qui, selon les inflexions de sa politique, se rapproche ou s'éloigne de l'Europe.	FABRE-LUCE Alfred			238     servitudes du pouvoir politique		berkeley	2444
Le sentiment de solitude qui est la misère et la fierté des hommes supérieurs.	FAGUET			423     solitude		berkeley	2445
Aimez autrui comme vous-même et vous trouverez à vous aimer vraiment.	FAIRGAGNETR Oscar		1992	330     coeur		berkeley	2545
Persévérez, et tenez-vous toujours ferme à l'heure présente. Chaque moment, chaque seconde est d'une valeur infinie, car elle est le représentant d'une éternité tout entière.	GOETHE Johann Wolfgang von	Conversations.	1823	440     courage		berkeley	2976
Il n'est de fascisme qu'irraisonnable et s'en affranchir ne connaît d'autres alternatives que celles de l'abattre ou de le fuir.	FAIRGAGNETR Oscar		1991	310     énergie		berkeley	2531
Le pacte léniniste, qui permet aux démocraties d'acheter la paix sociale au 'centre' qui contrôle dans le monde entier la révolte, est une des grandes découvertes politiques de ce siècle.	RUFIN Jean-Christophe	La Dictature Libérale.		238     servitudes du pouvoir politique	Le secret de la toute-puissance des démocraties au 20e siècle	berkeley	4896
...aucun piège ne fonctionne sans la complicité inconsciente de la victime.	PEREZ-REVERTE Arturo	Le Maître d"escrime	1985	441     sang-froid		berkeley	4679
Je ne peins pas l'être. Je peins le passage.	MONTAIGNE Michel Eyquem de	Essais, III, 2		365     discernement	1533-1592.	berkeley	4342
La limite idéale vers laquelle tend la nouvelle organisation du travail est celle où le travail se bornerait à cette seule forme de l'action: l'initiative.	FOURASTIé Jean	Le Grand Espoir du XXe siècle		380     travail	1907-1990.	berkeley	2848
Vivre, c'est se savoir vulnérable au risque de ne pouvoir engendrer beauté et richesse... du sentiment, de l'intention et du résultat des choses.	FAIRGAGNETR Oscar	Vitalités.	1995	550     grandeur	Le 7 mai 1995.	berkeley	2647
Nul ne pense pour soi ; cela ne peut aller... L'universel est le lieu des pensées.	CHARTIER Emile	Propos De Littérature.		370     esprit	alias Alain (1868-1951)	berkeley	1232
Vous resterez le seul... Ne vous heurtez pas de front avec les américains. Ils viendront à vous, car il n'y a pas d'alternative...	CHURCHILL Sir Winston Leonard Spencer		1942	441     sang-froid	 à de Gaulle, refusant la légitimité algéroise de Darlan.	berkeley	1372
Chassez le naturel, il revient au galop.	Destouches	Le Glorieux, III, 5, Lisette		510     ironie	1680-1754. (Philippe Néricault)	berkeley	1968
Ils [les gens] diront sans pudeur du mal d'un chef-d'oeuvre parce qu'ils croient qu'on a l'air de s'y connaître quand on dit du mal d'un ouvrage - mais dire du bien, s'enthousiasmer,attention ! Ils ne veulent pas être ridicules.	GUITRY Sacha	Théâtre, je t"adore.		120     grégarité		berkeley	3053
Les absents ont toujours tort.	Destouches	L"Obstacle imprévu, I, 6, Nérine		539     ironie sociale	1680-1754. (Philippe Néricault)	berkeley	1969
La plus belle moitié de la vie est cachée à l'homme qui n'a pas aimé avec passion.	STAEL Madame de			530     ironie amoureuse		berkeley	5130
Le pire des handicaps présente toujours une 'faille'. Il suffit d'aller la chercher.	FAIRGAGNETR Oscar	Vitalités.	1994	432     expérience		berkeley	2587
Ces troupes que l'offensive des Panzer a mises en débandade au cours des jours précédants. Rattrapés dans leur fuite par les détachements mécaniques de l'ennemi, ils ont reçu l'ordre de jeter leurs fusils et de filer vers le sud pour ne pas encombrer les routes. 'Nous n'avons pas, leur a-t-on crié, le temps de vous faire prisonniers !'.	DE GAULLE Charles	lettre à Yvonne de Gaulle.	1940	211     guerre		berkeley	1793
A la guerre, à part quelques principes essentiels, il n'y a pas de système universel, mais seulement des circontances et des personnalités.	DE GAULLE Charles	La Discorde chez l"ennemi.	1924	211     guerre	211     guer\\010hép\\010hâp´	berkeley	1794
Un roi sans divertissement est un homme plein de misères.	PASCAL Blaise			350     imagination		berkeley	4643
On raille de tout, parce que tout a un revers.	MONTESQUIEU Charles de	Mes pensées		221     vanité	1689-1755. (C. de Secondat, baron de La Brède et de M.)	berkeley	4419
La nouveauté de la civilisation démocratique contemporaine, nouveauté que Hobbes ne pouvait prévoir, est que cette civilisation produit en même temps état de société et état de nature. Elle entretient l'un et l'autre, tout en les maintenant séparés. Cette pratique paradoxale, très largement inconsciente, définit la fonction de la main invisible politique. Cette main invisible guide les sociétés libérales plus sûrement que ne le feraient une conscience unique et une volonté particulière. Le principe de ce pilotage est simple : il vise à maximiser à tout moment la peur.	RUFIN Jean-Christophe	La Dictature Libérale.		231     légitimité du pouvoir	Le secret de la toute-puissance des démocraties au 20e siècle	berkeley	4891
Toutes les grandes lectures sont une date dans l'existence.	LAMARTINE Alphonse de	Cours familiers de littérature.		421     initiation		berkeley	4001
La découverte scientifique désintéressée a été le facteur principal et peut-être le facteur unique du progrès humain.	PERRIN Jean			392     création économique		berkeley	4684
On dit du mal des femmes pour se venger de n'en rien savoir.	PETIT Henri	Les Justes Solitudes.		221     vanité	1900/1978	berkeley	4685
Assurons-nous bien du fait avant de nous inquiéter de la cause.	FONTENELLE Bernard le Bovier de	Histoire des oracles		441     sang-froid	1657-1757.	berkeley	2826
Il faut ne donner que la moitié de son esprit aux choses ... que l'on croit, et en réserver une autre moitié libre où le contraire puisse être admis s'il en est besoin.	FONTENELLE Bernard le Bovier de	Entretiens sur la pluralité des mondes		441     sang-froid	1657-1757.	berkeley	2827
N'abrégez pas le matin en vous levant tard ; regardez-le comme la quintessence de la vie, jusqu' à un certain point sacré.	SCHOPENHAUER Arthur	Conseils et Maximes.		440     courage		berkeley	4979
[...] pour découvrir le fondement de l'éthique, il n'y a qu'une route, celle de l'expérience.	SCHOPENHAUER Arthur	Le Fondement de la morale.		546     éthique		berkeley	4981
L'intelligence est un capitaine qui est toujours en retard d'une bataille. Et qui discute après la bataille.	FARGUE Léon-Paul	Sous la lampe		365     discernement	1876-1947.	berkeley	2655
L'artiste contient l'intellectuel. La réciproque est rarement vraie.	FARGUE Léon-Paul	Sous la lampe		390     création	1876-1947.	berkeley	2658
Les vieux fous sont plus fous que les jeunes.	LA ROCHEFOUCAULD François de	Maximes		360     bon sens	1613-1680.	berkeley	3850
Moralité  Deux pigeons s'aimaient d'amour tendre* 	BERNARD Tristan	Contes, Répliques et Bons Mots 		530     ironie amoureuse	1866-1947. (Paul Bernard) *Premier vers de la fable de La Fontaine les Deux Pigeons (livre IX, fable 2).	berkeley	718
Les femmes sont fausses dans les pays où les hommes sont tyrans. Partout la violence produit la ruse.	BERNARDIN DE SAINT-PIERRE Jacques-Henri	Paul et Virginie		210     violence	1737-1814.	berkeley	719
On n'a pas un enfant comme on a un bouquet de roses.  Tener un hijo no es tener un ramo de rosas.	GARCIA LORCA Federico	Yerma		433     perversion	1899-1936. (Espagnol)	berkeley	2911
On ne va pas à la guerre pour se faire tuer ; on y va pour vaincre l'ennemi.	MARMONT			211     guerre		berkeley	4239
Ce que les majorités victorieuses ont surtout à redouter, c'est de vouloir toucher à tout à la fois, au risque de tout confondre et de tout compromettre.  	GAMBETTA Léon			221     vanité	1838-1882.   Déclaration de Gambetta le 25 octobre 1875, après que la majorité royaliste de la Chambre des députés eut doté la France d"une Constitution jugée trop conservatrice.	berkeley	2902
Au chaume on reconnaît l'épi.	Homère	L"Odyssée, XIV, 214-215		432     expérience	IXe ou VIIIe s. av. J.-C.	berkeley	3222
Pauvre fou, ta fougue te perdra.	Homère	L"Iliade, VI, 407		441     sang-froid	IXe ou VIIIe s. av. J.-C.	berkeley	3223
A mauvais payeur, mauvaises garanties.	Homère	L"Odyssée, VIII, 351		441     sang-froid	IXe ou VIIIe s. av. J.-C.	berkeley	3224
L'artiste désespéré crache à la figure de la société qui vend ses crachats.	HUYGUES René			221     vanité		berkeley	3367
L'homme que je fus, l'homme que je suis, Elle aime les deux, mais elle est plus sûre De 'suis' que de 'fus' Je suis qui je suis, je suis qui je fus. Je voudrais qu'elle vît la différence.	WEST Morris	Le Loup Rouge.	1971	530     ironie amoureuse		berkeley	5451
- Il faut être deux, pour un amour. - Ne crois pas cela... Il y en toujours un qui donne et un qui reçoit... et c'est pourquoi les millionnaires épousent les entraîneuses et les entraîneuses deviennent les protectrices des poètes faméliques.	WEST Morris	Kaloni le navigateur	1976	530     ironie amoureuse		berkeley	5452
Entre époux, il faut qu'il y ait 'compatibilité de consciences'.	WEST Morris	De main de Maître.	1988	546     éthique		berkeley	5458
Le génie, en définitive, n'est guère plus que la faculté de percevoir sur un mode inhabituel.	JAMES William	Précis de psychologie.		320     intuition		berkeley	3415
Qui est fidèle pour très peu de chose est fidèle aussi pour beaucoup, et qui est malhonnête pour très peu est malhonnête aussi pour beaucoup.	Evangiles	Evangile selon saint Luc, XVI, 10		140     rapport à la cosmogonie		berkeley	2400
Le virtuose ne sert pas la musique; il s'en sert.	COCTEAU Jean	Portraits-souvenirs		221     vanité	1889-1963.	berkeley	1496
Aimable souvent est sable mouvant.	DESNOS Robert	Corps et biens		222     fourberie	1900-1945.	berkeley	1959
Il y a des gens qui vous laissent tomber un pot de fleurs sur la tête d'un cinquième étage et qui vous disent: Je vous offre des roses.	HUGO Victor	Tas de pierres		215     mystifications	1802-1885.	berkeley	3289
La presse a succédé au catéchisme dans le gouvernement du monde. Après le Pape, le papier.	HUGO Victor	Tas de pierres		215     mystifications	1802-1885.	berkeley	3290
Apprivoiser, c'est l à tout le gouvernement;  Régner, c'est l'art de faire, énigmes délicates,  Marcher les chiens debout et l'homme à quatre pattes.	HUGO Victor	Théâtre en liberté, Mangeront-ils?		215     mystifications	1802-1885.	berkeley	3291
La raison du meilleur est toujours la plus forte.	HUGO Victor	Tas de Pierre.		215     mystifications		berkeley	3292
Grattez le juge, vous trouverez le bourreau.	HUGO Victor	Littérature et philosophie mêlées		221     vanité	1802-1885.	berkeley	3293
Aimer, ce n'est pas se regarder l'un l'autre, c'est regarder ensemble dans la même direction.	SAINT-EXUPERY Antoine de	Terre des Hommes.		531     communication amoureuse		berkeley	4920
Tous savent conclure, peu savent juger.	SCHOPENHAUER Arthur	Le fondement de la morale.	1840	550     grandeur		berkeley	4983
L'argent n'a pas changé ma vie... Je suis redevenu moi-même, au-del à de mes rêves.	SCHUMACHER Michael			365     discernement		berkeley	4984
La plus perdue de toutes les journées est celle où l'on n'a pas ri.	CHAMFORT Nicolas-Sébastien de	Maximes et pensées		450     rire	1740/1794. Ac. Française	berkeley	1134
Le croyant est celui qui a besoin de croire.	NIETZSCHE Friedrich			321     volonté	321     volo\\010lq0\\010l{ à	berkeley	4587
Toutes les passions nous font faire des fautes mais l'amour nous en fait faire de plus ridicules.	LA ROCHEFOUCAULD François de	Maximes.		430     paradoxal émotionnel		berkeley	3872
Dieu n'est qu'un mot rêvé pour expliquer le monde.	LAMARTINE Alphonse de	Harmonies poétiques et religieuses		545     épistémologie	1790-1869.	berkeley	4014
Je parle au papier comme je parle au premier que je rencontre.	MONTAIGNE Michel Eyquem de	Essais, III, 1		393     création artistique	1533-1592.	berkeley	4347
[...] je voudrais aussi qu'on fût soigneux de lui choisir un conducteur qui eût plutôt la tête bien faite que bien pleine, et qu'on y requît tous les deux, mais plus les moeurs et l'entendement que la science.	MONTAIGNE Michel Eyquem de	Essais.		421     initiation		berkeley	4348
Adonne-toi à l'étude des lettres pour en tirer quelque chose qui soit toute tienne.	MONTAIGNE Michel Eyquem de	Essais.		421     initiation		berkeley	4350
Méfions-nous de la métaphysique appliquée aux choses simples.	CHOISEUL Duchesse de	Lettres		433     perversion	1736-1801.	berkeley	1353
La vie dicte aux hommes ses lois, qui ne sont écrites nulle part.	CHOLOKHOV Mikhaïl Aleksandrovitch	Le Don paisible		432     expérience	1905-1984. (Russe)	berkeley	1354
Si la destinée ne nous aide pas, nous l'aiderons nous-mêmes à se réaliser.	Chosroès Ier le Grand	Mémoires		321     volonté	roi de Perse VIe siècle	berkeley	1355
Le barbare, c'est d'abord celui qui croit à la barbarie.	LEVI-STRAUSS Claude	Race et histoire.	1961	110     entropie		berkeley	4120
La vraie barbarie, c'est Dachau; la vraie civilisation, c'est d'abord la part de l'homme que les camps ont voulu détruire.	MALRAUX André	Antimémoires		210     violence	1901-1976.	berkeley	4200
Le bonheur à deux exige une qualité très rare d'ignorance, d'incompréhension réciproque, pour que l'image merveilleuse que chacun avait inventée de l'autre demeure intacte, comme aux premiers instants.	GARY Romain	Charge d"âme.		530     ironie amoureuse		berkeley	2919
Fuyez ! grammairiens pleins de bile et d'audace, Vous qui pour une lettre, un seul point hors de place, D'abord la plume en main, versez l'encre à torrent, Et sonnez le tocsin sur tous les ignorants.	GAYOT de PITAVAL			221     vanité	(cité par...)	berkeley	2921
Ce n'est pas avec la raison, et c'est le plus souvent contre elle, que s'édifient les croyances capables d'ébranler le monde.	LE BON Gustave	Hier et Demain.		120     grégarité		berkeley	4061
L'âge où nous entrons sera véritablement l'ère des foules. Ce n'est plus dans les conseils des princes, mais dans l'âme des foules que se préparent les destinées des nations.	LE BON Gustave		1894	232     servitudes du pouvoir		berkeley	4062
La route de l'excès mène au palais de la sagesse.  The road of excess leads to the palace of wisdom.	BLAKE William	The Marriage of Heaven and Hell		560     sagesse	1757-1827. (Anglais)	berkeley	761
Parole parée n'est pas sincère.	LAO TSEU	Tao tö King, LXXXI		222     fourberie		berkeley	4029
Pour communiquer avec un imbécile, mieux vaut être diable ou héros.	FAIRGAGNETR Oscar	Vitalités.	1991	510     ironie		berkeley	2617
Rien ne pèse tant qu'un secret:  Le porter loin est difficile aux dames;  Et je sais même sur ce fait  Bon nombre d'hommes qui sont femmes.	LA FONTAINE Jean de	Fables, les Femmes et le Secret		423     solitude	1621-1695.	berkeley	3713
Quand le moment viendra d'aller trouver les morts,  J'aurai vécu sans soins, et mourrai sans remords.	LA FONTAINE Jean de	Fables, le Songe d"un habitant du Mogol		423     solitude	1621-1695.	berkeley	3714
On ne se sert pas de la musique ; on la sert.	MENUHIN Yehudi soeur de	Yehudi Menuhin.	1991	140     rapport à la cosmogonie	(date de diff. du doc. biograph. de Tony Palmer - FR3 le 30/11/91)	berkeley	4269
Nature est un doux guide, mais non pas plus doux que prudent et juste.	MONTAIGNE Michel Eyquem de	Essais, III, 13		140     rapport à la cosmogonie	1533-1592.	berkeley	4315
Il n'y a rien d'inutile en nature; non pas l'inutilité même.	MONTAIGNE Michel Eyquem de	Essais, III, 1		140     rapport à la cosmogonie	1533-1592.	berkeley	4316
Quand on veut plaire dans le monde, il faut se résoudre à apprendre beaucoup de choses qu'on sait par des gens qui les ignorent.	CHAMFORT Nicolas-Sébastien de	Maximes et pensées		421     initiation	1740/1794. Ac. Française	berkeley	1121
Il y a souvent plus d'orgueil que de bonté à plaindre les malheurs de nos ennemis ; c'est pour leur faire sentir que nous sommes au dessus d'eux, que nous leur donnons des marques de compassion.	LA ROCHEFOUCAULD François de	Maximes.		221     vanité	1613/1680	berkeley	3817
Ce qui nous rend la vanité des autres insupportable, c'est qu'elle blesse la notre.	LA ROCHEFOUCAULD François de	Maximes.		221     vanité	1613/1680	berkeley	3818
L'envie est plus irréconciliable que la haine.	LA ROCHEFOUCAULD François de	Maximes		221     vanité	1613-1680.	berkeley	3822
Que la farce soit avec vous.	OECH Roger von	Créatif de choc.	1983	510     ironie		berkeley	4626
Si vous dites aux gens où aller, mais non comment y aller, vous serez surpris du résultat.	PATTON George S.			391     commandement		berkeley	4657
On sert la France démocratique en aidant le général de Gaulle à prendre dès à présent l'attitude d'un chef...	BLUM Léon	OEuvre de Léon Blum. Tome VII.	1942	546     éthique	"message de recommandation" à FDR, à la demande de Ch.de Gaulle.	berkeley	776
Ne cherchez pas la paix d'esprit, la richesse, la sécurité ou la force intérieure, à l'extérieur de vous-même. La présence divine est en vous.	MURPHY  Dr J.	Comment utiliser les pouvoirs du subconscient.		320     intuition		berkeley	4511
... C'est par la force de l'illusion que les hommes deviennent des héros.	ISTRATI Panaït	Pour avoir aimé la terre		215     mystifications	1884-1935.	berkeley	3399
Un idéaliste est un homme qui aide les autres à prospérer.	FORD Henri			331     altruisme		berkeley	2836
S'il y a des hommes dont le ridicule n'est jamais paru, c'est qu'on ne l'a jamais bien cherché.	LA ROCHEFOUCAULD François de	Maximes.		520     ironie de soi		berkeley	3910
Nous aurions souvent honte de nos plus belles actions si le monde voyait tous les motifs qui les produisent.	LA ROCHEFOUCAULD François de	Maximes.		520     ironie de soi	1613/1680	berkeley	3911
Malheur aux vaincus ! (vae victis)	TITE-LIVE	Histoire de Rome. V.48.		210     violence		berkeley	5201
J'aimais les voix du soir dans les airs répandues,  Le bruit lointain des chars gémissant sous leur poids,  Et le sourd tintement des cloches suspendues  Au cou des chevreaux dans les bois.	LAMARTINE Alphonse de	Nouvelles Méditations, les Préludes		423     solitude	1790-1869.	berkeley	4003
On admire le monde à travers ce qu'on aime.	LAMARTINE Alphonse de	Jocelyn		312     foi	1790-1869.	berkeley	3996
Je me défendrai mal: l'innocence étonnée  Ne peut s'imaginer qu'elle soit soupçonnée.	CORNEILLE Pierre	Rodogune, V, 4, Rodogune		510     ironie	1606-1684.	berkeley	1679
Qu'ils soient religieux ou politiques, les intégrismes sont en effet une antithèse de l'intelligence. Lorsqu'il s'agit de foi religieuse ou politique, donc de processus peu ou pas rationnels, ils sont conce- vables, sinon excusables. Mais l'intégrisme scientifique...	TAZIEFF Haroun	La Prévision des Séismes.	1989	120     grégarité	vulcanologue et libre-penseur.	berkeley	5191
Les pires haines sont fraternelles.	TAZIEFF Haroun	La Prévision des Séismes.	1989	430     paradoxal émotionnel	vulcanologue et libre-penseur.	berkeley	5192
Accoutume-toi à être intérieurement attentif aux paroles des autres, et entre le plus possible dans l'âme de celui qui te parle.	MARC AURELE	Pensées.		234     communication		berkeley	4216
Fouille en dedans. C'est en dedans qu'est la source du bien et elle peut jaillir sans cesse si tu fouilles toujours.	MARC AURELE	Pensées		423     solitude		berkeley	4217
Un seul bon argument vaut mieux que plusieurs arguments meilleurs.	BERNARD Tristan	Secrets d"Etats.		234     communication		berkeley	711
Il n'y a de paix qu'entre esprit et esprit.	CHARTIER Emile	Mars Ou La Guerre Jugée.		234     communication	alias Alain (1868-1951)	berkeley	1217
Quand une femme est fidèle, on l'admire; mais il y a des femmes modestes qui n'ont pas la vanité de vouloir être admirées.	MARIVAUX Pierre Carlet de Chamblain de	Arlequin poli par l"amour		365     discernement	1688-1763.	berkeley	4228
Les français aiment les primeurs... en conserve.	COCTEAU Jean			221     vanité	cité dans émission TV sur les Cubistes, 22/12/94.	berkeley	1494
La politique la plus coûteuse, la plus ruineuse, c'est d'être petit ...	DE GAULLE Charles			442     démission	1890-1970.   Allocution prononcée au Champ-d"Arbaud, à Basse-Terre, 20 mars 1964, Discours et messages. Pour l"effort (1962-1965) (Plon)	berkeley	1851
La tragédie du western est tout entière dans l'idée du paria donnant à ses détracteurs la seule réplique de justice connue des 'sans foi ni loi' de tous bords, la violence des pôles meurtris de solitude et de grégarité.	FAIRGAGNETR Oscar	Vitalités.	1995	515     tragédie		berkeley	2631
Matinées d'un brin d'ironie, nos faiblesses se font moins aigûes.	FAIRGAGNETR Oscar	Vitalités.	1994	520     ironie de soi		berkeley	2634
Fier à ce que je fais, certes, sans jamais pourtant trouver à l'être à ce que je suis.	FAIRGAGNETR Oscar	ans jamais p\\010Q0	1990	520     ironie de soi		berkeley	2635
Chaque fois que la flamme semble vaciller, je retrouve la mesure de ce que les hommes ont toujours payé pour la confiance volée à l'adversité.	FAIRGAGNETR Oscar	Vitalités	1992	520     ironie de soi		berkeley	2636
Un grand homme montre sa valeur dans la manière dont il traite les petites gens.	CARLYLE Thomas			550     grandeur		berkeley	1036
Nous voyons l'abeille se poser sur toutes les plantes et tirer de chacune le meilleur.	Isocrate	A Démonicos, 52		421     initiation	436-338 av. J.-C.	berkeley	3394
Le coeur est la source de toutes les erreurs dont nous avons besoin.	FONTENELLE Bernard le Bovier de	Dialogues des morts		520     ironie de soi	1657-1757.	berkeley	2832
Mettez-vous dans l'esprit que les femmes veulent qu'on les aime, mais en même temps qu'on les divertisse.	FONTENELLE Bernard le Bovier de	Lettres galantes du chevalier d"Her...		531     communication amoureuse	1657-1757.	berkeley	2833
L'art des conversations amoureuses est qu'elles ne soient pas toujours amoureuses.	FONTENELLE Bernard le Bovier de	Lettres galantes du chevalier d"Her...		531     communication amoureuse	1657-1757.	berkeley	2834
Laisse penser tes sens, homme, et tu es ton Dieu.	FORT Paul	Ballades françaises, La Vision harmonieuse de la terre		320     intuition	1872-1960.	berkeley	2837
Hélas! rien d'éternel sinon l'éternité.	FORT Paul	Ballades françaises, Vivre en Dieu		510     ironie	1872-1960.	berkeley	2838
L'amour est le seul rêve qui ne se rêve pas.	FORT Paul	Ballades françaises, Sur les jolis ponts de Paris		531     communication amoureuse	1872-1960.	berkeley	2839
Ah! Quelle plaisanterie. Pas besoin de gril : l'enfer, c'est les Autres.	SARTRE Jean-Paul	Huis-Clos	1944	442     démission		berkeley	4958
J'apprends tous les jours à écrire.	BUFFON Georges-Louis Leclerc de	Lettre		390     création	1707-1788.	berkeley	896
Ce grand esprit*, c'est un chaos d'idées claires.	FAGUET Emile	Etudes littéraires du dix-huitième siècle		393     création artistique	1847-1916.  *Voltaire.	berkeley	2448
N'avoir ni paradis ni enfer, c'est se retrouver intolérablement privé de tout.	STEINER George			510     ironie		berkeley	5143
Pour être à la mesure de tout ce qui est exigé de lui, un homme doit surestimer ses capacités.	GOETHE Johann Wolfgang von			440     courage		berkeley	2975
La vérité a plusieurs visages, le mensonge n'en a qu'un! 	SCHéHADé Georges	La Soirée des proverbes		510     ironie	1907-1989.	berkeley	4969
- Attaché? dit le loup; vous ne courez donc pas  Où vous voulez? 	LA FONTAINE Jean de	Fables, le Loup et le Chien		221     vanité	1621-1695.	berkeley	3672
Nos actions sont comme des bouts rimés, que chacun fait rapporter à ce qui lui plait.	LA ROCHEFOUCAULD François de	Maximes.		430     paradoxal émotionnel		berkeley	3873
Et je crois bien que l'essentiel de l'esprit religieux consiste à croire qu'il y a une espèce de liberté dans les choses.	CHARTIER Emile			510     ironie	alias ALAIN	berkeley	1274
Il ne faut pas regarder le gouffre, car il y a au fond un charme inexprimable qui nous attire.	FLAUBERT Gustave	L"amour de l"art.	1915	310     énergie	(1821/1880) édition posthume	berkeley	2725
On rappellera que le passage de la servitude à la liberté exige des efforts de titan. On ajoutera que l'apprentissage de la liberté est difficile et exigeant. Celui de la prospérité également.	LATTES Robert	Le Risque et la Fortune.	1990	130     liberté		berkeley	4042
L'écriture est la seule forme parfaite du temps.	LE CLéZIO Jean-Marie Gustave	L"Extase matérielle		545     épistémologie	1940-.	berkeley	4076
L'homme se vante sans cesse, et pour des minuties.	LAUTRéAMONT Comte de	Les Chants de Maldoror		221     vanité	1846-1870. (Isidore Ducasse)	berkeley	4046
Nous n'avouons de petits défauts que pour persuader que nous n'en avons pas de grands.	LA ROCHEFOUCAULD François de	Maximes.		221     vanité		berkeley	3797
Savoir que l'on peut tout faire et tout réussir à la seule et unique condition d'acquérir la maîtrise du temps propre à chacune de nos activités.	FAIRGAGNETR Oscar	Vitalités.	1993	421     initiation		berkeley	2570
Gouverner, c'est choisir.	LéVIS Duc de	Maximes politiques		391     commandement	1764-1830.	berkeley	4124
Un prince sage donne aux choses les noms qui leur conviennent, et chaque chose doit être traitée d'après la signification du nom qu'il lui donne.	CONFUCIUS	Entretiens, VII, 13		231     légitimité du pouvoir	551-479 av. J.-C. (Chinois)	berkeley	1594
Entendre ou lire sans réfléchir est une occupation vaine; réfléchir sans livre ni maître est dangereux.	CONFUCIUS	Entretiens, I, 2		370     esprit	551-479 av. J.-C. (Chinois)	berkeley	1596
L'ouvrier qui veut bien faire son travail doit commencer par aiguiser ses instruments.	CONFUCIUS	Entretiens, VIII, 15		380     travail	551-479 av. J.-C. (Chinois)	berkeley	1597
Appliquez-vous à garder en toute chose le juste milieu.	CONFUCIUS	Entretiens, X, 20		430     paradoxal émotionnel	551-479 av. J.-C. (Chinois)	berkeley	1599
La pluralité des voix n'est pas une preuve qui vaille rien, pour les vérités un peu malaisées à découvrir.	DESCARTES René	Discours de la méthode		365     discernement	1596-1650.	berkeley	1921
Prenez garde à la tristesse. C'est un vice.	FLAUBERT Gustave	Correspondance, 1842, à Guy de Maupassant, 1878		433     perversion	1821-1880.	berkeley	2763
Un homme n'est pas malheureux parce qu'il a de l'ambition, mais parce qu'il en est dévoré.	MONTESQUIEU Charles de	Mes pensées		221     vanité	1689-1755. (C. de Secondat, baron de La Brède et de M.)	berkeley	4413
Le souper tue la moitié de Paris, le dîner l'autre.	MONTESQUIEU Charles de	Mes pensées		221     vanité	1689-1755. (C. de Secondat, baron de La Brède et de M.)	berkeley	4414
Si on ne voulait être qu'heureux, cela serait bientôt fait. Mais on veut être plus heureux que les autres, et cela est presque toujours difficile parce que nous croyons les autres plus heureux qu'ils ne sont.	MONTESQUIEU Charles de	Mes pensées		221     vanité	1689-1755. (C. de Secondat, baron de La Brède et de M.)	berkeley	4415
Il faut beaucoup de naïveté pour faire de grandes choses.	CREVEL René	L"Esprit contre la Raison.		321     volonté	1900/1935	berkeley	1717
Le système GPS Navstar avait une précision à moins de cinq mêtres près.	CLANCY Tom	La somme de toutes les peurs. I.	1991	392     création économique		berkeley	1425
Il faut faire en sorte que tout soit aussi simple que possible, mais pas plus simple.	EINSTEIN Albert			365     discernement		berkeley	2283
L'amour, c'est beaucoup plus que l'amour.	CHARDONNE Jacques	L"Amour, c"est beaucoup plus que l"amour		531     communication amoureuse	1884-1968.	berkeley	1204
De l à ce cri du plus grand des médecins*: la vie est courte, longue est la science.  Inde illa maximi medicorum exclamatio est: vitam brevem esse, longam artem.	SéNEQUE	De la brièveté de la vie, 1 		110     entropie	4 av. J.-C.- 65 apr. J.-C. (Lucius Annaeus Seneca) *Hippocrate.	berkeley	5007
Une grande âme convient à une grande condition.  Magnam fortunam magnus animus decet.	Sénèque	De la clémence, I, 5		510     ironie		berkeley	5009
Force est (au tyran) d'éprouver toutes les peurs qu'il inspire.  Tantum enim necesse est timeat, quantum timeri voluit.	Sénèque	De la clémence, I, 19		221     vanité		berkeley	5010
A chaque femme correspond un séducteur. Son bonheur, ce n'est que de le rencontrer.	KIERKEGAARD Sören	In vino veritas.		530     ironie amoureuse	1813/1855. Danois.	berkeley	3546
Les seules ententes internationales possibles sont des ententes gastronomiques.	DAUDET Léon	Paris vécu		510     ironie	1867-1942.	berkeley	1768
Le hasard est plus docile qu'on ne pense. Il faut l'aimer. Et dès qu'on l'aime, il n'est plus hasard, ce gros chien imprévu dans le sommeil des jeux de quilles.	DAUMAL René	Lettres à ses amis		140     rapport à la cosmogonie	1908-1944.	berkeley	1769
Chaque fois que l'aube paraît, le mystère est l à tout entier.	DAUMAL René	Poésie noire et poésie blanche		312     foi	1908-1944.	berkeley	1772
Faute que personne proposât rien qui répondit à la situation [...], je me sentis tenu d'en appeler à l'opinion... Il me fallait m'attendre à ce qu'un jour se posent sur moi les projecteurs de la vie publique. C'est avec peine que j'en pris mon parti, après vingt-cinq ans passés sous les normes militaires.	DE GAULLE Charles	Mémoires de guerre.	1953	230     pouvoir		berkeley	1804
Se donner n'a de sens que si l'on se possède.	CAMUS Albert	Carnets		531     communication amoureuse	1913-1960.	berkeley	1026
Une femme heureuse te rendra plus que dix-mille séduites.	FAIRGAGNETR Oscar	Vitalités.	1995	531     communication amoureuse		berkeley	2469
Pour toi, quand tu jeûnes, parfume ta tête et lave ton visage.	Evangiles	Evangile selon saint Matthieu, VI, 17		441     sang-froid		berkeley	2438
Qu'as-tu à regarder la paille qui est dans l'oeil de ton frère? Et la poutre qui est dans ton oeil à toi, tu ne la remarques pas? 	Evangiles	Evangile selon saint Matthieu, VII, 3		520     ironie de soi		berkeley	2439
La médiocrité est un garde-fou.	MONTESQUIEU Charles de	Mes pensées		360     bon sens	1689-1755. (C. de Secondat, baron de La Brède et de M.)	berkeley	4430
L'intégration de l'individu [dans la 'Dictature libérale'] se fait dans un groupe minoritaire et ce groupe lui-même est intégré à la société démocratique par les liens qu'elle tisse avec tout ce qui prétend s'exclure d'elle.	RUFIN Jean-Christophe	La Dictature Libérale.		539     ironie sociale	Le secret de la toute-puissance des démocraties au 20e siècle	berkeley	4899
Il faut toujours avoir deux idées : l'une pour tuer l'autre.	BRAQUE Georges	Le Jour Et La Nuit.		441     sang-froid	1882/1963	berkeley	832
Plus vous trouverez de raison dans un homme plus vous trouverez en lui de probité.	DIDEROT Denis	Encyclopédie		365     discernement	1713-1784.	berkeley	2094
Amour, amour, quand tu nous tiens,  On peut bien dire: 'Adieu, prudence!' 	LA FONTAINE Jean de	Fables, le Lion amoureux		510     ironie	1621-1695.	berkeley	3746
Sur les ruines de la révolution communiste allemande nous avons construit pour la Russie soviétique un service de renseignement que le monde entier nous envie.	KRIVITSKI Walter		1939	214     guerre du savoir	agent de Staline	berkeley	3578
La mère, l'éternel, l'inépuisable amour, qui donne tout, qui pardonne tout.	NIN Anaïs	Journal.		420     capital affectif		berkeley	4599
Il faut être voyant.	RIMBAUD Arthur			320     intuition		berkeley	4822
Un défaut qui empêche les hommes d'agir, c'est de ne pas sentir ce dont ils sont capables.	BOSSUET Jacques Bénigne	Pensées chrétiennes.		320     intuition		berkeley	802
J'aime qu' à mes desseins la fortune s'oppose :  Car la peine de vaincre en accroît le plaisir.	BERTAUT Jean	Stances		221     vanité	1552-1611.	berkeley	731
Il faut s'efforcer de traiter toujours la bêtise avec compassion et la vanité avec cruauté.	FAIRGAGNETR Oscar	Vitalités.	1993	330     coeur		berkeley	2543
Qui s'est abaissé devant une fourmi, n'a plus à s'abaisser devant un lion.	MICHAUX Henri	Tranches de savoir		441     sang-froid	1899-1984.	berkeley	4280
Quand on doit diriger des enfants ou des hommes, il faut de temps en temps commettre une belle injustice, bien nette, bien criante : c'est ça qui leur en impose le plus !	PAGNOL Marcel	Topaze.		391     commandement		berkeley	4630
Un rêve intact est une merveille fragile.	ESTAUNIé Edouard	L"Infirme aux mains de lumière		350     imagination	1862-1942.	berkeley	2382
La sublimation des instincts constitue l'un des traits les plus  saillants du développement culturel ; c'est elle qui permet  aux activités psychiques élevées, scientifiques, artistiques ou idéolo- giques, de jouer un rôle si important dans la vie des êtres civilisés. [...] Ce 'renoncement culturel' régit le vaste domaine des rapports sociaux entre humains : et nous savons déj à qu'en lui réside la cause de l'hostilité contre laquelle toutes les civilisations ont à lutter.	FREUD Sigmund	Malaise dans la civilisation.	1929	390     création		berkeley	2890
Je veux qu'il n'y ait si pauvre paysan en mon royaume qu'il n'ait tous les dimanches sa poule au pot.  	HENRI IV			215     mystifications	1553-1610.   Déclaration attribuée à Henri IV par l"archevêque de Paris Hardouin de Péréfixe dans son Histoire du roy Henry le Grand (1681).	berkeley	3116
'Il n'y a pas d'issue - nous payons la violence de nos ancêtres'	HERBERT Franck	Dune	1965	420     capital affectif		berkeley	3139
Le sujet d'une belle tragédie doit n'être pas vraisemblable.	CORNEILLE Pierre	Héraclius, Au lecteur		539     ironie sociale	1606-1684.	berkeley	1688
L à où était du ça, doit advenir du moi.	FREUD Sigmund	Les Nouvelles conférences d"introduction à la psychanalyse.	1916	140     rapport à la cosmogonie		berkeley	2889
Quand l'homme qui témoigne est armé d'un sabre, c'est le sabre qu'il faut entendre et non l'homme.	FRANCE Anatole	Crainquebille		210     violence	1844-1924. (Anatole François Thibault)	berkeley	2853
Les beaux fragments ne sont rien ; l'unité, l'unité, tout est l à.	FLAUBERT Gustave	L"amour de l"art.	1915	390     création	(1821/1880) édition posthume	berkeley	2744
Il était de cette dignité qui produit l'étoffe d'un siècle.	FAIRGAGNETR Oscar	Sur De Gaulle.		546     éthique		berkeley	2645
... La pensée, oui, dans une belle chair.	FARGUE Léon-Paul	Sous la lampe		130     liberté	1876-1947.	berkeley	2653
La plus belle chose que nous puissions éprouver, c'est le mystère des choses.  Das Schönste, was wir erleben können, ist das Geheimnisvolle.	EINSTEIN Albert	Comment je vois le monde		140     rapport à la cosmogonie	1879-1955. (Allemand, naturalisé Américain)	berkeley	2292
Je ne crois point, au sens philosophique du terme, à la liberté de l'homme. Chacun agit non seulement sous une contrainte extérieure, mais aussi d'après une nécéssité intérieure.	EINSTEIN Albert	Comment je vois le Monde.		140     rapport à la cosmogonie		berkeley	2293
Heureux celui qui traverse la vie, secourable, en ignorant la peur, étranger à l'agressivité et au ressentiment.	EINSTEIN Albert	Comment je vois le Monde	1934	140     rapport à la cosmogonie	rééd.corr. en 1952 et 1978.	berkeley	2294
Sa stérilité était infinie. Elle participait de l'extase.	CIORAN Emile-Michel	Le mauvais Démiurge	1969	430     paradoxal émotionnel	1911-.	berkeley	1389
L'histoire des idées est l'histoire de la rancune des solitaires.	CIORAN Emile-Michel	Syllogismes De L"amertume.		430     paradoxal émotionnel	1911-.	berkeley	1390
Un coeur noble est content de ce qu'il trouve en lui, Et ne s'appauvrit point des qualités d'autrui.	BOILEAU Nicolas	Epîtres.		330     coeur		berkeley	781
Ce qui se conçoit bien s'énonce clairement et les mots pour le dire arrivent aisément.	BOILEAU Nicolas			370     esprit		berkeley	782
Le pauvre examine le manteau de saint Martin et dit : 'Pas de poches ?'	JACOB Max	Le Cornet à dés.		233     spéculation	1876/1944	berkeley	3404
C'est le rôle essentiel du professeur d'éveiller la joie de travailler et de connaitre. ( ) Songer que toutes les merveilles, objets de vos études, expriment l'oeuvre de plusieurs générations, une oeuvre collective exigeant de tous un effort enthousiaste et une peine certaine. Tout cel à, dans vos mains devient un héritage. ( ) Nous sommes ainsi des mortels immortels parceque nous créons ensemble des oeuvres qui nous survivent.	EINSTEIN Albert	Comment je vois le Monde	1934	550     grandeur	rééd.corr. en 1952 et 1978.	berkeley	2324
Le soleil ni la mort ne se peuvent regarder fixement.	LA ROCHEFOUCAULD François de	Maximes		441     sang-froid	1613-1680.	berkeley	3892
Dans le canton, les gens disent que Jeppe boit, mais personne ne dit pourquoi Jeppe boit.	HOLBERG Ludvig	Jeppe du Mont, I, 3		539     ironie sociale	1684-1754. (Danois)	berkeley	3207
Pour vivre heureux vivons caché.	FLORIAN Jean-Pierre Claris de	Fables, le Grillon		441     sang-froid	1755-1794.	berkeley	2806
Imbéciles: Ceux qui ne pensent pas comme nous.	FLAUBERT Gustave	Dictionnaire des idées reçues		221     vanité	1821-1880.	berkeley	2719
Ce qui est commencé est à moitié fait.	HORACE	Art poétique.	1992	380     travail		berkeley	3230
Les plus grands tyrans du peuple sont presque toujours sortis du peuple.	DUHAMEL Georges	Le Combat contre les ombres		539     ironie sociale	1884-1966.	berkeley	2218
Hélas! on voit que de tout temps  Les petits ont pâti des sottises des grands.	LA FONTAINE Jean de	Fables, les Deux Taureaux et une Grenouille		221     vanité	1621-1695.	berkeley	3669
Aime l'autre qui engendre en toi une troisième personne, l'esprit.	SERRES Michel			341     étonnement		berkeley	5039
Gémir sur un malheur passé, c'est le plus sûr moyen d'en attirer un autre.	SHAKESPEARE William	Othello.		440     courage		berkeley	5057
Etre ou ne pas être, telle est la question.	SHAKESPEARE William	HAMLET	1602	440     courage	440     cour\\010R? à\\010RB@	berkeley	5058
La nécéssité est la meilleure des vertus.	SHAKESPEARE William	La vie et la mort du roi Richard II.		441     sang-froid		berkeley	5059
Pesez serment contre serment, et vous pèserez le néant.	SHAKESPEARE William	Le songe d"une nuit d"été.		510     ironie		berkeley	5061
Tous les lâches sont romanesques et romantiques, ils s'inventent des vies à reculons, pleines d'éclats, Campéador d'escaliers! 	CéLINE L.-F.	Féerie pour une autre fois		433     perversion	1894-1961. (Louis-Ferdinand Destouches)	berkeley	1073
On perd la plus grande partie de sa jeunesse à coups de maladresses.	CéLINE L.-F.	Voyage au bout de la nuit		442     démission	1894-1961. (Louis-Ferdinand Destouches)	berkeley	1077
Je ne connais qu'un seul devoir, et c'est celui d'aimer.	CAMUS Albert	Carnets		330     coeur	1913-1960.	berkeley	997
Il n'est pas élégant d'abuser de la malchance; certains individus, comme certains peuples, s'y complaisent tant qu'ils déshonorent la tragédie.	CIORAN Emile-Michel	Syllogismes de l"amertume		442     démission	1911-.	berkeley	1395
Celui qui dans la vie est parti de zéro pour n'arriver à rien dans l'existance n'a de merci à dire à personne.	DAC Pierre			510     ironie	André ISAAC dit Pierre Dac	berkeley	1741
Quarante années durant, j'ai vu. Aujourd'hui, je regarde.	DANINOS Pierre	Les Carnets du major W. Marmaduke Thompson		421     initiation	1913-.	berkeley	1745
Il est plus facile à l'imagination de se composer un enfer avec la douleur qu'un paradis avec le plaisir.	RIVAROL Antoine de	Discours sur l"homme intellectuel et moral		433     perversion	1753-1801. (Antoine Rivarol)	berkeley	4831
La raison se compose de vérités qu'il faut dire et de vérités qu'il faut taire.	RIVAROL Antoine de	Fragments et pensées politiques.		441     sang-froid	(Comte de)	berkeley	4832
Le monde entier joue la comédie.	PETRONE			221     vanité		berkeley	4694
L'homme le plus inquiet d'une prison est le directeur.	SHAW G.-B.	Maximes pour Révolutionnaires.		232     servitudes du pouvoir		berkeley	5072
Penses-tu que ce soit l à une petite chose que savoir-vivre ? Non seulement une grande, mais la plus grande.	St.BERNARD de CLAIRVAUX	Patrologie latine.		140     rapport à la cosmogonie		berkeley	5116
La démission et la violence sont dans notre nature, le courage et l'amour dans notre foi.	FAIRGAGNETR Oscar	Vitalités.	1994	140     rapport à la cosmogonie	 à la fin de la projection de "La belle histoire" de Claude Lelouch	berkeley	2494
L'espérance est un emprunt fait au bonheur.	JOUBERT Joseph	Pensées.		321     volonté		berkeley	3457
Je sais que vérité vaut infortune ; Je n'y puis pourtant renoncer.	K"UI YUAN			440     courage		berkeley	3511
Quand une fois on a accueilli le Mal chez soi, il ne demande plus qu'on lui fasse confiance.	KAFKA Franz	Journal intime.		222     fourberie		berkeley	3512
Au-dela d'un certain point, on ne peut plus revenir en arrière. C'est ce point qu'il faut atteindre.	KAFKA Franz			421     initiation		berkeley	3513
Le bonheur date de l'antiquité, mais il est encore tout neuf car il a peu servi.	KAFKA Franz			510     ironie		berkeley	3514
Un coeur miséricordieux et compatissant est le principe de l'humanité; le sentiment de la honte et de l'aversion est le principe de l'équité et de la justice; le sentiment d'abnégation et de déférence est le principe des usages sociaux; le sentiment du vrai et du faux ou du juste et de l'injuste est le principe de la sagesse.	CONFUCIUS	Doctrine ; Meng-tseu.		550     grandeur		berkeley	1610
Celui qui gouverne un peuple en lui donnant de bons exemples est comme l'étoile polaire, qui demeure immobile pendant que toutes les autres se meuvent autour d'elle.	CONFUCIUS	Entretiens, I, 2		550     grandeur	551-479 av. J.-C. (Chinois)	berkeley	1611
Il est bon d'étonner, mais ... il faut étonner justement.	CAILLOIS Roger	Art poétique		234     communication	1913-1978.	berkeley	958
On ne peut empêcher les gens de parler, et c'est ainsi que s'écrit l'histoire.	NERVAL Gérard de	Lettre, à son père, 12 juin 1854		540     mémoire	1808-1855. (Gérard Labrunie)	berkeley	4580
Aimez qui vous résiste et croyez qui vous blâme.	DELAVIGNE Casimir	Louis XI		421     initiation	1793-1843.	berkeley	1887
En amour, il n'y a que les commencements qui soient charmants. Il ne m'étonne pas qu'on trouve du plaisir à recommencer souvent.	LIGNE Prince de	Mes écarts		530     ironie amoureuse	1735-1814.	berkeley	4138
Vous pouvez tromper tout le monde un certain temps ; vous pouvez même tromper quelques personnes tout le temps ; mais vous ne pouvez tromper tout le monde tout le temps.	LINCOLN Abraham			222     fourberie	 à un visiteur à la Maison-Blanche.	berkeley	4139
Ce que je veux savoir avant tout, ce n'est pas si vous avez échoué, mais si vous avez su accepter votre échec.	LINCOLN Abraham			440     courage	1809/1865	berkeley	4141
Il ne faut pas toucher aux idoles: la dorure en reste aux mains.	FLAUBERT Gustave	Madame Bovary		215     mystifications	1821-1880.	berkeley	2714
Que chacun s'exerce dans l'art qu'il connaît.  Quam quisque norit artem, in hac se exerceat.	Cicéron	Tusculanes, I, 18.		360     bon sens	106-43 av. J.-C. (Marcus Tullius Cicero). Cicéron cite ce précepte comme un proverbe grec.	berkeley	1379
Ce qui vient après la mort est futile.	CAMUS Albert	Le Mythe de Sisyphe		510     ironie	1913-1960.	berkeley	1020
Les esprits généreux jugent tout par eux-mêmes.	CORNEILLE Pierre	Théodore, IV, 1, Placide		440     courage	1606-1684.	berkeley	1667
Une goutte d'eau assidue, à force de tomber, creuse dans le roc même une crevasse.	Bion de Phlossa	Bucoliques, Fragments I		321     volonté	IIIe s. av. J.-C.	berkeley	754
Il n'est, pour voir, que l'oeil du maître.	LA FONTAINE Jean de	Fables, l"Oeil du maître		239     servitudes du pouvoir autoritaire	1621-1695.	berkeley	3687
Savoir par coeur n'est pas savoir: c'est tenir ce qu'on a donné en garde à sa mémoire.	MONTAIGNE Michel Eyquem de	Essais, I, 26		365     discernement	1533-1592.	berkeley	4340
Quand ma volonté me donne à un parti, ce n'est pas d'une si violente obligation que mon entendement s'en infecte.	MONTAIGNE Michel Eyquem de	Essais, III, 10		365     discernement	1533-1592.	berkeley	4341
L'importance sans mérite obtient des égards sans estime.	CHAMFORT Nicolas-Sébastien de	Maximes et pensées		441     sang-froid	1740/1794. Ac. Française	berkeley	1130
La vraie, la seule histoire d'une personne humaine, c'est l'émergence graduelle de son vïu secret à travers sa vie publique.	MASSIGNON Louis	Un voeu et un destin : Marie-Antoinette, Reine de France.		321     volonté	Un voeu et un destin : Marie-Antoinette, Reine de France.	berkeley	4244
Dieu sait et vous ne savez pas.	Coran	Coran, II, 213		215     mystifications		berkeley	1639
Nous mettons tant de beauté en nous-mêmes et tout autour de nous, qu'il n'y aura plus de place pour le malheur et la tristesse, et s'ils veulent entrer malgré tout, il faudra bien qu'ils deviennent doux, avant d'oser frapper à notre porte.	MAETERLINCK Maurice	Aglavaine et Sélysette.		390     création		berkeley	4165
Que m'importe ce qui n'importe qu' à moi? 	MALRAUX André	Antimémoires		520     ironie de soi	1901-1976.	berkeley	4209
Etre jeune, c'est être spontané, rester proche des sources de la vie, pouvoir se dresser et secouer les chaînes d'une civilisation périmée, oser ce que d'autres n'ont pas eu le courage d'entreprendre ; en somme, se replonger dans l'élémentaire.	MANN Thomas	Le docteur Faustus.		130     liberté		berkeley	4210
C'est le meilleur de ne rien désirer et ne rien refuser.	SALES Saint de	Entretiens spirituels		140     rapport à la cosmogonie	1567-1622.	berkeley	4945
Si on me presse de dire pourquoi je l'aimais*, je sens que cela ne peut s'exprimer qu'en répondant: 'Parce que c'était lui, parce que c'était moi.' 	MONTAIGNE Michel Eyquem de	Essais, I, 28 		234     communication	1533-1592.  *Montaigne parle de son amitié avec La Boétie.	berkeley	4331
Un fait courageux ne doit pas conclure* un homme vaillant.	MONTAIGNE Michel Eyquem de	Essais, II, 1 		310     énergie	1533-1592.  *Définir.	berkeley	4334
Rien n'est moins pardonnable que l'esprit qui n'émeut point.	FAIRGAGNETR Oscar	Vitalités.	1993	234     communication		berkeley	2517
L'optimiste proclame que nous vivons dans le meilleur de tous les mondes possibles, et le pessimiste craint que ce ne soit vrai.  The optimist proclaims that we live in the best of all possible worlds, and the pessimist fears this is true.	CABELL James Branch	The Silver Stallion, XXVI		510     ironie	1879-1958. (Américain)	berkeley	950
A chacun suivant ses besoins. De chacun suivant ses forces.	CABET Etienne	Voyage en Icarie		215     mystifications	1788-1856.	berkeley	952
Il suffit de bien juger pour bien faire, et de juger le mieux qu'on puisse pour faire aussi tout son mieux.	DESCARTES René	Discours de la méthode		365     discernement	1596-1650.	berkeley	1924
Tout bonheur est un chef-d'oeuvre: la moindre erreur le fausse, la moindre hésitation l'altère, la moindre lourdeur le dépare, la moindre sottise l'abêtit.	YOURCENAR Marguerite	Mémoires d"Hadrien		140     rapport à la cosmogonie	1903-1987. (Marguerite de Crayencour)	berkeley	5506
Nous nous croyons purs tant que nous méprisons ce que nous ne désirons pas.	YOURCENAR Marguerite	Alexis ou le Traité du vain combat		221     vanité	1903-1987. (Marguerite de Crayencour)	berkeley	5507
Quand nous sommes las d'aimer, nous sommes bien aises qu'on nous devienne infidèle, pour nous dégager de notre infidélité.	LA ROCHEFOUCAULD François de	Maximes.		530     ironie amoureuse		berkeley	3918
La lecture est un bonheur qui demande plus d'innocence et de liberté que de considération.	BLANCHOT Maurice	Le Livre à venir		312     foi	1907-.	berkeley	765
C'est une force que n'admirer rien.	LéAUTAUD Paul	Journal littéraire		441     sang-froid	1872-1956.	berkeley	4080
En art, il faut croire avant d'y aller voir.	FARGUE Léon-Paul	Sous la lampe		393     création artistique	1876-1947.	berkeley	2662
Une seule chose est nécéssaire : la solitude. La grande solitude intérieure. Aller en soi-même et ne rencontrer pendant des heures personne, c'est à cela qu'il faut parvenir. Etre seul comme l'enfant est seul.	RILKE Rainer Maria	Lettres à un jeune poète.		423     solitude		berkeley	4820
Un Français est profond dans la mesure où, à son rang, il sait maintenir ce dialogue* vivant en lui.	DU BOS Charles	Approximations  		370     esprit	1882-1939. * Entre Pascal et Montaigne.	berkeley	2165
Je pense donc je suis.	DESCARTES René	Discours de la méthode pour bien conduire sa raison	1637	341     étonnement	(1596/1650)	berkeley	1916
Si tu ne trouves pas Dieu en toi, laisse-le où il se trouve.	BOUSQUET Joë	Langage Entier.		330     coeur		berkeley	823
Souffrir n'est rien, tant que l'on continue à écraser ses frustrations dans et par la création. C'est le prix de la beauté de l'existence. Mais méfiez-vous des frustrés qui, renonçant pour eux-mêmes, s'abandonnent à l'entropie. Evitez-les absolument. Leur perversion, toute en ressentiment, sera trop essentiellement venimeuse, à l'endroit de ceux qui commettront l'erreur de leur accorder plus de considération qu'ils n'en méritent.	FAIRGAGNETR Oscar	Vitalités.	1992	433     perversion		berkeley	2589
Pourquoi fallut-il que Balzac ne s'occupe si entièrement que des lois de la petitesse.	FAIRGAGNETR Oscar	Vitalités.	1993	433     perversion		berkeley	2590
La langueur est un pneu crevé.	FAIRGAGNETR Oscar	Vitalités.	1992	433     perversion		berkeley	2592
L'égoïsme et la haine ont seuls une patrie;  La fraternité n'en a pas! 	LAMARTINE Alphonse de	Poésies diverses, la Marseillaise de la paix		120     grégarité	1790-1869.	berkeley	3990
Mourir pour une cause ne fait pas que cette cause soit juste.	MONTHERLANT Henry Millon de	Les Lépreuses		510     ironie	1896-1973.	berkeley	4487
La confiance fournit plus à la conversation que l'esprit.	LA ROCHEFOUCAULD François de	Maximes.		234     communication	1613/1680	berkeley	3835
Un désespoir calme et serein.	FAIRGAGNETR Oscar	Vitalités.	1992	550     grandeur		berkeley	2648
On ne se sert pas de l'amour ; on le sert.	Dictons et proverbes	aphorisme.		140     rapport à la cosmogonie		berkeley	2060
On ne peut à la fois être soumis à ses propres désirs et libre, être maitre et serviteur.	Dictons et proverbes	Dicton.		230     pouvoir		berkeley	2061
Le fantastique suppose la solidité du monde réel, mais pour mieux la ravager.	CAILLOIS Roger	Images, images...		433     perversion	1913-1978.	berkeley	964
La double solitude où sont tous les amants.	NOAILLES Comtesse Anna de	Les Vivants et les Morts.		530     ironie amoureuse		berkeley	4601
Il n'y a que deux choses qui servent au bonheur : c'est de croire et d'aimer.	NODIER Charles	La Fée aux miettes.		330     coeur		berkeley	4602
Le ciel est aux vaillants qui livrent la bataille.	NOEL Marie	Les Chansons Et Les Heures.		140     rapport à la cosmogonie		berkeley	4603
Satan se déguise bien en ange de lumière. Ce n'est donc pas merveille si ses ministres se déguisent en ministres de justice.	Nouveau Testament	Nouveau Testament, II Corinthiens, XI, 14.		222     fourberie		berkeley	4605
Tout ce que vous demanderez dans la prière, croyez fermement que vous l'avez obtenu, et cela vous sera accordé.	Nouveau Testament	Marc,XI,24		321     volonté		berkeley	4606
La Beauté est Vérité, la Vérité Beauté.  C'est tout ce que l'on sait sur terre,  Et c'est tout ce qu'il faut savoir.  Beauty is Truth, Truth Beauty.  That is all ye know on earth  And all ye need to know.	KEATS John	Ode sur une urne grecque		546     éthique	1795-1821. (Anglais)	berkeley	3542
Que m'importent les tulipes et les roses, puisque par la pitié du Ciel, j'ai, pour moi seul, tout le jardin.	HAFIZ	Les Ghazels.		130     liberté		berkeley	3077
Les mots d'amour ne sont point de ceux que l'on peut prononcer.	HAFIZ Chams al-Din Muhammad			531     communication amoureuse	v. 1320-v.. 1389. Persan.	berkeley	3079
Il est bon d'apprendre, même de son ennemi. (Fas est et ab hoste doceri)	OVIDE	Les Métamorphoses. IV.		421     initiation		berkeley	4629
Les principes sont faits pour être violés. Etre humain est aussi un devoir.	GREENE Graham	Le troisième homme.		140     rapport à la cosmogonie		berkeley	3009
Sous le charme du parfum, mais sans s'en rendre compte, les gens changeaient de physionomie, d'attitude, de sentiments. [...] Il constata qu'au fond, il pouvait raconter aux gens ce qu'il voulait. Une fois qu'ils étaient en confiance - et ils l'étaient dès la première bouffée qu'ils respiraient de son odeur artificielle -, ils gobaient tout.	SUSKIND Patrick	Le Parfum.		215     mystifications		berkeley	5174
Et quand bien même son parfum le ferait apparaitre comme un dieu aux yeux du monde, s'il ne pouvait se sentir lui-même et si donc jamais il ne savait qui il était, alors il s'en fichait : il se fichait du monde, de lui-même, de son parfum.	SUSKIND Patrick	Le Parfum.		440     courage		berkeley	5179
Lorsqu'un homme politique dit oui il pense peut-être. S'il dit peut-être il pense non. S'il lui prenait l'envie de dire non il ne serait plus politicien. Une démarche que l'on rencontre chez les femmes. Lorsqu'elles te disent non elles pensent peut-être, lorsqu'elles disent peut-être elles pensent oui. Si elles disent oui ce sont de belles p...	PIQUET Nelson		1991	234     communication	triple champion du monde de F1	berkeley	4709
Vouloir ne s'apprend pas.	PLATON	Ménon.		321     volonté		berkeley	4714
Mais que suis-je réellement si ma faculté de penser ignore le langage ? Sans doute, je suis un animal supérieur mais sans la parole la condition humaine se découvre pitoyable.	EINSTEIN Albert	Comment je vois le Monde	1934	545     épistémologie	rééd.corr. en 1952 et 1978.	berkeley	2320
Vivez si m'en croyez N'attendez à demain Cueillez dès aujourd'hui Les roses de la vie.	RONSARD			140     rapport à la cosmogonie		berkeley	4849
Heureux les persécutés pour la justice,  car le Royaume des Cieux est à eux.	Evangiles	Evangile selon saint Matthieu, V, 10		215     mystifications		berkeley	2414
Nous autres dans la Jungle savons que l'Homme est le plus intelligent des êtres. Mais si nous devions nous fier à nos seules oreilles, nous devrions le juger le plus sot.	KIPLING Rudyard	Le second livre de la jungle.	1894	510     ironie		berkeley	3567
De tout ce qui fut nous, presque rien n'est vivant.	HUGO Victor	Les Rayons et les Ombres		520     ironie de soi	1802-1885.	berkeley	3339
(...) garde toujours l'esprit bien ouvert pour que la lumière puisse y entrer et aussi ton coeur pour que l'amour ne reste pas devant la porte.	WEST Morris	Les bouffons de Dieu.	1981	140     rapport à la cosmogonie		berkeley	5356
Dans une conjoncture révolutionnaire, il est impossible de négocier, on ne peut que faire des paris.	WEST Morris	Les bouffons de Dieu.	1981	211     guerre		berkeley	5359
O rage! ô désespoir! ô vieillesse ennemie! 	CORNEILLE Pierre	Le Cid, I, 4, Don Diègue		520     ironie de soi	1606-1684.	berkeley	1684
Il y a trois sortes de critiques: ceux qui ont de l'importance; ceux qui en ont moins; ceux qui n'en ont pas du tout. Les deux dernières sortes n'existent pas: tous les critiques ont de l'importance.	SATIE Erik	Eloge des critiques		221     vanité	1866-1925.	berkeley	4960
Le style n'est que l'ordre et le mouvement qu'on met dans ses pensées.	BUFFON Georges-Louis Leclerc de	Discours sur le style		370     esprit	1707-1788.	berkeley	892
Une science subtile de l'égarement illuminera les plus humbles choses.	DHOTEL André	Rhétorique fabuleuse		433     perversion	1900-1991.	berkeley	1976
Le bien public requiert qu'on trahisse et qu'on mente et qu'on massacre.	MONTAIGNE Michel Eyquem de	Essais, III, 1		215     mystifications	1533-1592.	berkeley	4320
Une femme se réclame d'autant de pays natals qu'elle a eu d'amours heureux.	COLETTE Sidonie Gabrielle	La Naissance du jour		420     capital affectif	1873-1954.	berkeley	1548
Un oeil pur et un regard fixe voient toutes choses devant eux devenir transparentes.	CLAUDEL Paul	La Ville		320     intuition	1868-1955.	berkeley	1439
Quoi que fasse mon maître, il a toujours raison.	DELAVIGNE Casimir	Louis XI		421     initiation	1793-1843.	berkeley	1886
Vivre, c'est discerner les excitations2 agréables et les provoquer [...].	FENEON Felix	Oeuvres.		390     création		berkeley	2701
Par le mal qu'ils ont fait les hommes sont vaincus.	HUGO Victor	La Fin de Satan		110     entropie	1802-1885.	berkeley	3273
Tout homme reçoit deux sortes d'éducations : l'une qui lui est donnée par les autres, et l'autre, beaucoup plus importante, qu'il se donne à lui-même.	GIBBON Edward			421     initiation		berkeley	2926
Une trop grande liberté met la jeunesse dans l'impossibilité de désobéir, alors que rien d'audacieux n'existe sans la désobéissance à des règles.	COCTEAU Jean	Poésie critique		130     liberté	1889-1963.	berkeley	1491
Si l'on ne brûlait pas Jeanne d'Arc, elle ne serait pas une héroïne et on ne pourrait pas faire des films avec.	COCTEAU Jean	Lettre Aux Américains.		215     mystifications		berkeley	1492
La sombre Jalousie, au teint pâle et livide, Suit d'un pied chancelant le Soupçon qui la guide.	VOLTAIRE	La Henriade.		530     ironie amoureuse		berkeley	5335
L'homme est astucieux, sa sagesse est-elle à la mesure de son habileté ? Est-il raisonnable de vouloir provoquer une rupture brutale de l'évolution naturelle ? Sommes-nous conscients de ce que, pour une grande part, les mutations que nous suscitons sont irréversibles ? Modifier les informations génétiques fondamentales des êtres vivants - informations qui deviendront des caractères acquis dont ils hériteront de génération en génération -, n'est-ce pas la forme ultime, le paroxysme de la pollution ?	GOLDSMITH Jimmy	Le Piège.	1993	433     perversion		berkeley	2993
Le roman est la manière dont cette société se parle, la manière dont l'individu doit se vivre pour y être accepté. (...) Le roman, avec le mutisme de la science, est la valeur de notre époque, autrement dit son code de référence instinctif, l'exercice de son pouvoir, la clé de son inconscience quotidienne, mécanique, fermée.	SOLLERS Philippe	Le roman et l"expérience des limites	1965	215     mystifications		berkeley	5095
Rien n'est peut-être plus égoïste que le pardon.	CHAMSON André	On ne voit pas les coeurs		441     sang-froid	1900-1983.	berkeley	1155
La campagne était finie et les princes qui avaient suivi l'empereur à la guerre rentraient chez eux, avec le butin.	COMBESCOT Pierre	Les Chevaliers du crépuscule.		120     grégarité		berkeley	1575
Le surréalisme a mis les pieds dans le plat de l'opportunisme contemporain, lequel plat n'était, d'ailleurs, comme chacun sait, qu'une vulgaire assiette au beurre.	CREVEL René	Le Clavecin De Diderot.		120     grégarité		berkeley	1715
Le passant qui vous arrête et qui vous demande du feu, laissez-le seulement parler: au bout de dix minutes, il vous demandera Dieu.	DUHAMEL Georges	Défense des lettres		223     cupidité	1884-1966.	berkeley	2204
C'est comme un second être en moiLe bonheur de t'aimer.	HIKMET Nazim	Voix.		531     communication amoureuse		berkeley	3194
La résignation allège tous les maux sans remède.  Levius fit patientia  Quidquid corrigere est nefas.	Horace	Odes, I, XXIV, 19		442     démission	65-8 av. J.-C. (Quintus Horatius Flaccus)	berkeley	3259
A Paris, la décence est aussi grande dans les usages que l'indécence l'est dans les moeurs.	BROSSES Président de	Voyage en Italie		120     grégarité	1709-1777.	berkeley	871
La tristesse: un appétit qu'aucun malheur ne rassasie.	CIORAN Emile-Michel	Syllogismes de l"amertume		442     démission	1911-.	berkeley	1394
Il ne suffit pas de parler, il faut parler juste.	SHAKESPEARE William	Le songe d"une nuit d"été.		370     esprit		berkeley	5051
Le patriotisme est l'ultime refuge de la canaille.	JOHNSON Samuel			120     grégarité	cité dans "Les Sentiers de la Gloire" de Stanley Kubrick (1957)	berkeley	3445
Le patriotisme est l'ultime refuge d'un gredin.  Patriotism is the last refuge of a scoundrel.	JOHNSON Samuel	Cité dans The Life of S. Johnson par J. Boswell		215     mystifications	1709-1784. (Anglais)	berkeley	3446
Celui qui peut, agit. Celui qui ne peut pas, enseigne.  He who can, does. He who cannot, teaches.	SHAW George Bernard	Maxims for Revolutionists		510     ironie	1856-1950. (Irlandais)	berkeley	5074
J'ai tenté toute ma vie de peindre comme un enfant de cinq ans.	MIRO Joan			140     rapport à la cosmogonie		berkeley	4289
Extirper: Ce verbe ne s'emploie que pour les hérésies et les cors aux pieds.	FLAUBERT Gustave	Dictionnaire des idées reçues		510     ironie	1821-1880.	berkeley	2774
Je ne cherche pas à comprendre pour croire, mais je crois pour comprendre.	St ANSELME DE CANTORBéRY	Proslogion.		320     intuition		berkeley	5107
L'opinion française ... sait gré de l'hypocrisie comme d'une politesse qu'on lui rend.	CONSTANT Benjamin	Cécile		221     vanité	1767-1830. (Henri-B. de Rebecque)	berkeley	1621
Le changement de modes est l'impôt que l'industrie du pauvre met sur la vanité du riche.	CHAMFORT Nicolas-Sébastien de	Maximes et pensées		120     grégarité	1740/1794. Ac. Française	berkeley	1106
La gloire des grands hommes tient pour un quart à leur audace, pour deux quarts au hasard, pour le dernier quart à leurs crimes.  La fama degli eroi spetta un quarto alla loro audacia; due quarti alla sorte; e l'altro quarto a' loro delitti.	FOSCOLO Ugo	Ultime Lettere di Jacopo Ortis, 4 décembre 1798		510     ironie	1778-1827. (Italien)	berkeley	2842
Vivez, si m'en croyez, n'attendez à demain.  Cueillez dès aujourd'hui les roses de la vie.	RONSARD Pierre de	Sonnets pour Hélène		140     rapport à la cosmogonie	1524-1585.	berkeley	4850
Le poète doit être un professeur d'espérance.	GIONO Jean	L"Eau Vive.		393     création artistique		berkeley	2953
Il faut se piquer d'être raisonnable, mais non d'avoir raison.	JOUBERT Joseph	Pensés.		550     grandeur		berkeley	3471
Il faut se piquer d'être raisonnable et non point d'avoir raison.	JOUBERT Joseph			560     sagesse		berkeley	3473
L'instant n'a de place qu'étroite entre l'espoir et le regret et c'est la place de la vie.	JOUHANDEAU Marcel	Algèbre des valeurs morales.		140     rapport à la cosmogonie		berkeley	3474
On a toujours plus de religion qu'on ne croit.	JOUHANDEAU Marcel	La Jeunesse de Théophile		221     vanité	1888-1979.	berkeley	3475
Tout bon livre est un attentat.	JOUHANDEAU Marcel	Essai sur moi-même		393     création artistique	1888-1979.	berkeley	3476
Procureur un jour, procureur toujours. On ne quitte jamais la toge.	CLANCY Tom	La somme de toutes les peurs. II.	1991	221     vanité		berkeley	1409
Trop de gens pensaient encore que les hommes sont des numéros, des machines qu'il faut réparer, des instruments à qui on donne des ordres, trop de gens évaluaient leurs hommes avec des chiffres, beaucoup plus faciles à comprendre que leur comportement réel.	CLANCY Tom	La somme de toutes les peurs. II.	1991	225     cynisme	225     cyni\\010xDP\\010xR&#240;	berkeley	1410
Nous devons attendre le moment opportun, la politique est l'art du possible. Une seule chose à la fois, [...] tu le sais aussi bien que moi.	CLANCY Tom	La somme de toutes les peurs. I.	1991	232     servitudes du pouvoir		berkeley	1411
Marcus n'est pas mauvais homme, mais il est paresseux. Ce qu'il aime, c'est sa fonction, pas les devoirs de sa fonction.	CLANCY Tom	La somme de toutes les peurs. II.	1991	232     servitudes du pouvoir		berkeley	1412
Les démarches diplomatiques les plus efficaces sont souvent celles qui débutent de façon informelle.	CLANCY Tom	La somme de toutes les peurs. I.	1991	234     communication		berkeley	1413
Quiconque a bouche ne dit à un autre qu'il souffle sur son potage.	Dictons et Proverbes	Diction.		370     esprit		berkeley	2014
L'originalité est souvent un bloc de préjugés.	CHARDONNE Jacques	Propos comme ça		221     vanité	1884-1968.	berkeley	1191
En tant que praticien de la vocation de me situer comme le responsable de mes actes, je suis, indubitablement, un progressiste à demain en meme temps qu'un conservateur à aujoud'hui.	FAIRGAGNETR Oscar	Vitalités	2003	440     courage	\N	BERKELEY	5617
Cel à te rappelle que les mots sont importants. Et ta parole, c'est ce qui compte le plus. Ta parole, c'est toi. C'est la dernière leçon que je te donne, il faudra continuer tout seul.	CLANCY Tom	Danger Immédiat	1989	550     grandeur		berkeley	1434
Il y a un pacte vingt fois séculaire entre la grandeur de la France et la liberté du monde.	DE GAULLE Charles			215     mystifications	1890-1970.   Discours prononcé à la "Réunion des Français de Grande-Bretagne", au Kingsway Hall, à Londres, 1er mars 1941. Discours et messages. Pendant la guerre (1940-1946) (Plon)	berkeley	1799
Je ne crois pas, ô Christ, à ta parole sainte:  Je suis venu trop tard dans un siècle trop vieux.  D'un siècle sans espoir naît un siècle sans crainte.	MUSSET Alfred de	Poésies, Rolla		215     mystifications	1810-1857.	berkeley	4519
Pour faire la paix, il faut être deux: soi-même et le voisin d'en face.	BRIAND Aristide	Paroles de paix		234     communication	1862-1932.	berkeley	859
Dors-tu content, Voltaire, et ton hideux sourire  Voltige-t-il encor sur tes os décharnés? 	MUSSET Alfred de	Poésies, Rolla		221     vanité	1810-1857.	berkeley	4523
Je hais comme la mort l'état de plagiaire;  Mon verre n'est pas grand, mais je bois dans mon verre.	MUSSET Alfred de	Premières Poésies, la Coupe et les lèvres		222     fourberie	1810-1857.	berkeley	4524
La curiosité est sans doute la qualité la plus importante dans le renseignement.	CLANCY Tom	La somme de toutes les peurs. II.	1991	214     guerre du savoir	\\010xL`\\020	berkeley	1406
L'oubli et, je dirais même, l'erreur historique, sont un facteur essentiel dans la création d'une nation.	RENAN Ernest			120     grégarité		berkeley	4806
La foi a cela de particulier que, disparue, elle agit encore.	RENAN Ernest	, disparue, \\010m&#223;&#240;\\010mâ0´		312     foi		berkeley	4807
Sans la musique, la vie serait une erreur.	NIETZSCHE Friedrich	Le crépuscule des idoles.		393     création artistique		berkeley	4588
Celui qui peut créer dédaigne de détruire.	LAMARTINE Alphonse de	Premières Méditations poétiques, la Prière		390     création	1790-1869.	berkeley	3998
Le politique s'efforce à dominer l'opinion [...]. Aussi met-il tout son art à la séduire, dissimulant suivant l'heure, n'affirmant qu'opportunément... Enfin, par mille intrigues et serments, voici qu'il l'a reconquise [...]. Va-t-il agir sans feindre ? Mais non, il lui faut plaire encore [...]. Toute sa vie, toute son oeuvre ont un caractère instable, agité, tumultueux...	DE GAULLE Charles	Le fil de l"Epée.	1932	235     séduction	\\010a&#235;p\\020	berkeley	1806
Bergson a montré comment, pour prendre avec les réalités un contact direct, il faut que l'esprit humain en acquière l'intuition en combinant l'instinct avec l'intelligence.	DE GAULLE Charles	Le Fil de l"épée		320     intuition		berkeley	1809
Souvent, l'intelligence n'accepte pas de faire à l'instinct sa part [...].	DE GAULLE Charles	1ere Leçon à l"Ecole supérieure de guerre.	1927	320     intuition		berkeley	1810
Songez que les ouvrages que nous feuilletons le moins, avec le plus de négligence et de partialité, ce sont ceux de nos collègues.	DIDEROT Denis	Lettres		221     vanité	1713-1784.	berkeley	2083
Il devrait exister une science de la contrariété. Les gens ont besoin d'épreuves difficiles et d'oppression pour développer leurs muscles psychiques.	HERBERT Franck	Dune	1965	441     sang-froid		berkeley	3151
Jusqu' à présent, il ne s'était jamais trahi. Il pouvait encore se regarder dans une glace sans avoir honte dee l'image qu'il y voyait. Mais le danger était l à, comme l'étincelle du désir prête à s'enflammer quand se présente la femme rêvée.	WEST Morris	Les bouffons de Dieu.	1981	442     démission		berkeley	5436
Il y a des reproches que l'on ne peut pas faire aux êtres que l'on aime. L'idée ne vous en vient pas. Ou alors, on la repousse bien vite par crainte de faire du mal. On croit toujours à la sensibilité de ceux que l'on aime.	CLAVEL Bernard	L"ouvrier de la nuit.	1956	330     coeur		berkeley	1475
Je ne cherche en aimant que le seul bien d'aimer.	CORNEILLE Pierre	La Veuve, II, 4, Philiste		330     coeur	1606-1684.	berkeley	1657
Je ne sais ce que c'est que des principes, sinon des règles qu'on prescrit aux autres pour soi.	DIDEROT Denis	Jacques le fataliste		221     vanité	1713-1784.	berkeley	2085
La poésie est la surabondance spontanée de sentiments puissants ; son origine se trouve dans l'émotion dont on a souvenance dans la tranquillité.	WORDSWORTH William	Ballade lyrique, Préface.		393     création artistique		berkeley	5495
L'amour, c'est l'infini mis à la portée des caniches.	CéLINE L.-F.	Voyage au bout de la nuit		221     vanité	1894-1961. (Louis-Ferdinand Destouches)	berkeley	1070
Nous mourons, quand il n'y a plus personne pour qui nous voulions vivre.	MONTHERLANT Henry Millon de	Les Garçons		520     ironie de soi	1896-1973.	berkeley	4488
[...] Toute absence est un risque : qui va à la chasse perd sa place.	MONTHERLANT Henry Millon de	Mais aimons-nous ceux que nous aimons ?		530     ironie amoureuse		berkeley	4489
L'absence de défauts n'est pas une qualité, en choses d'art, et les qualités moyennes même n'y sont presque comptées que comme absence de défauts.	FAGUET Emile	Etudes littéraires du dix-septième siècle		390     création	1847-1916.	berkeley	2446
Mettez ne fût-ce qu'un brin et répétez souevnt ce geste, le tas sera bientôt grand.	HESIOPE			380     travail	380     trav\\010t- à\\010t1Ä	berkeley	3176
Pourquoi voulez-vous que nous dissimulions l'émotion qui nous étreint tous, hommes et femmes, qui sommes ici chez nous, dans Paris debout pour se libérer et qui a su le faire de ses mains ? Non! Nous ne dissimulerons pas cette émotion profonde et sacrée. Il y a des minutes qui dépassent chacune de nos pauvres vies. Paris ! Paris outragé ! Paris brisé ! Paris marytisé ! Mais Paris libéré ! libéré par lui-même, libéré par son peuple avec le concours des armées de la France, avec l'appui et le concours de la France toute entière, de la France qui se bat, de la seule France...	DE GAULLE Charles	Mémoires de guerre.		430     paradoxal émotionnel	le 25 août 1944, entrant dans Paris.	berkeley	1830
Qui veut gagner les masses doit connaitre la clé qui ouvrira la porte de leur coeur.	HITLER Adolph			238     servitudes du pouvoir politique	cité par Aldous HUXLEY in Le Retour au Meilleur des Mondes	berkeley	3196
Le privilège de l'absurdité est réservé à la seule créature humaine.  The privilege of absurdity - to which no living creature is subject - is reserved to man only.	HOBBES Thomas	Leviathan, I, 5		510     ironie	1588-1679. (Anglais)	berkeley	3199
J'estime que la première condition du bonheur pour un homme est de sortir de lui-même, dans le monde aujourd'hui. Les choses n'ont que l'importance qu'on leur donne. Si nous jugeons que l'amour est au fond plus amer que doux, n'en faisons pour rien au monde l'objet principal de nos préoccupations, mais seulement un assaisonnement de la vie.	DE GAULLE Charles			530     ironie amoureuse		berkeley	1855
'Tut, tut, ma petite, dit la duchesse,  tout a une morale si l'on cherche bien.'  'Tut, tut, child', said the Duchess.  'Everything's got a moral if only you can find it.' 	CARROLL Lewis	Alice"s Adventures in Wonderland, IX		546     éthique	1832-1898. (Charles Dodgson) (Anglais)	berkeley	1043
Les seuls espions avoués sont les ambassadeurs.	CASANOVA DE SEINGALT Jean-Jacques	Mémoires		214     guerre du savoir	1725-1798.	berkeley	1044
Rien ne nous rend si grands qu'une grande douleur.	MUSSET Alfred de	Poésies, la Nuit de mai		510     ironie	1810-1857.	berkeley	4542
Il y a une infinité de choses où le moins mal est le meilleur.	MONTESQUIEU Charles de	Mes pensées		441     sang-froid	1689-1755. (C. de Secondat, baron de La Brède et de M.)	berkeley	4445
Un homme qui enseigne peut devenir aisément opiniâtre, parce qu'il fait le métier d'un homme qui n'a jamais tort.	MONTESQUIEU Charles de	Essai sur les causes qui peuvent affecter les esprits et les caractères		510     ironie	1689-1755. (C. de Secondat, baron de La Brède et de M.)	berkeley	4448
L'amitié est un contrat par lequel nous nous engageons à rendre de petits services afin qu'on nous en rende de grands.	MONTESQUIEU Charles de	Mes pensées		539     ironie sociale	1689-1755. (C. de Secondat, baron de La Brède et de M.)	berkeley	4453
La plus belle chose que nous puissions éprouver, c'est le côté mystérieux de la vie. C'est le sentiment profond qui se trouve au berceau de l'art et de la science véritable.	EINSTEIN Albert	Comment je vois le monde.		390     création		berkeley	2312
Il n'est donné qu' à un très petit nombre, par leur humour délicat, par leur état de grâce, de fasciner leur génération et de présenter la vérité sous l'aspect impersonnel de la forme artistique.	EINSTEIN Albert	Comment je vois le Monde	1934	393     création artistique	rééd.corr. en 1952 et 1978.	berkeley	2314
L'appétit vient en mangeant.	RABELAIS François	Gargantua.		421     initiation		berkeley	4755
Ce qui reste finit par nous rendre ce qu'on a perdu.	BOSCO Henri	Un oubli moins profond 		432     expérience	1888-1976.	berkeley	798
La vraie grandeur consiste à être maître de soi-même.	DEFOE Daniel	Robinson-Crusoë		550     grandeur		berkeley	1878
L'argent est la lampe d'Aladin.  Ready money is Aladdin's lamp.	BYRON George Gordon lord	Don Juan, XII, 12		230     pouvoir	1788-1824. (Anglais)	berkeley	942
C'est un grand signe de médiocrité de louer toujours modérément.	VAUVENARGUES Marquis de	Réflexions et Maximes.		221     vanité	CLAPIER Luc de	berkeley	5260
L'idéaliste a la marche des orteils; et le matérialiste a la marche des talons.	CHAZAL Malcolm de	Sens plastique		510     ironie	1902-1981.	berkeley	1332
Comme le souvenir est voisin du remords.	HUGO Victor			540     mémoire		berkeley	3349
L'homme doué [...] sait se servir de son obscurité.	VORAGINE Jacques de	La légende dorée.		320     intuition		berkeley	5340
Suis le chemin et ne t'y couche que pour mourir.	COLETTE Sidonie Gabrielle	Les Vrilles de la vigne		510     ironie	1873-1954.	berkeley	1561
On croit toujours que c'est plus facile de réussir dans ce qu'on n'a pas appris que dans ce qu'on a appris. C'est naturel.	COLETTE Sidonie Gabrielle	Mitsou ou Comment l"esprit vient aux filles.		510     ironie		berkeley	1562
L'âme de la cité n'est rien d'autre que la constitution, qui a le même pouvoir que dans le corps la pensée.	Isocrate	Aréopagitique, 14		539     ironie sociale	436-338 av. J.-C.	berkeley	3398
L'expérience immédiate de la vie résout les problèmes qui déconcertent le plus l'intelligence pure.	JAMES William	La volonté de croire.		360     bon sens		berkeley	3417
Dans la vie de l'esprit comme dans la vie pratique, celui dont les connaissances tiennent progresse toujours et réussit. Celui, au contraire, piétine qui perd son temps à réapprendre ce qu'il a oublié.	JAMES William	Précis de psychologie.		421     initiation		berkeley	3418
Bienheureux est celui qui, très loin du vulgaire, Vit en quelque rivage, éloigné, solitaire.	VAUQUELIN de la FRESNAYE	Satires.		423     solitude		berkeley	5256
On promet beaucoup pour se dispenser de donner peu.	VAUVENARGUES Marquis de	Réflexions et Maximes.		215     mystifications	CLAPIER Luc de	berkeley	5257
Il faut être bien dénué d'esprit, si l'amour, la malignité, la nécéssité n'en font pas trouver.	LA BRUYERE Jean de	Les Caractères.		370     esprit		berkeley	3611
On attendait, d'un instant à l'autre, l'offensive allemande et, devant cette perspective, tout le monde se fortifiait dans une exemplaire fermeté. C'était un spectacle proprement admirable que de voir chaque Anglais se comporter comme si le salut du pays tenait à sa propre conduite...	DE GAULLE Charles	Mémoires de guerre.		440     courage		berkeley	1840
Monsieur le Président,  Nous sommes au bord de l'abîme et vous portez la France sur votre dos. Je vous demande de considérer ceci :  1. Notre première défaite provient de l'application par l'ennemi de conceptions qui sont les miennes et du refus de notre commandement d'appliquer les mêmes conceptions. 2. Après cette terrible leçon, vous qui, seul, m'aviez suivi, vous êtes trouvé le maître, en partie parceque vous m'aviez suivi et qu'on le savait.  Mais une fois devenu le maître, vous nous abandonnez aux hommes d'autrefois. Je ne méconnais ni leur gloire passée ni leurs mérites de jadis. Mais je dis que ces hommes d'autrefois - si on les laisse faire - perdent cette guerre nouvelle.  Les hommes d'autrefois me redoutent parcequ'ils savent que j'ai raison et que je possède le dynamisme pour leur forcer la main. Ils font donc tout, aujourd'hui comme hier - et peut-être de très bonne foi -, pour m'empêcher d'accéder au poste où je pourrais agir avec vous. 5. Le pays sent qu'il faut nous renouveler d'urgence. Il saluerait avec espoir l'avènement d'un homme nouveau, de l'homme de la guerre nouvelle. 6. Sortez du conformisme, des situations 'acquises', des influences d'académie. Soyez Carnot, ou nous périrons. Carnot fit Hoche, Marceau, Moreau. 7. Venir près de vous comme irresponsable ? Chef de cabinet ? Chef d'un bureau d'études ? Non! J'entends agir avec vous, mais par moi-même. Ou alors, c'est inutile et je préfère commander !  8. Si vous renoncez à me prendre comme sous-secrétaire d'Etat, faites tout au moins de moi le chef - non point seulement d'une de vos quatre divisions cuirassées - mais bien du corps cuirassé groupant tous ces éléments. Laissez-moi dire sans modestie, mais après expérience faite sous le feu depuis vingt jours, que je suis le seul capable de commander ce corps qui sera notre suprême ressource. L'ayant inventé, je prétends le conduire.	DE GAULLE Charles	Lettre à Paul Raynaud.	1940	440     courage	Lettre à Paul Raynaud, président du conseil.	berkeley	1841
On risque autant à croire trop qu' à croire trop peu.	DIDEROT Denis	Pensées philosophiques		312     foi	1713-1784.	berkeley	2090
Un vaincu est un lâcheur. Un vainqueur, lui, n'abandonne jamais.	VINCENT Raymond	La passion du succès.		440     courage		berkeley	5311
Les mains bougent, les lèvres bougent. Les idées surgissent de ses paroles, Et son regard est dévorant ! Il est une île sur lui seul close.	HERBERT Franck	Dune	1965	420     capital affectif		berkeley	3138
Tenter de comprendre Muad'Dib sans comprendre ses ennemis mortels, les Harkonnens, c'est tenter de voir la Vérité sans connaitre le Mensonge. C'est tenter de voir la Lumière sans connaitre les Ténèbres.	HERBERT Franck	Dune	1965	421     initiation		berkeley	3140
Nul ne mérite d'être loué de bonté s'il n'a pas la force d'être méchant.	LA ROCHEFOUCAULD François de	Maximes		440     courage	1613-1680.	berkeley	3889
Pour supporter sa propre histoire, chacun y ajoute un peu de légende.	JOUHANDEAU Marcel	L"Imposteur		520     ironie de soi	1888-1979.	berkeley	3488
Je n'ai pas aimé d'être admiré mais d'en être digne.	JOUHANDEAU Marcel	Algèbre des valeurs morales.		520     ironie de soi		berkeley	3489
On ne donne rien si libéralement que ses conseils.	LA ROCHEFOUCAULD François de	Maximes		221     vanité	1613-1680.	berkeley	3824
Je ne crois pas beaucoup à l'inspiration. La respiration, oui. Il y a bien des moments de petits miracles, mais c'est rare. Je préfère un travail continu et puis cel à vient peu à peu.	WOU-KI Zao	Les secrets de la création in Télérama 2175 (21/09/91)	1991	390     création	peintre, né d"une famille issue de la dynastie Song, vit à Paris	berkeley	5497
Il y a des héros en mal comme en bien.	LA ROCHEFOUCAULD François de	Maximes		215     mystifications	1613-1680.	berkeley	3794
Confiance, séduction, défiance, conflit. Des mots qui se partagent la réalité primitive des relations dites humaines. Tout le reste ne sera jamais que par privilège de liberté.	FAIRGAGNETR Oscar	Vitalités.	1992	510     ironie		berkeley	2626
Se vaincre soi-même, rendre à son coeur l'honnêteté qu'il tenait de la nature, voil à la vertu parfaite .... Il dépend de chacun d'être parfaitement vertueux.	CONFUCIUS	Entretiens, VI, 12		546     éthique	551-479 av. J.-C. (Chinois)	berkeley	1607
Danser est le fin mot de vivre et c'est par danser aussi soi-même qu'on peut seulement connaître quoi que ce soit: il faut s'approcher en dansant.	DUBUFFET Jean	Prospectus et tous Ecrits suivants		140     rapport à la cosmogonie	1901-1985.	berkeley	2184
Il faut plaindre tous ceux qui n'ont pas eu de mère, Car leur espoir est triste et leur joie est amère.	BOURGET Paul	Les Aveux.		420     capital affectif		berkeley	819
Pour être sage, une heureuse ignorance Vaut souvent mieux qu'une faible vertu.	DESHOULIERES Mme			510     ironie		berkeley	1955
Toute vertu est fondée sur la mesure.  Omnis in modo est virtus.	Sénèque	Lettres à Lucilius, LXVI		560     sagesse		berkeley	5024
[...] sans les autres, sans l'amour et la compagnie d'un autre ou d'une autre, nous sommes perdus et désespérés comme des feuilles emportées par le vent.	WEST Morris	Kaloni le navigateur	1976	420     capital affectif		berkeley	5401
Le travail éloigne de nous trois grands vices : l'ennui, le vice et le besoin.	VOLTAIRE	Candide.		380     travail		berkeley	5330
La plus noble activité mentale est l'interrogation.	VERCORS. Jean BRULAIRE			341     étonnement		berkeley	5274
On a dit que l'amour qui ôtait l'esprit à ceux qui en avaient en donnait à ceux qui n'en avaient pas.	DIDEROT Denis	Paradoxe sur le comédien		530     ironie amoureuse	1713-1784.	berkeley	2115
Quoi qu'on fasse, on ne peut se déshonorer quand on est riche.	DIDEROT Denis	Le Neveu de Rameau		539     ironie sociale	1713-1784.	berkeley	2116
Vieil océan, ô grand célibataire ...	LAUTRéAMONT Comte de	Les Chants de Maldoror		423     solitude	1846-1870. (Isidore Ducasse)	berkeley	4051
Le silence est l'élément dans lequel se forment les grandes choses.	MAETERLINCK Maurice	Le Trésor des humbles.		441     sang-froid		berkeley	4168
Pauvre Caton, tu t'imagines que ta vertu t'élève au-dessus de toutes choses.	MALEBRANCHE Nicolas de	De la recherche de la vérité		221     vanité	1638-1715.	berkeley	4190
On se trompe toujours lorsqu'on ne ferme pas les yeux pour pardonner ou pour mieux regarder en soi-même.	MAETERLINCK Maurice	Pelléas et Mélisande.		510     ironie		berkeley	4169
Philosopher n'est qu'une façon de raisonner la mélancolie.	VILMORIN Louise de	Julietta		545     épistémologie	1902-1969.	berkeley	5304
Je n'ai point l'autorité d'être cru, ni ne le désire, me sentant trop mal instruit pour instruire autrui.	MONTAIGNE Michel Eyquem de	Essais, I, 26		433     perversion	1533-1592.	berkeley	4358
Mille baisers aussi brulants que tu es froide !	Napoléon I			530     ironie amoureuse	courrier adressé pendant la campagne d"Italie	berkeley	4563
L'homme n'a inventé Dieu qu'afin de pouvoir vivre sans se tuer.	DOSTOIEVSKI Fiodor Mikhaïlovitch	Les Possédés		539     ironie sociale	1821-1881. (Russe)	berkeley	2151
... Toute âme est une très vile comédie.	CLAUDEL Paul	Tête d"or, III, le roi		510     ironie	1868-1955.	berkeley	1460
Il n'y a de société vivante que celle qui est animée par l'inégalité et l'injustice.	CLAUDEL Paul	Conversations dans le Loir-et-Cher		515     tragédie	1868-1955.	berkeley	1461
Se servir d'une seule âme pour être deux.	CLAUDEL Paul	Journal		531     communication amoureuse	1868-1955.	berkeley	1466
L'humanité se compose de plus de morts que de vivants.	COMTE Auguste			110     entropie		berkeley	1583
La croyance consiste à accepter les affirmations de l'âme ; l'incroyance à les nier. Quelques esprits sont incapables de scepticisme.	EMERSON Ralph Waldo	Hommes représentatifs.		320     intuition		berkeley	2341
D'un système d'interdits, on peut comprendre ce que les gens font d'habitude, dit Belbo, et on peut en tirer des ébauches de vie quotidienne.	ECO Umberto	Le Pendule de Foucault	1988	545     épistémologie		berkeley	2277
Le temps ne s'occupe pas de réaliser nos espérances; il fait son oeuvre et s'envole.	Euripide	Héraclès, 506-507		510     ironie	480-406 av. J.-C.	berkeley	2394
L'argent ... est un bon serviteur et un mauvais maître.	DUMAS Alexandre	Préface de la Dame aux camélias		441     sang-froid	1824-1895. (fils)	berkeley	2234
La philosophie donne moyen de parler vraisemblablement de toutes choses, et se faire admirer des moins savants.	DESCARTES René	Discours de la méthode		221     vanité	1596-1650.	berkeley	1911
... Quelle mâle gaîté, si triste et si profonde  Que, lorsqu'on vient d'en rire, on devrait en pleurer! 	MUSSET Alfred de	Poésies, Une soirée perdue		510     ironie	1810-1857.	berkeley	4543
Tout ce que nous faisons garde la graine de ce que nous avons fait avant...	VISCONTI Luchino			432     expérience	cité par le présentateur du cinéma de minuit de F3 à l"occasion de la projection de "Rocco et ses frères", le 25/07/93.	berkeley	5318
Quant aux cours des princes, il les faut, pour parler et apprendre de tout, avoir vues, et savoir de quel bois on s'y chauffe, mais s'en retirer au plus tôt qu'on peut.	DU FAIL Noël	Contes et discours d"Eutrapel		441     sang-froid	1520-1591.	berkeley	2178
Il est impossible de prévoir l'imprévu, comprends-tu ? Mais l'imprévu se produit toujours.	DARD Frédéric	La Vieille qui marchait dans la Mer. San-Antonio.	1988	421     initiation		berkeley	1759
On compte ses aïeux lorsqu'on ne compte plus.	CHATEAUBRIAND François-René de	Vie de Rancé		221     vanité	1768-1848.	berkeley	1290
Les biens de la terre ne font que creuser l'âme et en augmenter le vide.	CHATEAUBRIAND François-René de	Le Génie du christianisme		223     cupidité	1768-1848.	berkeley	1291
La plus subtile folie se fait de la plus subtile sagesse.	MONTAIGNE Michel Eyquem de	Essais, II, 12		433     perversion	1533-1592.	berkeley	4357
Heureux le pays qui n'a pas besoin de héros.	BRECHT B.			510     ironie		berkeley	840
... Quand une femme a le don de se taire,  Elle a des qualités au-dessus du vulgaire.	CORNEILLE Pierre	Le Menteur, I, 4, Cliton		560     sagesse	1606-1684.	berkeley	1690
Le cïur ne mène pas si vite à l'absurde que la raison à l'odieux.	ROSTAND Jean	Julien Ou Une Conscience.		330     coeur		berkeley	4868
Il est un âge où quelques mois ajoutés à la vie suffisent pour développer des facultés jusqu'alors ensevelies dans un coeur à demi-fermé : on se couche enfant ; on se réveille homme.	CHATEAUBRIAND François-René de	Mémoires d"outre-tombe.		420     capital affectif		berkeley	1302
Les roses ... ne savent pas, elles, qu'elles se faneront.	DUVERNOIS Henri	Beauté		510     ironie	1875-1937.	berkeley	2253
Tout passe. Tout change.	Dictons et Proverbes			510     ironie		berkeley	2044
A l'impossible je suis tenu.	COCTEAU Jean	Orphée		520     ironie de soi	1889-1963.	berkeley	1536
Mes oreilles vont plus loin que le son, Mes yeux vont plus loin que la vue, Et découvrent une terre, des cieux, des océans nouveaux.	THOREAU Henry David			390     création	"célèbre mystique de Walden Pond"	berkeley	5199
Ce que l'on conçoit bien s'énonce clairement, Et les mots pour le dire arrivent aisément.	Proverbes et Dictons			370     esprit		berkeley	4741
Mieux vaut l'imprudent mouvement que la prudente immobilité.	KEATS			440     courage		berkeley	3540
Qui en un an veut être riche, à la moitié on le pend.	Dictons et Proverbes	Dicton.		110     entropie		berkeley	1985
L'angoisse est la disposition fondamentale qui nous place face au néant.	HEIDEGGER Martin	De l"essence à la vérité.		430     paradoxal émotionnel		berkeley	3103
Il y a plus de paroles en un plein pot de vin qu'en un muid de cervoise.  Plus a paroles an plain pot / De vin qu'an un mui de cervoise.	Chrétien de Troyes	Le Chevalier au Lion		234     communication	Seconde moitié du XIIe siècle	berkeley	1358
Le coeur a des pensées que ne dit pas la bouche.  Ce panse cuers que ne dit boche.	Chrétien de Troyes	Erec Et Enide.		430     paradoxal émotionnel	Seconde moitié du XIIe siècle.	berkeley	1359
Pour être un membre irréprochable parmi une communauté de moutons, il faut avant toute chose être soi-même un mouton.	EINSTEIN Albert	Comment je vois le Monde.	1934	120     grégarité	rééd.corr. en 1952 et 1978.	berkeley	2287
Lorsqu'on est déterminé, lorsqu'on croit dur comme fer qu'on arrivera à ses fins, on dégage une force inéluctable.	VINCENT Raymond	La passion du succès.		422     confiance en soi		berkeley	5308
Tout le monde n'est pas fait pour être heureux.	CLAUDEL Paul	L"Otage, I, 1, Coûfontaine		442     démission	1868-1955.	berkeley	1456
C'est un plaisir fade et nuisible d'avoir affaire à gens qui nous admirent et fassent place.	MONTAIGNE Michel Eyquem de	Essais, III, 8		520     ironie de soi	1533-1592.	berkeley	4384
L'erreur essentielle est certainement d'espérer ou de croire que l'on peut ou que l'on doit vivre pour soi-même plutôt que par soi-même et pour l'échange.	FAIRGAGNETR Oscar	elle	1991	370     esprit		berkeley	2552
Essayons donc toujours d'attraper les étoiles. Il en restera invariablement quelque chose.	FAIRGAGNETR Oscar	Vitalités.	1992	370     esprit		berkeley	2553
Le début de l'absence est comme la fin de la vie.  El principio de la ausencia es como el fin de la vida.	LOPE DE VEGA CARPIO Félix	El servir con mala estrella, I, 5		530     ironie amoureuse	1562-1635. (Espagnol)	berkeley	4146
C'est par le travail qu'on règne.	Louis XIV			380     travail		berkeley	4148
La voix de la conscience et de l'honneur est bien faible quand les boyaux crient.	DIDEROT Denis	Le Neveu de Rameau		441     sang-froid	1713-1784.	berkeley	2109
Nous nous promenons entre des ombres, ombre nous-mêmes pour les autres et pour nous.	DIDEROT Denis	Eléments de physiologie		510     ironie	1713-1784.	berkeley	2111
Comble du droit, comble de l'injustice.  Summum jus, summa injuria.	Cicéron	Des devoirs, I, 10, 33		539     ironie sociale	106-43 av. J.-C. (Marcus Tullius Cicero)	berkeley	1382
Voil à ce que c'est que les moutons. Ils obéissent aux chiens qui obéissent aux bergers qui obéissent aux astres.	CINGRIA Charles Albert	Bois sec, bois vert		120     grégarité	1883-1954.	berkeley	1383
La malhonnêteté d'un penseur se reconnaît à la somme d'idées précises qu'il avance.	CIORAN Emile-Michel	Syllogismes de l"amertume		215     mystifications	1911-.	berkeley	1384
Le paradis terrestre est où je suis.	VOLTAIRE			341     étonnement		berkeley	5328
Peu d'esprit avec de la droiture ennuie moins, à la longue, que beaucoup d'esprit avec du travers.	LA ROCHEFOUCAULD François de	Maximes.		234     communication		berkeley	3833
Deux mains qui se cherchent c'est assez pour le toit de demain.	BRETON André	Signe ascendant		531     communication amoureuse	1896-1966.	berkeley	857
Sans culture morale, aucune chance pour les hommes.	EINSTEIN Albert	Comment je vois le Monde	1934	546     éthique	rééd.corr. en 1952 et 1978.	berkeley	2321
On n'est jamais si bien servi que par soi-même.	ETIENNE Charles Guillaume	Brueys et Palaprat		440     courage	1777-1845.	berkeley	2388
Le peuple au plus ardent de sa colère est pareil à un feu trop vif pour être éteint.	Euripide	Oreste, 696-697		120     grégarité	480-406 av. J.-C.	berkeley	2389
Je sus toujours mieux louer que blâmer.	CHARTIER Emile	Histoire De Mes Pensées.		330     coeur	alias Alain (1868-1951)	berkeley	1223
Un pays sans police est un grand navire sans boussole et sans gouvernail.	DUMAS Alexandre	Les Mohicans de Paris		391     commandement	1802-1870. (père)	berkeley	2228
En général, je ne commence un livre que lorsqu'il est écrit.	DUMAS Alexandre	Propos d"art et de cuisine		393     création artistique	1802-1870. (père)	berkeley	2229
Il arrive quelquefois des accidents dans la vie d'où il faut être un peu fou pour se bien tirer.	LA ROCHEFOUCAULD François de	Maximes		420     capital affectif	1613-1680.	berkeley	3867
Le silence est le parti le plus sûr pour celui qui se défie de soi-même.	LA ROCHEFOUCAULD François de	Maximes.		422     confiance en soi		berkeley	3868
Le bonheur est comme la vérole: pris trop tôt, il peut gâter complètement la constitution.	FLAUBERT Gustave	Correspondance, 1842, à Louise Colet, 1853		420     capital affectif	1821-1880.	berkeley	2756
C'est dans la seconde période de la vie d'artiste que les voyages sont bons, mais dans la première il est mieux de jeter dehors tout ce qu'on a de vraiment intime, d'original, d'individuel.	FLAUBERT Gustave	L"amour de l"art.	1915	421     initiation	(1821/1880) édition posthume	berkeley	2757
La confiance que l'on a en soi fait naitre la plus grande partie de celle que l'on a aux autres.	LA ROCHEFOUCAULD François de	Maximes.		422     confiance en soi		berkeley	3869
Les grandes pensées viennent du coeur.	VAUVENARGUES Marquis de	Réflexions et Maximes.		330     coeur	CLAPIER Luc de	berkeley	5263
La grandeur est une expérience passagère. Jamais elle n'est stable. Elle dépend en partie de l'imagination humaine qui crée les mythes. La personne qui connait la grandeur doit percevoir le mythe qui l'entoure. Elle doit se montrer puissamment ironique. Ainsi, elle se garde de croire en sa propre prétention. En étant ironique, elle peut se mouvoir librement en elle-même. Sans cette qualité, même une grandeur occasionnelle peut détruire un homme.	HERBERT Franck	Dune	1965	520     ironie de soi		berkeley	3153
Mon père me dit une fois que le respect de la vérité est presque le fondement de toute morale. 'Rien ne saurait sortir de rien', disait-il. Et cel à apparait certes comme une pensée profonde si l'on conçoit à quel point 'la vérité' peut être instable.	HERBERT Franck	Dune	1965	546     éthique		berkeley	3154
Vous pouvez conduire un cheval à la rivière, mais il boira quand et ce qu'il lui plaira.	HERBERT George	Jacula Prudentum		510     ironie	1593/1632	berkeley	3157
La moitié de mon âme est dans la nef fragile  Qui sur la mer sacrée où chantait Arion  Vers la terre des Dieux porte le grand Virgile.	HEREDIA José Maria de	Les Trophées		312     foi	1842-1905.	berkeley	3159
Tout amuse quand on y met de la persévérance: l'homme qui apprendrait par coeur un dictionnaire finirait par y trouver du plaisir.	FLAUBERT Gustave	Correspondance, 1842		380     travail	1821-1880.	berkeley	2741
La Passion s'arrange mal de cette longue patience que demande le métier. L'art est assez vaste pour occuper tout un homme ; en distraire quelque chose est presque un crime, c'est un vol fait à l'idée, un manque au devoir.	FLAUBERT Gustave	L"amour de l"art.	1915	390     création	(1821/1880) édition posthume	berkeley	2745
Ne me dites pas que ce problème est difficile. S'il n'était pas difficile, ce ne serait pas un problème.	FOCH Ferdinand			441     sang-froid	1851-1929.	berkeley	2814
Partout, la société conspire contre l'humaine nature de chacun de ses membres.  Society everywhere is in conspiracy against the manhood of every one of its members.	EMERSON Ralph Waldo	Essays, Self-Reliance		539     ironie sociale	1803-1882. (Américain)	berkeley	2343
On ne choisit pas son sujet. Voil à ce que le public et les critiques ne comprennent pas. Le secret des chefs-d'oeuvre est l à, dans la concordance du sujet et du tempérament de l'auteur.	FLAUBERT Gustave	Correspondance, 1842, à Mme Roger des Genettes, 1861		393     création artistique	1821-1880.	berkeley	2751
L'égalité, c'est l'esclavage. Voil à pourquoi j'aime l'art. C'est que l à, au moins, tout est liberté dans ce monde des fictions.	FLAUBERT Gustave	Correspondance, 1842		393     création artistique	1821-1880.	berkeley	2753
Ce n'est pas de sacrifices que le coeur a faim, mais de confidences.	FLAUBERT Gustave	L"amour de l"art.	420	420     capital affectif	1821/1880, édition posthume	berkeley	2755
Nul ne peut se sentir, à la fois, responsable et désespéré.	SAINT-EXUPéRY Antoine de	Pilote de guerre		430     paradoxal émotionnel	1900-1944.	berkeley	4932
La jeunesse montre l'homme comme le matin montre le jour.	MILTON J.	Paradis retrouvé, IV.		510     ironie		berkeley	4286
Femme qui abandonne sa bouche accorde sans peine le surplus. Feme qui sa bouche abandone / Le surplus molt de legier done.	Chrétien de Troyes	Le Conte Du Graal.		460     plaisir	Seconde moitié du XIIe siècle	berkeley	1362
En dépit des influences qu'il a subies, c'est lui-même qui a 'foré le sol profond de ses préférences'.	RICHET Alfred			320     intuition	sur le collectionneur André Lefèvre, in L"homme de l"art.	berkeley	4819
Corneille nous assujettit à ses caractères et à ses idées, Racine se conforme aux nôtres; celui-l à peint les hommes comme ils devraient être, celui-ci les peint tels qu'ils sont.	LA BRUYERE Jean de	Les Caractères		393     création artistique	1645-1696.	berkeley	3615
Rien n'est affreux en libertinage, parce que tout ce que le libertinage inspire, l'est également par la nature.	SADE Marquis de	La Philosophie dans le boudoir		460     plaisir	1740-1814.	berkeley	4908
Chaque vie contient, craint et repousse sa propre mort tant qu'elle reste le siège d'une foi plus grande que l'adversité.	FAIRGAGNETR Oscar	Vitalités.	1994	140     rapport à la cosmogonie		berkeley	2491
Le mépris porté à autrui l'est, d'abord, à soi-même.	FAIRGAGNETR Oscar	Vitalités.	1993	221     vanité		berkeley	2503
Quand un vrai génie paraît dans le monde, on le distingue à cette marque : tous les sots se soulèvent contre lui.	FRéRON Elie	Lettres Sur Quelques écrits De Ce Temps.		120     grégarité		berkeley	2887
Le gout est un prince détrôné qui, de temps en temps, doit faire des protestations.	FRéRON Elie	L"Année Littéraire.		370     esprit		berkeley	2888
L'homme n'est heureux que de vouloir et d'inventer.	CHARTIER Emile	Propos Sur Le Bonheur.		390     création	alias Alain (1868-1951)	berkeley	1239
L'art d'écrire précède la pensée.	CHARTIER Emile	Propos De Littérature.		390     création	alias Alain (1868-1951)	berkeley	1240
La tragédie, c'est d'aller au bout de soi-même.	SIMENON Georges	Entretien avec Claude Chabrol.		510     ironie	in n° de Studio années 60/70.	berkeley	5083
On ne connait l'intensité d'une séduction (..) que lorsqu'elle a disparu...	SIMON Yves	LA Dernière Passion. (Les Séductions de l"Existence)	1990	235     séduction		berkeley	5084
Mais il fut courageux. C'est- à-dire qu'il combattit la peur de savoir par la peur de ne pas savoir ; et il gagna, parcequ'il savait qu'il n'avait pas le choix.	SUSKIND Patrick	Le Parfum.	1985	440     courage		berkeley	5178
Que d'efforts pour se porter seulement vers l'être que l'on respecte de soi.	FAIRGAGNETR Oscar	Vitalités.	1993	440     courage		berkeley	2598
La France se perdra par les gens de guerre.	MONTESQUIEU Charles de	Mes pensées		110     entropie	1689-1755. (C. de Secondat, baron de La Brède et de M.)	berkeley	4393
Toutes les choses ont leur mystère, et la poésie, c'est le mystère de toutes les choses.  Todas las cosas tienen su misterio, y la poesía es el misterio que tienen todas las cosas.	GARCIA LORCA Federico	Al habla con F. García Lorca, 1936		393     création artistique	1899-1936. (Espagnol)	berkeley	2910
Quand Eve voulut un deuxième enfant, Adam fut très embarrassé car il ne savait pas quel était le geste, parmi tous ceux qu'il avait fait, qui avait eu pour conséquence d'engendrer le premier bébé.	CAVANNA François			510     ironie		berkeley	1061
Quand dans une cage, on enferme un lion affamé, un homme affamé et une côtelette, ce n'est jamais la côtelette qui gagne.	CAVANNA François			510     ironie	510     iron\\001ïéP\\001ïí@	berkeley	1062
Que le mal nous façonne, il faut bien l'accepter. Mieux est de façonner le mal à notre usage, et même à notre commodité.	COLETTE Sidonie Gabrielle	L"Etoile Vesper		520     ironie de soi	1873-1954.	berkeley	1566
Point de révolte: honorons les âges dans leurs chutes successives et le temps dans sa voracité.	SEGALEN Victor	Stèles		510     ironie	1878-1919.	berkeley	4993
J'aime le jeu, l'amour, les livres, la musique  La ville et la campagne, enfin tout; il n'est rien  Qui ne me soit souverain bien,  Jusqu'au sombre plaisir d'un coeur mélancolique.	LA FONTAINE Jean de	Les Amours de Psyché et de Cupidon		460     plaisir	1621-1695.	berkeley	3738
Les remords meurent, comme le reste. Et il y en a dont le souvenir embaume.	MONTHERLANT Henry Millon de	La Reine morte, III, 6, Ferrante		540     mémoire	1896-1973.	berkeley	4490
L'esprit qu'on veut avoir gate celui qu'on a.	GRESSET Jean-Baptiste Louis	Le Méchant.		221     vanité	1709-1777	berkeley	3025
Par eux-mêmes souvent les méchants sont trahis.	GRESSET Jean-Baptiste Louis	Le Méchant		222     fourberie	1709-1777.	berkeley	3026
Quand la haine des hommes ne comporte aucun risque, leur bêtise est vite convaincue, les motifs viennent tout seuls.	CéLINE L.-F.	Voyage au bout de la nuit		433     perversion	1894-1961. (Louis-Ferdinand Destouches)	berkeley	1074
Le mensonge, ce rêve pris sur le fait.	CéLINE L.-F.	Voyage au bout de la nuit		433     perversion	1894-1961. (Louis-Ferdinand Destouches)	berkeley	1075
Agir en primitif et prévoir en stratège.	CHAR René	Feuillets d"Hypnos		441     sang-froid	1907-1988.	berkeley	1185
Nous oublions aisément nos fautes lorsqu'elles ne sont sues que de nous.	LA ROCHEFOUCAULD François de	Maximes.		540     mémoire		berkeley	3940
Ce mode de production [l'art] peut être comparé à celui d'un homme expérimenté qui, tout en connaissant la vie et ses contingences, ne réussit pas à formuler son expérience en règles mais a toujours devant ses yeux les cas isolés qu'il a connus ( ) tout en étant capa- ble de se livrer à des réflexions générales, [il] ne sait expliciter son expérience concrète que dans des récits portant sur des cas isolés.	HEGEL Friedrich	Esthétique.		393     création artistique	1770/1831	berkeley	3097
Les hommes ne veulent connaître que l'histoire des grands et des rois, qui ne sert à personne.	BERNARDIN DE SAINT-PIERRE Jacques-Henri	Paul et Virginie		221     vanité	1737-1814.	berkeley	720
Ne mens pas pour le plaisir de parler.	Hésiode	Les Travaux et les Jours, 709		441     sang-froid	VIIIe s. av. J.-C.	berkeley	3174
Celui qui veut faire un emploi sérieux de la vie doit agir comme s'il avait à vivre longuement et se régler comme s'il lui fallait mourir prochainement.	LITTRE Emile	Dictionnaire de la langue française.		441     sang-froid		berkeley	4143
Ainsi la paresse est mère. Elle a un fils, le vol, et une fille, la faim.	HUGO Victor	Les Misérables.		110     entropie		berkeley	3277
Toutes les fois que je vous entends, je suis mécontent de moi-même.	Louis XIV		1699	510     ironie	 à Massilon	berkeley	4149
...de Gaulle [...] se fit durement traiter pour avoir exalté la valeur des circonstances, et il dut à son courage de sortir dans le dernier tiers.	LOUSTAUNAU-LACAU Georges	Mémoires d"un Français rebelle.	1924	440     courage	(de l"Ecole de Guerre)	berkeley	4150
Un père vaut plus qu'une centaine de maîtres d'école.	HERBERT George	Jacula Prudentum.		421     initiation	1593/1632	berkeley	3156
Trouver de mauvaises raisons à ce que l'on croit en vertu d'autres mauvaises raisons - voil à la philosophie.  Finding bad reasons for what one believes for other bad reasons - that's philosophy.	HUXLEY Aldous	Brave New World, 17		433     perversion	1894-1963. (Anglais)	berkeley	3362
Les faits ne cessent pas d'exister parce qu'on les ignore. Facts do not cease to exist because they are ignored.	HUXLEY Aldous	A Note On Dogma.		440     courage	1894-1963 (Anglais)	berkeley	3364
Les faits ne cessent pas d'exister parce qu'on les ignore.  Facts do not cease to exist because they are ignored.	HUXLEY Aldous	A Note on Dogma		441     sang-froid	1894-1963. (Anglais)	berkeley	3365
La fortune reçue en héritage effondre trop souvent celui sur qui elle tombe.	FAIRGAGNETR Oscar		1991	510     ironie		berkeley	2622
La divinité aime rabaisser tout ce qui s'élève.	Hérodote	Histoires, VII, 10		221     vanité	v. 484-v. 420 av. J.-C.	berkeley	3167
[...] Il ne faut point se dire : 'ce n'est point parce que j'ai réussi que je suis content ; mais c'est parceque j'étais content que j'ai réussi'.	CHARTIER Emile	Propos sur le bonheur.		430     paradoxal émotionnel	alias ALAIN	berkeley	1253
Ta vie sociale, c'est le cercle du public, des publics que tu fais rêver.	FAIRGAGNETR Oscar	Vitalités.	1994	539     ironie sociale	\\010QJ0\\020	berkeley	2643
La culture, c'est comme les spaggettis : à en faire de trop petits morceaux, on lui enlève toute sa saveur.	FAIRGAGNETR Oscar	Vitalités.	1993	540     mémoire		berkeley	2644
Le monde est plein de braves gens qui ne voient partout que des gredins.	CHARDONNE Jacques	L"Amour, c"est beaucoup plus que l"amour		433     perversion	1884-1968.	berkeley	1197
Je crois à l'économie de marché. Il n'en existe pas d'autre. (...) J'aime le capitalisme et sa capacité infinie de mouvement et de renouvellement. Il rime avec la vie : le nier, c'est en économie refuser le principe vital. J'en connais certes les rugosités et les petitesses, mais elles demeurent dérisoires, comparées à cette formidable puissance de création.	MINC Alain	L"Argent Fou	1990	392     création économique		berkeley	4287
Il y a deux espèces de sots: ceux qui ne doutent de rien et ceux qui doutent de tout.	LIGNE Prince de	Mes écarts		365     discernement	1735-1814.	berkeley	4137
Les mots vitaux et les actes des esprits d'autrefois Que ni temps, ni changement ne peuvent dompter, Les sombres et séculaires traditions, sources des mauvaises [croyances, Dont l'ombre obscure alimente un fleuve de poison.	SHELLEY P.-B.	La révolte de l"Islam.		215     mystifications		berkeley	5076
L'absence est aussi bien un remède à la haine  Qu'un appareil contre l'amour.	LA FONTAINE Jean de	Fables, les Deux Perroquets, le Roi et son Fils		423     solitude	1621-1695.	berkeley	3715
L'artiste est celui qui vit avec les pensées de la nuit. L'homme est celui qui se contente des pensées du jour. Le comédien est celui qui use des pensées du jour pour donner à croire qu'il vit avec les pensées de la nuit.	FAIRGAGNETR Oscar	Vitalités.	1992	510     ironie		berkeley	2623
Le bon sens, c'est le principe et la source du bien écrire.  Scribendi recte sapere est et principium et fons.	Horace	Art poétique, 309		360     bon sens	65-8 av. J.-C. (Quintus Horatius Flaccus)	berkeley	3239
Mon plaisir à moi est d'enfermer des mots dans la mesure d'un vers. Me pedibus delectat claudere verba.	Horace	Satires, II, 1, 28		393     création artistique	65-8 av. J.-C. (Quintus Horatius Flaccus)	berkeley	3244
L'amour et l'amitié s'excluent l'un l'autre.	LA BRUYERE Jean de	Les Caractères		530     ironie amoureuse	1645-1696.	berkeley	3629
[la Religion] institution sociale caractérisée par l'existence d'une communauté d'individus, unis : par l'accomplissement de certains rites réguliers et par l'adoption de certaines formules ; par la croyance en une valeur absolue avec laquelle rien ne peut être mis en balance, croyance que cette communauté a pour objet de maintenir ; par une mise en rapport de l'individu avec une puissance spirituelle supérieure à l'homme, puissance conçue soit comme diffuse, soit comme multiple, soit enfin comme unique, Dieu.	LALANDE André	Vocabulaire technique et critique de la philosophie. PUF 1991	1991	120     grégarité	cité par Stéphanie Jamet dans mémoire DEA IEP 1992	berkeley	3989
L'enthousiasme en France est un danger public et permanent. C'est lui qui nous jette à toutes les sottises.	MAUPASSANT Guy de	Enthousiasme et cabotinage, in le Gaulois		539     ironie sociale	1850-1893.	berkeley	4257
Tous les documents de toutes les périodes sont faux ! Tous représentent la vie 'vue par les artistes'. Toutes les images que nous avons de la nature, c'est aux peintres que nous les devons. C'est par eux que nous les percevons. Rien que cela devrait les rendre suspects...	PICASSO Pablo			540     mémoire	in "Conversations avec Picasso" de Brassaï.	berkeley	4708
Ne permets pas aux évènements de ta vie de tous les jours de t'enchaîner mais ne te soustrais jamais à eux. Ainsi tu atteindras la libération.	HUANG POE			560     sagesse		berkeley	3272
Le bonheur n'est jamais grandiose.  Happiness is never grand.	HUXLEY Aldous	Brave New World, 16		441     sang-froid	1894-1963. (Anglais)	berkeley	3366
Le temps perdu ne se rattrape pas.	CLANCY Tom	La somme de toutes les peurs. I.	1991	432     expérience		berkeley	1428
Je ne crois pas que notre monde soit absurde. L'ironie veut, pourtant, que les cons soient le plus souvent assez nombreux pour avoir raison de la raison.	FAIRGAGNETR Oscar	Vitalités.	1992	510     ironie		berkeley	2624
Mais alors, à quoi reconnaît-on un vrai peintre ? Et pourquoi peint-il ? Parcequ'il ne peut pas faire autrement et qu'un démon intérieur l'y pousse.	KAHNWEILER Daniel-Heinrich	Lettre à Togorès.	1925	393     création artistique		berkeley	3525
Hugo, l'Homme apocalyptique  l'Homme-ceci-tûra-cela,  Meurt, gardenational épique ...	CORBIERE Tristan	Les Amours jaunes		510     ironie	1845-1875. (Edouard Joachim Corbière)	berkeley	1645
A l'être responsable, la solitude se pose comme la première et la plus délicate des exigences.	FAIRGAGNETR Oscar	Vitalités.	1992	423     solitude		berkeley	2581
Les bons ouvriers le* commencent par le milieu, et savent si bien joindre le commencement au milieu, et le milieu à la fin, que de telles pièces rapportées font un corps entier et parfait.	RONSARD Pierre de	Abrégé de l"art poétique français 		393     création artistique	1524-1585.  *Le poème.	berkeley	4854
Soyez moins satirique, ou soyez plus satyre.  Valentins  	Guilleragues	Vers extrait d"une épigramme adressée par une femme à son amant.		221     vanité	1628-1685. (Gabriel-Joseph de Lavergne, comte de)	berkeley	3048
Rien n'est si contraire à la simplicité que le scrupule. Il cache je ne sais quoi de double et de faux.	Fénelon	Correspondance, à Mme de Montberon, 26 décembre 1700		393     création artistique	1651-1715. (François de Salignac de La Mothe-)	berkeley	2691
(Dans l'éducation), il faut se contenter de suivre et d'aider la nature.	Fénelon	De l"éducation des filles		421     initiation	1651-1715. (François de Salignac de La Mothe-)	berkeley	2692
Le vrai moyen de gagner beaucoup est de ne vouloir jamais trop gagner et de savoir perdre à propos.	Fénelon	Les Aventures de Télémaque		421     initiation	1651-1715. (François de Salignac de La Mothe-)	berkeley	2693
Ce n'est pas le difficile, c'est le beau que je cherche.	Fénelon	Lettre à l"Académie		431     désir	1651-1715. (François de Salignac de La Mothe-)	berkeley	2694
Il faut arriver à l'identité avec soi-même.	FICHTE			421     initiation		berkeley	2706
Seul peut entendre le coeur qui ne cherche ni la possession ni la victoire.	JOCOTTET Philippe			330     coeur		berkeley	3439
Les vices de la cour ont commencé la Révolution ; les vices du peuple l'achèveront.	RIVAROL Antoine de	é la Révolut\\010{q à\\010{t∞		240     débauche	(Comte de)	berkeley	4828
Un homme, c'est deux ou trois saloperies qu'il ne fera jamais.	JULLIAN Marcel			546     éthique	Grand-père de Marcel Julliand évoqué dans "Faut pas Rêver" du 4 mars 1994.	berkeley	3507
Mon pessimisme n'est qu'une forme de l'optimisme.	COCTEAU Jean	Lettre, aux Américains		441     sang-froid	1889-1963.	berkeley	1515
Pour être heureux en vivant dans le monde, il y a des côtés de son âme qu'il faut entièrement paralyser.	CHAMFORT Nicolas-Sébastien de	Maximes et pensées		423     solitude	1740/1794. Ac. Française	berkeley	1122
Il connaît l'univers et ne se connaît pas.	LA FONTAINE Jean de	Fables, Démocrite et les Abdéritains		140     rapport à la cosmogonie	1621-1695.	berkeley	3653
Tout faiseur de journaux doit tribut au Malin.	LA FONTAINE Jean de	Lettre, à M. Simon de Troyes, février 1686		215     mystifications	1621-1695.	berkeley	3655
Jamais surintendant ne trouva de cruelles. L'or, même à la laideur, donne un teint de beauté.	BOILEAU Nicolas	Satires, VIII.		530     ironie amoureuse		berkeley	785
N'essayez jamais d'être ce que vous n'êtes pas.	BONNET Serge & GOULEY Bernard	Les Ermites.		360     bon sens		berkeley	789
Il n'est pas difficile de nourrir des pensées admirables lorsque les étoiles sont présentes.	YOURCENAR Marguerite	Alexis ou le Traité du vain combat		520     ironie de soi	1903-1987. (Marguerite de Crayencour)	berkeley	5515
Mais le temps des chevaliers est révolu. Lui a succédé celui des sophistes, des économistes et des calculateurs.	BURKE Edmund	Réflexions sur la révolution française	1790	214     guerre du savoir		berkeley	905
Oui, travaille, aime l'Art. De tous les mensonges, c'est encore le moins menteur.	FLAUBERT Gustave	L"amour de l"art.	1915	393     création artistique	(1821/1880) édition posthume	berkeley	2748
Plus une idée est belle, plus la phrase est sonore.	FLAUBERT Gustave	Correspondance, 1842		393     création artistique	1821-1880.	berkeley	2752
J'apprends chaque jour pour enseigner le lendemain.	FAGUET Emile			421     initiation		berkeley	2451
Ne vous souvient-il plus que l'amour est, comme la médecine, seulement l'art d'aider la nature.	LACLOS Pierre Choderlos de	Les Liaisons dangereuses		330     coeur	1741-1803.	berkeley	3963
Partout où il y a esclavage, il ne peut y avoir éducation.	LACLOS Pierre Choderlos de	De l"éducation des femmes		421     initiation	1741-1803.	berkeley	3964
Le parti le plus difficile ou le plus gai est toujours celui que je prends; et je ne me reproche pas une bonne action, pourvu qu'elle m'exerce ou m'amuse.	LACLOS Pierre Choderlos de	Les Liaisons dangereuses		440     courage	1741-1803.	berkeley	3965
Le scélérat a ses vertus, comme l'honnête homme a ses faiblesses.	LACLOS Pierre Choderlos de	Les Liaisons dangereuses		510     ironie	1741-1803.	berkeley	3966
Il faut renoncer au monde pour le comprendre.	GRENIER Jean	Lexique		510     ironie	1898-1971.	berkeley	3020
L'homme se découvre quand il se mesure avec l'objet.	SAINT-EXUPéRY Antoine de	Terre des hommes		365     discernement	1900-1944.	berkeley	4926
De tous les sentiments, le plus difficile à feindre c'est la fierté 	LéVIS Duc de	Maximes et réflexions sur divers sujets		430     paradoxal émotionnel	1764-1830.	berkeley	4125
L'habitude de la sagesse dispense presque toujours de la vertu.	LéVIS Duc de	Pensées détachées		560     sagesse	1764-1830.	berkeley	4126
Ils ne s'entraiment pas, mais ils s'entrecraignent.	LA BOéTIE Etienne de	Discours De La Servitude Volontaire.		539     ironie sociale		berkeley	3584
La justice est le droit du plus faible.	JOUBERT Joseph	Pensées		546     éthique	1754-1824.	berkeley	3470
Eau trouble, gain de pêcheur.	Dictons et Proverbes	Dicton.		222     fourberie		berkeley	2003
Je tremble toujours de n'avoir écrit qu'un soupir, quand je crois avoir noté une vérité.	STENDHAL	De L"amour.		520     ironie de soi	Henri Beyle dit STENDHAL	berkeley	5155
Connais-toi toi-même.	SOCRATE	l"une des formule du temple de Delphes		421     initiation	Socrate (469/399 av.JC) en fit sa devise.	berkeley	5092
Il y a dans l'art beaucoup de beautés qui ne deviennent naturelles qu' à force d'art.	JOUBERT Joseph	Pensées		393     création artistique	1754-1824.	berkeley	3460
Ne jouons point avec les grands,  Le plus doux a toujours des griffes à la patte.	FLORIAN Jean-Pierre Claris de	Fables, les Singes et le Léopard		441     sang-froid	1755-1794.	berkeley	2805
Arriver haletant, se coucher, s'endormir;  On appelle cela naître, vivre et mourir.	FLORIAN Jean-Pierre Claris de	Fables, le Voyage		510     ironie	1755-1794.	berkeley	2807
Je n'aime dans l'histoire que les anecdotes.	MERIMEE Prosper	Préface à la Chronique du Règne de Charles IX.		540     mémoire		berkeley	4272
Il est né sans raison de naître celui qui ne vit que pour lui seul, et c'est cette noble passion qui seule enseigne à s'oublier pour autrui.	METASTASE	Regulus.		331     altruisme		berkeley	4274
Les princes ne méritent pas Qu'un autre annonce leur trépas Plutôt que la mort d'un autre homme Leur corps ne vaut pas une pomme.	MEUNG Jean de	Le Roman de la Rose.		510     ironie		berkeley	4275
Il n'était pas homme à tolérer qu'on essaye de le contraindre, encore un indice de sa force de caractère. Ryan était un salaud en béton et il prenait les choses de front quand c'était nécéssaire. 'Mais c'est aussi sa faiblesse, songea Wellington. Il aime mieux prendre les problèmes de front, il manque de finesse. C'est l à un défaut assez commun chez les gens honnêtes, et une grave faiblesse dans le monde de la politique.'	CLANCY Tom	La somme de toutes les peurs. I.	1991	546     éthique		berkeley	1432
Alors, au spectacle de ce peuple éperdu et de cette déroute militaire, au récit de cette insolence méprisante de l'adversaire, je me sens soulevé d'une fureur sans bornes. Ah! c'est trop bête ! La guerre commence infiniment mal. Il faut donc qu'elle continue. Il y a pour cela de l'espace dans le monde. Si je vis, je me battrai, où il faudra, tant qu'il faudra, jusqu' à ce que l'ennemi soit défait et lavée la tache nationale. Ce que j'ai pu faire, par la suite, c'est ce jour-l à que je l''ai résolu.	DE GAULLE Charles	Mémoires de guerre, I.	1953	321     volonté		berkeley	1817
Une note diplomatique outrancière avait décidé le Tzar Nicolas II à foncer au secours d'un peuple qu'il n'aimait pas, et le compte à rebours avait commencé.(...) Le dernier des Tzar aurait pu tout arrêter, mais il ne l'avait pas fait. S'il avait seulement su ce que signifiait sa décision de déclarer la guerre, il aurait peut-être trou- vé le courage de tout arrêter, mais, avec sa peur et sa faiblesse, il avait signé l'ordre de mobilisation qui marquait la fin d'une époque et lee commencement d'une ère nouvelle. Cette guerre avait éclaté parcequ'un homme faible et petit craignait moins de déclencher la guerre que d'exposer sa faiblesse.	CLANCY Tom	La somme de toutes les peurs.	1991	211     guerre		berkeley	1404
La prospérité était l'antichambre de la paix, et la mort du mécontentement.	CLANCY Tom	La somme de toutes les peurs. I.	1991	392     création économique		berkeley	1426
O que c'est un doux et mol chevet*, et sain, que l'ignorance et l'incuriosité, à reposer une tête bien faite! 	MONTAIGNE Michel Eyquem de	Essais, III, 18 		510     ironie	1533-1592.  *Oreiller.	berkeley	4374
... Vous invoquez des raisons stratégiques, mais c'est une erreur stratégique que de se mettre en contradiction avec le caractère moral de cette guerre. Nous ne sommes plus au XVIIIe siècle, où Frédéric payait des gens à la Cour de Vienne pour pouvoir prendre la Silésie, ni au temps de la Renaissance italienne où on utilisait les sbires de Milan ou les spadassins de Florence.	DE GAULLE Charles	Mémoires de guerre.		211     guerre	 à Churchill qui lui dit l""avantage" de maintenir Darlan à Alger	berkeley	1796
Tous les maux viennent de faute de foi.	COMMYNES Philippe de	Mémoires		442     démission	1447-1511.	berkeley	1582
Le travail est la meilleure des régularités et la pire des intermittences.	HUGO Victor	Tas de pierres		380     travail	1802-1885.	berkeley	3315
Le monosyllabe a une étrange capacité d'immensité: mer, nuit, jour, bien, mal, mort, oui, non, Dieu, etc.	HUGO Victor	Fragments		393     création artistique	1802-1885.	berkeley	3316
(.. .) Sans l'ironie, le monde serait comme une forêt sans oiseaux.	FRANCE Anatole	La Vie littéraire		510     ironie	1844-1924. (Anatole François Thibault)	berkeley	2867
Je suis comme un milieu entre Dieu et le néant.	DESCARTES René	Méditations		520     ironie de soi	1596-1650.	berkeley	1951
Ceux qui oublient leur passé sont condamnés à le revivre.	GANDHI Mahatma			540     mémoire	cité par J.M. Cavada pendant la Marche du Siècle du 08/09/93. (Projection d"extraits du procès Barbie, montés par Paul Lefèvre)	berkeley	2907
Si nous connaissions les autres comme nous-mêmes, leurs actions les plus condamnables nous paraîtraient mériter l'indulgence.	MAUROIS André			441     sang-froid		berkeley	4264
Les soldats devraient craindre davantage leur général que leurs ennemis.	Maxime militaire			391     commandement		berkeley	4266
L'âme haute et l'esprit pur  Se nourrissent de rancune.	LA TOUR DU PIN Patrice de	Une somme de poésie		433     perversion	1911-1975.	berkeley	3949
L'AS aura levé, de novembre 1942 à juin 1944, une centaine de milliers de combattants effectifs qui, du Périgord aux Alpes, de l'Ain à la Bretagne - où ils reçurent notamment les renforts des parachu- tistes du 2e RCP détachés des forces anglaises - créèrent des zones interdites à l'occupant, bloquèrent ses transports, sabotèrent les diverses formes de communication et désorganisèrent l'appareil d'Etat vichyste.	LACOUTURE Jean	De Gaulle.	1984	540     mémoire		berkeley	3983
Au del à de toutes choses s'étend l'océan.	SENEQUE			140     rapport à la cosmogonie		berkeley	5003
La première qualité pour voir est de posséder de bons yeux. Or, s'ils sont troublés par les passions, c'est- à-dire par un intérêt personnel, les choses vous échappent. Un bon coeur donne tant d'esprit.	FLAUBERT Gustave	L"amour de l"art.	1915	441     sang-froid	(1821/1880) édition posthume	berkeley	2772
Dans le domaine des sentiments, le réel ne se distingue pas de l'imagiaire.	GIDE André	Les Faux-Monnayeurs.		420     capital affectif		berkeley	2936
J'ay mis tous mes efforts à former ma vie. Voyla mon mestier et mon ouvrage. Je suis moins faiseur de livres que de nulle autre besogne.	MONTAIGNE Michel Eyquem de			390     création		berkeley	4344
L'expérience est une lenterne qui n'éclaire que le chemin parcouru.	LEBB Michel			432     expérience	d"après Confucius	berkeley	4081
Soyons humains au moins aussi longtemps que la Science n'aura pas découvert que nous sommes autre chose.	LEC Stanislas	Pensées Echevelées.		330     coeur		berkeley	4083
A quinze ans, il avait déj à appris le silence.	HERBERT Franck	Dune	1965	423     solitude		berkeley	3143
... Il arrive beaucoup de choses entre la bouche et le verre.	FURETIERE Antoine	Le Roman bourgeois		441     sang-froid	1619-1688.	berkeley	2896
A qui venge son père, il n'est rien d'impossible.	CORNEILLE Pierre	Le Cid, II, 2, Rodrigue		440     courage	1606-1684.	berkeley	1668
Le désespoir est une insulte à l'avenir.	Grand Rabbin de Paris			442     démission	cité par André Brink, militant anti-apparteid.	berkeley	3004
Vous ne pouvez choisir votre champ de bataille, Les dieux s'en chargent pour vous ; Mais vous pouvez planter un drapeau Où jamais un drapeau n'a été planté.	GRANE Natalia	Le Drapeau.		321     volonté		berkeley	3005
Le tout, c'est d'avoir du génie à vingt ans et du talent à quatre-vingts.  	COROT Camille			510     ironie	1796-1875.   Cité par Marguerite Matisse, in les Nouvelles Littéraires, n° 2222, 23 avril 1970.	berkeley	1692
Ces gens-l à n'auraient rien à dire  Si les autres n'avaient rien dit.	COTIN Abbé Charles	Les Pédants		120     grégarité	1604-1682.	berkeley	1693
La forme, c'est le bonheur de la matière.	GUéRIN Maurice de	Le Cahier vert		390     création	1810-1839.	berkeley	3043
Ma liberté se lève dans la nuit.	GUéRIN Maurice de	Lettre, à H. de la Morvonnais		520     ironie de soi	1810-1839.	berkeley	3044
La vraie patrie des enfants est celle des vacances heureuses.	GUICHARD Olivier	Mon général.	1980	420     capital affectif		berkeley	3045
Point n'est besoin d'espérer pour entreprendre ni de réussir pour persévérer.  	GUILLAUME IER D"ORANGE-NASSAU			390     création	1533-1584.  dit le Taciturne. Citation également attribuée à d"autres, tel Pierre de Coubertin, le promoteur des jeux Olympiques modernes.	berkeley	3046
La plupart des gens vous nuisent, sans avoir la moindre intention de vous nuire. Ils ont parlé contre vous et ils ne voulaient que parler: ils ont parlé contre vous parce qu'ils étaient dans l'impuissance de se taire.	MONTESQUIEU Charles de	Mes pensées		442     démission	1689-1755. (C. de Secondat, baron de La Brède et de M.)	berkeley	4446
L'ordre et les dieux meurent dès qu'un seul homme a poussé son accomplissement jusqu'au terme de la liberté.	BLANCHOT Maurice	Faux Pas		130     liberté	1907-.	berkeley	764
Enseigner, c'est apprendre deux fois.	JOUBERT Joseph	Pensées.		421     initiation	1754/1824	berkeley	3463
Je voulais en mourant prendre soin de ma gloire, Et dérober au jour une flamme si noire [...]	RACINE Jean	Phèdre.		510     ironie		berkeley	4787
Dans la nuit du tombeau, j'enfermerai ma honte.	RACINE Jean	Iphigénie en Aulide.		520     ironie de soi		berkeley	4788
Je n'ai vraiment l'impression que je suis libre que lorsque je suis enfermé. Lorsque je fais tourner la clef ce n'est pas moi qui suis bouclé ce sont les autres que j'enferme.	GUITRY Sacha	Un soir quand on est seul		423     solitude	1885-1957.	berkeley	3063
L'ignorance et l'incuriosité sont deux oreillers fort doux, mais, pour les trouver tels, il faut avoir la tête aussi bien faite que Montaigne.  Pensées philosophiques  	DIDEROT Denis	Cf. Montaigne. Essais, III, 13.		430     paradoxal émotionnel	1713-1784.	berkeley	2107
J'ose presque dire que l'état de réflexion est un état contre nature et que l'homme qui médite est un animal dépravé.	ROUSSEAU Jean-Jacques	Discours sur les sciences et les arts.		510     ironie		berkeley	4887
Toute forme de mépris, si elle intervient en politique, prépare ou instaure le fascisme.	CAMUS Albert	L"Homme révolté		239     servitudes du pouvoir autoritaire	1913-1960.	berkeley	993
L'homme se fait lui-même, et il n'arrive à se faire complètement que dans la mesure où il se désacralise et désacralise le monde.	ELIADE Mircea	Le Sacré et le profane		421     initiation	1907-1986.	berkeley	2328
Examinez bien vos paroles et vous trouverez que, lors même que vous n'avez aucun motif d'être faux, il est très difficile de dire l'exacte vérité.  Examine your words well, and you will find that even when you have no motive to be false, it is a very hard thing to say exact truth.	ELIOT George	Adam Bede, II, 17		520     ironie de soi	1819-1880. (Mary Ann Evans) (Anglaise)	berkeley	2329
Le ridicule déshonore plus que le déshonneur.	LA ROCHEFOUCAULD François de	Maximes		120     grégarité	1613-1680.	berkeley	3788
Rien de tel que l'écriture pour reprendre son sang-froid.	LACOUTURE Jean	De Gaulle.	1984	441     sang-froid		berkeley	3979
La haine a sa cristallisation ; dès qu'on peut espérer de se venger, on recommence de haïr.	STENDHAL	De L"amour.		221     vanité	Henri Beyle dit STENDHAL	berkeley	5146
Il est difficile de ne pas s'exagérer le bonheur dont on ne jouit pas.	STENDHAL	Journal.		221     vanité	Henri Beyle dit STENDHAL	berkeley	5147
La tristesse est le passage de l'homme d'une plus grande perfection à une moindre perfection.	PHILIPE Anne	Le temps d"un soupir	1969	430     paradoxal émotionnel		berkeley	4695
Je ne crois pas en Dieu, mais je meurs comme si je croyais en lui.	CUREL François de	La Nouvelle Idole		546     éthique	1854-1928.	berkeley	1732
On dit que l'égoïsme ne sait pas aimer, mais il ne sait pas mieux se laisser aimer.	CUSTINE Astolphe de	Aloys ou le Religieux du mont Saint-Bernard		423     solitude	1790-1857.	berkeley	1733
Pour un enfant, le père est le maître, le chef, celui que l'on admire sans réserve, que l'on rêve d'imiter. Je voulais à tout prix savoir avec certitude que j'étais digne de lui.	TAPIE Bernard	Gagner.	1986	420     capital affectif		berkeley	5188
La seule entreprise qui m'importât, durant toute mon adolescence, était la reconquête du marché paternel.	TAPIE Bernard	Gagner.	1986	420     capital affectif		berkeley	5189
On n'est jamais aussi vainqueur ni aussi vaincu qu'on se l'imagine.	MONTALEMBERT Charles	Oeuvres polémiques et diverses, II		520     ironie de soi	1810-1870. (Charles Forbes de Tryon, comte de M.)	berkeley	4392
Je suis distrait, je n'ai de mémoire que dans le coeur.	MONTESQUIEU Charles de	Mes pensées		540     mémoire	1689-1755. (C. de Secondat, baron de La Brède et de M.)	berkeley	4456
Ne t'attache en toi qu' à ce que tu sens, qui n'est nulle part ailleurs qu'en toi-même, et crée de toi, impatiemment ou patiemment, ah ! le plus irremplaçable des êtres.	GIDE André	Les nourritures terrestres.		320     intuition		berkeley	2928
Le besoin d'avoir raison, - marque d'esprit vulgaire.	CAMUS Albert	Carnets		221     vanité	1913-1960.	berkeley	989
( ) que vos prières sollicitent un esprit sain dans un corps sain. Demandez une âme forte, exempte des terreurs de la mort et qui place parmi les bienfaits de la nature l'étape suprême de la vie ; une âme capable de supporter n'importe quels labeurs, inaccessible à la colère, aux vains désirs et qui préfère les travaux, les épreuves d'Hercule aux amours, aux festins, au duvet moelleux de Sardanapale. Je vous montre l à des biens que vous pouvez vous procurer vous-même : c'est par la vertu que passe l'unique sentier d'une vie tranquille. Si nous sommes sages, ô Fortune, ton pouvoir n'existe plus. C'est nous, oui, nous, qui te faisons déesse et qui te plaçons au ciel.	JUVENAL	Les Satires.		560     sagesse	65?/128? poète latin	berkeley	3510
L'importance sans mérite obtient des égards sans estime.	CHAMFORT Nicolas-Sébastien de	Maximes et Pensées.		230     pouvoir	1740/1794. Ac. Française	berkeley	1114
Ce n'est que par la mémoire que nous sommes un même individu pour les autres et pour nous-mêmes.	DIDEROT Denis			540     mémoire		berkeley	2117
Vouloir être de son temps, c'est déj à être dépassé 	IONESCO Eugène	Notes et Contre-notes		221     vanité	1912-.	berkeley	3385
L'homme supérieur est celui qui remplit son devoir.	IONESCO Eugène	Le Rhinocéros.		550     grandeur		berkeley	3389
Lorsque tu es enclume, souffre comme enclume ; lorsque tu es marteau, frappe comme marteau.	Dictons et Proverbes	Dicton.		440     courage		berkeley	2033
Une noble vengeance est fille d'un silence profond.	Dictons et Proverbes	Proverbe italien.		441     sang-froid		berkeley	2035
Heureux les affamés et assoiffés de justice,  car ils seront rassasiés.	Evangiles	Evangile selon saint Matthieu, V, 6		215     mystifications		berkeley	2417
Il lit au front de ceux qu'un vain luxe environne  Que la Fortune vend ce qu'on croit qu'elle donne.	LA FONTAINE Jean de	Philémon et Baucis		221     vanité	1621-1695.	berkeley	3668
Le christianisme est un caméléon éternel, il se transforme sans cesse.	VIGNY Alfred de	Journal d"un poète		215     mystifications	1797-1863.	berkeley	5292
Les dindons sont en troupe ; le lion est seul dans le désert.	VIGNY Alfred de			423     solitude		berkeley	5295
Quand, cycliquement, l'entropie culturelle se substitue au volontarisme, elle annonce une décadence économique, sociale et politique.	FAIRGAGNETR Oscar		1991	110     entropie		berkeley	2470
La vilenie des faibles est telle qu'il faudra toujours des soldats pour les protéger ou les séparer dans leurs disputes.	FAIRGAGNETR Oscar	Aphorismes.	1992	110     entropie		berkeley	2471
Le récit n'est plus l'écriture d'une aventure mais l'aventure d'une écriture [Nouveau roman & Introspection publique].	Dictons et Proverbes			510     ironie		berkeley	2048
Malhabiles nous sommes à nous atteindre, les hommes, malgré la promesse entrevue dans l'eau du regard.	FRéNAUD André	Il n"y a pas de paradis		234     communication	1907-.	berkeley	2884
Les grands écrivains n'ont jamais été faits pour subir la loi des grammairiens, mais pour imposer la leur et non pas seulement leur volonté, mais leur caprice.	CLAUDEL Paul	Positions et propositions		393     création artistique	1868-1955.	berkeley	1450
Le bonheur n'est pas le but mais le moyen de la vie.	CLAUDEL Paul	Journal		420     capital affectif	1868-1955.	berkeley	1452
La vertu est un moyen terme entre deux vices et à mi-chemin des deux.  Virtus est medium vitiorum et utrimque reductum.	Horace	Epîtres, I, XVIII, 9		520     ironie de soi	65-8 av. J.-C. (Quintus Horatius Flaccus)	berkeley	3263
Toutes les fois que les rois font des sottises, ce sont les Grecs qui pâtissent.  Quidquid delirant reges, plectuntur Achioi.	Horace	Epîtres, I, II, 14		539     ironie sociale	65-8 av. J.-C. (Quintus Horatius Flaccus)	berkeley	3264
Trop rechercher fait tomber dans la maladresse, tel le peintre qui ajouterait des pattes à un serpent.	Houang T"Ing-Kien	Traduction D. Tsan		441     sang-froid	1050-1110. (Chinois)	berkeley	3268
A droit aller, nul ne trébuche.	Dictons et Proverbes	Devise des Thomelin.		546     éthique		berkeley	2056
L'art ne rend pas ce qui est visible mais rend visible.	KLEE Paul		1939	393     création artistique		berkeley	3570
Je n'ai pas d'autre ennemi à craindre que la peur.	KNOWLES Frédéric Lawrence	La Peur.		440     courage	1869/1905. USA.	berkeley	3571
Tous pour chacun. Chacun pour tous.	CABET Etienne	Voyage en Icarie		215     mystifications	1788-1856.	berkeley	951
Bon appétit, Messieurs! O ministres intègres!  Conseillers vertueux! Voil à votre façon  De servir, serviteurs qui pillez la maison.	HUGO Victor	Ruy Blas, III, 2, Ruy Blas		238     servitudes du pouvoir politique	1802-1885.	berkeley	3300
De quelque mot profond tout homme est le disciple.	HUGO Victor	Les Contemplations		312     foi	1802-1885.	berkeley	3302
La sagesse n'a rien d'austère ni d'affecté : c'est elle qui donne les vrais plaisirs ; elle seule sait les assaisonner pour les rendre purs et durables.	FENELON	Les Aventures de Télémaque.		550     grandeur		berkeley	2682
Il me semble qu'une Académie est tout ce qu'il y a de plus antipathique au monde à la constitution même de l'Esprit, qui n'a ni règle, ni loi, ni uniforme.	FLAUBERT Gustave	Correspondance, 1842		221     vanité	1821-1880.	berkeley	2721
Il n'importe pas d'avoir été, mais d'être. Je ne suis pas : je serai. Seulement, parce que je prétends être plus que je ne suis, j'ai fait peu de cas de ce que je fus pour devenir ce que je veux être.	MOLINA Tirso de			520     ironie de soi		berkeley	4306
...la guerre est un duel où l'assaillant, seul, choisit ses armes.	RAYNAUD Paul	Discours à la Chambre des Députés (armée de métier ; chars)		225     cynisme	défendant les thèses gaull.(armée de métier; corps de manoeuvre)	berkeley	4798
Le jour où vous avez accepté la prison d'un corps mutilé, vous avez d'un seul coup obtenu la liberté. Désormais, les murs ne peuvent plus vous enfermer, les barreaux ne peuvent plus vous empêcher d'accéder aux pâturages du contentement.	WEST Morris	La seconde victoire.	1972	130     liberté		berkeley	5353
...En outre, il apparaît qu'une époque démagogique attentive à se désindividualiser envisage instinctivement une certaine forme mystérieuse de génie comme un privilège, une injustice inadmis- sible et même une manière de maladie honteuse dont bientôt un alcaloïde tiré de l'ergot du seigle délivrera les pauvres créatures qui en sont atteintes...	COCTEAU Jean			120     grégarité	article écrit à la mémoire de Mozart. Publié par André Parinaud dans "Arts" le 25 janvier 1956.	berkeley	1490
Je mettais entre les excès toutes les promesses par lesquelles on retranche quelque chose de sa liberté.	DESCARTES René	Discours de la méthode		433     perversion	1596-1650.	berkeley	1941
Les propos du président américain achevèrent de me prouver que, dans les affaires entre Etats, la logique et le sentiment ne pèsent pas lourd en comparaison des réalités de la puissance ; que ce qui importe, c'est ce que l'on prend et ce que l'on sait retenir ; que la France, pour retrouver sa place, ne doit compter que sur elle-même ...	DE GAULLE Charles	Mémoires de guerre		441     sang-froid		berkeley	1848
Ne vous servez donc pas de ce terme élevé d'idéal quand nous avons pour cela, dans le langage usuel, l'excellente expression de mensonge.	IBSEN Henrik	Le Canard sauvage		433     perversion	1828-1906. (Norvégien)	berkeley	3380
Tout homme est une histoire sacrée.	LA TOUR DU PIN Patrice de	Somme de Poésies.		330     coeur		berkeley	3948
La forme est la soeur jumelle de la liberté.	IHERING			130     liberté	juriste allemand du XIXe siècle.	berkeley	3381
Avec le talent, on fait ce qu'on veut. Avec le génie, on fait ce qu'on peut.	INGRES Dominique			390     création	1780-1867.	berkeley	3382
Une forme d'expression établie est aussi une forme d'oppression.	IONESCO Eugène	Notes et Contre-notes		214     guerre du savoir	1912-.	berkeley	3383
Pour écrire bien, il faut sauter les idées intermédiaires, assez pour n'être pas ennuyeux; pas trop, de peur de n'être pas entendu.	MONTESQUIEU Charles de	Mes pensées		234     communication	1689-1755. (C. de Secondat, baron de La Brède et de M.)	berkeley	4425
L'homme est plus intéressant que les hommes : c'est lui et non pas eux que Dieu a fait à son image. Chacun est plus précieux que tous.	GIDE André			539     ironie sociale	\\010s\\004 à\\020	berkeley	2946
La première vertu révolutionnaire, c'est l'art de faire foutre les autres au garde- à-vous.	GIONO Jean	Le Hussard Sur Le Toit.		215     mystifications		berkeley	2948
Je ne crois pas à l'importance de ce que je fais, mais je crois important de savoir ce que je fais.	GIROUD Françoise	Ce que je crois.		520     ironie de soi	\\010r&#225;&#240;\\020	berkeley	2967
S'il fallait tenir compte des services rendus à la science, la grenouille occuperait la première place.	BERNARD Claude	Introduction à l"étude de la médecine expérimentale		510     ironie	1813-1878.	berkeley	706
Le seul péché est de ne pas se risquer pour vivre son désir.	DOLTO Françoise	L"Evangile au risque de la psychanalyse.		431     désir	L"Evangile au risque de la psychanalyse.	berkeley	2131
Béni soit celui qui inventa le sommeil.	CERVANTES SAAVEDRA Miguel de	Don Quichotte.		510     ironie	1547-1616. (Espagnol)	berkeley	1094
Seule la vérité peut affronter l'injustice. La vérité, ou bien l'amour.	CAMUS Albert	Requiem pour une nonne		130     liberté	1913-1960.	berkeley	984
Ce qui m'a toujours beaucoup nui, c'est que j'ai toujours trop méprisé ceux que je n'estimais pas.	MONTESQUIEU Charles de	Mes pensées		221     vanité	1689-1755. (C. de Secondat, baron de La Brède et de M.)	berkeley	4421
Pour que l'on ne puisse abuser du pouvoir, il faut que, par la disposition des choses, le pouvoir arrête le pouvoir.	MONTESQUIEU Charles de	L"Esprit des lois.	1748	232     servitudes du pouvoir		berkeley	4422
Avec des amis comme ceux-l à, on peut se passer d'ennemis.	Dictons et proverbes	Proverbe anglais.	1991	510     ironie		berkeley	2070
Il faut se prêter aux autres et ne se donner qu' à soi-même.	MONTAIGNE Michel Eyquem de			441     sang-froid		berkeley	4362
Le plus grave défaut est de ne pas connaitre ses défauts.	CESBRON Gilbert	Journal sans date.		360     bon sens		berkeley	1099
La paix, le commerce, une honnête amitié avec toutes les nations, d'étroites alliances avec aucune.	JEFFERSON	Discours inaugural. (?)	1801	232     servitudes du pouvoir		berkeley	3433
La moindre chose contient un peu d'inconnu. Trouvons-le.	MAUPASSANT Guy de	Pierre et Jean		341     étonnement	1850-1893.	berkeley	4251
Je ne sais pas posséder.	CAMUS Albert	L"Envers et l"endroit		520     ironie de soi	1913-1960.	berkeley	1023
Je n'aime pas le travail, nul ne l'aime ; mais j'aime ce qui est dans le travail l'occasion de se découvrir soi-même, j'entends notre propre réalité, ce que nous sommes à nos yeux, et non pas en facade.	CONRAD Joseph	Le coeur des ténèbres.		380     travail		berkeley	1616
La dernière illusion est de croire qu'on les a toutes perdues.	CHAPELAN Maurice	Main courante		442     démission	1906-.	berkeley	1172
Il faut être l'homme de la pluie et l'enfant du beau temps.	CHAR René	Le Marteau sans maître		441     sang-froid	1907-1988.	berkeley	1183
L'orgueil ne veut pas devoir et l'amour-propre ne veut pas payer.	LA ROCHEFOUCAULD François de	Maximes.		221     vanité		berkeley	3815
Malheur aux gens qui n'ont jamais tort; ils n'ont jamais raison.	LIGNE Prince de	Mes écarts		221     vanité	1735-1814.	berkeley	4133
Tout est disposé en faveur du pessimiste. Mais le pessimiste s'est toujours trompé.	CHARDONNE Jacques	L"Amour, c"est beaucoup plus que l"amour		442     démission	1884-1968.	berkeley	1199
Le courage réel est plus patient qu'audacieux.	SENANCOUR Etienne Pivert de			441     sang-froid	1770-1846.   De l"amour considéré dans les lois réelles et dans les formes sociales de l"union des sexes	berkeley	5000
Le mensonge est l'arme des forts.	ZEVACO Michel	Les Pardaillan		214     guerre du savoir	1860-1918.	berkeley	5520
Tous égo.	NAHON Pierre			520     ironie de soi		berkeley	4554
Ne demandez pas ce que votre pays peut faire pour vous, mais ce que vous pouvez faire pour votre pays.	KENNEDY John F.			215     mystifications		berkeley	3544
La continuité des grands spectacles nous fait sublimes ou stupides. Sur les Alpes on est aigle ou crétin.	HUGO Victor	Tas de pierres		520     ironie de soi	1802-1885.	berkeley	3340
Un sot n'a pas assez d'étoffe pour être bon.	LA ROCHEFOUCAULD François de	Maximes		330     coeur	1613-1680.	berkeley	3847
Ecrire donne un sens à la vie la plus tortueuse.	NIN Anaïs	Journal.		393     création artistique		berkeley	4598
La virilité d'une idée ne consiste pas moins dans sa puissance à créer un passage à travers la pensée contemporaine que dans sa capacité à dominer les mouvements futurs.	KAKUZO O.	Le Livre du Thé.		440     courage	440     cour\\010vé à\\010vë à	berkeley	3532
Renoncez à l'étude et vous n'aurez aucun souci.	LAO TSE			510     ironie		berkeley	4028
Le mal que font les hommes vit après eux ; le bien est souvent enseveli avec leurs cendres.	SHAKESPEARE William	Jules César.		210     violence		berkeley	5044
Ce qui commence dans le mal s'affermit dans le mal.	SHAKESPEARE William	Macbeth, III,2.		210     violence		berkeley	5045
Le succès est une conséquence et ne doit pas être un but.	FLAUBERT Gustave	L"amour de l"art.	1915	441     sang-froid	1821/1880, édition posthume	berkeley	2771
Avec l'énorme spécialisation engendrée par la recherche scientifi- que ( ), des individualités de premier rang dans leur domaine propre ont rarement la possibilité et le courage de rendre d'éminents services à la communauté au niveau des instances politiques internationales. Car cel à implique une grande puissance de travail, une vive intelligence et une réputation fondée sur des travaux d'envergure. Cela exige aussi une indépendance des préjugés nationaux ( ) et, enfin, un dévouement aux buts communs à tous.	EINSTEIN Albert	Comment je vois le Monde	1934	550     grandeur	rééd. augm. en 1952 et 1978.	berkeley	2325
La soumission implique la possibilité de l'arrogance et de la révolte: de la stabilité sort le mouvement.	CAILLOIS Roger	L"Homme et le sacré		441     sang-froid	1913-1978.	berkeley	966
Je me méfie de ceux qu'on dit visionnaires: les voyants vont vers leur plaisir en vision comme tout homme vers ses amours.	LA TOUR DU PIN Patrice de	Une somme de poésie		441     sang-froid	1911-1975.	berkeley	3951
Il faut aller si peu, mais si peu, au-del à ...	LA TOUR DU PIN Patrice de	Une somme de poésie		441     sang-froid	1911-1975.	berkeley	3952
Les hommes ne s'attachent point à nous en raison des services que nous leur rendons, mais en raison de ceux qu'ils nous rendent.	LABICHE Eugène	Le Voyage de M. Perrichon		120     grégarité	1815-1888	berkeley	3956
Désirer l'immortalité, c'est désirer la perpétuation éternelle d'une grande faute.	SCHOPENHAUER Arthur	La mode comme volonté et comme représentation.		221     vanité		berkeley	4976
Qu'il se discipline et qu'il se fasse ; toujours en effort, toujours en ascension. Apprendre difficilement les choses faciles. Après cela bondir et crier, selon la nature animale. Progrès, dit l'Ombre, par oppositions et négations.	CHARTIER Emile	"Propos" La Dépèche de Rouen.	1913	421     initiation	alias ALAIN. l""Ombre" de Hegel	berkeley	1249
Les vices entrent dans la composition des vertus, comme les poisons entrent dans la composition des remèdes.	LA ROCHEFOUCAULD François de	Maximes		546     éthique	1613-1680.	berkeley	3942
La plus véritable marque d'être né avec de grandes qualités, c'est d'être né sans envie.	LA ROCHEFOUCAULD François de	Réflexions ou Sentences et Maximes morales.		550     grandeur	1613/1680	berkeley	3943
Voltaire parle à un parti, Molière parle à la société, Shakespeare parle à l'homme.	HUGO Victor	Littérature et philosophie mêlées		393     création artistique	1802-1885.	berkeley	3317
Bergers, bergers, le loup n'a tort  Que quand il n'est pas le plus fort! 	LA FONTAINE Jean de	Fables, le Loup et les Bergers		210     violence	1621-1695.	berkeley	3654
Si nous résistons à nos passions, c'est plus par leur faiblesse que par notre force.	LA ROCHEFOUCAULD François de	Maximes		321     volonté	1613-1680.	berkeley	3842
Il n'y a que les personnes qui ont de la fermeté qui puissent avoir une véritable douceur.	LA ROCHEFOUCAULD François de	Maximes		321     volonté	1613-1680.	berkeley	3843
In vino veritas.	Dictons et Proverbes	Latinisme.		234     communication		berkeley	2010
Loin de la vérité, les mots mentent tout seuls.	CROMMELYNCK Fernand	Chaud Et Froid.		215     mystifications	1886-1970	berkeley	1722
Aimez, aimez, tout le reste n'est rien.	LA FONTAINE Jean de	Les Amours de Psyché et de Cupidon		531     communication amoureuse	1621-1695.	berkeley	3758
Mets les choses à leur place, elles te mettront à la tienne.	Dictons et Proverbes	Proverbe arabe		380     travail		berkeley	2016
Cette responsabilité totale dans la solitude, n'est-ce pas le	SARTRE Jean-Paul	La République du Silence	1944	423     solitude	édition du groupe COMBAT de FRENAY, in n°1 Lettres Françaises (09/44)	berkeley	4957
Dans les affaires, comme en amour, il est un moment où l'on doit s'abandonner.	GRASSET Bernard	Remarques sur l"action		234     communication	1881-1955.	berkeley	3006
Le principal en ce monde est de tenir son âme dans une région haute, loin des fanges bourgeoises et démocratiques. Le culte de l'art donne de l'orgueil ; on n'en a jamais trop.	FLAUBERT Gustave	L"amour de l"art.	1915	422     confiance en soi	(1821/1880) édition posthume	berkeley	2759
Imaginer c'est choisir.	GIONO Jean	Noë.		350     imagination		berkeley	2951
Un optimiste est un homme qui regarde vos yeux, un pessimiste, un homme qui regarde vos pieds.	CHESTERTON Gilbert Keith	Othodoxie.		430     paradoxal émotionnel		berkeley	1348
Deux coqs vivaient en paix: une poule survint,  Et voil à la guerre allumée.	LA FONTAINE Jean de	Fables		530     ironie amoureuse	1621-1695.	berkeley	3755
Dans le caractère de notre nation, il y a toujours une tendance à exercer la force, quand on la possède, ou les prétentions du pouvoir, quand on le tient en main.	NERVAL Gérard de	Les Filles du feu, Angélique		510     ironie	1808-1855. (Gérard Labrunie)	berkeley	4578
Les grandes formes artistiques nécéssitent une certaine connaissance du monde, une expérience profonde des relations humaines... Il n'en va pas de même de ces autres activités abstraites où le talent est la clé et l'expérience n'est qu'un complément. Je veux parler de la musique, des mathématiques... Des échecs.	PEREZ-REVERTE Arturo	Le Tableau du Maître flamand	1990	393     création artistique		berkeley	4670
Renier son âge, c'est renier sa vie.	PEREZ-REVERTE Arturo	Le Maître d"escrime	1985	433     perversion		berkeley	4673
Comme osera la bouche dire 	CHARTIER Alain	Rondeau 		330     coeur	1385-1433.  *Coeur.	berkeley	1207
La simplicité affectée est une imposture délicate.	LA ROCHEFOUCAULD François de	Maximes.		221     vanité		berkeley	3802
J'errais solitaire comme un nuage Qui flotte, l à-haut, par monts et par vaux.	WORDSWORTH William	Poèmes sur l"imagination.		423     solitude		berkeley	5496
L'arbitraire n'est pas seulement funeste lorsqu'on s'en sert pour le crime. Employé contre le crime, il est encore dangereux.	CONSTANT Benjamin	Des réactions politiques		546     éthique	1767-1830. (Henri-B. de Rebecque)	berkeley	1633
L'ignorance et la superstition ont toujours un rapport étroit et même mathématique entre elles.  Ignorance and superstition ever bear a close and even a mathematical relation to each other.	COOPER James Fenimore	Jack Tier, 13		110     entropie	1789-1851. (Américain)	berkeley	1634
Dieu n'impose à chaque homme que ce qu'il peut porter.	Coran	Coran, II, 286		550     grandeur		berkeley	1641
Mais à l'époque, j'agis dans un crépuscule où s'annulaient les différences. Raciste, je pensai que les croyances d'autrui sont pour l'homme fort des occasions d'amènes rêveries.	ECO Umberto	Le Pendule de Foucault	1988	221     vanité		berkeley	2265
Les bourgeois, par une vanité ridicule, font de leurs filles un fumier pour les terres des gens de qualité.	CHAMFORT Nicolas-Sébastien de	Maximes et pensées		221     vanité	1740/1794. Ac. Française	berkeley	1112
Pour être heureux en amour, il faut que la femme attende et que l'homme croit.	Dictons et Proverbes	Dicton Astèque.	1992	530     ironie amoureuse	\\010jë@\\020	berkeley	2053
Toutes les dettes reçoivent quelque compensation, mais seul l'amour peut payer l'amour.  Todas las deudas del mundo reciben compensacion en diverso género; el amor no admite sino solo amor por paga.	ROJAS Fernando de	La Célestine, 16		531     communication amoureuse	v. 1465-v. 1541. (Espagnol)	berkeley	4842
Un grand artiste écrit presque fatalement une oeuvre gaie quand il est triste, une oeuvre triste quand il est gai.	ROLLAND Romain	Musiciens d"aujourd"hui.		393     création artistique		berkeley	4844
Il n'y a plus de patrie; je ne vois d'un pôle à l'autre que des tyrans et des esclaves.	DIDEROT Denis	Le Neveu de Rameau		120     grégarité	1713-1784.	berkeley	2076
Dans la nature, toutes les espèces se dévorent: toutes les conditions se dévorent dans la société.	DIDEROT Denis	Le Neveu de Rameau		210     violence	1713-1784.	berkeley	2077
Je suis le bon pasteur.  Le bon pasteur donne sa vie pour ses brebis.	Evangiles	Evangile selon saint Jean, X, 11		215     mystifications		berkeley	2427
La bienfaisance est bien plutôt un vice de l'orgueil qu'une véritable vertu de l'âme.	SADE Marquis de	La Philosophie dans le boudoir		221     vanité	1740-1814.	berkeley	4905
Seul celui qui aime existe.  Nur der ist etwas, der etwas liebt.	FEUERBACH Ludwig	Critiques philosophiques, 2		420     capital affectif	1804-1872. (Allemand)	berkeley	2703
Nos vrais ennemis sont en nous-mêmes.	BOSSUET Jacques Bénigne			423     solitude		berkeley	805
L'amour-propre est le plus grand de tous les flatteurs.	LA ROCHEFOUCAULD François de	Maximes.		520     ironie de soi		berkeley	3912
[...] celui qui, venu en visite, garde le silence, est une branche morte sur l'arbre de l'humanité.	WEST Morris	Le Loup Rouge.	1971	234     communication		berkeley	5370
[...] bien des gens tuaient leur oeuvre à force de parler [...]	WEST Morris	Les Bouffons de Dieu.	1981	234     communication		berkeley	5371
Mourir, c'est facile. Faire rire, c'est difficile.	BRUCE Lenny			390     création		berkeley	882
Toute vie véritable est rencontre.	BUBER Martin	Le Je et le Tu.		234     communication		berkeley	883
La Révolution, comme Saturne, dévore ses propres enfants.  Die Revolution ist wie Saturn, sie frißt ihre eigenen Kinder.	BÜCHNER Georg	La Mort de Danton		110     entropie	1813-1837. (Allemand)	berkeley	884
Les arbres sont responsables de plus de pollution aérienne que les usines.	REAGAN Ronald			215     mystifications		berkeley	4799
La musique, cette sublime entremetteuse...	DE GAULLE Charles			460     plaisir		berkeley	1852
Quand notre mérite baisse, notre goût baisse aussi.	LA ROCHEFOUCAULD François deo	Maximes.		110     entropie	1613/1680	berkeley	3947
Il ne peut y avoir de réalisme véritable que si l'on fait sa part à l'imagination, si l'on comprend que l'imaginaire est dans le réel, et que nous voyons le réel par lui.	BUTOR Michel	Répertoire, II		350     imagination	1926-.	berkeley	934
Les douleurs de la conscience sont des choses dangereuses.  Extirpons la conscience - il n'y aura plus de douleur.	EVTOUCHENKO Evgheni Aleksandrovitch	Les Affres de la conscience		442     démission	1933-. (Russe)	berkeley	2440
(L'homme) est une plante qui porte des pensées, comme un rosier porte des roses, et un pommier des pommes.	FABRE D"OLIVET Antoine	L"Histoire philosophique du genre humain		510     ironie	1768-1825.	berkeley	2441
La guerre, l'art de tuer en grand et de faire avec gloire ce qui, fait en petit, conduit à la potence.	FABRE Jean Henri	Souvenirs emtomologiques.		211     guerre		berkeley	2442
Le désir fleurit, la possession flétrit toute chose.	PROUST Marcel	flétrit tout\\001ÇS&#240;\\001ÇW†		510     ironie		berkeley	4737
Que celui qui a des oreilles entende! 	Evangiles	Evangile selon saint Matthieu, XIII, 9		225     cynisme		berkeley	2430
La jeunesse attend toujours d'un nouveau dieu, d'un nouveau chef ce qu'elle n'obtiendra qu' à force de vieillir.	BRASILLACH Robert	La Reine De Césarée.		421     initiation		berkeley	835
Les braves gens n'aiment pas que l'on suive une autre route qu'eux.	BRASSENS Georges	Les braves gens...		110     entropie		berkeley	836
Oh! que ce monde-ci serait une bonne comédie si l'on n'y faisait pas un rôle.	DIDEROT Denis	Lettres		221     vanité	1713-1784.	berkeley	2082
'Entre le peuple et la Bastille, c'est toujours la Bastille qui finit par avoir tort.'	DE GAULLE Charles		1942	546     éthique		berkeley	1858
Un seul être vous manque, et tout est dépeuplé! 	LAMARTINE Alphonse de	Premières Méditations poétiques		530     ironie amoureuse	1790-1869.	berkeley	4011
Sois le maudit et non le maudissant.	Le Talmud	Sanhedrin.		440     courage		berkeley	4077
Apprendre à ne plus penser, c'est une partie, et non la moindre, de l'art de penser.	CHARTIER Emile	Esquisses De L"homme.		441     sang-froid	alias Alain (1868-1951)	berkeley	1273
Le corps humain est le tombeau des dieux.	CHARTIER Emile	Système Des Beaux-arts.		520     ironie de soi	alias Alain (1868-1951)	berkeley	1277
Nous essayons de nous faire honneur des défauts que nous ne voulons pas corriger.	LA ROCHEFOUCAULD François de	Maximes.		221     vanité	1613/1680	berkeley	3799
Tout pouvoir légitime est issu d'une usurpation.	DU CAMP Maxime	L"Attentat Fieschi		231     légitimité du pouvoir	1822-1894.	berkeley	2170
Nul lieu n'offre de la vanité des espérances humaines une preuve plus frappante qu'une bibliothèque publique.  No place affords a more striking conviction of the vanity of human hopes, than a public library.	JOHNSON Samuel	In le journal The Rambler, 23 mars 1751		510     ironie	1709-1784. (Anglais)	berkeley	3448
Il n'y a point de plaisir qui ne perde à être connu.	MARIVAUX Pierre Carlet de Chamblain de	Le Paysan parvenu		460     plaisir	1688-1763.	berkeley	4232
Le son du tambour dissipe les pensées; c'est par cela même que cet instrument est éminemment militaire.	JOUBERT Joseph	Carnets		120     grégarité	1754-1824.	berkeley	3449
Quand on écrit avec facilité, on croit toujours avoir plus de talent qu'on n'en a.	JOUBERT Joseph	Carnets		221     vanité	1754-1824.	berkeley	3450
Il y a des gens qui n'ont de la morale qu'en pièce; c'est une étoffe dont ils ne se font jamais d'habit.	JOUBERT Joseph	Pensées		221     vanité	1754-1824.	berkeley	3451
Les lois morales sont les règles d'un jeu auquel chacun triche, et cel à depuis que le monde est monde.	COCTEAU Jean	Le Grand Ecart		510     ironie		berkeley	1522
M***, pour peindre d'un seul mot la rareté des honnêtes gens, me disait que, dans la société, l'honnête homme est une variété de l'espèce humaine.	CHAMFORT Nicolas-Sébastien de	Caractères et anecdotes		510     ironie	1740/1794. Ac. Française	berkeley	1136
Faire consister la force du mariage dans celle de l'amour, c'est aller jusqu' à méconnaître l'esprit de cette institution.	SENANCOUR Etienne Pivert de			530     ironie amoureuse	1770-1846.   De l"amour considéré dans les lois réelles et dans les formes sociales de l"union des sexes	berkeley	5001
Il est tout à fait d'un philosophe, ce sentiment de s'étonner. La philosophie n'a point d'autre origine...	PLATON	Théétète.		341     étonnement		berkeley	4715
Certaines âmes vont à l'absolu comme l'eau va à la mer.	MONTHERLANT Henry Millon de	Les Jeunes Filles		140     rapport à la cosmogonie	1896-1973.	berkeley	4463
La société est composée de deux grandes classes: ceux qui ont plus de dîners que d'appétit et ceux qui ont plus d'appétit que de dîners.	CHAMFORT Nicolas-Sébastien de	Maximes et pensées		510     ironie	1740/1794. Ac. Française	berkeley	1138
La fausse modestie est le plus décent de tous les mensonges.	CHAMFORT Nicolas-Sébastien de	Maximes et pensées		510     ironie	1740/1794. Ac. Française	berkeley	1139
Aller vite lentement.	COCTEAU Jean	Journal d"un inconnu		390     création	1889-1963.	berkeley	1503
Attendre d'en savoir assez pour agir en toute lumière, c'est se condamner à l'inaction.	ROSTAND Jean	Inquiétudes D"un Biologiste.		440     courage		berkeley	4872
La justice est souvent le masque du courroux.	ROTROU Jean de	Venceslas, V, 6		222     fourberie	1609-1650.	berkeley	4875
Plus une calomnie est difficile à croire,  Plus pour la retenir les sots ont de mémoire.	DELAVIGNE Casimir	Louis XI		221     vanité	1793-1843.	berkeley	1884
Vivre pour mes amis, mes livres et moi-même.	DELILLE Abbé Jacques	L"Homme des champs		560     sagesse	1738-1813.	berkeley	1893
La phrase de Gustave Flaubert est une belle automobile en panne.	DELTEIL Joseph	Choléra		393     création artistique	1894-1978.	berkeley	1894
Un programme informatique peut être d'une beauté aussi complexe que celle d'un arbre, aussi fascinante que la plus belle toile. [...] Un bon analyste utilise au mieux le potentiel de sa machine pour concevoir des mondes où d'autres pourront vivre. Et parfois se battre.	CAMP John	Trajectoire de fou	1989	392     création économique		berkeley	981
Le dogmatisme inhérant à l'enseignement fait fleurir chez nous les doctrines d'école que leur caractère spéculatif et absolu rend à la fois séduisantes et périlleuses et qui nous ont coûté si cher !	DE GAULLE Charles	1ere Leçon à l"Ecole supérieure de guerre.	1927	221     vanité	221     vani\\010uL@\\010uPp	berkeley	1801
Les querelles ne dureraient pas longtemps, si le tort n'était que d'un côté 	LA ROCHEFOUCAULD François de	Maximes		510     ironie	1613-1680.	berkeley	3902
Quand on n'aime pas trop, on n'aime pas assez.	BUSSY-RABUTIN Roger de Rabutin	Maximes d"amour pour les femmes		530     ironie amoureuse	1618-1693. comte de Bussy	berkeley	923
On ne devient homme véritable qu'en se conformant à l'enseignement des mythes, en imitant les dieux.	ELIADE Mircea	Le Sacré et le profane		421     initiation	1907-1986.	berkeley	2327
Il n'y a pas d'éloquence solitaire et tout orateur a deux génies, le sien et celui du siècle qui l'écoute.	LACORDAIRE			234     communication		berkeley	3969
Je compris alors ce que c'était que le bonheur parfait, quelque chose de très proche de la tristesse.	CHAPLIN Charlie			510     ironie		berkeley	1174
L'éternité n'est guère plus longue que la vie.	CHAR René			441     sang-froid	cité dans "La belle histoire" de Claude Lelouch	berkeley	1175
Voir ce qui est juste et ne pas le faire est de la couardise.	CONFUCIUS	Entretiens familiers. II,24		110     entropie		berkeley	1589
Le livre est un grand arbre émergé des tombeaux.	JARRY Alfred	Les Minutes de sable mémorial		540     mémoire	1873-1907.	berkeley	3428
Si l'on a baptisé Jules Renard 'l'oeil', j'appellerai Picasso le 'regard' 	CENDRARS Blaise	Aujourd"hui		393     création artistique	1887-1961. (Frédéric Sauser)	berkeley	1085
Tout homme qui a été professeur garde en lui quelque chose de l'écolier.	VIGNY Alfred de	Mémoires inédits		510     ironie	1797-1863.	berkeley	5298
On nous veut avec les stigmates des grandes écoles, je le veux avec les stigmates de la vie. Savoir s'il est agrégé en soleil. S'il a ses grades en désespoirs.	GIONO Jean	Virgile.		421     initiation		berkeley	2955
La poésie, c'est quelque chose qui marche par les rues.  La poesía es algo que anda por las calles.	GARCIA LORCA Federico	Al habla con F. García Lorca, 1936		393     création artistique	1899-1936. (Espagnol)	berkeley	2909
Comme un vol de gerfauts hors du charnier natal,  Fatigués de porter leurs misères hautaines,  De Palos de Moguer, routiers et capitaines  Partaient, ivres d'un rêve héroïque et brutal.  (. ..)  Et les vents alizés inclinaient leurs antennes  Aux bords mystérieux du monde occidental.  ...  Ou penchés à l'avant des blanches caravelles,  Ils regardaient monter en un ciel ignoré  Du fond de l'océan des étoiles nouvelles.	HEREDIA José Maria de	Ils regardaient monter en un ci		440     courage	1842-1905.	berkeley	3160
Le temps des hommes est de l'éternité pliée.	COCTEAU Jean	La Machine infernale		510     ironie	1889-1963.	berkeley	1523
L'éducation n'est pas le fait de l'école, mais bien de quelque vertu qu'on porte en soi.	BROMFIELD Louis	Mrs. Parkington.		421     initiation		berkeley	865
Le poids ne se sent fort que dans la balance.	CHAZAL Malcolm de	Poèmes		221     vanité	1902-1981.	berkeley	1322
L'exclusion n'est-elle pas le résultat conjugué d'une pression externe autant que d'un sentiment entretenu au plus profond de soi.	CAMUS Patrick	Prost/Ligier Acte 1 Scène 2. Le miroir à double face.	1992	110     entropie	in Auto Hebdo n°814.	berkeley	1031
Il n'y a que le méchant qui soit seul.	DIDEROT Denis	Le Fils naturel, IV, 3, Constance		423     solitude	1713-1784. Cette phrase, en 1758, brouilla Diderot avec Rousseau, qui se crut visé.	berkeley	2106
Comprendre, c'est pardonner.	STAEL Madame de	Corinne.		330     coeur		berkeley	5124
Ce qui est maintenant prouvé ne fut jadis qu'imaginé.  What is now proved was once only imagined.	BLAKE William	The Marriage of Heaven and Hell		390     création	1757-1827. (Anglais)	berkeley	758
Aller jusqu'au bout, ce n'est pas seulement résister, mais aussi se laisser aller.	CAMUS Albert	Carnets		440     courage	1913-1960.	berkeley	1013
Notre vie est semblable à la mer vagabonde,  Où le flot suit le flot, et l'onde pousse l'onde,  Surgissant à la fin au havre de la mort.	CHASSIGNET Jean-Baptiste	Le Mespris de la vie et consolation contre la mort		510     ironie	v. 1570-v. 1635.	berkeley	1285
Nous abritons un ange que nous choquons sans cesse. Nous devons être les gardiens de cet ange.	COCTEAU Jean	Le Rappel à l"ordre		546     éthique	1889-1963.	berkeley	1537
L'extrême limite de la sagesse, voil à ce que le public baptise folie.	COCTEAU Jean	Le Rappel à l"ordre		560     sagesse	1889-1963.	berkeley	1538
Quand les mystères sont très malins, ils se cachent dans la lumière.	GIONO Jean	Ennemonde.		370     esprit		berkeley	2952
Les exemples vivants sont d'un autre pouvoir.	CORNEILLE Pierre	Le Cid, I, 3, le comte		432     expérience	1606-1684.	berkeley	1664
(Les 'Du Kowor' [les lutteurs de l'Esprit]. Spiritualité de certains Russes Blancs, sans prêtres, ni clergé, ni immanence, ni religion. Pratiquée par communautés RB installées de par le monde.)	FAIRGAGNETR Oscar	Notes.	1994	546     éthique	Reportage de Faut pas rêver, F3 le 29/04/94.	berkeley	2646
La vraie peur, c'est quelque chose comme une réminiscence des terreurs fantastiques d'autrefois.	MAUPASSANT Guy de	Contes de la bécasse, la Peur		420     capital affectif	1850-1893.	berkeley	4253
Si on nous apporte sous le titre de l'esprit quelque chose qui ne soit contenue en l'Evangile, ne le croyons pas.	CALVIN Jean	Institution de la religion chrétienne		215     mystifications	1509-1564.	berkeley	973
Dieu ne joue pas aux dés.	EINSTEIN Albert			221     vanité		berkeley	2298
Ce pour quoi tu acceptes de mourir, c'est cela seul dont tu peux vivre.	SAINT-EXUPéRY Antoine de	Citadelle		440     courage	1900-1944.	berkeley	4934
Dieu est mort ; mais telle est la nature des hommes que des millénaires durant peut-être, il y aura des cavernes où l'on montrera son ombre. Et quant à nous autres - il nous faudra vaincre son ombre aussi.	NIETZSCHE Friedrich	Le Gai Savoir.	1882	110     entropie	1844/1900	berkeley	4583
C'est une grande servitude qu'une grande carrière.  Magna servitus est magna fortuna.	Sénèque	Consolation à Polybe, 6		391     commandement		berkeley	5027
Et si je ris de toute chose ici-bas,  C'est afin de n'en pas pleurer.  And if I laugh at any mortal thing  'Tis that I may not weep.	BYRON George Gordon lord	Don Juan, IV, 4		510     ironie	1788-1824. (Anglais)	berkeley	944
Il y aurait bien moins de bavards, s'il y avait plus de faces parlantes.	CHAZAL Malcolm de	Sens plastique		510     ironie	1902-1981.	berkeley	1333
La poésie cesse à l'idée. Toute idée la tue.	COCTEAU Jean	La Difficulté d"être		393     création artistique	1889-1963.	berkeley	1507
Le tout est d'approfondir même un murmure.	CAYROL Jean	Je l"entends encore		234     communication	1911-.	berkeley	1065
Un voyage de mille milles commence par un seul pas.	Proverbe chinois			321     volonté	in M. WEST, Kaloni le navigateur.	berkeley	4739
Jamais trigneux n'aima le peigne.	Dictons et Proverbes	Dicton.		222     fourberie		berkeley	2002
L'âge moderne représente le triomphe de la médiocrité collective.	LE BON Gustave	Hier et Demain.		120     grégarité		berkeley	4060
Vous êtes aussi jeune que votre foi, aussi vieux que vos doutes, aussi jeune que votre confiance en vous, aussi vieux que vos craintes, aussi jeune que votre espoir, aussi vieux que votre désespoir.	KRAMER Edward L.	Chemins vers la puissance.		140     rapport à la cosmogonie		berkeley	3572
Quand on ne trouve pas son repos en soi-même, il est inutile de le chercher ailleurs.	LA ROCHEFOUCAULD François de	Maximes.		423     solitude		berkeley	3871
On aime à deviner les autres ; mais l'on n'aime pas à être deviné.	LA ROCHEFOUCAULD François de	Maximes.		230     pouvoir		berkeley	3832
L'homme connaît le monde non point par ce qu'il y dérobe mais par ce qu'il y ajoute.	CLAUDEL Paul	Art poétique		390     création	1868-1955.	berkeley	1447
Quand mon plan est fait, ma pièce est faite.	RACINE Jean			320     intuition		berkeley	4776
Mon père, un brave homme, me disait : 'Ne perds jamais ton ignorance ; tu ne pourras pas la remplacer.	REMARQUE Erich		1946	421     initiation	interview	berkeley	4805
On confond toujours l'homme et l'artiste, car le hasard les a unis dans un même corps.	RENARD Jules	Journal.		120     grégarité		berkeley	4811
Rien n'est plus dangereux qu'une idée, quand on n'a qu'une idée.	CHARTIER Emile	Propos Sur La Religion.		221     vanité	alias Alain (1868-1951)	berkeley	1211
Qui est mécontent des autres est toujours mécontent de soi ; nos flèches rebondissent sur nous.	CHARTIER Emile	Propos D"un Normand.		221     vanité	alias Alain (1868-1951)	berkeley	1212
Un auteur gâte tout quand il veut trop bien faire.	LA FONTAINE Jean de	Fables		390     création	1621-1695.	berkeley	3706
Le plus semblable aux morts meurt le plus à regret.	LA FONTAINE Jean de	Fables		433     perversion	1621-1695.	berkeley	3718
Est bourgeois tout ce qui vit de persuader.	CHARTIER Emile	Les Idées Et Les Ages.		221     vanité	alias Alain (1868-1951)	berkeley	1213
Il n'y a pas de petites ressources pour le génie, il n'y en a que de possibles ou d'impossibles.	CéLINE L.-F.	Semmelweis		390     création	1894-1961. (Louis-Ferdinand Destouches)	berkeley	1072
Le privilège de l'Anglais est de ne comprendre aucune autre langue que la sienne. Et même s'il comprend, il ne doit en aucun cas s'abaisser à le laisser croire.	DANINOS Pierre	Les Carnets du major W. Marmaduke Thompson		539     ironie sociale	1913-.	berkeley	1746
Le miracle est, avec la vigne, l'une des principales cultures de la France.	DANINOS Pierre	Les Carnets du major W. Marmaduke Thompson		539     ironie sociale	1913-.	berkeley	1747
Ce ne sont pas des mots qu'il faut au marché, c'est de la monnaie.	Hérondas	Mimes, VII, 49-50		230     pouvoir	début du IIIe s. av. J.-C.	berkeley	3168
Dénigrer, se dénigrer : une seule et même défaîte.	FAIRGAGNETR Oscar	Vitalités.	1992	110     entropie		berkeley	2475
Cette entrevue s'annonçait cruciale : sa première passe d'armes avec le grand requin blanc, celle où toutes ses forces seraient mises à l'épreuve et les limites de sa faiblesse explorées sans merci.	WEST Morris	De main de Maître.	1988	441     sang-froid		berkeley	5433
Un innocent ne savait pas que c'était impossible, alors il l'a fait.	Dictons et Proverbes	Proverbe américain		390     création		berkeley	2017
La rouille aux dents pourries ronge le trésor caché, Mais l'or mis en service attire plus d'or.	Dictons et Proverbes	Vénus et Adonis		392     création économique		berkeley	2018
Celui qui a vu son semblable au plus bas de la déchéance n'a plus les mêmes yeux : il a détruit sans le savoir le mur qui séparait l'homme de son image.	BOUSQUET Joë	D"une Autre Vie.		234     communication		berkeley	822
J'ai voulu être capable de me faire aimer de ma vie.	BOUSQUET Joë	Lettres A Poisson D"Or..		422     confiance en soi		berkeley	824
Il faut savoir faire la part du médiocre.	BOYLESVE René	Feuilles Tombées.		232     servitudes du pouvoir		berkeley	826
Il n'y a point de déguisement qui puisse longtemps cacher l'amour où il est, ni le feindre où il n'est pas.	LA ROCHEFOUCAULD François de	Maximes		531     communication amoureuse	1613-1680.	berkeley	3935
Il n'y a guère de gens qui ne soient honteux de s'être aimés, quand ils ne s'aiment plus.	LA ROCHEFOUCAULD François de	Maximes		531     communication amoureuse	1613-1680.	berkeley	3936
Le caractère, qui, parfois demeure étranger au talent, anime toujours le génie.	DUHAMEL Georges	Défense des lettres		390     création	1884-1966.	berkeley	2208
Ce qu'il y a de plus utile pour former de jeunes esprits, ce sont les choses inutiles.	DUHAMEL Georges	Querelles de famille		421     initiation	1884-1966.	berkeley	2209
Il y a toujours du courage à dire ce que tout le monde pense.	DUHAMEL Georges	Le Combat contre les ombres		440     courage	1884-1966.	berkeley	2210
Le cul voudrait arriver avant la tête, mais la tête ne veut quand même pas.	DUHAMEL Georges	Le Désert de Bièvres		510     ironie	1884-1966.	berkeley	2213
Calypso ne pouvait se consoler du départ d'Ulysse. Dans sa douleur elle se trouvait malheureuse d'être immortelle.	Fénelon	Les Aventures de Télémaque		515     tragédie	1651-1715. (François de Salignac de La Mothe-)	berkeley	2698
Le bon historien n'est d'aucun temps ni d'aucun pays: quoiqu'il aime sa patrie, il ne la flatte jamais en rien.	Fénelon	Lettre à l"Académie		540     mémoire	1651-1715. (François de Salignac de La Mothe-)	berkeley	2699
Les moeurs et l'état de tout le corps de la nation ont changé d'âge en âge ... Il est cent fois plus important d'observer ce changement de la nation entière, que de rapporter simplement des faits particuliers.	Fénelon	Lettre à l"Académie		545     épistémologie	1651-1715. (François de Salignac de La Mothe-)	berkeley	2700
Mut signifie en allemand 'courage' et désignait plus anciennement (muot) le siège des affects et des sentiments (cf. anglais 'mood').	FERON Bertrand			440     courage	note de traduction d"un texte consacré par Freud au linguiste K.Abel (1910).	berkeley	2702
L'erreur est la règle; la vérité est l'accident de l'erreur.	DUHAMEL Georges	Le Notaire du Havre		515     tragédie	1884-1966.	berkeley	2215
Le serment d'un amoureux n'est pas plus valable que la parole d'un cabaretier : l'un et l'autre se portent garants de faux comptes.	SHAKESPEARE William	Comme il vous plaira.		510     ironie		berkeley	5062
Le diable est-il malade, il se fait solitaire ; L'infirmité le quitte, il quitte aussi la haire.	LEONIUS			410     santé		berkeley	4114
A ne s'imaginer qu'une seule espérance, faire rêver le monde, le plus grand nombre se consume au feu de l'énergie qui va et de l'entropie qui vient.	FAIRGAGNETR Oscar		1992	221     vanité		berkeley	2508
La haine est le privilège des imbéciles.	FAIRGAGNETR Oscar	Vitalités.	1993	221     vanité		berkeley	2505
Ni l'or ni la grandeur ne nous rendent heureux.	LA FONTAINE Jean de	Philémon et Baucis		441     sang-froid	1621-1695.	berkeley	3725
Nous sommes faits de la même étoffe que les songes et notre petite vie, un somme la parachève... (trad.Pléiade) Nous sommes de la même étoffe que celle dont les rêves sont faits et notre petite vie est cernée de sommeil. (t.M.100)	SHAKESPEARE William	La Tempête.	1611	520     ironie de soi		berkeley	5064
Il n'est qu'un esprit lézardé pour avoir des ouvertures sur l'au-del à.	CIORAN Emile-Michel	Syllogismes de l"amertume		510     ironie	1911-.	berkeley	1396
Rien n'est en soi bon ni mauvais ; tout dépend de ce qu'on en pense.	SHAKESPEARE William	Hamlet		546     éthique		berkeley	5066
Les paradoxes-vérité ont une certaine clarté charmante et bizarre qui illumine les esprits justes et qui égare les esprits faux.	HUGO Victor	Tas de pierres		365     discernement	1802-1885.	berkeley	3311
J'avais le talent pour être derrière Fangio mais pas le génie pour être devant.	MOSS Stirling		1991	520     ironie de soi		berkeley	4507
On ne fait jamais rien d'extraordinaire, de grand et de beau, qu'en y pensant plus souvent et mieux que les autres.	Louis XIV	Mémoires.		321     volonté		berkeley	4147
Qui oblige s'oblige.	ROQUEPLAN Nestor	Nouvelles A La Main.		441     sang-froid		berkeley	4860
Il y a de mauvais conseils que seule une honnête femme peut donner.	CAPUS Alfred	Les Passagères		510     ironie	1858-1922.	berkeley	1034
Chaque homme est une histoire qui n'est identique à aucune autre.	CARREL Alexis	L"Homme, cet inconnu		320     intuition	1873-1944.	berkeley	1038
S'il est incertain que la vérité que vous allez dire soit comprise, taisez-la.	MAETERLINCK Maurice	Le Double Jardin.		441     sang-froid		berkeley	4167
La douleur est le premier aliment de l'amour, et tout amour qui ne s'est pas nourri d'un peu de douleur pure meurt.	MAETERLINCK Maurice	Sur la vie.		531     communication amoureuse	1862/1949	berkeley	4171
Le diable est diable parce qu'il se croit bon.  El diablo es diablo porque se cree bueno.	MAEZTU Ramiro de	La crisis del humanismo, I, La herejía alemana		433     perversion	1875-1936. (Espagnol)	berkeley	4172
Les divinités qu'adoraient ces peuples les ont-elles sauvés ? Au contraire, elles se sont dérobées à leurs regards, et il ne leur est resté que le mensonge et le blasphème.	MAHOMET	Le Koran, XLVI.		215     mystifications		berkeley	4173
La volonté est tout aussi nécéssaire qu'insuffisante.	FAIRGAGNETR Oscar	Vitalités.	1994	321     volonté	321     volo\\010PÇ à\\010PÖÄ	berkeley	2538
L'homme n'est rien de plus grand qu'un coeur à brasser les énergies, les siennes propres et celles des autres.  Si le coeur est chaud, les énergies transformées sont productives, créatrices. S'il est sans foi, nourries aux sources du ressentiment, les énergies ne produiront rien, hors la violence, jusqu' à l'entropie complète.	FAIRGAGNETR Oscar	Vitalités.	1992	330     coeur		berkeley	2541
Il existe trois moyens de se hisser au sommet d'un arbre : 1) grimper ; 2) s'assoir sur un gland ; ou, 3) se lier d'amitié avec un grand oiseau.	MAIDMENT Robert			510     ironie		berkeley	4175
De toute évidence, il avait affaire à un rongeur de talent, facteur qui établissait la différence entre chasser et être chassé.	PEREZ-REVERTE Arturo	Le Maître d"escrime	1985	365     discernement		berkeley	4668
En escrime, ce qui est simple est inspiration. Ce qui est complexe est technique.	PEREZ-REVERTE Arturo	Le Maître d"escrime	1985	390     création		berkeley	4669
Oui, on peut jouir en couchant avec une prostituée mais il faut toujours se rendre compte que c'est une prostituée.	PICASSO Pablo		1946	510     ironie	rapporté par DHK dans un entretien donné au Point en 1952.	berkeley	4707
Les mots sans les pensées ne vont jamais au ciel.	SHAKESPEARE William	Hamlet.		370     esprit		berkeley	5049
Le plus haut des tourments humains est d'être jugé sans loi.	CAMUS Albert	La Chute		210     violence	1913-1960.	berkeley	985
Beaucoup d'amants, c'est beaucoup de malchance.	VILMORIN Louise de	La Lettre dans un taxi		530     ironie amoureuse	1902-1969.	berkeley	5303
Le gouvernement a un bras long et un bras court ; le long sert à prendre et arrive partout, le bras court sert à donner, mais il arrive seulement à ceux qui sont tout près.	SILONE I.	Le pain et le vin.		238     servitudes du pouvoir politique		berkeley	5082
Cette maison est mal en train, où la quenouille commande l'épée.	Dictons et proverbes	Dicton.		510     ironie		berkeley	2069
Les âmes excessivement bonnes sont volontiers imprudentes par excès de bonté même, et d'un autre côté, les âmes prudentes sont assez rarement bonnes.	MARIVAUX Pierre Carlet de Chamblain de	Le Paysan parvenu		330     coeur	1688-1763.	berkeley	4227
Je suis las des musées, cimetières des arts.	LAMARTINE Alphonse de	Voyage en Orient.		510     ironie		berkeley	4008
Borné dans sa nature, Infini dans ses voeux, L'homme est un dieu tombé Qui se souvient des cieux.	LAMARTINE Alphonse de	Premières Méditations poétiques.		510     ironie		berkeley	4009
Rien n'est vrai, rien n'est faux; tout est songe et mensonge,  Illusion du coeur qu'un vain espoir prolonge.  Nos seules vérités, hommes, sont nos douleurs.	LAMARTINE Alphonse de	Harmonies poétiques et religieuses, le Tombeau d"une mère		510     ironie	1790-1869.	berkeley	4010
J'aimai, je fus aimé; c'est assez pour ma tombe.	LAMARTINE Alphonse de	Le Dernier Chant du pèlerinage d"Harold		531     communication amoureuse	1790-1869.	berkeley	4012
Personne dans un théâtre n'a moins d'importance que l'auteur de la pièce.	BERNARD Tristan	Monsieur Codomat, prologue		510     ironie	1866-1947. (Paul Bernard)	berkeley	717
Par instants seulement l'homme supporte le poids de la plénitude divine.  Nur zu Zeiten erträgt göttliche Fülle der Mensch.	HÖLDERLIN Friedrich	Le Pain et le Vin		510     ironie	1770-1843. (Allemand)	berkeley	3211
Je crois fermement que si la meteria medica telle qu'elle est maintenant utilisée pouvait être précipitée au fond de la mer, ce serait pour le plus grand bien de l'humanité... et le plus grand dommage des poissons.	HOLMES Olivier W.	Discours à la Société médicale du Massachusetts.	1860	510     ironie		berkeley	3212
Il y a deux types de vérités, la vérité simple et la vérité absolue. La vérité simple est facile à reconnaître parce que c'est le contraire du mensonge. Le contraire de la vérité absolue est une autre vérité.	BOHR Niels			214     guerre du savoir		berkeley	778
Nous autres du jeu sommes hors de protection. Si nous mourons, nous mourons. Nos noms sont effacés du livre.	KIPLING Rudyard	Kim		441     sang-froid		berkeley	3566
O découvertes, et toujours découvertes ! Il n'y a qu' à attendre pour que tout s'éclaire. Au lieu d'aborder des îles, je vogue donc vers ce large où ne parvient que le bruit solitaire du coeur, pareil à celui du ressac. Rien ne dépérit, c'est moi qui m'éloigne, rassurons-nous. Le large, mais non le désert. Découvrir qu'il n'y a pas de désert : c'est assez pour que je triomphe de ce qui m'assiège.	COLETTE Sidonie Gabrielle	Le Fanal bleu.		423     solitude		berkeley	1550
C'est de ces visages innocents que naissent les plus grandes tragédies, parce qu'ils semblent ne receler aucune des ruses de la séduction.	SIMON Yves	La Dernière Passion. (Les Séductions de l"Existence)	1990	510     ironie		berkeley	5086
Il y a de bons mariages, mais il n'y en a point de délicieux.	LA ROCHEFOUCAULD François de	Maximes		530     ironie amoureuse	1613-1680.	berkeley	3932
Le plus grand miracle de l'amour, c'est de guérir de la coquetterie.	LA ROCHEFOUCAULD François de	Maximes.		531     communication amoureuse		berkeley	3933
L'absence diminue les médiocres passions et augmente les grandes, comme le vent éteint les bougies et allume le feu.	LA ROCHEFOUCAULD François de	Maximes.		531     communication amoureuse		berkeley	3934
Les nations modernes doivent cesser de croire qu'elles sont moralement supérieures parce que leur technologie est plus avancée.	GOLDSMITH Jimmy	Le Piège.	1993	221     vanité	221     vani\\010i\\035†\\010i!ê	berkeley	2988
La paix n'est pas comparable à un objet précieux qui nous appartient. Il faut toujours la conquérir.	GRIEG Nordahl	La Défaite		546     éthique	1902-1943. (Norvégien)	berkeley	3028
L'amour est toujours devant vous. Aimez.	BRETON André	Le Surréalisme et la Peinture		330     coeur	1896-1966.	berkeley	847
Plus fait douceur que violence.	LA FONTAINE Jean de	Fables, Phébus et Borée		560     sagesse	1621-1695.	berkeley	3764
Quitte tout et tu retrouveras tout; renonce à tes désirs et tu trouveras le repos.  Dimitte omnia, et invenies omnia; relinque cupidinem, et reperies requiem.	GROOTE Geert	L"Imitation de Jésus-Christ, III, 32, 4 		215     mystifications	1340-1384.  *Un des auteurs possibles de l"Imitation.	berkeley	3031
Si le fou persistait dans sa folie, il deviendrait sage.  If the fool would persist in his folly, he would become wise.	BLAKE William	The Marriage of Heaven and Hell		510     ironie	1757-1827. (Anglais)	berkeley	760
Celui qui n'a rien à faire est un imbécile.	FAIRGAGNETR Oscar	Vitalités.	1994	221     vanité		berkeley	2507
Une femme a toujours, en vérité, la situation qu'elle impose par l'illusion qu'elle sait produire.	MAUPASSANT Guy de	Notre coeur		235     séduction	1850-1893.	berkeley	4250
La victoire ne se partage pas. Elle s'assume.	FAIRGAGNETR Oscar	e pa	1990	423     solitude		berkeley	2579
La famille est une Cour de justice qui ne chôme ni nuit ni jour.	CHAZAL Malcolm de	Sens plastique		420     capital affectif	1902-1981.	berkeley	1326
Celui qui se conduit vraiment en chef ne prend pas part à l'action.	LAO TSEU	Tao tö King, LXVIII		391     commandement		berkeley	4032
Il faut mettre ses principes dans les grandes choses, aux petites la miséricorde suffit.	CAMUS Albert	L"Envers et l"endroit		441     sang-froid	1913-1960.	berkeley	1014
La route (qui mène à la misère) est plane et elle est l à tout près.	Hésiode	Les Travaux et les Jours, 288		441     sang-froid	VIIIe s. av. J.-C.	berkeley	3175
Quoi de plus bête, et qui rende plus malheureux que la lucidité.	HESSE Hermann			510     ironie		berkeley	3179
L'art n'est pas une imitation mais une conquête.	SUARES André	Goethe, le grand Européen.		393     création artistique		berkeley	5160
Etre imbécile est plus complexe. C'est un comportement social. L'imbécile est celui qui parle toujours hors de son verre.( ) Lui, il veut parler de ce qu'il y a dans son verre, mais sans savoir comment ni pourquoi, il parle en dehors.( ) C'est celui qui fait des gaffes, qui demande des nouvelles de sa charmante épouse au type que sa femme vient de plaquer.( ) L'imbécile est fort demandé, surtout dans les occasions mondaines. Il met tout le monde dans l'embarras, mais ensuite il offre matière à commentaires.	ECO Umberto	Le Pendule de Foucault	1988	120     grégarité		berkeley	2261
Il faut rire avant que d'être heureux, de peur de mourir sans avoir ri.	LA BRUYERE Jean de	Les Caractères		450     rire	1645-1696.	berkeley	3621
Vous êtes orfèvre, monsieur Josse, et votre conseil sent son homme qui a envie de se défaire de sa marchandise.	MOLIERE	L"Amour Médecin.		222     fourberie		berkeley	4297
La parfaite raison fuit toute extrémité, Et veut que l'on soit sage avec sobriété.	MOLIERE	Le Médecin Malgré Lui.		560     sagesse		berkeley	4303
Chaque homme porte la forme entière de l'humaine condition.	MONTAIGNE Michel Eyquem de	Essais, III, 2		510     ironie	1533-1592.	berkeley	4377
Et l'absence de ce qu'on aime,  Quelque peu qu'elle dure, a toujours trop duré 	Molière	Amphitryon, II, 2, Amphitryon		531     communication amoureuse	1622-1673. (Jean-Baptiste Poquelin)	berkeley	4305
- ( ) Jack, tu ne regretteras jamais d'avoir été honnête même si cela blesse quelqu'un.	CLANCY Tom	Danger Immédiat	1989	546     éthique		berkeley	1433
On ne saurait mieux comparer l'absurdité des demi-mesures qu' à celle des mesures absolues.	COURTELINE Georges	La Philosophie de G. Courteline		221     vanité	1860-1929. (Georges Moinaux)	berkeley	1699
Les hommes ne sont pas très rares qui aiment à faire payer les services qu'on leur rend.	COURTELINE Georges	La Philosophie de G. Courteline		221     vanité	1860-1929. (Georges Moinaux)	berkeley	1700
Aux extrêmes périls, peu sert la connaissance.	DESPORTES Philippe	Amours d"Hippolyte		441     sang-froid	1546-1606.	berkeley	1964
C'est proprement ne valoir rien que de n'être utile à personne.	DESCARTES René	Discours de la méthode		221     vanité	1596-1650.	berkeley	1912
Pour la plus grande part, le monde se compose de sots et de coquins.  The world is made up for the most part of fools and knaves.	BUCKINGHAM GEORGE VILLIERS dDc de	To Mr. Clifford, on his Human Reason		510     ironie	1628-1688. (Anglais)	berkeley	885
... Rien de trop est un point  Dont on parle sans cesse et qu'on n'observe point.	LA FONTAINE Jean de	Fables, Rien de trop		441     sang-froid	1621-1695.	berkeley	3732
Dieu n'a pas prévu le bonheur pour ses créatures. Il n'a prévu que des compensations.	GIRAUDOUX Jean			110     entropie		berkeley	2962
L'idée n'est pas au ciel de l'abstraction; mais plutôt elle monte des terres et des travaux.	CHARTIER Emile	Propos D"économique.		370     esprit	alias Alain (1868-1951)	berkeley	1235
Dans la vie, la plupart du temps, les gens ont raison tout seuls.	GOLDSMITH Jimmy		1993	423     solitude	lire Le Piège	berkeley	2992
Dans l'adolescence on aime les autres femmes parce qu'elles ressemblent plus ou moins à la première; plus tard on les aime parce qu'elles diffèrent entre elles.	FLAUBERT Gustave	Carnets		530     ironie amoureuse	1821-1880.	berkeley	2786
Le souvenir est l'espérance renversée. On regarde le fond du puits comme on a regardé le sommet de la tour.	FLAUBERT Gustave	Carnets		540     mémoire	1821-1880.	berkeley	2787
La destinée de chaque homme ne lui est personnelle que dans la mesure où il lui arrive de ressembler à ce que sa mémoire contenait déj à.	MALLEA Eduardo			540     mémoire	540     mémo\\010iΩP\\010i àÄ	berkeley	4198
Un cynique est une espèce de confesseur inverti, se faisant continuellement des ennemis pour une cause qu'il sait être fausse.	MALLOCK W.-H.	La nouvelle république.		225     cynisme		berkeley	4199
Pourquoi la vanité est-elle aussi forte que la mort? 	MALRAUX André	Antimémoires		221     vanité	1901-1976.	berkeley	4201
Shakespeare: rendez-vous d'une rose et d'une hache ...	CIORAN Emile-Michel	Syllogismes de l"amertume		515     tragédie	1911-.	berkeley	1397
Le noeud de l'affaire vois-tu c'est que mes possibilités de travail dépendent de la vente de mes oeuvres (...) Ne pas vendre, quand on n'a pas de ressources, vous met dans l'impossibilité de faire aucun progrès, tandis que cela irait tout seul dans le cas contraire.	VAN GOGH Vincent	Lettre à Théo.		393     création artistique		berkeley	5254
Le maniement des grandes affaires vous fait voir la puissance des actes infimes : il suffit de limer la dent d'un engrenage pour arrêter tout un mouvement.	VARENNE Jean de la	Le Centaure de Dieu.		230     pouvoir		berkeley	5255
Les grands esprits ne doivent attendre le succès que de grandes idées, de grandes actions et de rien d'autre.	VAUVENARGUES Marquis de			421     initiation	CLAPIER Luc de	berkeley	5265
C'est le jeu, [...] Ils sont persuadés de pouvoir te faire ou te défaire et ils le peuvent, mais seulement si tu le leur permets.	WEST Morris	De main de Maître.	1988	441     sang-froid		berkeley	5434
Napoléon a commencé à décliner lorsqu'il a cessé de dérouter.	DE GAULLE Charles			215     mystifications	\\010hèÄ\\020	berkeley	1798
Le plus redoutable de tous les maux qui menacent l'avenir des Etats-Unis naît de la présence des Noirs sur leur sol.	TOCQUEVILLE Alexis de	De la démocratie en Amérique		239     servitudes du pouvoir autoritaire	1805-1859. Ecrit en 1835.	berkeley	5206
Dans les milieux politiques, les gens vous passent la main dans le dos même quand ils s'apprêtent à vous poignarder.	CAMP John	Trajectoire de fou	1989	238     servitudes du pouvoir politique		berkeley	980
Pour la plupart des hommes, la guerre est la fin de la solitude. Pour moi, elle est la solitude définitive.	CAMUS Albert	Carnets		120     grégarité	1913-1960.	berkeley	983
Le génie, c'est Dieu qui le donne, mais le talent nous regarde.	FLAUBERT Gustave	Correspondance, 1842		380     travail	1821-1880.	berkeley	2742
Quand je découvre une mauvaise assonance ou une répétition dans une de mes phrases, je suis sûr que je patauge dans le faux ; à force de chercher, je trouve l'expression juste qui était la seule et qui est, en même temps, l'harmonieuse. Le mot ne manque jamais quand on possède l'idée.	FLAUBERT Gustave	L"amour de l"art.	1915	390     création	1821/1880, édition posthume	berkeley	2743
La méthode est tout ce qu'il y a de plus haut dans la critique, puisqu'elle donne le moyen de créer.	FLAUBERT Gustave	L"amour de l"art.	1915	390     création	(1821/1880) édition posthume	berkeley	2746
La conscience des mots amène à la conscience de soi : à se connaître, à se reconnaître.	PAZ Octavio	A propos de Lopez Velarde		421     initiation		berkeley	4659
Ni la contradiction n'est marque de fausseté, ni l'incontradiction n'est marque de vérité.	PASCAL Blaise			214     guerre du savoir		berkeley	4638
L'espérance est une petite fille de rien du tout, C'est cette petite fille pourtant qui traverse les mondes.	PEGUY Charles	Le Porche du mystère de la deuxième vertu		312     foi		berkeley	4660
... ces grands aventuriers du monde moderne, les pères de famille.	PEGUY Charles			420     capital affectif	\\010l&#248;&#240;\\020	berkeley	4662
Dans les limites de la vérité, la presse est une noble institution, également amie des sciences et des libertés civiles.	JEFFERSON			232     servitudes du pouvoir	cité par Aldous HUXLEY in Retour au Meilleur des Mondes	berkeley	3434
Les sots sont ici-bas pour nos menus plaisirs.	GRESSET Jean-Baptiste Louis	Le Méchant		225     cynisme	1709-1777.	berkeley	3027
Que lui reproche-t-on ? Ses idées politiques. En voil à une idée ! Alors qu'il est déj à si difficile de croire aux opinions politiques des hommes politiques !	GUITRY Sacha	Théatre, je t"adore.		510     ironie		berkeley	3066
Oh! l'amour d'une mère! amour que nul n'oublie!  Pain merveilleux qu'un dieu partage et multiplie!  Table toujours servie au paternel foyer!  Chacun en a sa part, et tous l'ont tout entier! 	HUGO Victor	Les Feuilles d"automne, Ce siècle avait deux ans		420     capital affectif	1802-1885.	berkeley	3321
Les malheureux sont ingrats; cela fait partie de leur malheur.	HUGO Victor	Tas de pierres		420     capital affectif	1802-1885.	berkeley	3324
Il ne faut pas croire tout ce qu'on nous dit de ceux qui ne pensent pas comme nous.	SCHWEITZER Docteur Albert		1959	120     grégarité	au Père Pire	berkeley	4987
Oh ! l'amour d'une mère ! amour que nul n'oublie ! Pain merveilleux qu'un dieu partage et multiplie ! Table toujours servie au paternel foyer ! Chacun en sa part et tous l'ont tout entier.	HUGO Victor	Les Feuilles d"Automne.		420     capital affectif		berkeley	3325
N'imitez rien ni personne. Un lion qui copie un lion devient un singe.	HUGO Victor	Tas de pierres		441     sang-froid	1802-1885.	berkeley	3332
C'est une absolue perfection, et comme divine, de savoir loyalement jouir de son être.	MONTAIGNE Michel Eyquem de	De l"expérience.		130     liberté		berkeley	4313
Notre grand et glorieux chef-d'oeuvre, c'est vivre à propos.	MONTAIGNE Michel Eyquem de	Essais.		140     rapport à la cosmogonie		berkeley	4314
On peut, à force de confiance, mettre quelqu'un dans l'impossibilité de nous tromper.	JOUBERT Joseph	Carnets		422     confiance en soi	1754-1824.	berkeley	3464
Tous les êtres viennent de peu, et il s'en faut de peu qu'ils ne viennent de rien.	JOUBERT Joseph	Pensées		520     ironie de soi	1754-1824.	berkeley	3468
Jamais un orateur n'a pensé en parlant ; jamais un auditeur n'a pensé en écoutant.	CHARTIER Emile	Propos Sur L"éducation.		234     communication	alias Alain (1868-1951)	berkeley	1216
C'est la foi même qui est Dieu.	CHARTIER Emile	Eléments De Philosophie.		312     foi	alias Alain (1868-1951)	berkeley	1220
On ne doit s'occuper que de ce qui nous regarde.	HERODOTE	Histoire.		441     sang-froid		berkeley	3165
Le poète seul peut tutoyer les rois.	DE HEREDIA José Maria			510     ironie	remarque de l"auteur à Nicolas II	berkeley	1865
Ne disons point au jour les secrets de la nuit.	PARNY Evariste Désiré de	Elégies		441     sang-froid	1753-1814.	berkeley	4634
Hélas! je n'ai rien fait pour la postérité; et pourtant j'avais quelque chose l à.  	CHéNIER André de			520     ironie de soi	1762-1794.   Paroles prononcées par le poète avant de monter sur l"échafaud, le 25 juillet 1794.	berkeley	1338
Dieu fit la liberté, l'homme a fait l'esclavage.	CHENIER Marie-Joseph de	Fénelon.		110     entropie		berkeley	1340
En vieillissant on devient plus fou et plus sage.	LA ROCHEFOUCAULD François de	Maximes		510     ironie	1613-1680.	berkeley	3907
Les braves gens ne savent pas ce qu'il en coûte de temps et de peine pour apprendre à lire. J'ai travaillé à cel à quatre-vingt ans, et je ne peux pas dire encore que j'y sois arrivé.	GOETHE Johann Wolfgang von	Conversations.		421     initiation		berkeley	2973
L'homme heureux ne croit pas qu'il arrive encore des prodiges ; c'est dans le malheur qu'on apprend que le doigt de Dieu dirige les bons vers le bien.	GOETHE Johann Wolfgang von	Hermann et Dorothée.		421     initiation		berkeley	2974
Si dans l'épée de la France, la lame est bonne et bien trempée,	DE GAULLE Charles			321     volonté		berkeley	1811
Le moins que l'on puisse demander à une sculpture, c'est qu'elle ne bouge pas.	DALI Salvador	Les Cocus du vieil art moderne		221     vanité	1904-1989.	berkeley	1742
Sois audacieux et rusé dans tes plans, ferme et persévérant dans leur exécution, et résolu à une fin glorieuse.	CLAUSEWITZ	Principes de la Guerre.	1812	390     création		berkeley	1472
J'entendrai des regards que vous croirez muets.	RACINE Jean	Britannicus		340     sensibilité		berkeley	4778
Il n'est point de secrets que le temps ne révèle [...]	RACINE Jean	Britannicus		421     initiation		berkeley	4780
Je meurs si je vous perds, mais je meurs si j'attends.	RACINE Jean	Andromaque		430     paradoxal émotionnel		berkeley	4781
Pour qui sont ces serpents qui sifflent sur vos têtes.	RACINE Jean	Andromaque		433     perversion		berkeley	4782
La foi qui n'agit point, est-ce une foi sincère ?	RACINE Jean	Andromaque		433     perversion		berkeley	4783
On demandait à M. de Fontenelle mourant: 'Comment cela va-t-il?' - 'Cela ne va pas, dit-il, cela s'en va.' 	CHAMFORT Nicolas-Sébastien de	Caractères et anecdotes		441     sang-froid	1740/1794. Ac. Française	berkeley	1128
Quand il s'agit d'obtenir les honneurs, on rame avec le mérite personnel, et on vogue à pleines voiles avec la naissance.	MONTESQUIEU Charles de	Mes pensées		221     vanité	1689-1755. (C. de Secondat, baron de La Brède et de M.)	berkeley	4416
Je n'ai jamais su agir que sur ce qui se paye d'adrénaline.	FAIRGAGNETR Oscar	Vitalités.	1995	460     plaisir		berkeley	2614
Sache toujours ce que tu n'as pas à dire à ceux qui te regardent du haut de leur c...	FAIRGAGNETR Oscar	Vitalités.	1995	510     ironie		berkeley	2615
Je suis maître de moi comme de l'univers :  Je le suis, je veux l'être.	CORNEILLE Pierre	Cinna, V, 3, Auguste		422     confiance en soi	1606-1684.	berkeley	1660
Nos plus heureux succès sont mêlés de tristesse.	CORNEILLE Pierre	Le Cid, III, 5, Don Diègue		430     paradoxal émotionnel	1606-1684.	berkeley	1661
C'est parce qu'on imagine simultanément tous les pas qu'on devra faire qu'on se décourage, alors qu'il s'agit de les aligner un à un.	JOUHANDEAU Marcel	De la grandeur		441     sang-froid	1888-1979.	berkeley	3480
La générosité n'est que la pitié des âmes nobles.	CHAMFORT Nicolas-Sébastien de	Maximes et pensées		331     altruisme	1740/1794. Ac. Française	berkeley	1118
Si l'on doit aimer son prochain comme soi-même, il est au moins aussi juste de s'aimer comme son prochain.	CHAMFORT Nicolas-Sébastien de	Maximes et pensées		430     paradoxal émotionnel	1740/1794. Ac. Française	berkeley	1124
Quiconque n'a pas de caractère n'est pas un homme, c'est une chose.	CHAMFORT Nicolas-Sébastien de	Maximes et pensées		432     expérience	1740/1794. Ac. Française	berkeley	1125
Il réussit celui que Dieu protège.  Mult ben espleitet qui Damnesdeus aiuet.	Chanson de Roland			140     rapport à la cosmogonie	v. 1100 	berkeley	1162
Dans les grandes choses, les hommes se montrent comme il leur convient de se montrer; dans les petites, ils se montrent comme ils sont.	CHAMFORT Nicolas-Sébastien de	Maximes et pensées		432     expérience	1740/1794. Ac. Française	berkeley	1127
C'est vrai qu'il est très efficace mais il n'a pas assez de finesse politique pour ce genre de choses. Il faut encore qu'il fasse ses preuves pour diriger une opération globale.	CLANCY Tom	Danger Immédiat	1989	238     servitudes du pouvoir politique		berkeley	1417
' - Techniquement, oui, je suis au point. Mais je n'ai pas assez de     finesse politique pour le poste.   - Eh bien, il n'y a qu'un seul moyen de l'acquérir.'	CLANCY Tom	Danger Immédiat	1989	238     servitudes du pouvoir politique		berkeley	1418
Narmonov avait absolument besoin d'un plan et d'une vision, et il n'en avait pas.	CLANCY Tom	La somme de toutes les peurs. II.	1991	320     intuition		berkeley	1420
[...] le vulgaire manque toujours de la discipline nécéssaire pour savoir ce qui est bon pour lui.	CLANCY Tom	La somme de toutes les peurs. I.	1991	370     esprit		berkeley	1421
Détails que tout cela. Mais l'art de l'ingénieur est fait de petits détails.	CLANCY Tom	La somme de toutes les peurs. II.	1991	380     travail	380     trav\\010b&#227;\\020\\010bèê	berkeley	1422
Nous ne sommes, mon amour, que des enfants vieillis qui s'agitent avant de trouver le repos.	CARROLL Lewis			530     ironie amoureuse		berkeley	1042
Savoir mal est pire qu'ignorer.	CASANOVA DE SEINGALT Jean-Jacques	Mémoires		370     esprit	1725-1798.	berkeley	1045
Le travail est l'aliment des âmes nobles.  Generosos animos labor nutrit.	Sénèque	Lettres à Lucilius, XXXI		380     travail		berkeley	5018
La victoire, pour moi, c'est le droit à la parole.	DARNICHE Bernard			234     communication		berkeley	1764
...Il m'a toujours semblé que dans nos luttes sociales, il y avait beaucoup moins comme motif 'l'intérêt' que la 'jalousie'... Du côté des 'petits', cette jalousie devient l'envie. Du côté des 'grands', elle prend la forme de l'orgueil : 'Noli me tangere !'	DE GAULLE Charles	Lettre à Jean Auburtin	1937	225     cynisme		berkeley	1802
[...] Le prestige ne peut aller sans mystère, car on révère peu ce que l'on connaît.	DE GAULLE Charles	Le fil de l"Epée.	1932	230     pouvoir		berkeley	1803
Au fond, l'ordre établi n'a jamais rien à craindre de ses propres troupes, quand il mérite le suffrage du pays.	DE GAULLE Charles	Lettre à son ami André Leconte.	1936	231     légitimité du pouvoir		berkeley	1805
Il faut savoir quitter la scène à temps.	Dictons et Proverbes	?		441     sang-froid		berkeley	2041
Fruits et racines ont même commune mesure qui est l'arbre.	SAINT-EXUPéRY Antoine de	Citadelle		440     courage	1900-1944.	berkeley	4933
Ki houen Sseu réfléchissait à plusieurs reprises avant de faire une chose. Le Maître, l'ayant appris, dit: 'Il suffit de réfléchir deux fois.' 	CONFUCIUS	Entretiens, III, 5	 5	441     sang-froid	551-479 av. J.-C. (Chinois)	berkeley	1600
Je ne veux ni ne rejette rien absolument, mais je consulte toujours les circonstances.	CONFUCIUS	Entretiens, IX, 18	18	441     sang-froid	551-479 av. J.-C. (Chinois)	berkeley	1601
Ma définition de la poésie pure : quelque chose créé par le poète hors de sa personnalité.	MOORE G.	Anthologie de la poésie pure, Introduction.		393     création artistique		berkeley	4492
On peut citer de mauvais vers, quand ils sont d'un grand poète.	LACLOS Pierre Choderlos de	Les Liaisons dangereuses		539     ironie sociale	1741-1803.	berkeley	3968
On ne devient jamais que ce qu'on est. L'imagination, l'énergie et les circontances font le reste.	LACOUTURE Jean	De Gaulle.	1984	140     rapport à la cosmogonie		berkeley	3971
(...) il a compris la formidable efficacité mais aussi la terrible nocivité, de la levée en masse, qui convoque le monde pour des guerres proprement biologiques, ces guerres sans limites qui succèderont aux conflits de professionnnels, de castes et de bandes.	LACOUTURE Jean	De Gaulle.	1984	211     guerre		berkeley	3972
Il ne fait que passer trop vite, hélas ! Il faut le retenir, au contraire, le temps... Il faut l''empêcher de passer ! Et pour cela, il n'y a qu'un moyen : c'est de considérer que tout est intéressant et de s'intéres- ser à tout !	GUITRY Sacha			341     étonnement		berkeley	3058
Les armes sont les bijoux des hommes.	FOLLAIN Jean	Appareil de la terre		539     ironie sociale	1903-1971.	berkeley	2816
L'instant où l'on naît est un pas vers la mort.	VOLTAIRE			510     ironie		berkeley	5333
Comme vous aviez raison de m'imposer cette épreuve. A présent, je sais que l'audace et la présence d'esprit permettent à l'homme de se dépasser et d'envisager l'impossible.	DARD Frédéric	La Vieille qui marchait dans la Mer. San-Antonio.	1988	421     initiation		berkeley	1760
La France ne veut pas d'hommes. Ce qu'il lui faut, c'est des castrats.	DARIEN Georges	La Belle France		120     grégarité	1862-1921. (Georges Adrien)	berkeley	1762
Dis-moi qui t'admire et je te dirai qui tu es.	SAINTE-BEUVE Charles Augustin Charles Augustin	Causeries du lundi		510     ironie	1804-1869.	berkeley	4942
Toute puissance est faible à moins que d'être unie.	LA FONTAINE Jean de	Fables, le Vieillard et ses Enfants		230     pouvoir	1621-1695.	berkeley	3683
La raison du plus fort est toujours la meilleure.	LA FONTAINE Jean de	Fables, le Loup et l"Agneau		230     pouvoir	1621-1695.	berkeley	3684
Je n'appelle pas gaieté ce qui excite le rire, mais un certain charme, un air agréable qu'on peut donner à toutes sortes de sujets, même les plus sérieux.	LA FONTAINE Jean de	Fables, Préface		234     communication	1621-1695.	berkeley	3685
En amour, celui qui est guéri le premier est toujours le mieux guéri.	LA ROCHEFOUCAULD François de	Maximes		530     ironie amoureuse	1613-1680.	berkeley	3926
L'asile le plus sûr est le sein d'une mère.	FLORIAN Jean-Pierre Claris de	Fables, La mère, l"enfant et les Sarigues.		420     capital affectif		berkeley	2804
Plaisir d'amour ne dure qu'un moment  Chagrin d'amour dure toute la vie.	FLORIAN Jean-Pierre Claris de	Romance extraite de Célestine		530     ironie amoureuse	1755-1794.	berkeley	2809
Que me font ces vallons, ces palais, ces chaumières ? Vains objets dont pour moi le charme est envolé ; Fleuves, rochers, forêts, solitudes si chères, Un seul être vous manque et tout est dépeuplé.	LAMARTINE Alphonse de	Méditations poétiques. "L"Isolement".	1820	420     capital affectif		berkeley	4000
O temps, suspends ton vol Et vous, heures propices, Suspendez votre cours...	LAMARTINE Alphonse de			510     ironie		berkeley	4007
En amour, il n'y a ni crimes ni délits. Il y a des fautes de goût.	GERALDY Paul	L"Homme et l"Amour.		530     ironie amoureuse		berkeley	2924
Berlioz attache une boucle romantique à de vieilles perruques.	DEBUSSY Claude	Monsieur Croche, antidilettante		393     création artistique	1862-1918.	berkeley	1870
Rentre en toi-même, Octave, et cesse de te plaindre.  Quoi! tu veux qu'on t'épargne et n'as rien épargné! 	CORNEILLE Pierre	Cinna, IV, 2, Auguste		441     sang-froid	1606-1684.	berkeley	1671
La courtisane est un mythe. Jamais une femme n'a inventé une débauche.	FLAUBERT Gustave	L"amour de l"art.	1915	530     ironie amoureuse	(1821/1880) édition posthume	berkeley	2783
Un miroir à nos yeux distraits Vient-il offrir notre grimace ? Il ne faut pas briser la glace, Mais, s'il se peut, changer nos traits.	FRERON Elie	Epître persane à Saadi.		520     ironie de soi		berkeley	2886
L'angoisse des départs sans main chaude dans la main.	SENGHOR Léopold Sédar	Chants d"ombre, C"est le temps de partir		420     capital affectif	1906-.	berkeley	5037
Mauvais est l'homme qui oublie honte et vilenie qu'on lui fit.  Que molt est malvais qui oblie / S'on li fait honte ne laidure.	Chrétien de Troyes	Le Conte Du Graal.		442     démission	Seconde moitié du XIIe siècle.	berkeley	1361
Et au plus élevé trône du monde si ne sommes assis que sur notre cul.	MONTAIGNE Michel Eyquem de	Essais.		520     ironie de soi		berkeley	4383
Quant au génie, c'est affaire de biologie.	ETIEMBLE René			510     ironie		berkeley	2387
On peut mélanger l'espoir et le désespoir jusqu' à ne plus distinguer l'un de l'autre.	CHAMSON André	On ne voit pas les coeurs		433     perversion	1900-1983.	berkeley	1154
Le syllogisme est le farfadet des petits esprits.	EMERSON Ralph Waldo			110     entropie		berkeley	2336
Le nationalisme est une maladie infantile. C'est la rougeole de l'humanité.	EINSTEIN Albert			221     vanité		berkeley	2296
L'identité sera convulsive ou ne sera pas.	ERNST Max	Ecritures		130     liberté	1891-1976.   Rappel de la célèbre affirmation de A. Breton dans Nadja: "La beauté sera convulsive ou ne sera pas."	berkeley	2370
La grammaire est l'art de lever les difficultés d'une langue; mais il ne faut pas que le levier soit plus lourd que le fardeau.	RIVAROL Antoine de	Discours sur l"universalité de la langue française		370     esprit	1753-1801. (Antoine Rivarol, Comte de Rivarol)	berkeley	4830
Qui ne demande rien, c'est qu'il attend tout.	ROSTAND Jean	Pages d"un moraliste.		430     paradoxal émotionnel		berkeley	4869
Le chat ne nous caresse pas, il se caresse à nous.	RIVAROL Antoine de	Esprit de Rivarol		441     sang-froid	1753-1801. (Antoine Rivarol)	berkeley	4833
Il est mille fois plus aisé de faire le bien, que de le bien faire.	MONTESQUIEU Charles de	De l"esprit des lois		221     vanité	1689-1755. (C. de Secondat, baron de La Brède et de M.)	berkeley	4411
Par les airs du valet, on peut juger du maître.	Destouches	Le Glorieux, IV, 5, Lycandre		365     discernement	1680-1754. (Philippe Néricault)	berkeley	1967
Le pouvoir politique se doit de ménager, toujours, le mythe des ses faits d'armes et de sa puissance.	FAIRGAGNETR Oscar	Vitalités.	1993	215     mystifications		berkeley	2498
On a tort de craindre la supériorité de l'esprit et de l'âme ; elle est très morale cette supériorité, car tout comprendre rend très indulgent, et sentir profondément inspire une grande bonté.	STAEL Madame de	Corinne ou de l"Italie.		560     sagesse		berkeley	5134
Tout poème naît d'un germe, d'abord obscur, qu'il faut rendre lumineux pour qu'il produise des fruits de lumière.	DAUMAL René	Poésie noire et poésie blanche		393     création artistique	1908-1944.	berkeley	1774
Les rencontres, ça ne se fait pas avec les gens [..], ça se fait avec les choses.	DELEUZE Gilles			234     communication	Arte, le 19/03//95.	berkeley	1891
Les premiers essais (*) seront sans doute grossiers et liés d'ordinaire à une condition plus pénible et plus dangereuse que lorsqu'on se trouvait encore sous les ordres mais confié aux soins d'autrui.	KANT			130     liberté	(de la liberté)	berkeley	3534
On ne saurait adopter une profession si l'on n'a pas d'orgueil, et l'orgueil se nourrit de succès.	WEST Morris	Toute la vérité.	1957	440     courage		berkeley	5429
Quand on a une idée, on s'y tient.	KAHNWEILER Daniel-Heinrich			320     intuition		berkeley	3518
Les peuples passent, les trônes s'écroulent, l'Eglise demeure.	Napoléon I			230     pouvoir		berkeley	4556
Mais ce qui reste est l'oeuvre des poètes.  Was bleibet aber, stiften die Dichter.	HÖLDERLIN Friedrich	Souvenir		393     création artistique	1770-1843. (Allemand)	berkeley	3209
... le terrain fétide et palpitant de la vie.	BERNARD Claude	Introduction à l"étude de la médecine expérimentale		510     ironie	1813-1878.	berkeley	707
Il m'a fait trop de bien pour en dire du mal, Il m'a fait trop de mal pour en dire du bien.	CORNEILLE Pierre	Poésies diverses.		510     ironie	1606-1684.	berkeley	1680
Le seul moyen de n'être pas malheureux c'est de s'enfermer dans l'art et de compter pour rien tout le reste, l'orgueil remplace tout quand il est assis sur une large base.	FLAUBERT Gustave	L"amour de l"art.	1915	423     solitude	(1821/1880) édition posthume	berkeley	2761
Le comble de l'orgueil, c'est de se mépriser soi-même.	FLAUBERT Gustave	Carnets		433     perversion	1821-1880.	berkeley	2766
L'illumination n'est que la vision soudaine, par l'Esprit, d'une route lentement préparée.	SAINT-EXUPéRY Antoine de	Pilote de guerre		390     création	1900-1944.	berkeley	4929
En général, les gens ne formulent pas toutes les parties d'une pensée donnée qu'ils essaient de communiquer, parce qu'ils s'efforcent d'être brefs et laissent de côté des informations sous-entendues ou inessentielles. Le processeur conceptuel cherche un type d'information qui remplira la case requise dans une phrase ou une plus grande unité de discours.	SCHANK Roger			365     discernement		berkeley	4965
Il faisait tout très lentement et avec sérénité	ROSE Ben			560     sagesse	Pilote du bateau emmenant Jacques Mayol vers son premier grand record des - 60 m.	berkeley	4861
Il y a des outrages qui vous vengent de tous les triomphes, des sifflets qui sont plus doux pour l'orgueil que des bravos.	FLAUBERT Gustave	Correspondance, 1842		510     ironie	1821-1880.	berkeley	2777
La bêtise consiste à vouloir conclure.	FLAUBERT Gustave	Correspondance, 1842, à Louis Bouilhet, 1850		510     ironie	1821-1880.	berkeley	2778
L'ancien droit n'est pas l'oeuvre d'un législateur ; il s'est, au contraire, imposé au législateur.	FUSTEL de COULANGES Numa Denis	La Cité Antique.		231     légitimité du pouvoir		berkeley	2898
L'esprit sommeille dans la brute et c'est pourquoi elle ne connait que la loi de la force physique. La dignité de l'homme demande l'obéissance à un loi plus haute, à la force de l'esprit.	GANDHI			546     éthique	cité dans Tous les hommes sont frères. UNESCO.	berkeley	2903
La distance, âme du beau.	LAO TSEU	Tao tö King, LXXX		441     sang-froid		berkeley	4033
Je hais cet accidentel repentir que l'âge apporte.	MONTAIGNE Michel Eyquem de	Essais, III, 2		221     vanité	1533-1592.	berkeley	4325
Il est important de se rappeler que la démocratie, et j'irai plus loin en disant la liberté, est fondée sur le principe que ce ne sont pas les gouvernants qui déterminent les libertés à accorder aux citoyens. Il s'agit du contraire. C'est aux citoyens de décider quels pouvoirs ils sont disposés à prêter à leurs gouvernants.	GOLDSMITH Jimmy	Le Piège.	1993	231     légitimité du pouvoir		berkeley	2989
Ce n'est pas parce que les choses sont difficiles que nous n'osons pas, c'est parce que nous n'osons pas qu'elles sont difficiles.	SENEQUE			440     courage		berkeley	5006
Et s'il faut parler de choses 'sacrées', seul le mécontentement que l'homme éprouve de lui-même et son inspiration à s'améliorer me sont sacrés.	GORKI Maxime	Le métier des lettres.		520     ironie de soi		berkeley	3000
Ne me farde pas la mort.	Homère	L"Odyssée, XI, 488  		441     sang-froid	IXe ou VIIIe s. av. J.-C. Achille, aux enfers, regrette la vie et refuse les consolations.	berkeley	3225
Qui est plus esclave qu'un courtisan assidu, si ce n'est un courtisan plus assidu? 	LA BRUYERE Jean de	Les Caractères		120     grégarité	1645-1696.	berkeley	3592
La liberté, ce bien qui fait jouir des autres biens.	MONTESQUIEU Charles de	Mes pensées		130     liberté	1689-1755. (C. de Secondat, baron de La Brède et de M.)	berkeley	4400
Je donnerais bien des jours, pour une nuit de ce soleil l à.	Dictons et proverbes			530     ironie amoureuse		berkeley	2072
L'imbécile est fort demandé, surtout dans les occasions mondaines. Il met tout le monde dans l'embarras, mais ensuite il offre matière à commentaires. Dans sa forme positive, il devient diplomate. Il parle hors de son verre quand ce sont les autres qui ont fait une gaffe, il fait dévier le propos.	ECO Umberto	Le Pendule de Foucault	1988	120     grégarité		berkeley	2259
J'appartiens à une génération perdue, et je me retrouve seulement quand j'assiste en compagnie à la solitude de mes semblables.	ECO Umberto	Le Pendule de Foucault	1988	120     grégarité		berkeley	2260
Que si le moi est haïssable, aimer son prochain comme soi-même devient une atroce ironie.	VALERY Paul	Tel Quel - Choses Tues		530     ironie amoureuse		berkeley	5245
L'histoire justifie ce que l'on veut. Elle n'enseigne absolument rien, car elle contient tout et donne des exemples de tout. Elle est le produit le plus dangereux que la chimie de l'intellect ait élaboré.	VALERY Paul	Regards sur le monde actuel.		540     mémoire		berkeley	5246
Tout, jusqu' à la vérité, trompe dans ses écrits.  Eloges  	LA HARPE Jean François de	A propos de J.-J. Rousseau.		234     communication	1739-1803.	berkeley	3772
On fait tant, à la fin, que l'huître est pour le juge,  Les écailles pour les plaideurs.	LA FONTAINE Jean de	Fables		215     mystifications	1621-1695.	berkeley	3656
Peindre n'est pas dépeindre... Ecrire n'est pas décrire... J'aime la règle qui corrige l'émotion... Le vase donne une forme au vide, la musique au silence... Faire des progrès en art, ce n'est pas étendre ses limites mais mieux les connaître... La peinture n'est pas un art à tout faire.	BRAQUE Georges	Pensées et réflexions sur la peinture.		393     création artistique	in Revue Nord-Sud (entre 1915 et 1920)	berkeley	831
Au grand scandale des uns sous l'oeil à peine moins sévère des autres soulevant son poids d'ailes ta liberté.	BRETON André	Ode à Charles Fourier		130     liberté	1896-1966.	berkeley	843
La plupart des hommes ont, comme les plantes, des propriétés cachées que le hasard fait découvrir.	LA ROCHEFOUCAULD François de	Maximes		432     expérience	1613-1680.	berkeley	3877
Il y a du mérite sans élévation, mais il n'y a point d'élévation sans quelque mérite.	LA ROCHEFOUCAULD François de	Maximes		440     courage	1613-1680.	berkeley	3890
Il est plus honteux de se défier de ses amis que d'en être trompé.	LA ROCHEFOUCAULD François de			442     démission		berkeley	3899
Nous promettons selon nos espérances, et nous tenons selon nos craintes.	LA ROCHEFOUCAULD François de	Maximes		442     démission	1613-1680.	berkeley	3900
S'il y a des hommes dont le ridicule n'ait jamais paru, c'est qu'on ne l'a pas bien cherché 	LA ROCHEFOUCAULD François de	Maximes		510     ironie	1613-1680.	berkeley	3901
On admire toujours d'autant plus qu'on observe davantage et qu'on raisonne moins.	BUFFON Georges-Louis Leclerc de	Histoire naturelle, Des animaux		510     ironie	1707-1788.	berkeley	900
Crois et tu comprendras; la foi précède, l'intelligence suit.  Si non potes intelligere, crede ut intelligas. Praecedit fides, sequitur intellectus.	ST.AUGUSTIN	Sermons, 118, 1		320     intuition	354-430.	berkeley	5110
Ce n'est pas tant aux opinions des hommes qu'il faut regarder, mais à la vérité en elle-même.	St.AUGUSTIN			441     sang-froid		berkeley	5112
Les passions sont les seuls orateurs qui persuadent toujours.	LA ROCHEFOUCAULD François de	Maximes		234     communication	1613-1680.	berkeley	3836
L'amour physique est plus communément le fruit d'une grégarité que celui d'une intimité.	FAIRGAGNETR Oscar	Vitalités.	1994	530     ironie amoureuse		berkeley	2639
L'éternité n'est guère plus longue que la vie.	CHAR René	Feuillets d"Hypnos		441     sang-froid	1907-1988.	berkeley	1181
Imite le moins possible les hommes dans leur énigmatique maladie de faire des noeuds.	CHAR René	Les Matinaux		441     sang-froid	1907-1988.	berkeley	1182
Plus le visage est sérieux, plus le sourire est beau.	CHATEAUBRIAND François-René de	Mémoires d"outre-tombe		330     coeur	1768-1848.	berkeley	1295
Entre les interstices de nos différences, de nos originalités, de nos rigidités se glisse parfois le miracle de la curiosité et de l'écoute de l'autre... En lui consacrant l'attention que nous devons à tout être unique, nous aggrandissons en nous-même notre propre conscience et nous accédons à la jouissance du sentiment, unique et différent de chacun de ceux qui le partagent, devenant en cel à le lien qui rapproche et fonde l'amitié ou la confiance, l'amour ou le respect. Quand l'autre nous renvoie à nos propres limites, tant affectives qu'éthiques, aucune de ses provocations ne restera vaine si chacune nous pousse  à nous mieux connaître, à nous mieux aimer, pour nous-mêmes et pour les autres. C'est l à le prix du 'miracle de la communication sincère' que nous aurons découvert.	FAIRGAGNETR Oscar	Vitalités.	1992	234     communication		berkeley	2524
Personne ne déploiera jamais les facultés de son intelligence s'il n'intercale, pour le moins, quelques moments de solitude dans sa vie.  No man ever will unfold the capacities of his own intellect, who does not at least checker his life with solitude.	QUINCEY Thomas de	Suspiria De Profundis		520     ironie de soi	1785-1859. (Anglais)	berkeley	4751
Que la science que nous acquerons par la lecture ne soit pour nous que le ciseau du sculpteur ; qu'elle nous aide à tailler le bloc de pensées et de sentiments qui fait le fond de nous-mêmes.	PIRMEZ O.	Heures de Philosophie.		421     initiation		berkeley	4710
Quelle est donc la juste façon de vivre. La vie doit être vécue comme un jeu.	PLATON			110     entropie		berkeley	4712
La nécéssité qui est mère de l'invention...	PLATON	La République, II		390     création		berkeley	4716
Le goût populaire : deux mots qui hurlent d'être accouplés ; tout peut être populaire, excepté le goût qui est le résultat de l'éducation.	RABUSSON H.			120     grégarité		berkeley	4760
Si tu ne peux les battre, unis-toi à eux.	ECO Umberto	Le Pendule de Foucault	1988	225     cynisme		berkeley	2266
Plus tard, Lia devait me dire : 'Tu vis de surfaces. Quand tu as l'air profond c'est que tu en encastres beaucoup, et que tu combines l'apparence d'un solide - un solide qui, a supposer qu'il fût solide, ne pourrait se tenir debout.'	ECO Umberto	Le Pendule de Foucault	1988	235     séduction		berkeley	2267
Je ne peux pas imaginer un Dieu qui récompense et punit l'objet de sa création. Je ne peux pas me figurer un Dieu qui règlerait sa volonté sur l'expérience de la mienne. Je ne veux pas et ne peux  pas concevoir un être qui survivrait à la mort de son corps. Si de pareilles idées se développent en un esprit, je le juge faible, craintif et stupidement égoïste.	EINSTEIN Albert	Comment je vois le Monde	1934	110     entropie	rééd.corr. en 1952 et 1978.	berkeley	2286
On n'est jamais si heureux ni si malheureux qu'on s'imagine.	LA ROCHEFOUCAULD François de	Maximes		441     sang-froid	1613-1680.	berkeley	3898
La tentation d'être un chef juste et humain est naturelle dans un homme instruit ; mais il faut savoir que le pouvoir change profondément celui qui l'exerce; et cela ne tient pas seulement à une contagion de société: la raison en est dans les nécessités du commandement, qui sont inflexibles.	CHARTIER Emile	Souvenirs De Guerre.		391     commandement	alias Alain (1868-1951)	berkeley	1245
Celui qui mange l'estomac plein, creuse sa tombe avec ses dents.	Dictons et Proverbes	Proverbe turc.		410     santé		berkeley	2020
Peut-être dans le domaine de la religion, comme dans celui de l'amour, est-il inévitable de recourir à des termes vagues: tout y est vrai, pourvu qu'on y croie.	CABANIS José	Plaisir et lectures		510     ironie	1922-.	berkeley	947
On ne se méfie pas qu'une chose, quand on la nomme, ça la roussit comme un coup de soleil.	DUBUFFET Jean	Prospectus et tous Ecrits suivants		370     esprit	1901-1985.	berkeley	2186
Heureux qui, comme Ulysse, a fait un beau voyage Ou comme celui-l à qui conquit la toison, Et puis est retourné, plein d'usage et de raison, Vivre entre ses parents le reste de son âge.	DU BELLAY Joachim	Regrets. Sonnet n°31.	1558	140     rapport à la cosmogonie	1524/1585	berkeley	2160
(La formule sacrée du positivisme):  L'Amour pour principe, l'Ordre pour base, et le Progrès pour but.	COMTE Auguste	Système de politique positive		546     éthique	1798-1857.	berkeley	1585
Le désir qui naît de la joie est plus fort, toutes circonstances égales d'ailleurs, que le désir qui naît de la tristesse.	SPINOZA Baruch	L"Ethique.		420     capital affectif		berkeley	5104
Je suis devenu chrétien ... Ma conviction est sortie du coeur; j'ai pleuré et j'ai cru.	CHATEAUBRIAND François-René de	Le Génie du christianisme		546     éthique	1768-1848.	berkeley	1317
La drogue. On en revenait toujours l à. A son extraordinaire capacité de corruption. La drogue corrompait les gens, obscurcissait leurs idées, et finissait par mettre un terme à leur vie. Et la drogue engendrait des sommes d'argent propres à corrompre ceux qu'elle n'intéressait pas en elle-même. La drogue corrompait les institutions à tous les niveaux et de toutes les façons possibles. La drogue corrompait des gouvernements entiers.	CLANCY Tom	Danger Immédiat	1989	210     violence		berkeley	1403
... La vertu, comme le corbeau, niche dans les ruines. Elle habite les creux et les rides du corps.	FRANCE Anatole	La Rôtisserie de la reine Pédauque		520     ironie de soi	1844-1924. (Anatole François Thibault)	berkeley	2870
Toute la philosophie est comme un arbre, dont les racines sont la métaphysique; le tronc est la physique, et les branches qui sortent de ce tronc sont toutes les autres sciences, qui se réduisent à trois principales, à savoir la médecine, la mécanique et la morale; j'entends la plus haute et la plus parfaite morale, qui présupposant une entière connaissance des autres sciences est le dernier degré de la sagesse.	DESCARTES René	Principes de la philosophie		545     épistémologie	1596-1650.	berkeley	1953
Un peu de dureté sied bien aux grandes âmes.	CORNEILLE Pierre	Suréna, V, 3, Suréna		441     sang-froid	1606-1684.	berkeley	1669
Un monarque a souvent des lois à s'imposer;  Et qui veut pouvoir tout ne doit pas tout oser.	CORNEILLE Pierre	Tite et Bérénice, IV, 5, Tite		441     sang-froid	1606-1684.	berkeley	1670
Quelle vérité est-ce que ces montagnes bornent, qui est mensonge au monde qui se tient au-del à? 	MONTAIGNE Michel Eyquem de	Essais, II, 12		215     mystifications	1533-1592.	berkeley	4317
La Critique est la dixième Muse et la Beauté la quatrième Grâce.	FLAUBERT Gustave	Carnets		421     initiation	1821-1880.	berkeley	2758
Je me suis souvent repenti d'avoir parlé, mais jamais de m'être tu.	COMMYNES Philippe de			441     sang-froid	1447-1511. Sentence gravée en latin sur la muraille du château de Loches	berkeley	1581
Un empire fondé par les armes a besoin de se soutenir par les armes.	MONTESQUIEU Charles de			239     servitudes du pouvoir autoritaire	1689-1755. (C. de Secondat, baron de La Brède et de M.)  Considérations sur les causes de la grandeur des Romains et de leur décadence	berkeley	4428
Crois et tu comprendras ; la foi précède, l'intelligence suit.	St.AUGUSTIN	Sermons.		320     intuition		berkeley	5111
Le hasard, le hasard seul gouverne le monde. Il faut savoir cependant le saisir, et pour le saisir, il faut être en état de le reconnaitre ; attendre, espérer sa visite.	COMBESCOT Pierre	Les Chevaliers du Crépuscule.	1975	510     ironie		berkeley	1579
L'enfance est le seul moment de grande liberté pour un individu.	COMENCINI Luigi			420     capital affectif		berkeley	1580
Chaque route que l'on suit exactement jusqu'au bout ne conduit exactement à rien. Escaladez la montagne pour voir si c'est une montagne. Quand vous serez au sommet de la montagne, vous ne pourrez plus voir la montagne.	HERBERT Franck	Dune	1965	421     initiation		berkeley	3142
Tout sentiment qui n'est pas illimité est sans valeur.	MUSIL	L"homme sans qualités.		330     coeur		berkeley	4515
Les chefs qui depuis de nombreuses années, sont à la tête des armées françaises, ont formé un gouvernement. Ce gouvernement, alléguant la défaite de nos armées, s'est mis en rapport avec l'ennemi pour cesser le combat. Certes, nous avons été, nous sommes submergés par la force mécanique, terrestre et aérienne, de l'ennemi. Infiniment plus que leur nombre, ce sont les chars, les avions, la tactique des Allemands qui nous font reculer. Ce sont les chars, les avions, la tactique des Allemands qui ont surpris nos chefs au point de les amener l à où ils en sont aujourd'hui. Mais le dernier mot est-il dit? L'espérance doit-elle disparaitre? La défaite est-elle définitive ? Non! Croyez-moi, moi qui vous parle en connaissance de cause et vous dis que rien n'est perdu pour la France. Les mêmes moyens qui nous ont vaincus peuvent faire venir un jour la victoire. Car la France n'est pas seule. Elle n'est pas seule! Elle n'est pas seule! Elle a un vaste Empire derrière elle. Elle peut faire bloc avec l'Empire britannique qui tient la mer et continue la lutte. Elle peut, comme l'Angleterre, utiliser sans limite l'immense industrie des Etats-Unis. Cette guerre n'est pas limitée au territoire malheureux de notre pays. Cette guerre n'est pas tranchée par la bataille de France. Cette guerre est une guerre mondiale. Toutes les fautes, tous les retards, toutes les souffrances n'empèchent pas qu'il y a, dans l'univers, tous les moyens pour écraser un jour nos ennemis. Foudroyés aujourd'hui par la force mécanique, nous pourrons vaincre dans l'avenir par une force mécanique supérieure. Le destin du monde est l à. Moi, général de Gaulle, actuellement à Londres, j'invite les officiers et les soldats français qui se trouvent en territoire britannique ou qui viendraient à s'y trouver, avec leurs armes ou sans leurs armes, j'invite les ingénieurs et les ouvriers spécialistes des industries d'armement qui se trouvent en territoire britannique ou qui viendraient à s'y trouver, à se mettre en rapport avec moi. Quoi qu'il arrive, la flamme de la résistance française ne doit pas s'éteindre et ne s'éteindra pas. Demain, comme aujourd'hui, je parlerai à la radio de Londres.	DE GAULLE Charles	Appel du 18 juin.	1940	440     courage	Appel du Général de Gaulle - BBC Londres - 18 juin 1940.	berkeley	1842
Chaque culture traverse les phases évolutives de l'homme en particulier. Chacune a son enfance, sa jeunesse, sa maturité et sa vieillesse.	SPENGLER O.	Le déclin de l"Occident.		545     épistémologie		berkeley	5101
C'est de ta peur que j'ai peur.	SHAKESPEARE William	Roméo et Juliette.		430     paradoxal émotionnel		berkeley	5054
O, gardez-vous, mon seigneur, de la jalousie ; C'est le monstre aux yeux gris qui se moque De la viande dont il se nourrit.	SHAKESPEARE William	Othello,III		433     perversion		berkeley	5055
Face à cette illusion, assez aristocratique, de la puissance de perception illimitée de la pensée, existe une autre illusion, assez plébienne, le réalisme simplet, selon lequel les objets 'sont' la pure vraisemblance de nos sens. Cette illusion occupe l'activité quotidienne des hommes et des animaux.	EINSTEIN Albert	Comment je vois le Monde	1934	360     bon sens	rééd.corr. en 1952 et 1978.	berkeley	2309
Les résultats de la recherche n'exaltent ni ne passionnent. Mais l'effort tenace pour comprendre et le travail intellectuel pour recevoir et pour traduire transforment l'homme.	EINSTEIN Albert	Comment je vois le Monde	1934	390     création	réédition corrigée en 1952 et 1978.	berkeley	2311
La possession de merveilleux moyens de production n'a pas apporté la liberté, mais le souci et la famine.  Der Besitz von wunderbaren Produktionsmitteln brachte nicht Freiheit, sondern Sorge und Hunger.	EINSTEIN Albert	Comment je vois le monde		539     ironie sociale	1879-1955. (Allemand, naturalisé Américain)	berkeley	2319
Le succès fut toujours un enfant de l'audace.	CRéBILLON père	Catilina		440     courage	1674-1762. (Prosper Jolyot de Crébillon)	berkeley	1714
L'identité et la sécurité de la communauté dépendaient de l'existen- ce et de l'exercice du pouvoir, et la connaissance était un des instruments du pouvoir. Elle devait être préservée, certes, mais elle devait aussi être réservée, comme un arcane et un dépôt sacré entre les mains des rois, des prêtres ou des élus. C'était l'essence même du kapu, le fondement du respect pour l'ordre établi. Le roi pouvait mourir de la peste ou devenir gateux mais la royauté demeurait une fonction inviolable, car personne ne pouvait l'exercer sans être investi du mana.	WEST Morris	Kaloni le navigateur.	1976	231     légitimité du pouvoir		berkeley	5367
Très souvent, la seule chose qui sépare un homme charmant d'une femme charmante, c'est qu'ils sont mariés ensemble.	FLERS Robert de	La Belle Aventure		530     ironie amoureuse	1872-1927. (et Gaston Arman de Caillavet)	berkeley	2799
Erostrate vit, qui incendia le temple de Diane; il est presque oublié celui qui le bâtit.  Herostratus lives that burnt the Temple of Diana; he is almost lost that built it.	BROWNE Sir	Urn Burial, 5		510     ironie	1605-1682. (Anglais)	berkeley	875
Leurs oeuvres tomberont à terre. Mais eux-mêmes, je le sais, tendent souvent vers un havre qui m'est interdit... [les artistes]	BROWNING Robert	Andrea del Sarto, the Perfect Painter.		393     création artistique	cité par Morris West dans De main de Maître, 1988.	berkeley	877
Chaque joie est un gain Et un gain est un gain, si petit soit-il.	BROWNING Robert	Paracelsus, IV.		420     capital affectif		berkeley	878
La vérité est en nous, elle ne vient point du dehors.  Truth is within ourselves, it takes no rise from outward things.	BROWNING Robert	Paracelse, I		440     courage	1812-1889. (Anglais)	berkeley	879
Le calcul vaincra le jeu.	Napoléon I			441     sang-froid		berkeley	4561
La gloire se donne seulement à ceux qui l'ont toujours rêvée.	DE GAULLE Charles	Mémoire.		550     grandeur		berkeley	1860
Nos vrais plaisirs consistent dans le libre usage de nous-mêmes.	BUFFON Comte de	Histoire Naturelle		130     liberté		berkeley	886
Tel qui trahit se perd, et les autres avec lui.  Ki hume traïst sei ocit e altroi.	Chanson de Roland			222     fourberie	v. 1100 	berkeley	1163
Dans les idéogrammes chinois, le symbole qui signifiait 'crise' était un mélange de 'danger' et de 'occasions'.	CLANCY Tom	Danger Immédiat	1989	390     création		berkeley	1423
Le plus philosophe du monde ne saurait s'empêcher d'avoir de mauvais songes lorsque son tempérament l'y dispose.	DESCARTES René	Correspondance		433     perversion	1596-1650.	berkeley	1942
J'appelle vices des maladies de l'âme, qui ne sont point si aisées à connaître que les maladies du corps, parce que nous faisons assez souvent l'expérience d'une parfaite santé du corps, mais jamais de l'esprit.	DESCARTES René	Cogitationes privatae		433     perversion	1596-1650.	berkeley	1943
Dieu fit la douce illusion Pour les heureux fous du bel âge ; Pour les vieux fous, l'ambition, Et la retraite pour le sage.	VOLTAIRE	Epîtres.		510     ironie		berkeley	5334
La meilleure éducation consiste à tirer le meilleur parti de soi-même.	GANDHI Mahatma			421     initiation		berkeley	2906
C'est drôle comme les gens qui se croient instruits éprouvent le besoin de faire chier le monde.	VIAN Boris			221     vanité		berkeley	5288
Celui qui jette des livres au feu jettera des peuples au feu.	HEINE Heinrich			110     entropie		berkeley	3104
En fait de vertu, la laideur, c'est déj à la moitié du chemin.  Häßlichkeit bei einem Weise ist schon der halbe Weg zur Tugend.	HEINE Heinrich	Pensées		510     ironie	1797-1856. (Allemand)	berkeley	3105
Quand on commence par brûler des livres, on finit par brûler des hommes.	HEINE Henri			110     entropie		berkeley	3106
Malheur à moi je suis nuance.	NIETZSCHE Friedrich			510     ironie		berkeley	4592
La gaieté est aux hommes ce que la mélancolie est aux femmes; mais la mélancolie est une voilette, et la gaieté est un voile plus difficile à soulever.	DONNAY Maurice	Le Geste		234     communication	1859-1945.	berkeley	2132
Dans les périodes dites heureuses, seules les réponses semblent vivantes.	BLANCHOT Maurice	L"Espace littéraire		312     foi	1907-.	berkeley	766
La véritable nuit est dans le coeur des fleurs, des grandes fleurs noires qui ne s'ouvrent pas.	DAUMAL René	Le Contre-ciel		515     tragédie	1908-1944.	berkeley	1779
Le poète doit, avant qui que ce soit, prouver ce qu'il dit.	DALI Salvador	Métamorphose de Narcisse		393     création artistique	1904-1989.	berkeley	1743
Le sceptique est un homme qui ne se doute de rien.	CLAUDEL Paul	Journal		510     ironie	1868-1955.	berkeley	1457
Il y a des vérités qui peuvent tuer un peuple.	GIRAUDOUX Jean	Electre.		120     grégarité		berkeley	2963
C'est la plus méchante roue du chariot qui mène le plus grand bruit.	Dictons et Proverbes	Dicton		221     vanité		berkeley	2001
Les nations ont le sort qu'elles se font. Rien d'heureux ne leur vient du hasard. Ceux qui les servent sont ceux qui développent leur force profonde.	HERRIOT Edouard	Agir		390     création	1872-1957.	berkeley	3172
L'homme est un loup pour l'homme. (Lupus est homo homini)	PLAUTE	Comédie de Plaute.		210     violence	(254/184 av. J.C.)	berkeley	4721
Un bonheur nous vient-il, cherchons-en un nouveau.	DIERX Léon	Aspirations		390     création	1838-1912.	berkeley	2119
Nos défauts sont parfois les meilleurs adversaires que nous opposions à nos vices.	YOURCENAR Marguerite	Alexis ou le Traité du vain combat		520     ironie de soi	1903-1987. (Marguerite de Crayencour)	berkeley	5516
Il faut choisir, mourir ou mentir.	CéLINE L.-F.	Voyage au bout de la nuit		442     démission	1894-1961. (Louis-Ferdinand Destouches)	berkeley	1080
Un sot ne voit pas le même arbre qu'un sage.  A fool sees not the same tree that a wise man sees.	BLAKE William	The Marriage of Heaven and Hell		510     ironie	1757-1827. (Anglais)	berkeley	759
Les femmes ont un grand besoin de fierté : elles veulent être fières d'elles-mêmes, de leur mari, de leur entourage. Elles sont rarement fières de l'invisible.	GREENE Graham	Le Fond du problème.		510     ironie		berkeley	3011
Dans une vie qui repose sur un perpétuel pari, le risque peut être un perpétuel bonheur.	GRENIER Jean	Inspirations méditerranéennes		312     foi	1898-1971.	berkeley	3012
Le coq ne sort pas de sa nature moins par incapacité, que par orgueil.	LAUTRéAMONT Comte de	Les Chants de Maldoror		221     vanité	1846-1870. (Isidore Ducasse)	berkeley	4047
Riez, mais pleurez en même temps.	LAUTRéAMONT Comte de	Les Chants de Maldoror		330     coeur	1846-1870. (Isidore Ducasse)	berkeley	4048
D'esclave, l'homme de crime peut devenir tyran, mais jamais il ne devient libre.	LAMENNAIS Félicité Robert de	Paroles d"un croyant		210     violence	1782-1854.	berkeley	4021
N'oubliez pas que la concurrence est une forme de guerre controlée.	GOLDSMITH Jimmy	Le Piège.	1993	212     guerre économique		berkeley	2985
La lutte elle-même vers les sommets suffit à remplir un coeur d'homme. Il faut imaginer Sisyphe heureux.	CAMUS Albert	Le Mythe de Sisyphe		440     courage	1913-1960.	berkeley	1012
La Révolution leur criait: - Volontaires,  Mourez pour délivrer tous les peuples vos frères! -  Contents, ils disaient oui.	HUGO Victor	Les Châtiments		215     mystifications	1802-1885.	berkeley	3287
Abrutir est un art. Les prêtres des divers cultes appellent cet art Liberté d'enseignement. Ils n'y mettent aucune mauvaise intention, ayant eux-mêmes été soumis à la mutilation d'intelligence qu'ils voudraient pratiquer après l'avoir subie. Le castrat faisant l'eunuque, cela s'appelle l'Enseignement libre.	HUGO Victor	Paris et Rome		215     mystifications	1802-1885.	berkeley	3288
Etrange, n'est-ce pas, que des myriades d'êtres Avant nous aient franchi la porte des ténèbres... Nul ne revient pour nous dire par où il faut passer Et pour le découvrir, nous devons y aller... !	WEST Morris	Kaloni le navigateur.	1976	421     initiation		berkeley	5411
Si les locomotives étaient conduites comme l'Etat, le machiniste aurait une femme sur les genoux.	CHARTIER Emile	Politique.		240     débauche	alias Alain (1868-1951)	berkeley	1219
L'humour est une tentative pour décaper les grands sentiments de leur connerie.	QUENEAU Raymond			510     ironie		berkeley	4747
Quand on a le physique d'un emploi, on en a l'âme.	MAUPASSANT Guy de	Mont-Oriol		420     capital affectif	1850-1893.	berkeley	4252
On n'écrit pas librement tant qu'on pense à ceux qui vous liront, on n'écrit pas bien tant qu'on ne pense pas à eux.	GRENIER Jean	Nouveau Lexique		393     création artistique	1898-1971.	berkeley	3015
Puisque je vais porter un sort, le mien, Puisque je vais tenter mes forces, ma mesure, Et jouer ce rôle qui m'appartient, Que l'énergie me soit donnée, avec l'amour !	DUHAMEL Georges	Selon ma Loi.		140     rapport à la cosmogonie		berkeley	2203
En politique, la communauté des haines fait presque toujours le fond des amitiés.	TOCQUEVILLE Alexis de	Souvenirs		222     fourberie	1805-1859.	berkeley	5204
... Le bonheur, amie, est chose grave.  Il veut des coeurs de bronze et lentement s'y grave.	HUGO Victor	Hernani, V, 3, Hernani		421     initiation	1802-1885.	berkeley	3326
L'espoir changea de camp, le combat changea d'âme.	HUGO Victor	Les Châtiments		430     paradoxal émotionnel	1802-1885.	berkeley	3327
... Dieu bénit l'homme,  Non pour avoir trouvé, mais pour avoir cherché 	HUGO Victor	Les Contemplations, la Vie aux champs, I, 6		440     courage	1802-1885.	berkeley	3329
La moitié d'un ami, c'est la moitié d'un traître.	HUGO Victor	La Légende des siècles, le Cid exilé		441     sang-froid	1802-1885.	berkeley	3330
Etre contesté, c'est être constaté.	HUGO Victor	Tas de pierres		441     sang-froid	1802-1885.	berkeley	3331
Favoriser le développement des personnalités en exerçant avec méthode la réflexion, le jugement, la faculté de décision, telle doit être la seule loi de l'enseignement donné à l'Ecole.  Cet enseignement se garde rigoureusement de tout corps de théories qui, sous prétexte d'unité de doctrine, prétendrait dresser un critère de l'action de guerre ou codifier les procédés.	DE GAULLE Charles		1926	421     initiation	réflexion sur l"enseignement à l"Ecole supérieure de guerre.	berkeley	1828
... L'autorité ne va pas sans prestige, ni le prestige sans éloignement.	DE GAULLE Charles	Le Fil de l"épée		425     charisme	1890-1970.	berkeley	1829
Il y a des minutes qui dépassent chacune de nos pauvres vies.	DE GAULLE Charles	Mémoires de guerre.		430     paradoxal émotionnel	le 25 août 1944, entrant dans Paris.	berkeley	1831
...je m'apparaissais à moi-même seul et démuni de tout, comme un homme au bord d'un océan qu'il prétendrait traverser à la nage.	DE GAULLE Charles	Mémoires de guerre.		430     paradoxal émotionnel	17/06/40, arrivant à Londres après le voyage depuis Mérignac.	berkeley	1833
Le monde est fait d'idées qui se compensent. Faute de cet équilibre, où irions nous ? Il faut un frein d'autant plus fort que le char est rapide.	DE GAULLE Charles		1934	432     expérience		berkeley	1836
Le courage consiste toujours à ne pas tenir compte du danger. Et puis il faut mourir assassiné ou foudroyé.	DE GAULLE Charles			440     courage		berkeley	1837
Sortez du conformisme, des situations 'acquises', des influnces d'académie. Soyez Carnot, ou nous périrons. Carnot fit Hoche, Marceau, Moreau.	DE GAULLE Charles	lettre à Paul Raynaud, président du conseil.	1940	440     courage	lettre datée du 03/06/40.	berkeley	1839
L'être dit libre est celui qui peut réaliser ses projets.	SARTRE Jean-Paul	L"Etre et le Néant.		130     liberté		berkeley	4955
L'exotisme est tout ce qui est Autre. Jouir de lui est apprendre à déguster le Divers.	SEGALEN Victor	Equipée		460     plaisir	1878-1919.	berkeley	4990
La soumission de l'esprit ! La pire souffrance qu'on puisse imposer à un honnête homme.	WEST Morris	Les bouffons de Dieu.	1981	210     violence		berkeley	5357
Nature n'a rien fait qu'on doive mépriser.	LA CEPPEDE Jean de	Théorèmes spirituels		140     rapport à la cosmogonie	v. 1550-1622 	berkeley	3635
La vraie liberté, c'est de pouvoir toute chose sur soi.	MONTAIGNE Michel Eyquem de	Essais, III, 12		130     liberté	1533-1592.	berkeley	4308
Penser (peser) est fonction de peseur, non fonction de balance.	CHARTIER Emile	Histoire De Mes Pensées.		370     esprit	alias Alain (1868-1951)	berkeley	1230
La haine, c'est la colère des faibles! 	DAUDET Alphonse	Lettres de mon moulin		515     tragédie	1840-1897.	berkeley	1766
Il n'y a pas le pouvoir, il y a l'abus de pouvoir, rien d'autre.	MONTHERLANT Henry Millon de	Le Cardinal d"Espagne, I, 7, Cardona		231     légitimité du pouvoir	1896-1973.	berkeley	4469
Tant de choses ne valent pas d'être dites. Et tant de gens ne valent pas que les autres choses leur soient dites. Cela fait beaucoup de silence.	MONTHERLANT Henry Millon de	Le Maître de Santiago, II, 1, Alvaro		234     communication	1896-1973.	berkeley	4470
Non seulement nous n'avons pas les principes qui mènent au vrai, mais nous en avons d'autres qui s'accommodent bien avec le faux.	FONTENELLE Bernard le Bovier de	Histoire des oracles		441     sang-froid	1657-1757.	berkeley	2825
Le Saint-Esprit n'inspire pas les gens intelligents.	FRANCE Anatole	Propos, rapportés par Paul Gsell		215     mystifications	1844-1924. (Anatole François Thibault)	berkeley	2856
La principale règle est de plaire et de toucher. Toutes les autres ne sont faites que pour parvenir à cette première.	RACINE Jean	Bérénice		234     communication		berkeley	4775
L'homme est prêt à croire à tout, pourvu qu'on le lui dise avec mystère. Qui veut être cru, doit parler bas.	CHAZAL Malcolm de	Sens plastique		215     mystifications	1902-1981.	berkeley	1321
Les maris des femmes qui nous plaisent sont toujours des imbéciles! 	FEYDEAU Georges	Le Dindon, I, 1		235     séduction	1862-1921.	berkeley	2705
Chacun doit être l'aide-jardinier de sa propre âme ...	HUYSMANS Joris-Karl	En route		546     éthique	1848-1907.	berkeley	3372
La préméditation* de la mort est préméditation de la liberté. Qui a appris à mourir, il a désappris à servir.	MONTAIGNE Michel Eyquem de	Essais, I, 20 		130     liberté	1533-1592.  *Méditation préliminaire.	berkeley	4310
Never was so much owed by so many to so few.	CHURCHILL Sir Winston Leonard Spencer		1940	331     altruisme	 à propos du "blitz" et du courage des aviateurs de la R.A.F.	berkeley	1367
Nous pardonnons souvent à ceux qui nous ennuient, mais nous ne pouvons pardonner à ceux que nous ennuyons.	LA ROCHEFOUCAULD François de	Maximes		221     vanité	1613-1680.	berkeley	3825
La connaissance des mots conduit à la connaissance des choses	PLATON			421     initiation	\\010r©	berkeley	4717
La paresse est nécessaire.	CHARDONNE Jacques			370     esprit		berkeley	1192
Nous autres, civilisations, nous savons maintenant que nous sommes mortelles.	VALERY Paul			510     ironie		berkeley	5244
Les animaux se repaissent, l'homme mange, l'homme d'esprit seul sait manger.	BRILLAT-SAVARIN Anthelme	La Physiologie du goût.		370     esprit	1755-1826. compagnon de captivité du Connétable, en 14/18.	berkeley	861
C'est une erreur de moduler vos messages en fonction de ce que vous pensez de cet homme, de sa personnalité et de son état mental. Quand ils sont soumis au stress, les gens changent. L'homme que vous avez au bout du fil n'est peut-être pas celui que vous avez rencontré à Rome.	CLANCY Tom	La somme de toutes les peurs. II.	1991	234     communication		berkeley	1414
L'arbre comme l'homme s'affine en société.	BORDEAUX Henri	La robe de laine.		421     initiation		berkeley	790
Faute de pouvoir agir utilement sur la bêtise, autant l'éviter et y rester indifférent.	FAIRGAGNETR Oscar	Vitalités.	1998	140     rapport à la cosmogonie		berkeley	2453
De cet 'universel abandon', Charles de Gaulle, au début de juillet, croit avoir tout connu. Presque tous sont partis. Presque aucun n'est venu.	LACOUTURE Jean	De Gaulle.	1984	423     solitude		berkeley	3975
Quand on n'a pas ce que l'on aime, il faut aimer ce que l'on a.	BUSSY-RABUTIN Roger de Rabutin	Lettres, A Madame De Sévigné, 23 Mai 1667  		560     sagesse	1618-1693. comte de Bussy. Cette citation se retrouve dans une tragédie héroïque de Thomas Corneille, l"Inconnu  (1675).	berkeley	924
N'importe quel sot peut dire la vérité, mais il faut qu'un homme soit un peu sensé pour savoir bien mentir.  Any fool can tell the truth, but it requires a man of some sense to know how to lie well.	BUTLER Samuel	Notebooks		370     esprit	1835-1902. (Anglais)	berkeley	925
Le panache qu'on voit est l'apanage des gens fauchés.	Dictons et Proverbes	Proverbe WASP.		221     vanité		berkeley	1999
La réthorique, dit Juvénal, mène au Consulat.	Dictons et Proverbes			221     vanité	cité par Ch. de Gaulle.	berkeley	2000
Quand il n'y a plus de quoi, le roi perd son droit.	Dictons et Proverbes			231     légitimité du pouvoir		berkeley	2004
Quand on donne des jambes à la fortune, elle court chez le voisin.	Dictons et Proverbes	Dicton populaire		232     servitudes du pouvoir		berkeley	2005
Quand l'âme d'un ami vous a touché, jamais il ne part.	Dictons et Proverbes	Dicton africain		234     communication		berkeley	2007
N'employez aucun parfum si ce n'est le charme des pensées.	Dictons et Proverbes	Maxime bouddhiste siamoise.		234     communication		berkeley	2008
La confiance c'est comme en amour, il y a toujours un risque.	Dictons et Proverbes	Proverbe anglais		234     communication		berkeley	2009
C'est aux pensées à nourrir les paroles, aux paroles à vêtir les pensées.	Dictons et Proverbes	Maxime orientale.		234     communication		berkeley	2011
Si les choses ne vont pas pour vous et moi aussi mal qu'elles auraient pu aller, nous en sommes redevables en partie à ceux qui ont vécu fidèlement une vie cachée et qui reposent dans des tombes délaissées.  If things are not so ill with you and me as they might have been is half owing to the number who lived faithfully a hidden life and rest in unvisited tombs.	ELIOT George	Middlemarch, Epilogue		546     éthique	1819-1880. (Mary Ann Evans) (Anglaise)	berkeley	2330
Malheureusement, il y a des moments où la violence est la seule façon dont on puisse assurer la justice sociale.  Unhappily, there are times when violence is the only way in which social justice can be secured.	ELIOT Thomas Stearns	Murder in the Cathedral, II		539     ironie sociale	1888-1965. (Américain, naturalisé Anglais)	berkeley	2331
On ne doit pas avaler plus de croyances qu'on ne peut en digérer.  A man must not swallow more beliefs than he can digest.	ELLIS Henry Havelock	The Dance of Life, V		320     intuition	1859-1939. (Anglais)	berkeley	2332
La vie peut être considérée comme un art.  Life may be regarded as an art.	ELLIS Henry Havelock	The Dance of Life, VII		390     création	1859-1939. (Anglais)	berkeley	2333
Si ce sont les plumes qui font le plumage, ce n'est pas la colle qui fait le collage.	ERNST Max	Au-del à de la peinture		390     création	1891-1976.	berkeley	2372
Plus une civilisation progresse rapidement, plus tôt elle meurt pour laisser place à une autre.  The more rapidly a civilization progresses, the sooner it dies for another to arise in its place.	ELLIS Henry Havelock	The Dance of Life		539     ironie sociale	1859-1939. (Anglais)	berkeley	2334
Tout gouvernement est une théocratie impure.  Every government is an impure theocracy.	EMERSON Ralph Waldo	Essays, Politics		215     mystifications	1803-1882. (Américain)	berkeley	2337
Tout héros finit dans la peau d'un raseur.  Every hero becomes a bore at last.	EMERSON Ralph Waldo	Essays, Uses of Great Men		221     vanité	1803-1882. (Américain)	berkeley	2338
La bêtise est quelque chose d'inébranlable, rien ne l'attaque sans se briser contre elle; elle est de la nature du granit, dure et résistante.	FLAUBERT Gustave	L"amour de l"art.	1915	110     entropie	(1821/1880) édition posthume	berkeley	2708
La mouche, en ce commun besoin,  Se plaint qu'elle agit seule, et qu'elle a tout le soin,  Qu'aucun n'aide aux chevaux à se tirer d'affaire.	LA FONTAINE Jean de	Fables, le Coche et la Mouche		221     vanité	1621-1695.	berkeley	3665
Quand une seule victime ne peut obtenir justice, chacun doit s'attendre à être le premier à subir ensuite ces outrages.	Démosthène	Contre Midias, 220		210     violence	384-322 av. J.-C.	berkeley	1896
Je suis l à où je ne pense pas.	LACAN Jacques			130     liberté		berkeley	3959
La patrie d'un cochon se trouve partout où il y a du gland.	Fénelon	Dialogue des morts		223     cupidité	1651-1715. (François de Salignac de La Mothe-)	berkeley	2687
Il faut aimer la nature pour savoir ce qu'elle est.	Proverbes et Dictons	dicton provencal		140     rapport à la cosmogonie		berkeley	4740
La critique est aisée, et l'art est difficile.	Destouches	Le Glorieux, II, 5, Philinte		221     vanité	1680-1754. (Philippe Néricault)	berkeley	1966
L'amitié la plus désinteressée n'est qu'un commerce où notre amour-propre se propose toujours quelque chose à gagner.	LA ROCHEFOUCAULD François de			510     ironie		berkeley	3904
A force d'interroger l'homme, on attend la réponse de Dieu.	PETIT Henri	Le Bonheur.		370     esprit		berkeley	4689
A défaut de pardon, laisse venir l'oubli.	MUSSET Alfred de			360     bon sens		berkeley	4531
... Je suis une force qui va! 	HUGO Victor	Hernani, III, 4, Hernani		310     énergie	1802-1885.	berkeley	3301
La vérité est une science enfantine.	SCHéHADé Georges	Monsieur Bob"le		510     ironie	1907-1989.	berkeley	4967
Les Dieux tousjours à soy ressemblent.	JODELLE Etienne	Didon se sacrifiant		546     éthique	1532-1573.	berkeley	3443
Il n'est, je le vois bien, si poltron sur la terre, Qui ne puisse trouver un plus poltron que soi.	LA FONTAINE Jean de	Fables ; Le Lièvre et les Grenouilles.		221     vanité		berkeley	3667
Les esprits médiocres sont en général assez satisfaits de la vie commune.	STAEL Madame de			110     entropie		berkeley	5121
... des mots bien usés, des mots utiles qui sentaient l'assiette, le pain, l'huile, le linge et le feu de bois.	BOSCO Henri	Le Jardin d"Hyacinthe 		234     communication	1888-1976.	berkeley	794
Il n'y a pas deux temps pareils de solitude car on n'est jamais seul de la même façon.	BOSCO Henri	Malicroix		423     solitude	1888-1976.	berkeley	795
Le mal que peuvent faire les mauvais livres n'est corrigé que par les bons; les inconvénients des lumières ne sont évités que par un plus haut degré de lumières.	STAEL Madame de	De l"Allemagne		421     initiation	1766-1817. (Germaine Necker, baronne de Staël-Holstein)	berkeley	5128
Mais mourir,  Ce peut être une grande fatigue  Un soir,  Et un aveu.	GUILLEVIC Eugène	Terraqué		442     démission	1907-.	berkeley	3051
Tous les hommes mentent et savent qu'ils mentent. La vérité, c'est leur poison.	GUILLOUX Louis	Journal		433     perversion	1899-1980.	berkeley	3052
Une affection est une conviction.	HUGO Victor	Les Misérables.		312     foi		berkeley	3303
On ne devient pas un autre homme. Mais en nous et autour de nous, tout change.	MARCEAU Félicien	Les Années courtes.		441     sang-froid		berkeley	4218
A ne vivre que pour soi, on se conforte un destin de bestiale médiocrité, une enveloppe de vanité infinie où se meurt tout sursaut de conscience de soi, du monde et des autres.	FAIRGAGNETR Oscar	Vitalités.	1994	515     tragédie		berkeley	2632
L'esprit est ce qu'il y a de plus bête au monde.	DU CAMP Maxime	L"Attentat Fieschi		370     esprit	1822-1894.	berkeley	2171
En toute oeuvre d'art, la pensée sort de l'oeuvre, et jamais une oeuvre ne sort d'une pensée.	CHARTIER Emile	La Visite Au Musicien, Les Arts Et Les Dieux .		393     création artistique	alias Alain (1868-1951)	berkeley	1247
Nous n'avons pas toujours assez de force pour supporter les maux d'autrui.	CHARTIER Emile	Propos Sur Le Bonheur.		420     capital affectif	alias Alain (1868-1951)	berkeley	1248
Les défauts de l'esprit augmentent en vieillissant, comme ceux du visage.	LA ROCHEFOUCAULD François de	Maximes		370     esprit	1613-1680.	berkeley	3860
Le travail du corps délivre des peines de l'esprit, et c'est ce qui rend les pauvres heureux.	LA ROCHEFOUCAULD François de	Maximes		380     travail	1613-1680.	berkeley	3861
Pour atteindre de grands objectifs, nous devons oser de grandes choses.	CLAUSEWITZ	De la Guerre.	1812	440     courage		berkeley	1473
D'idées vraies en idées vraies et de clartés en clartés, le raisonnement peut n'arriver qu' à l'erreur.	RIVAROL Antoine de	Discours sur l"homme intellectuel et moral		221     vanité	1753-1801. (Antoine Rivarol)	berkeley	4827
Si l'on veut réaliser des progrès spectaculaires, obtenir des résultats transcendants dans quelque domaine que ce soit, il faut combiner une compétence hors du commun avec une motivation sans failles, des qualités tout à fait hors normes chez une population qui passe ses trente-cinq heures par semaine, en moyenne, devant la télévision et moins d'une heure à faire de l'exercice. [...] Et vu que nous vivons dans une société incapable de mettre en place des politiques éducatives ou sportives cohérantes, il vaut mieux que les accrocs d'informatique [...] se trouvent leurs propres motivations.	CRINGELY Robert X.	Batisseurs d"empires par accident	1992	392     création économique		berkeley	1719
La mer me console - ou me distrait - de la cruelle imbécilité de mon espèce.	FALCO Albert	Capitaine de la Calypso.	1990	510     ironie		berkeley	2652
C'est en se débarrassant de son opacité que l'univers se fond dans l'homme.	ERNST Max	Ecritures		140     rapport à la cosmogonie	1891-1976.	berkeley	2371
L'art nous offre des énigmes, mais par bonheur aucun héros.	BLANCHOT Maurice	Le Livre à venir		393     création artistique	1907-.	berkeley	770
Escusez-moi, monsieur, je n'entends pas le grec.	MOLIERE	Les Femmes Savantes.		510     ironie		berkeley	4301
S'il y a cent mille damnés pour un sauvé, le diable a toujours l'avantage sans avoir abandonné son fils à la mort.	DIDEROT Denis	Addition aux Pensées philosophiques		215     mystifications	1713-1784.	berkeley	2079
L'épouse, c'est pour le bon conseil ; la belle-mère, c'est pour le bon accueil ; mais rien ne vaut une douce maman.	TOLSTOI Léon	Anna Karénine.		420     capital affectif		berkeley	5214
Prophète n'est pas celui qui aurait reçu une éducation de prophète, mais celui qui a la conscience intime de ce qu'il est, doit et ne peut pas ne pas être. Cette conscience est rare, et ne peut être éprouvée que grâce aux sacrifices que l'homme fait à sa vocation. De même que la vraie science et l'art véritable.	TOLSTOI Léon	lettre à Romain Rolland.	1887	550     grandeur		berkeley	5215
Garde-toi de toute complaisance devant la folie de ces quelques-uns et le stress de tous ces autres qui cherchent en toi l'exultoire qu'ils ne trouvent en eux-mêmes. Garde-toi de toute complaisance devant la bêtise de ces trop nombreux qui cherchent en toi le faire-valoir qu'ils ne trouvent en eux-mêmes. Garde-toi de toute complaisance devant la vulgarité qui jamais ne comprend que rien ne s'obtient par procuration.	FAIRGAGNETR Oscar	Vitalités.	1992	441     sang-froid	le 08/06/92, à trois jours du départ pour Besançon.	berkeley	2612
L'univers entier n'est animé que par un seul principe de vie. C'est votre vie présente, mais ce principe de vie peut être orienté de manière constructive ou destructrice, parce que vous avez le pouvoir de choisir. commentaire : le pouvoir de choisir d'inspirer ou de subir sa destinée, d'en extraire l'essentiel, non de la contredire en pure vanité.	MURPHY Dr J.	Comment utiliser les pouvoirs du subconscient.		320     intuition	Comment utiliser les pouvoirs du subconscient.	berkeley	4512
Le premier amour, c'est l'amour de soi.	DESJARDINS Arnaud			312     foi		berkeley	1957
Pensée fait la grandeur de l'homme.	PASCAL Blaise	Pensées		370     esprit		berkeley	4644
Puisque ces mystères me dépassent, feignons d'en être l'organisateur.	COCTEAU Jean	Les Mariés de la tour Eiffel		422     confiance en soi	1889-1963.	berkeley	1510
Ce que le public te reproche, cultive-le, c'est toi.	COCTEAU Jean	Le Potomak		423     solitude	1889-1963.	berkeley	1511
Trouvez ce qui vous rend unique et différent des autres.	KAMI Mike			421     initiation		berkeley	3533
Car il n'y a que la seule irrésolution qui cause les regrets et les repentirs.	DESCARTES René	Correspondance, à Elisabeth, 15 septembre 1645		440     courage	1596-1650.	berkeley	1944
Pourquoi, pauvres idiots, commettre des coquineries en dehors de la loi? il y a tellement de place pour en commettre en dedans.  Perchè, o stolti, far birberie fuor della legge? c'è tanto posto di farne dentro! 	DOSSI Carlo	Note Azzurre, 1977		222     fourberie	1849-1910. (Italien)	berkeley	2140
L'hypocrisie est simplement un hommage à l'intérêt.	DOUWES DEKKER Eduard	Idées		222     fourberie	1820-1887. (Néerlandais)	berkeley	2152
La bonne foi n'est pas une fleur spontanée, la modestie non plus.	COLETTE Sidonie Gabrielle	Ces plaisirs		440     courage	1873-1954.	berkeley	1559
Le difficile, ce n'est pas de donner, c'est de ne pas tout donner.	COLETTE Sidonie Gabrielle	La Naissance du jour		441     sang-froid	1873-1954.	berkeley	1560
Dès que l'homme est trop heureux, il reste seul; et il reste seul, également, dès qu'il est trop malheureux.	ISTRATI Panaït	Oncle Anghel		423     solitude	1884-1935.	berkeley	3401
[une bonne action] C'est celle qui fait apparaître un sourire sur le visage d'autrui.	Jaccard Roland	Carnets d"un été. (Les Séductions de l"Existence)	1990	330     coeur		berkeley	3402
L'art est un jeu. Tant pis pour celui qui s'en fait un devoir.	JACOB Max	Conseils à un jeune poète.		393     création artistique	1876/1944	berkeley	3409
Ouvrez les yeux, ouvrez les yeux, les loups !	KIPLING Rudyard	Le livre de la jungle	1894	440     courage		berkeley	3565
La nécéssité ne connait pas de loi.	St.AUGUSTIN	Solil. Animae ad Deum.		546     éthique		berkeley	5114
Nous avons plus de paresse dans l'esprit que dans le corps.	LA ROCHEFOUCAULD François de	Maximes		321     volonté	1613-1680.	berkeley	3846
L'envie est détruite par la véritable amitié et la coquetterie par le véritable amour.	LA ROCHEFOUCAULD François de	Maximes.		330     coeur		berkeley	3848
La générosité est un industrieux emploi du désintéressement pour aller plutôt à un plus grand intérêt.	LA ROCHEFOUCAULD François de	Maximes.		331     altruisme		berkeley	3849
Venez à moi, vous tous qui peinez et ployez sous le fardeau, et moi je vous soulagerai.	Evangiles	Evangile selon saint Matthieu, XI, 28		215     mystifications		berkeley	2404
Veillez et priez pour ne pas entrer en tentation; l'esprit est ardent, mais la chair est faible.	Evangiles	Evangile selon saint Matthieu, XXVI, 41		215     mystifications		berkeley	2405
Prolétaires de tous les pays, unissez-vous !	MARX Karl & ENGELS Friedrich	Manifeste du Parti communiste.		120     grégarité		berkeley	4243
A un problème, il y a toujours des tas de solutions. Et quand il n'y a pas de solution, c'est qu'il n'y a pas de problème.	SULITZER Paul-Loup	Cartel.	1990	441     sang-froid		berkeley	5163
Ceux qui ne marchent que fort lentement peuvent avancer beaucoup davantage, s'ils suivent toujours le droit chemin, que ne font ceux qui courent, et qui s'en éloignent.	DESCARTES René	Discours de la méthode		441     sang-froid	1596-1650.	berkeley	1946
Et, rêvant déj à de bataille,  Tous sont heureux naïvement;  Car toujours la France tressaille  Au passage d'un régiment.	COPPéE François	Contes en vers et poésies diverses		120     grégarité	1842-1908.	berkeley	1635
Est-ce que les oiseaux se cachent pour mourir ? 	COPPéE François	Promenades et Intérieurs		510     ironie	1842-1908.	berkeley	1636
Rien ne vous atteindra hormis ce que Dieu vous destine.	Coran	Coran, IX, 5		215     mystifications		berkeley	1637
Redoute l'imprécation de l'opprimé, car entre elle et Dieu ne s'interpose aucun voile.	Coran	Coran, II, 139		215     mystifications		berkeley	1638
Hélas! que j'en ai vu mourir, de jeunes filles.	HUGO Victor	Les Orientales		442     démission	1802-1885.	berkeley	3335
Tout est un moyen, même l'obstacle.	IBN SEOUD			421     initiation		berkeley	3375
... Sachant que c'est à l'ironie  Que commence la liberté 	HUGO Victor	La Légende des siècles, Rupture avec ce qui amoindrit		510     ironie	1802-1885.	berkeley	3336
Les pires choses en général sont faites des meilleures qui ont mal tourné. Les diables sont faits d'anges.	HUGO Victor	Fragments		515     tragédie	1802-1885.	berkeley	3338
Ne pouvoir se passer de Paris, marque de bêtise; ne plus l'aimer, signe de décadence.	FLAUBERT Gustave	Carnets		110     entropie	1821-1880.	berkeley	2709
Il y a de par le monde une conjuration générale et permanente contre deux choses, à savoir, la poésie et la liberté; les gens de goût se chargent d'exterminer l'une, comme les gens d'ordre de poursuivre l'autre.	FLAUBERT Gustave	Correspondance, 1842		120     grégarité	1821-1880.	berkeley	2710
J'ai toujours tâché de vivre dans une tour d'ivoire; mais une marée de merde en bat les murs, à la faire crouler...	FLAUBERT Gustave	Correspondance, 1842, à Tourgueniev, 1872		210     violence	1821-1880.	berkeley	2711
La censure, quelle qu'elle soit, me paraît une monstruosité, une chose pire que l'homicide; l'attentat contre la pensée est un crime de lèse-âme. La mort de Socrate pèse encore sur le genre humain.	FLAUBERT Gustave	Correspondance, 1842		214     guerre du savoir	1821-1880.	berkeley	2713
Il arrive que les grandes décisions ne se prennent pas mais se forment d'elles-mêmes.	BOSCO Henri	Malicroix.		430     paradoxal émotionnel		berkeley	796
Qu'est-ce que l'homme? Il est cette force qui finit toujours par balancer les tyrans et les dieux.	CAMUS Albert	Lettres		440     courage	1913-1960.	berkeley	1010
Aimer, c'est trouver sa richesse hors de soi.	CHARTIER Emile	Eléments De Philosophie.		330     coeur	alias Alain (1868-1951)	berkeley	1224
La proximité d'un objet désiré incline à trop d'indulgence. L à réside le danger.	HERBERT Franck	Dune	1965	433     perversion	on	berkeley	3146
Pour obtenir un bien si grand, si précieux, J'ai fait la guerre aux rois, je l'eusse faite aux dieux.	DU RYER	Alcionée.		440     courage		berkeley	2182
Il n'y a rien si sujet à être trompé que la prudence humaine: ce qu'elle espère lui manque, ce qu'elle craint s'écoule, ce qu'elle n'attend point lui arrive.	DU VAIR Guillaume	Traité de la constance		510     ironie	1556-1621.	berkeley	2183
J'ai eu devant moi un homme manifestement rompu à l'exercice du pouvoir, et ayant acquis une très grande confiance en lui-même... Il est intimement convaincu de son mérite et ce qui domine le personnage actuel, c'est son assurance. Conséquence inéductable, il est ambitieux, très ambitieux... De Gaulle l'emportera, ne peut pas ne pas l'emporter...	BOUSCAT René		1943	230     pouvoir	conseillier de Giraud en mission auprès de De Gaulle.	berkeley	821
Car je vous le dis en vérité, si vous avez de la foi gros comme un grain de sénevé, vous direz à cette montagne: 'Déplace-toi d'ici à l à', et elle se déplacera, et rien ne vous sera impossible.	Evangiles	Evangile selon saint Matthieu, XVII, 20		215     mystifications		berkeley	2419
Gloire à Dieu au plus haut des cieux et paix sur la terre aux hommes qu'il aime!	Evangiles	Evangile selon saint Luc, II, 14		215     mystifications	Traduction traditionnelle et, paraît-il, erronée: "... aux hommes de bonne volonté".	berkeley	2422
Déj à même la cognée se trouve à la racine des arbres; tout arbre donc qui ne produit pas de bon fruit va être coupé et jeté au feu.	Evangiles	Evangile selon saint Luc, III, 9		215     mystifications		berkeley	2423
C'est ainsi, je vous le dis, qu'il y aura plus de joie dans le ciel pour un seul pécheur qui se repent que pour quatre-vingt-dix-neuf justes, qui n'ont pas besoin de repentir.	Evangiles	Evangile selon saint Luc, XV, 7		215     mystifications		berkeley	2424
Si le grain de blé ne tombe en terre et ne meurt,  il reste seul;  s'il meurt,  il porte beaucoup de fruit.  Qui aime sa vie la perd;  et qui hait sa vie en ce monde  la conservera en vie éternelle.	Evangiles	Evangile selon saint Jean, XII, 24-25		215     mystifications	Origine du titre d"André Gide: Si le grain ne meurt.	berkeley	2426
Un ami sûr se révèle dans l'adversité.  Amicus certus in re incerta cernitur.  De l'amitié, XVII, 64  	Cicéron			440     courage	106-43 av. J.-C. (Marcus Tullius Cicero)  C"est la citation, par Cicéron, d"un vers d"Ennius, qui l"a traduit d"Euripide (Hécube, 1202).	berkeley	1380
Réussi ou raté, c'est fait.	WEST Morris	De main de Maître.	1988	510     ironie		berkeley	5439
Il faut toujours rendre justice avant que d'exercer la charité 	MALEBRANCHE Nicolas de	Traité de morale		331     altruisme	1638-1715.	berkeley	4191
Les Français n'ont pas la tête épique.  	MALéZIEU Nicolas de	Cité par Voltaire. Essai sur la poésie épique.		510     ironie	1650-1729.	berkeley	4192
Je te salue, âme du monde, Sacré soleil, astre de feu, De tous les biens source féconde, Soleil, image de mon Dieu !	MALFILATRE	Le Soleil fixe au milieu des planètes.		410     santé		berkeley	4193
Toutes les passions, comme le nom l'indique, viennent de ce que l'on subit au lieu de gouverner.	CHARTIER Emile	Minerve Ou De La Sagesse.		430     paradoxal émotionnel	alias Alain (1868-1951)	berkeley	1254
Toute douleur veut être contemplée, ou bien elle n'est pas sentie du tout.	CHARTIER Emile	Propos Sur Le Bonheur.		430     paradoxal émotionnel	alias Alain (1868-1951)	berkeley	1255
C'est chose difficile et profonde De complaire à Dieu et au monde.	Dictons et Proverbes	Dicton.		140     rapport à la cosmogonie		berkeley	1995
La vérité existe. On n'invente que le mensonge.	BRAQUE Georges	Le Jour Et La Nuit.		215     mystifications	1882/1963	berkeley	828
Cet animal est triste, et la crainte le ronge.	LA FONTAINE Jean de	Fables		442     démission	1621-1695.	berkeley	3737
Tous les guerriers vous diront qu'il n'y a que deux types de combattants : l'infanterie, et ceux qui, d'une manière ou d'une autre, soutiennent l'infanterie.	CLANCY Tom	Danger Immédiat	1989	211     guerre		berkeley	1405
Le négligé est une abjuration simulée de coquetterie; mais en même temps le chef-d'oeuvre de l'envie de plaire.	MARIVAUX Pierre Carlet de Chamblain de	Lettre sur les habitants de Paris		235     séduction	1688-1763.	berkeley	4223
La coquette ne sait que plaire, et ne sait pas aimer, voil à pourquoi on l'aime tant.	MARIVAUX Pierre Carlet de Chamblain de	Lettre sur les habitants de Paris		235     séduction	1688-1763.	berkeley	4224
Ne désire rien de plus que ce que Dieu désire.	EPICTETE	Entretiens, II, 17, 22		560     sagesse	v. 50-v. 125.	berkeley	2361
Vous êtes le sel de la terre. Mais si le sel perd sa saveur, avec quoi va-t-on le saler? 	Evangiles	Evangile selon saint Matthieu, V, 13		225     cynisme		berkeley	2429
L'Homme a toujours besoin de caresse et d'amour ...  Il rêvera partout à la chaleur du sein.	VIGNY Alfred de	Les Destinées, la Colère de Samson		420     capital affectif	1797-1863.	berkeley	5294
Faute de courage, le plus grand nombre vous parlera toujours de ce sur quoi il n'agit pas..., en mal, naturellement.	STONE Peter	Vitalités	2003	440     courage	\N	BERKELEY	6010
Un roman : c'est un miroir qu'on promène le long du chemin.	STENDHAL	Le Rouge et le Noir.	1830	393     création artistique		berkeley	5149
Dans les arts, rien ne vit que ce qui donne continuellement du plaisir.	STENDHAL	Vies De Haydn, De Mozart Et De....		393     création artistique	Vies de Haydn, de Mozart et de Métastase, Lettres sur Haydn.	berkeley	5150
On dit souvent que nous souffrons d'être seuls. Je crois que c'est exactement l'inverse : nous souffrons d'un manque de solitude, d'un manque de confiance de chacun dans la vérité personnelle et solitaire de sa propre vie. C'est à partir de cette vérité, et non contre elle, qu'une communauté est possible, souhaitable.	BOBIN Christian			423     solitude	in "Nouvel Observateur" du 3-9/03/94, p. 12.	berkeley	777
Chaque homme est son propre sauveur.	MURPHY Dr J.	Comment utiliser les pouvoirs du subconscient.		320     intuition		berkeley	4513
Eh bien! moi, je vous dis de ne pas tenir tête au méchant: au contraire, quelqu'un te donne-t-il un soufflet sur la joue droite, tends-lui encore l'autre.	Evangiles	Evangile selon saint Matthieu, V, 39		225     cynisme		berkeley	2431
Malheur à vous, scribes et pharisiens hypocrites, qui ressemblez à des sépulcres blanchis: au-dehors ils ont belle apparence, mais au-dedans ils sont pleins d'ossements de morts et de toute pourriture.	Evangiles	Evangile selon saint Matthieu, XXIII, 27		239     servitudes du pouvoir autoritaire		berkeley	2432
Mais si quelqu'un doit scandaliser l'un de ces petits qui croient en moi, il serait préférable pour lui de se voir suspendre autour du cou une de ces meules que tournent les ânes et d'être englouti en pleine mer! 	Evangiles	Evangile selon saint Matthieu, XVIII, 6		239     servitudes du pouvoir autoritaire		berkeley	2433
Le vent souffle où il veut;  Tu entends sa voix,  Mais tu ne sais ni d'où il vient ni où il va.  Ainsi en est-il de quiconque est né de l'Esprit.	Evangiles	Evangile selon saint Jean, III, 8		433     perversion		berkeley	2436
La confiance ne se partage pas. Elle est entièrement donnée ou refusée. Le reste n'est que calcul.	FAIRGAGNETR Oscar			130     liberté		berkeley	2487
Celui qui consomme épuise son bien en espérant consoler ses maux d'esprit. Celui qui collectionne les honneurs et les biens n'accumule que des diplômes de puissance sociale et de sécurisation matérielle qui n'en peuvent mais flattent un égo condamné à l'insatisfaction.	FAIRGAGNETR Oscar	vitalités.	1992	140     rapport à la cosmogonie		berkeley	2492
'l'esprit d'équipe' ?.. une vulgarité d'euphémisme qui ne profitera jamais qu'aux politiciens, aux démagogues et autres profiteurs de la faiblesse humaine.	FAIRGAGNETR Oscar	Vitalités.	1994	215     mystifications		berkeley	2499
Celui qui tire son bonheur des échecs d'autrui mérite sa misère.	FAIRGAGNETR Oscar	Vitalités.	1995	221     vanité	221     vani\\010uì&#240;\\010uñ&#240;	berkeley	2501
Se gausse volontiers des vicissitudes d'autrui celui qui, ému par la certitude de sa propre sureté matérielle et sociale, se laisse emporter par un accès de vanité.	FAIRGAGNETR Oscar		1992	221     vanité		berkeley	2502
L'esprit libre et curieux de l'homme est ce qui a le plus de prix au monde.	STEINBECK John	A l"Est d"Eden;		341     étonnement		berkeley	5142
Mieux vaut être seul que mal accompagné.	GRINGORE Pierre	Notables Enseignements, adages et proverbes		423     solitude	v. 1475-v. 1538.	berkeley	3029
Les honnêtes femmes sont inconsolables des fautes qu'elles n'ont pas commises.	GUITRY Sacha	Elles et toi.		510     ironie		berkeley	3067
Il y a des gens qui parlent, qui parlent - jusqu' à ce qu'ils aient enfin trouvé quelque chose à dire.	GUITRY Sacha			510     ironie		berkeley	3068
Le Mont est foudroyé plus souvent que la plaine.	SPONDE Jean de	Sonnets 		120     grégarité	1557-1595.	berkeley	5106
Ne pense pas avoir fait le moindre progrès, si tu ne te sens pas inférieur à tous.  Non reputes te aliquid profecisse, nisi omnibus inferiorem te esse sentias.	GROOTE Geert	L"Imitation de Jésus-Christ, II, 2, 12		215     mystifications	1340-1384.	berkeley	3033
On défend bien plus férocement sa chance que son droit.	GUéHENNO Jean	Changer la vie		510     ironie	1890-1978.	berkeley	3037
Qui vit sans folie n'est pas si sage qu'il croit.	LA ROCHEFOUCAULD François de	Maximes.		370     esprit		berkeley	3854
Dieu est nommé pour le seul être que l'on puisse adorer en soi sans être enchaîné par l'orgueil.	DAUMAL René	Lettres à ses amis		140     rapport à la cosmogonie	1908-1944.	berkeley	1771
(Leibniz) pose des définitions exactes qui le privent de l'agréable liberté d'abuser des termes dans les occasions.	FONTENELLE Bernard le Bovier de	Eloges des académiciens		370     esprit	1657-1757.	berkeley	2819
Le plus grand secret pour le bonheur, c'est d'être bien avec soi.	FONTENELLE Bernard le Bovier de			423     solitude		berkeley	2820
Celui qui veut être heureux [...] change peu de place et en tient peu.	FONTENELLE Bernard le Bovier de	Entretiens sur la pluralité des mondes.		433     perversion		berkeley	2821
Celui qui peut, agit. Celui qui ne peut pas, enseigne.	SHAW G.-B.	Maximes pour révolutionnaires.		510     ironie		berkeley	5073
Les feux de l'amour laissent parfois une cendre d'amitié.	RéGNIER Henri de	"Donc..."		530     ironie amoureuse	1864-1936.	berkeley	4804
J'ai rêvé de vous après avoir longuement compté les moutons.	Dictons et proverbes			530     ironie amoureuse		berkeley	2073
Tout ce qui est plus d'un est infiniment moins qu'un.	Fénelon	Traité de l"existence de Dieu		365     discernement	1651-1715. (François de Salignac de La Mothe-)	berkeley	2690
Qu'est-ce que la France, je vous le demande? Un coq sur un fumier. Otez le fumier, le coq meurt.	COCTEAU Jean	La Difficulté d"être		510     ironie	1889-1963.	berkeley	1521
C'est seulement quand le froid de l'hiver est arrivé qu'on s'aperçoit que le pin et le cyprès perdent leurs feuilles après tous les autres arbres.	CONFUCIUS	Entretiens, V, 9		441     sang-froid	551-479 av. J.-C. (Chinois)	berkeley	1602
J'avais besoin de ton affection, mais mon orgueil la repoussait.	CLAVEL Bernard	L"ouvrier de la nuit.	1956	430     paradoxal émotionnel		berkeley	1480
Tous les gueux se réconcilient à la gamelle.	DIDEROT Denis	Le Neveu de Rameau		110     entropie	1713-1784.	berkeley	2075
Parfois, le mensonge explique mieux que la vérité ce qui se passe dans l'âme.	GORKI Maxime	Les Vagabonds.		433     perversion		berkeley	2999
J'étais convaincu depuis longtemps que les gazettes sont faites uniquement pour amuser la foule et l'éblouir sur le moment, soit qu'une force extérieure empêche le rédacteur de dire la vérité, soit que l'esprit de parti l'n détourne : aussi n'en lisais-je plus aucune.	GOETHE Johann Wolfgang von	Annales.	1811	215     mystifications		berkeley	2972
Amour, ange de neige et visage aux yeux clos ...	EMIé Louis	Hauts Désirs sans absence		530     ironie amoureuse	1900-1967.	berkeley	2345
Ce qui m'intéresse ce n'est pas trop ce que les choses sont, mais plutôt la manière dont les gens les voient.	EPICTETE			421     initiation		berkeley	2347
Ne demande pas que ce qui arrive, arrive comme tu veux. Mais veuille que les choses arrivent comme elles arrivent, et tu sera heureux.	EPICTETE	Manuel.		440     courage		berkeley	2349
Lorsque quelqu'un a de la malchance, souviens-toi que cette malchance vient de lui, car Dieu a créé les hommes pour le bonheur et pour la paix.	EPICTETE	Entretien III		441     sang-froid		berkeley	2350
Ce qui trouble les hommes, ce ne sont pas les choses, mais les jugements relatifs aux choses.	EPICTETE	Manuel, V		433     perversion	v. 50-v. 125.	berkeley	2353
L'être grégaire qui semble présenter des excuses n'y réussit jamais au-del à d'un simple vice de fourberie...	FAIRGAGNETR Oscar	Vitalités.	1993	222     fourberie		berkeley	2509
Pour ne pas se perdre, la confiance ne doit aller qu' à la foi et au courage.	FAIRGAGNETR Oscar	Vitalités.	1992	234     communication	\\010P`@\\020	berkeley	2518
Les deux voies naturelles pour entrer au cabinet des Dieux et y prévoir le cours des destinées sont la fureur* et le sommeil.	MONTAIGNE Michel Eyquem de	Essais, II, 12 		221     vanité	1533-1592.  *Folie, transe.	berkeley	4328
La vie que nous recevons le jour de notre naissance n'est qu'un accompte sur la vraie vie, que nous devons découvrir seuls.	GUTH Paul	Lettre à votre fils...		421     initiation		berkeley	3075
Sachant que la nature a toujours ses raisons, autant ne pas se disperser à en vouloir à qui que ce soit, sur quoi que ce soit.	FAIRGAGNETR Oscar	Vitalités.	1993	370     esprit		berkeley	2549
L'espoir nait des noces du réel et de l'imaginaire.	CAMUS Albert			350     imagination		berkeley	1001
Toutes les idées sur lesquelles repose aujourd'hui la société ont été subversives avant d'être tutélaires.	FRANCE Anatole	La Vie littéraire		215     mystifications	1844-1924. (Anatole François Thibault)	berkeley	2855
Mallarmé: ce professeur d'attention.	CLAUDEL Paul	Positions et propositions		393     création artistique	1868-1955.	berkeley	1449
La France ne peut être la France sans la grandeur.	DE GAULLE Charles			550     grandeur		berkeley	1861
Le séjour de la vérité dans le noyau sombre des choses est paradoxalement lié à ce pouvoir souverain du regard empirique qui met leur nuit à jour.	FOUCAULT Michel	Naissance de la clinique.		421     initiation		berkeley	2845
Il ne faut pas repousser ceux qui vous aiment.	WEST Morris	Lazare.	1990	330     coeur		berkeley	5385
Il sera toujours plus commode que nécéssaire de ne se mouvoir que d'un simple jet de pierre.	FAIRGAGNETR Oscar			110     entropie		berkeley	2474
Les lois inutiles affaiblissent les lois nécessaires.	MONTESQUIEU Charles de	De l"esprit des lois		546     éthique	1689-1755. (C. de Secondat, baron de La Brède et de M.)	berkeley	4457
Il est plus facile de faire la guerre que la paix.	CLEMENCEAU Georges	Discours de paix, 1919		211     guerre	1841-1929.	berkeley	1482
Le Dieu des chrétiens est un père qui fait grand cas de ses pommes et fort peu de ses enfants.	DIDEROT Denis	Addition aux Pensées philosophiques		215     mystifications	1713-1784.	berkeley	2080
Un sot sera plus souvent un méchant qu'un homme d'esprit.	DIDEROT Denis	Le Neveu de Rameau		221     vanité	1713-1784.	berkeley	2081
La fortune et l'humeur gouvernent le monde.	LA ROCHEFOUCAULD François de	Maximes		539     ironie sociale	1613-1680.	berkeley	3938
En pardonnant trop à qui a failli, on fait injustice à qui n'a pas failli.  Perdonando troppo a chi falla, si fa ingiustizia a chi non falla.	CASTIGLIONE Baldassarye	Il Cortegiano, I		441     sang-froid	1478-1529. (Italien)	berkeley	1053
Ne tenons pas des boutades pour des confidences.	MALRAUX André			234     communication		berkeley	4202
Il n'y a pas d'efforts inutiles, Sisyphe se faisait les muscles.	CAILLOIS Roger	Circonstancielles		441     sang-froid	1913-1978.	berkeley	967
Un gouvernement conservateur est une hypocrisie organisée.  A Conservative government is an organized hypocrisy.	DISRAELI Benjamin	Speech in House of Commons, 17 mars 1845		231     légitimité du pouvoir	1804-1881. (Anglais)	berkeley	2124
La raison et l'amour sont ennemis jurés.	CORNEILLE Pierre	La Veuve, II, 3, la nourrice		530     ironie amoureuse	1606-1684.	berkeley	1686
Mais le trône soutient la majesté des rois  Au-dessus des mépris, comme au-dessus des lois.	CORNEILLE Pierre	Médée, II, 3, Créon		539     ironie sociale	1606-1684.	berkeley	1687
Suis l'exemple et fais voir qu'une âme généreuse Trouve toujours dans sa vertu de quoi la rendre heureuse.	CORNEILLE Pierre	Pulchérie.		550     grandeur	1606-1684.	berkeley	1689
Créer, c'est d'abord peupler.	HERRIOT Edouard	Créer.		390     création		berkeley	3173
L'homme essaie de justifier le Dieu auquel il croit.	GRENIER Jean	L"Existence malheureuse		510     ironie	1898-1971.	berkeley	3019
La faveur des princes n'exclut pas le mérite, et ne le suppose pas aussi.	LA BRUYERE Jean de	Les Caractères, Des jugements		215     mystifications	1645-1696.	berkeley	3597
Une chose m'excède maintenant après m'avoir ébloui: ce sont les citations2 et les références.	GRENIER Jean	La Vie quotidienne		510     ironie	1898-1971.	berkeley	3022
L'homme ne peut agir que parce qu'il peut ignorer. Mais il ne voudrait agir qu'en connaissance de cause - funeste ambition.	GRENIER Jean	Lexique		510     ironie	1898-1971.	berkeley	3023
L'important n'est pas d'aimer mais de donner quelque chose à aimer.	GRENIER Jean	Lexique		530     ironie amoureuse	1898-1971.	berkeley	3024
Je suis une unité qui va bien ou une diversité qui va mal.	DU BOS Charles	Propos à Marie Gouhier		430     paradoxal émotionnel	1882-1939.	berkeley	2168
Tout homme porte sur l'épaule gauche un singe et, sur l'épaule droite, un perroquet.	COCTEAU Jean	Thomas l"imposteur		520     ironie de soi	1889-1963.	berkeley	1531
Je suis un mensonge qui dit toujours la vérité.	COCTEAU Jean	Opéra		520     ironie de soi	1889-1963.	berkeley	1533
L'ignorance toujours est prête à s'admirer.	BOILEAU Nicolas	Art poétique.		110     entropie		berkeley	780
Réputation, réputation, réputation ! Oh, j'ai perdu ma réputation ! J'ai perdu la partie immortelle de moi-même, et ce qui reste est bestial.	SHAKESPEARE William	Othello.		120     grégarité		berkeley	5042
Une indifférence paisible  Est la plus sage des vertus.	PARNY Evariste Désiré de	Elégies		221     vanité	1753-1814.	berkeley	4633
A mon sens, le style de Racine a beaucoup plus vieilli que le style de Corneille. Corneille est ridé; Racine est fané. Corneille reste magnifique, vénérable et puissant. Corneille a vieilli comme un vieil homme; Racine comme une vieille femme.	HUGO Victor	Tas de pierres		221     vanité	1802-1885.	berkeley	3294
Voltaire alors régnait, ce singe de génie  Chez l'homme en mission par le diable envoyé 	HUGO Victor	Les Rayons et les Ombres, Regard jeté dans une mansarde		234     communication	1802-1885.	berkeley	3297
Concision dans le style. Précision dans la pensée. Décision dans la vie.	HUGO Victor			321     volonté	devise adoptée par Charles de Gaulle.	berkeley	3304
C'est par l'esprit que l'homme se sauve, mais c'est par l'esprit que l'homme se perd.	CHARTIER Emile	Mars Ou La Guerre Jugée.		510     ironie	alias Alain (1868-1951)	berkeley	1275
Mirabeau est capable de tout pour de l'argent, même d'une bonne action.	RIVAROL Comte de	Rivaroliana		223     cupidité	1753-1801. (Antoine Rivarol)	berkeley	4839
Il ne faut pas se donner des principes plus forts que son caractère.	CHAMFORT Nicolas-Sébastien de	Pensées, maximes et anecdotes. recueil posthume.		441     sang-froid	1740/1794. Ac. Française.	berkeley	1131
Il faut être juste avant d'être généreux, comme on a des chemises avant d'avoir des dentelles.	CHAMFORT Nicolas-Sébastien de	Maximes et pensées		441     sang-froid	1740/1794. Ac. Française	berkeley	1132
En vivant et en voyant les hommes, il faut que le coeur se brise ou se bronze.	CHAMFORT Nicolas-Sébastien de	Caractères Et Anecdotes.		441     sang-froid	1740/1794. Ac. Française	berkeley	1133
Nous ne cherchons jamais les choses, mais la recherche des choses.	PASCAL Blaise	Pensées.		510     ironie	1623/1662	berkeley	4649
Il y a assez de lumière pour ceux qui ne désirent que de voir, et assez d'obscurité pour ceux qui ont une disposition contraire.	PASCAL Blaise	Pensées		510     ironie		berkeley	4650
Nous ne louons d'ordinaire de bon coeur que ceux qui nous admirent.	LA ROCHEFOUCAULD François de	Maximes		221     vanité	1613-1680.	berkeley	3826
A qui donner le prix? Au coeur, si l'on m'en croit.	LA FONTAINE Jean de	Fables, le Corbeau, la Gazelle, la Tortue et le Rat		330     coeur	1621-1695.	berkeley	3695
Le devoir ... est ce qu'on exige des autres.	DUMAS Alexandre	Denise		433     perversion	1824-1895. (fils)	berkeley	2232
Séduire n'est rien. C'est donner la foi qui est grand.	FAIRGAGNETR Oscar	Vitalités.	1992	234     communication		berkeley	2516
Il y a des services si grands qu'on ne peut les payer que par l'ingratitude.	DUMAS Alexandre	Mes Mémoires		433     perversion	1802-1870. (père)	berkeley	2233
Entre deux mots, il faut choisir le moindre.	VALERY Paul			441     sang-froid		berkeley	5242
Si le vaisseau ne tient qu' à une ancre, le mouillage n'est pas sûr.	Hérondas	Mimes, I, 41-42		441     sang-froid	début du IIIe s. av. J.-C.	berkeley	3169
Le scepticisme est système chez les veules.  Lo scetticismo è il sistema degli infingardi.	BINI Carlo	Manoscritto d"un prigioniero, XXII		433     perversion	1806-1842. (Italien)	berkeley	753
Ceux qui méprisent l'homme ne sont pas de grands hommes.	VAUVENARGUES Marquis de	Réflexions et maximes.		221     vanité	CLAPIER Luc de	berkeley	5259
Dire les formes pour parler du fond.	FAIRGAGNETR Oscar		1988	393     création artistique	(cf. l"OEuvre au Noir)	berkeley	2564
Dieu fit le premier jardin et Caïn la première cité.  God the first garden made, and the first city Cain.	COWLEY Abraham	The Garden		510     ironie	1618-1667. (Anglais)	berkeley	1709
Dieu fit la campagne et l'homme fit la ville.  God made the country, and man made the town.	COWPER William	The Task, I		510     ironie	1731-1800. (Anglais)	berkeley	1710
Dès qu'il a placé le premier pas sur la route, le pèlerin sait qu'il se perd dans le monde, et qu' à mesure qu'il avancera il se perdra de mieux en mieux.	DHOTEL André	Rhétorique fabuleuse		110     entropie	1900-1991.	berkeley	1974
Avant de nous promener sur les routes, ... il faut nous envelopper d'éternel.	DHOTEL André	La Chronique fabuleuse		420     capital affectif	1900-1991.	berkeley	1975
Le corps et l'âme sont des vues prises du même objet à l'aide de méthodes différentes.	CARREL Alexis	L"Homme, cet inconnu		410     santé	1873-1944.	berkeley	1039
Apprenez à juger et à n'accorder votre confiance qu' à ceux qui sont doués d'intuition et de courage.	FAIRGAGNETR Oscar	Vitalités.	1992	365     discernement		berkeley	2548
Laissez-le s'estimer pour qu'il soit estimable.	DELILLE Abbé Jacques	L"Homme des champs		330     coeur	1738-1813.	berkeley	1892
L'esprit n'est pas aussi solide que le corps.	CARREL Alexis	L"Homme, cet inconnu		410     santé	1873-1944.	berkeley	1040
Le snobisme fait faire aux gens du monde autant de vilaines actions que la misère aux malheureux.	FLERS Robert de	Les Précieuses de Genève		221     vanité	1872-1927. (et Francis de Croisset)	berkeley	2794
Il existe, dans l'étendue illimitée de l'avenir, des réponses qui ne répondent à aucune question.	CASSOU Jean	Dernières Pensées d"un amoureux		441     sang-froid	1897-1986.	berkeley	1048
Il n'est pas possible de vivre heureux sans être sage, honnête et juste, ni sage, honnête et juste sans être heureux.	EPICURE	Fragments.		421     initiation		berkeley	2365
Le faible vainc le fort, le souple vainc le dur,  Voie et vertu de l'eau.	LAO TSEU	Tao tö King, LXXVIII		232     servitudes du pouvoir		berkeley	4030
Trompeurs, c'est pour vous que j'écris:  Attendez-vous à la pareille.	LA FONTAINE Jean de	Fables		222     fourberie	1621-1695.	berkeley	3674
L'amour-propre est l'amour de soi-même et de toutes choses pour soi ; il rend les hommes idolâtres d'eux-mêmes, et les rendrait les tyrans des autres, si la fortune leur en donnait les moyens. Il ne se repose jamais hors de soi et ne s'arrête dans les sujets étrangers que comme les abeilles sur les fleurs pour en tirer ce qui lui est propre.	LA ROCHEFOUCAULD François de	Réflexions ou Sentences et Maximes morales.	1665	221     vanité	1613/1680	berkeley	3816
Il est plus facile de paraître digne des emplois qu'on n'a pas que de ceux que l'on exerce.	LA ROCHEFOUCAULD François de	Maximes		221     vanité	1613-1680.	berkeley	3820
Les gens heureux ne se corrigent guère: ils croient toujours avoir raison quand la fortune soutient leur mauvaise conduite.	LA ROCHEFOUCAULD François de	Maximes		221     vanité	1613-1680.	berkeley	3821
Le plus important dans la vie       : amour, devoir. Le plus important dans le travail : beauté, discipline.	DIETRICH Marlène	Livre d"Or du réalisateur Ruben MAMOULIAN		421     initiation	M.demandait à ss invités d"y noter lrs pensées ls pls secret	berkeley	2120
L'amour à la sauvage églantine est pareil,  Et l'amitié pareille au houx,  Sombre est le houx, quand l'églantine est tout en fleur,  Mais lequel fleurit avec plus de constance ?  Love is like the wild rose-briar,  Friendship like the holly-tree,  The holly is dark when the rose-briar blooms  But which will bloom most constantly ? 	BRONTE Emily	Love and Friendship		531     communication amoureuse		berkeley	868
Un jeune homme méfiant est en danger d'être un jour fourbe.	JOUBERT Joseph	Carnets		222     fourberie	1754-1824.	berkeley	3452
La faiblesse est le seul défaut que l'on ne saurait corriger.	LA ROCHEFOUCAULD François de	Maximes		321     volonté	1613-1680.	berkeley	3845
Ce n'est pas assez d'avoir de grandes qualités, il en faut avoir l'économie* 	LA ROCHEFOUCAULD François de	Maximes 		360     bon sens	1613-1680.  *Bonne administration.	berkeley	3851
Il y a des gens niais qui se connaissent et qui emploient habilement leur niaiserie.	LA ROCHEFOUCAULD François de	Maximes		360     bon sens	1613-1680.	berkeley	3852
On est quelquefois un sot avec de l'esprit, mais on ne l'est jamais avec du jugement.	LA ROCHEFOUCAULD François de	Maximes		365     discernement	1613-1680.	berkeley	3853
L'esprit est toujours la dupe du coeur.	LA ROCHEFOUCAULD François de	Maximes		370     esprit	1613-1680. "Les grandes pensées viennent du coeur" dira Vauvenargues.	berkeley	3859
Cessez de juger sur l'apparence. Jugez avec équité.	Evangiles	Evangile selon saint Jean, VII, 24		215     mystifications		berkeley	2428
Je suis venu vers vous sans savoir mon dessin : Mon amour m'entrainait ; et je venais peut-être Pour me chercher moi-même, et pour me reconnaître.	RACINE Jean	Bérénice		531     communication amoureuse		berkeley	4791
Le navigateur n'a aucun autre choix que de naviguer jusqu'au moment où il aborde à une terre, à moins que la mer ne  l'engloutisse car il en était décidé ainsi lors de la fondation de toutes choses. Que puis-je vous dire de plus, à vous qui m'avez fait confiance ?	WEST Morris	Kaloni le navigateur	1976	441     sang-froid	\\010b&#236;∞\\020	berkeley	5431
La peur est ce qui nous maintient en vie. Chez celui qui meurt, il n'y a pas de peur. Je suis déj à mort... Repose en paix.	WEST Morris	Kaloni le navigateur.	1976	441     sang-froid		berkeley	5432
[...] le fanatisme de tous ou partie de ces gamins baptisés Jeunes Génies était né du sentiment de leur supériorité extrême sur le commun des mortels.	LENTERIC Bernard	La nuit des enfants rois.	1981	221     vanité		berkeley	4109
Le monde va comme les vulgaires, les soldats et les artistes le mènent.	FAIRGAGNETR Oscar	Appartés.	1992	510     ironie		berkeley	2620
Le fourbe travaille à donner le change. Le créatif donne le change pour pouvoir travailler.	FAIRGAGNETR Oscar		1991	510     ironie		berkeley	2621
L'amour est la seule passion qui se paye d'une monnaie qu'elle fabrique elle-même.	STENDHAL	De L"amour.		420     capital affectif	Henri Beyle dit STENDHAL	berkeley	5151
Il n'y a pas de droit naturel : ce mot n'est qu'une antique niaiserie. Avant la loi, il n'y a de naturel que la force du lion, ou le besoin de l'être qui a faim, qui a froid, le besoin en un mot.	STENDHAL 	Le Rouge et le Noir.		546     éthique		berkeley	5156
Car l'homme propose et Dieu dispose, et la voie de l'homme n'est pas dans le pouvoir de l'homme.	KEMPIS T. a	Imitation de Jésus-Christ.		520     ironie de soi		berkeley	3543
Le jeu est trop souvent l'émotion des coeurs pauvres.	FAIRGAGNETR Oscar		1986	330     coeur		berkeley	2540
'Make Money', c'est aussi un art, une passion sans rapport avec son objet, une permanente quête de l'inaccessible... C'est une danse ironique, distante et désespérée devant le temps.	SULITZER Paul-Loup	Money	1980	510     ironie		berkeley	5166
Le véritable lieu de naissance est celui où on a porté pour la première fois un coup d'oeil intelligent sur soi-même.	YOURCENAR Marguerite	Mémoires d"Adrien.		520     ironie de soi		berkeley	5514
Les coeurs de nos amis sont souvent plus impénétrables que les coeurs de nos ennemis.	VALERY Paul	Mélange.		340     sensibilité		berkeley	5237
Le sacré est ce qui donne la vie et ce qui la ravit, c'est la source d'où elle coule, l'estuaire où elle se perd.	CAILLOIS Roger	L"Homme et le sacré		312     foi	1913-1978.	berkeley	959
Le seul choix est celui de se battre pour la beauté.	FAIRGAGNETR Oscar	Aphorismes.	1992	312     foi		berkeley	2532
Pourquoi prendrai-je le parti de ce qui est contre ce qui sera? 	SAINT-EXUPéRY Antoine de	Citadelle		365     discernement	1900-1944.	berkeley	4927
Dans la vie, il n'y a pas de solutions. Il y a des forces en marche: il faut les créer, et les solutions suivent.	SAINT-EXUPéRY Antoine de	Vol de nuit		390     création	1900-1944.	berkeley	4928
Et ses yeux n'ont pas vu, présage de son sort,  Auprès d'elle, effeuillant sur l'eau sombre des roses,  Les deux Enfants divins, le Désir et la Mort.	HEREDIA José Maria de	Les Trophées, le Cydnus		510     ironie	1842-1905.	berkeley	3161
Pour l'artiste scrupuleux, l'oeuvre réalisée, quelle qu'en puisse être la valeur, n'est jamais que la scorie de son rêve.	HEREDIA José Maria de			520     ironie de soi	1842-1905.   in les Lettres et les Arts (1886), Notice sur le sculpteur Ernest Christophe	berkeley	3162
Tous ces caprices philosophiques appelés des devoirs n'ont aucun rapport avec la nature.	FOURIER Charles	Théorie de l"unité universelle		221     vanité	1772-1837.	berkeley	2852
Les dessins d'un grand général doivent toujours être impénétrables.	VEGECE	Traité de l"Art militaire. III	378	391     commandement		berkeley	5270
Il faut du courage pour subir une humiliation sans y céder, du courage et de l'ironie pour ne voir toujours, des douleurs du parcours, que les épines d'une rose précieuse.	FAIRGAGNETR Oscar	Vitalités.	1994	510     ironie		berkeley	2630
Hier, aujourd'hui et demain ne font qu'un dans la rivière du temps. Ici et l à-bas sont un unique pays, dès lors qu'ils coexistent dans un esprit.	WEST Morris	De main de Maître.	1988	540     mémoire		berkeley	5455
La réalité du monde est un chaos tragique où chacun doit, par-del à l'adversité et la solitude, s'initier à devenir lui-même pour pouvoir faire, le moment venu, don de ses forces, à l'amour de l'être cher. C'est l à le prix de la beauté de vivre pour et par les siens, au-del à de toutes les misères.	FAIRGAGNETR Oscar	Vitalités.	1995	530     ironie amoureuse		berkeley	2637
Ne prétendons pas changer la nature es choses.	EPICTETE			441     sang-froid	id	berkeley	2355
L'imagination qui, déployant la hardiesse de son vol, a voulu, pleine d'espérance, s'étendre dans l'éternité, se contente alors d'un petit espace, dès qu'elle voit tout ce qu'elle rêvait de bonheur s'évanouir dans l'abime du temps.	Goethe Johann Wolfgang von	Faust.		510     ironie		berkeley	2983
Ce pelé, ce galeux, d'où venait tout leur mal.	LA FONTAINE Jean de	Fables		120     grégarité	1621-1695.	berkeley	3648
Quelque honte que nous ayons méritée, il est presque toujours en notre pouvoir de rétablir notre réputation.	LA ROCHEFOUCAULD François de	Maximes.		441     sang-froid	1613/1680	berkeley	3891
La langueur a ses usages; mais quand elle est perpétuelle, c'est un assoupissement.	FONTENELLE Bernard le Bovier de	Lettres galantes du chevalier d"Her...		442     démission	1657-1757.	berkeley	2828
Vous êtes comme les roses du Bengale, Marianne, sans épines et sans parfum.	MUSSET Alfred de	Les Caprices de Marianne, II, 1, Octave		235     séduction	1810-1857.	berkeley	4525
Après avoir souffert, il faut souffrir encore;  Il faut aimer sans cesse après avoir aimé.	MUSSET Alfred de	Poésies, la Nuit d"août		312     foi	1810-1857.	berkeley	4527
Car l'épée est l'axe du monde et la grandeur ne se divise pas.	DE GAULLE Charles	Vers l"armée de métier.	1934	440     courage		berkeley	1845
On dit : 'Triste comme la porte D'une prison'. Et je crois, le diable m'emporte, Qu'on a raison.	MUSSET Alfred de	Poésies nouvelles.		420     capital affectif		berkeley	4533
A quoi sert la vie si les enfants n'en font pas plus que leurs pères? 	COURBET Gustave	Manuscrit du Cabinet des Estampes		510     ironie	1819-1877.	berkeley	1694
Il n'y a nulle si bonne et désirable finesse que la simplicité.	SALES Saint de	Introduction à la vie dévote		311     distinction	1567-1622.	berkeley	4946
La paresse fait tourner les moulins.	SCHéHADé Georges	Rodogune Sinne		110     entropie	1907-1989.	berkeley	4968
Je ne me suis proposé rien d'autre que de savoir ce que je disais quand je parlais comme tout le monde.	CHARTIER Emile	Propos D"un Normand, T. V.		441     sang-froid	alias Alain (1868-1951)	berkeley	1270
Un homme d'esprit sent ce que les autres ne font que savoir.	MONTESQUIEU Charles de	Les causes qui peuvent affecter les esprits et mes pensées.		140     rapport à la cosmogonie		berkeley	4401
Censure: Utile! on a beau dire.	FLAUBERT Gustave	Dictionnaire des idées reçues		214     guerre du savoir	1821-1880.	berkeley	2712
Partir, c'est mourir un peu C'est mourir à ce qu'on aime On laisse un peu de soi-même En toute heure et en tout lieu.	HARAUCOURT Edmond de	Rondel de l"adieu.		423     solitude	1857/1941	berkeley	3085
La fleur noire d'une société civilisée, une prison.	HAWTHORNE N.	La lettre écarlate, Douane.		210     violence		berkeley	3087
A l'ennemi qui résiste il faut se montrer superbe, et après qu'il est vaincu il est honnête d'user d'humanité 	LA NOUE François de	Discours politiques et militaires		441     sang-froid	1531-1591.	berkeley	3783
Les esprits médiocres condamnent d'ordinaire tout ce qui passe leur portée.	LA ROCHEFOUCAULD François de	Maximes.		110     entropie	1613/1680	berkeley	3785
L'honnêteté des femmes est souvent l'amour de leur réputation et de leur repos.	LA ROCHEFOUCAULD François de	Maximes.		110     entropie		berkeley	3786
Il y a peu de vices qui empêchent un homme d'avoir beaucoup d'amis, autant que peuvent le faire de trop grandes qualités.	CHAMFORT Nicolas-Sébastien de	Maximes et pensées		515     tragédie	1740/1794. Ac. Française	berkeley	1145
La cause qui vous emmène vaut mieux que vous-même.	Dictons et Proverbes	Proverbe Bambara.		550     grandeur	cité dans commentaire d"un documentaire sur le Soudan, diffusé sur F2 le 02/08/93.	berkeley	2058
Le gouvernement est une invention de la sagesse humaine pour pourvoir aux besoins humains. Les hommes ont droit à ce que cette sagesse pourvoie à leurs besoins.  Government is a contrivance of human wisdom to provide for human wants. Men have a right that these wants should be provided for by this wisdom.	BURKE Edmund	Reflections on the Revolution in France		215     mystifications	1729-1797. (Irlandais)	berkeley	906
Sans un peu de travail on n'a pas de plaisir.	FLORIAN Jean-Pierre Claris de	La guenon, le singe et la noix.		380     travail		berkeley	2803
Quelques-uns prennent pour de l'amitié ce qui est de la charité.	MONTHERLANT Henry Millon de	Les Prisonniers		365     discernement	1896-1973.	berkeley	4476
Il n'appartient qu'aux grands hommes d'avoir de grands défauts.	LA ROCHEFOUCAULD François de	Maximes		550     grandeur	1613-1680.	berkeley	3945
Certitude, servitude.	ROSTAND Jean	Carnets d"un biologiste.		221     vanité		berkeley	4864
Il y a des hommes n'ayant pour mission parmi les autres que de servir d'intermédiaires; on les franchit comme des ponts, et l'on va plus loin.	FLAUBERT Gustave	L"Education sentimentale		510     ironie	1821-1880.	berkeley	2773
Erection: Ne se dit qu'en parlant des monuments.	FLAUBERT Gustave	Dictionnaire des idées reçues		510     ironie	1821-1880.	berkeley	2775
L'été est une saison qui prête au comique. Pourquoi? Je n'en sais rien. Mais cela est.	FLAUBERT Gustave	Correspondance, 1842		510     ironie	1821-1880.	berkeley	2776
Je n'en veux point aux sots, j'en veux à la sottise.	DU LORENS Jacques	Les Satires du sieur Lorens		515     tragédie	1583-v.. 1655.	berkeley	2181
'Officier intelligent, cultivé et sérieux ; du brillant et de la facilité ; très bien doué ; beaucoup d'étoffe. Gâte malheureusement d'incontestables qualités par son assurance excessive, sa rigueur pour les opinions des autres et son attitude de roi en exil. Parait par ailleurs avoir plus d'aptitude pour l'étude synthétique et générale d'un problème que pour l'examen approfondi et pratique de son exécution.	MOYRAND Colonel	igen		120     grégarité	Bulletin de fin d"études de Ch. de Gaulle à l"ESG. Appréciation du professeur de tactique.	berkeley	4508
Toutes ces misères-l à prouvent sa grandeur. Ce sont misères de grand seigneur, misères d'un roi dépossédé.	PASCAL Blaise			550     grandeur		berkeley	4654
Nous appelons désintéressé tout homme à qui l'intérêt de sa gloire est plus précieux que celui de la fortune.	Holbach	Système de la nature		221     vanité	1723-1789. (Paul Henri Dietrich, baron d")	berkeley	3203
Evidemment, les fascistes ne sont pas en sommeil, mais il est de notre intéret de les laisser attaquer les premiers ; Ils rassembleront ainsi l'ensemble de la classe ouvrière autour du mouvement... Par ailleurs, toutes nos informations tendent à montrer qu'en Allemagne le fascisme est faible.	STALINE Joseph		1923	215     mystifications		berkeley	5136
Ce n'est pas parce qu'un jour on a fait une action d'éclat, que, fatalement, on a mené une vie exemplaire. Tandis qu'un homme mérite de devenir illustre s'il n'a pas, pendant sa vie, fait de la peine à quelqu'un.	GUITRY Sacha			330     coeur		berkeley	3057
Tous les gestes sont bons quand ils sont naturels. Ceux qu'on apprend sont toujours faux.	GUITRY Sacha	Debureau.		433     perversion		berkeley	3064
Ah! Si j'avais eu la lune! Si l'amour suffisait! Tout serait changé.	CAMUS Albert			520     ironie de soi		berkeley	1024
Il est encore plus facile de juger de l'esprit d'un homme par ses questions que par ses réponses.	LéVIS Duc de	Maximes et réflexions sur divers sujets		365     discernement	1764-1830.	berkeley	4123
Le bel esprit a le malheur d'affaiblir tout ce qu'il croit orner.	Fénelon	Lettre à l"Académie		221     vanité	1651-1715. (François de Salignac de La Mothe-)	berkeley	2684
La jeunesse ressent un plaisir incroyable lorsqu'on commence à se fier à elle.	Fénelon	De l"éducation des filles		221     vanité	1651-1715. (François de Salignac de La Mothe-)	berkeley	2685
D'ordinaire ceux qui gouvernent les enfants ne leur pardonnent rien, et se pardonnent tout à eux-mêmes.	Fénelon	De l"éducation des filles		221     vanité	1651-1715. (François de Salignac de La Mothe-)	berkeley	2686
'Combien de divisions ?'	STALINE Joseph		1943	225     cynisme	s"interrogeant sur la force de l"autorité du Pape.	berkeley	5138
Le trop spirituel est un homme qui n'a jamais assez d'esprit pour savoir la juste mesure qu'il en faut avoir.	MARIVAUX Pierre Carlet de Chamblain de	Réflexions		370     esprit	1688-1763.	berkeley	4229
En général, il faut se redresser pour être grand: il n'y a qu' à rester comme on est pour être petit.	MARIVAUX Pierre Carlet de Chamblain de	La Vie de Marianne		440     courage	1688-1763.	berkeley	4230
Le meilleur moyen pour apprendre à se connaître, c'est de chercher à comprendre autrui.	GIDE André	Journal.		421     initiation		berkeley	2937
Ne peut rien pour le bonheur d'autrui celui qui ne sait être heureux lui-même.	GIDE André	Les Nouvelles Nourritures.		423     solitude		berkeley	2938
J'ai dû réapprendre l'égoïsme et me persuader que, sans égoïsme, je ne parviendrais pas à me 'réussir'.	GIDE André	Journal.		423     solitude		berkeley	2939
'Nil actum reputans, si quid superess et agendum.' Estimant que rien n'est achevé tant qu'il reste quelque chose à tenter.	Latinisme			440     courage		berkeley	4041
En art, comme partout, la pureté seule m'importe.	GIDE André	Les Faux-Monnayeurs.		390     création		berkeley	2933
C'est avec les beaux sentiments que l'on fait de la mauvaise littérature.	GIDE André	Journal.	1940	390     création		berkeley	2934
Malheur à ceux qui se contentent de peu.	MICHAUX Henri	Ecuador.		110     entropie		berkeley	4276
La grandeur de l'homme est grande en ce qu'il se connait misérable. L'arbre ne se connait pas misérable.	PASCAL Blaise	Pensées		520     ironie de soi		berkeley	4652
La femme sera toujours le danger de tous les paradis.	CLAUDEL Paul	Conversations dans le Loir-et-Cher		510     ironie	1868-1955.	berkeley	1458
Ils veulent se mettre hors d'eux et échapper à l'homme. C'est folie ; au lieu de se transformer en ange, ils se transforment en bêtes ; au lieu de se hausser ils s'abattent.	MONTAIGNE Michel Eyquem de	Essais		221     vanité		berkeley	4323
L'honneur que nous recevons de ceux qui nous craignent, ce n'est pas honneur.	MONTAIGNE Michel Eyquem de	Essais, I, 42		221     vanité	1533-1592.	berkeley	4326
L'artiste doit, non pas raconter sa vie telle qu'il l'a vécue, mais la vivre telle qu'il la racontera.	GIDE André			393     création artistique		berkeley	2935
Je n'aime point Dieu parce que je ne le connais pas, ni le prochain parce que je le connais.	MONTESQUIEU Charles de	Mes pensées		215     mystifications	1689-1755. (C. de Secondat, baron de La Brède et de M.)	berkeley	4403
Dans une monarchie bien réglée, les sujets sont comme des poissons dans un grand filet: ils se croient libres, et pourtant ils sont pris.	MONTESQUIEU Charles de	Mes pensées		215     mystifications	1689-1755. (C. de Secondat, baron de La Brède et de M.)	berkeley	4404
On met longtemps à devenir jeune.	PICASSO Pablo	 à d		421     initiation	on	berkeley	4706
On ne comprend guère le mot jeunesse avant trente ans.	DUTOURD Jean	L"Ame sensible		421     initiation	1920-.	berkeley	2244
Les impatients arrivent toujours trop tard.	DUTOURD Jean	Le Fond et la forme		441     sang-froid	1920-.	berkeley	2247
Ecrire, peindre. Cela seul a de l'importance quoi qu'il arrive. Nous mourrons tôt ou tard, d'une façon ou d'une autre, mais les oeuvres resteront.	KAHNWEILER Daniel-Heinrich	l"importance\\010vÄ\\010vÇ†	1934	393     création artistique		berkeley	3528
Un travail réglé et des victoires après des victoires, voil à sans doute la formule du bonheur.	CHARTIER Emile	Propos sur le bonheur.		360     bon sens	alias ALAIN	berkeley	1228
Il faut vivre comme on pense, sinon tôt ou tard on finit par penser comme on a vécu.	BOURGET Paul	Le Démon de midi.		440     courage		berkeley	820
On ne doit plus craindre les mots lorsqu'on a consenti aux choses.  Alexis ou le Traité du vain combat	YOURCENAR Marguerite			440     courage	1903-1987. (Marguerite de Crayencour)	berkeley	5513
...la différence entre 'être bon' et 'gagner', c'est ma préparation mentale avant chaque compétition.	HOPPER Robert			321     volonté	nageur US.	berkeley	3229
L'honnête homme tient le milieu entre l'habile homme et l'homme de bien, quoique dans une distance inégale de ces deux extrêmes.	LA BRUYERE Jean de	Les Caractères		546     éthique	1645-1696.	berkeley	3633
Une grande âme est au-dessus de l'injure, de l'injustice, de la douleur, de la moquerie; et elle serait invulnérable si elle ne souffrait par la compassion.	LA BRUYERE Jean de	Les Caractères		560     sagesse	1645-1696.	berkeley	3634
Le sage ne connaît au-dessus de lui que Jupiter.  Sapiens uno minor est Jove.	Horace	Epîtres, I, I, 106		441     sang-froid	65-8 av. J.-C. (Quintus Horatius Flaccus)	berkeley	3253
L'âge de nos pères ne vaut pas celui de nos aïeux.  Aetas parentum pejor avis.	Horace	Odes, III, VI, 46	6	441     sang-froid	65-8 av. J.-C. (Quintus Horatius Flaccus)	berkeley	3254
Cueille le jour présent, en te fiant le moins possible au lendemain.  Carpe diem quam minimum credula postero.	Horace	Odes, I, XI, 8		441     sang-froid	65-8 av. J.-C. (Quintus Horatius Flaccus)	berkeley	3256
Celui qui ajourne le moment de bien vivre, attend comme les paysans que la rivière ait fini de couler.  Qui recte vivendi prorogat horam,  Rusticus exspectat, dum defluat amnis.	Horace	Epîtres, I, II, 41		442     démission	65-8 av. J.-C. (Quintus Horatius Flaccus)	berkeley	3258
Alléguer l'impossible aux rois, c'est un abus.	LA FONTAINE Jean de	Fables, le Lion, le Loup et le Renard		215     mystifications	1621-1695.	berkeley	3658
Ce n'est pas de tuer l'innocent comme innocent qui perd la société, c'est de le tuer comme coupable.	CHATEAUBRIAND François-René de	Mémoires d"outre-tombe		239     servitudes du pouvoir autoritaire	1768-1848.	berkeley	1294
Si c'est le succès que vous recherchez, préparez vous d'abord à l'échec. C'est toute la philosophie du grand jeu de la vie.	OECH Roger von	Créatif de choc.	1983	421     initiation		berkeley	4625
Nos chimères sont ce qui nous ressemble le mieux.	HUGO Victor	Les Misérables		365     discernement	1802-1885.	berkeley	3310
... On disait que je mettais le nez de travers... mais il fallait bien que je le mette de travers pour qu'ils voient que c'était un nez !	PICASSO Pablo			234     communication	by DHK in "Mes galeries...", entr. av. F.Crémieux.Gallimard 1961	berkeley	4697
Tirons notre courage de notre désespoir même.  Animus ex ipsa desperatione sumatur.  Questions naturelles, II, 59  	Sénèque	Cf. Corneille, Horace		441     sang-froid		berkeley	5030
Oui Seigneur, pardonne à la France qui dit bien la voie droite et chemine par les sentiers obliques.	SENGHOR Léopold Sédar	Hosties noires, Prière de paix		215     mystifications	1906-.	berkeley	5036
On blâme l'injustice, non pas par l'aversion qu'on a pour elle, mais par le préjudice que l'on en reçoit.	LA ROCHEFOUCAULD François de	Maximes.		433     perversion		berkeley	3879
Ceux qui s'appliquent trop aux petites choses deviennent ordinairement incapables des grandes.	LA ROCHEFOUCAULD François de	Maximes.		433     perversion	1613/1680	berkeley	3881
Il ne faut pas s'offenser que les autres nous cachent la vérité, puisque nous nous la cachons si souvent à nous-mêmes.	LA ROCHEFOUCAULD François de	Maximes		433     perversion	1613-1680.	berkeley	3882
On aime mieux dire du mal de soi-même que de n'en point parler.	LA ROCHEFOUCAULD François de	Maximes		433     perversion	1613-1680.	berkeley	3883
Nous sommes si accoutumés à nous déguiser aux autres qu'enfin nous nous déguisons à nous-mêmes.	LA ROCHEFOUCAULD François de	Maximes		433     perversion	1613-1680.	berkeley	3884
Il y a des méchants qui seraient moins dangereux s'ils n'avaient aucune bonté 	LA ROCHEFOUCAULD François de	Maximes		433     perversion	1613-1680.	berkeley	3885
Peu de gens sont assez sages pour préférer le blâme qui leur est utile à la louange qui les trahit.	LA ROCHEFOUCAULD François de	Maximes		440     courage	1613-1680.	berkeley	3888
Quelque bien qu'on dise de nous, on ne nous apprend rien de nouveau.	LA ROCHEFOUCAULD François de	Maximes		441     sang-froid	1613-1680.	berkeley	3893
Ainsi, être vu me constitue comme un être sans défense pour une liberté qui n'est pas ma liberté. C'est en ce sens que nous pouvons nous considérer comme des 'esclaves', en tant que nous apparais- sons à autrui. [] Je suis esclave dans la mesure où je suis dépendant dans mon être au sein d'une liberté qui n'est pas la mienne et qui est la condition même de mon être. Et tant que je suis objet de valeurs qui viennent me qualifier sans que je puisse agir sur cette qualification, ni même la connaître, je suis en esclavage. Du même coup, en tant que je suis l'instrument de possibilités qui ne sont pas mes possibilités, dont je ne fais qu'entrevoir la pure présence par- del à mon être, et qui nient ma transcendance pour me constituer un moyen vers des fins que j'ignore, je suis en danger. Et ce danger n'est pas un accident, mais la structure permanente de mon être-pour-autrui.	SARTRE Jean-Paul	L"Etre et le Néant.	1943	120     grégarité		berkeley	4954
Beaucoup de personnes croient que l'essence vient d'abord et l'existence ensuite [ ]. Cette idée a son origine dans la pensée religieuse [ ]. Mais ceux-mêmes qui n'ont pas la foi ont conservé cette opinion traditionnelle que l'objet n'existait jamais qu'en conformité avec son essence, et le XVIIIe siècle tout entier a pensé qu'il y avait une essence commune à tous les hommes que l'on nom- me nature humaine. L'existentialisme tient, au contraire, que chez l'homme - et chez l'homme seul - l'existence précède l'essence.	SARTRE Jean-Paul	in journal Action	1944	510     ironie		berkeley	4959
Il n'est pas de vice qui ne trouve de défenseur.  Nullum est vitium sine patrocinio.	Sénèque	Lettres à Lucilius, CXVI		221     vanité		berkeley	5022
L'esprit voit, brille et frappe ; il est inspirateur, en un mot prompt et brillant.	RIVAROL Antoine de			370     esprit		berkeley	4829
La dignité, ça s'apprend aussi dans le regard de l'autre.	FAIRGAGNETR Oscar	Vitalités.	1995	421     initiation	on	berkeley	2464
Tes amis, c'est ceux qui n'attendent pas que tu sois en pleine forme pour venir te chercher.	FAIRGAGNETR Oscar	Vitalités.	1995	420     capital affectif		berkeley	2465
Pour se trouver, il faut vivre l à où les efforts accomplis ne sont pas perdus.	FAIRGAGNETR Oscar	Vitalités.	1995	360     bon sens		berkeley	2466
Il y a une architecture qui marche.	CLAUDEL Paul	Conversations dans le Loir-et-Cher		320     intuition	1868-1955.	berkeley	1440
Rien de grand ne se fait sans l'idée fixe, ce clou à transpercer l'invisible.	CHAZAL Malcolm de	Sens plastique		321     volonté	1902-1981.	berkeley	1323
Désordre dans le corps, erreur dans l'esprit, l'un nourrissant l'autre, voil à le réel de l'imagination.  [...] La loi suprême de l'invention humaine est que l'on n'invente qu'en travaillant.	CHARTIER Emile	Système Des Beaux-arts.		390     création	alias Alain (1868-1951)	berkeley	1243
... Les idées, même les plus sublimes, ne sont jamais à inventer, et elles se trouvent inscrites dans le vocabulaire consacré par l'usage.	CHARTIER Emile	Histoire De Mes Pensées.		390     création	alias Alain (1868-1951)	berkeley	1244
Le vrai poète est celui qui trouve l'idée en forgeant le vers.	CHARTIER Emile	Préliminaires A L"esthétique.		393     création artistique	alias Alain (1868-1951)	berkeley	1246
Il y a bien des ingrédients dans la formule qui mène au succès. Et ce n'est jamais deux fois la même mixture. Une goutte de chance créera parfois l'occasion espérée. Mais dans toute recette de succès bien composée, on trouvera avant tout l'honnêteté, l'énergie et la ténacité, sans oublier les capacités et l'expérience qui vient avec le temps. Enfin, n'oublions pas l'imagination créatrice et la confiance qui unissent ces éléments et en font un tout.	COCHRAN Jacqueline	Aviatrice.	1955	390     création	Aviatrice américaine. Compétition et records. Edition condensée pour la jeunesse de son livre "Les Etoiles de Midi. France-Empire Ed.	berkeley	1486
Le premier et le pire effet du gouvernement populaire est que le pouvoir suprême est placé dans des mains irresponsables.	BROUGHAM Lord	De la Démocratie.		230     pouvoir		berkeley	873
L'art ne peut être que figuratif. Cela ne signifie pas pour autant que le peintre doive se substituer à l'appareil photographique. Au contraire. On n'attend pas de lui qu'il reproduise l'objet mais qu'il nous le donne à lire à travers des signes qu'il aura au besoin inventés pour nous transmettre son émotion. La création d'un nouveau langage c'est justement la marque du génie d'un grand peintre. Après un apprentissage, une accoutumance, certains contemporains du peintre sauront le lire. Or la peinture abstraite ne s'appuyant pas sur des signes ne donne rien à lire.	KAHNWEILER Daniel-Heinrich	"A batons rompus avec DHK".	1966	393     création artistique	in Dernières nouvelles d"Alsace, 23/07/1966.	berkeley	3527
Mais je hais les cafards et la race hypocrite  Des tartuffes de moeurs, comédiens insolents,  Qui mettent leurs vertus en mettant leurs gants blancs.	MUSSET Alfred de	Premières Poésies		221     vanité	1810-1857.	berkeley	4521
... on nous ruine en fêtes;  L'une fait tort à l'autre; et Monsieur le curé  De quelque nouveau saint charge toujours son prône.	LA FONTAINE Jean de	Fables, le Savetier et le Financier		120     grégarité	1621-1695.	berkeley	3649
L'oubli me paraît une mort.	Guilleragues	Lettre, à Mme de La Sablière		540     mémoire	1628-1685. (Gabriel-Joseph de Lavergne, comte de)	berkeley	3049
Crève s'il le faut [...] mais ne renonce jamais.	HIGGINS Jack	Saison en enfer.	1989	440     courage		berkeley	3193
L'homme libre, qui vit parmi les ignorants, s'applique autant qu'il le peut à éviter leurs bienfaits.	SPINOZA Baruch	L"Ethique.		423     solitude		berkeley	5105
Il y a un tact moral qui s'étend à tout et que le méchant n'a point.	DIDEROT Denis	Discours sur la poésie dramatique		330     coeur	1713-1784.	berkeley	2092
Provision faite en saison, et dépendue par raison, Fait du bien à la maison.	Dictons et Proverbes	Dicton.		380     travail		berkeley	2015
Le besoin pressant d'un univers logique et cohérant est profondément ancré dans l'inconscient humain. Mais l'univers réel est toujours à un pas au-del à de la logique.	HERBERT Franck	Dune	1965	432     expérience		berkeley	3145
De toutes les catastrophes qui peuvent arriver à un gouvernement, la guerre exceptée, il n'en est pas de pire que des fuites dans un système de communication. [...] Un gouvernement qui ne peut pas garder ses secrets ne peut pas fonctionner.	CLANCY Tom	La somme de toutes les peurs. II.	1991	214     guerre du savoir		berkeley	1407
Toutes les fois que les gouvernements prétendent faire nos affaires, ils les font plus mal et plus dispendieusement que nous.	CONSTANT Benjamin	Cours de politique constitutionnelle		215     mystifications	1767-1830. (Henri-B. de Rebecque)	berkeley	1618
La plupart des hommes, en politique comme en tout, concluent des résultats de leurs imprudences à la fermeté de leurs principes.	CONSTANT Benjamin	Journal intime		221     vanité	1767-1830. (Henri-B. de Rebecque)	berkeley	1620
L'homme qui peut se mettre à la place des autres, qui peut comprendre le mécanisme de leurs pensées, celui-l à n'a pas à s'inquiéter de ce que l'avenir lui réserve.	YOUNG Owen D.			370     esprit		berkeley	5503
Il y a longtemps que je sais qu'une once d'inertie pèse plus qu'un boisseau de sagesse, dit Zénon avec dépit.	YOURCENAR Marguerite	L"OEuvre au Noir	1968	110     entropie	Académie Française. vivait en Nouvelle-Angleterre.	berkeley	5504
Eglé, belle et poète, a deux travers : Elle fait son visage et ne fait pas ses vers.	ECOUCHARD-LEBRUN			221     vanité	 à l"adresse de Mme Fanny de Beauharnais.	berkeley	2279
Le geôlier est une autre sorte de captif.	NERVAL Gérard de	Sur un carnet		232     servitudes du pouvoir	1808-1855. (Gérard Labrunie)	berkeley	4567
La philosophie nous enseigne à douter de ce qui nous parait évident. La propagande, au contraire nous enseigne à accepter pour évident ce dont il serait raisonnable de douter.	HUXLEY Aldous	Retour au Meilleur des Mondes	1958	214     guerre du savoir		berkeley	3354
Le but du démagogue est de créer la cohésion sociale sous sa propre autorité.	HUXLEY Aldous	Retour au Meilleur des Mondes	1958	215     mystifications		berkeley	3355
L'ambition est la plus violente des perversions de l'espérance.	FAIRGAGNETR Oscar	Aphorismes.	1992	433     perversion		berkeley	2594
Face à l'évènement, c'est à lui-même que recourt l'homme de caractère. Son mouvement est d'imposer à l'action sa marque, de la prendre à son compte, d'en faire son affaire.	DE GAULLE Charles	Mémoires de Guerre		440     courage		berkeley	1843
Rien ne rehausse l'autorité mieux que le silence, splendeur des forts, et refuge des faibles.	DE GAULLE Charles	Le Fil de l"Epée.		441     sang-froid		berkeley	1847
La poésie est une peinture qui se sent au lieu de se voir.	VINCI Léonard de	Traité de la Peinture.		393     création artistique		berkeley	5315
Tu perds ta peine, douleur; si importune que tu sois, je n'avouerai jamais que tu sois un mal.  Nihil agis, dolor! quamvis sis molestus, nunquam te esse confitebor malum.	Cicéron	Tusculanes, II, 25.		321     volonté	106-43 av. J.-C. (Marcus Tullius Cicero). Cicéron prête ces mots au philosophe Posidonios.	berkeley	1378
Faites ce que je dis et non ce que je fais.	DELAVIGNE Casimir	Louis XI.		520     ironie de soi		berkeley	1890
Etre supérieur aux autres n'a jamais représenté un grand effort si l'on n'y joint pas le beau désir d'être supérieur à soi-même.	DEBUSSY Claude	Monsieur Croche, antidilettante		520     ironie de soi	1862-1918.	berkeley	1871
Nul ne doit être inquiété pour ses opinions, même religieuses, pourvu que leur manifestation ne trouble pas l'ordre public établi par la loi.	Déclaration des Droits de l"Homme	Article X	1789	215     mystifications	1789. (et du Citoyen)	berkeley	1872
L'argent n'est rien, l'honneur est beaucoup et le courage est tout.	Napoléon I			440     courage		berkeley	4560
La dernière vilenie de l'âme est la crainte de son devoir.  La última villanía del Animo es temer su obligacion.	QUEVEDO Y VILLEGAS Francisco Gomez de	La constancia y paciencia del santo Job		442     démission	1580-1645. (Espagnol)	berkeley	4750
La bourgeoisie sans le peuple, c'est la tête sans le bras. Le peuple sans la bourgeoisie, c'est la force sans la lumière.	QUINET Edgar	Avertissement Au Pays.		238     servitudes du pouvoir politique	1803-1875	berkeley	4752
Il est impossible que Voltaire contente, et impossible qu'il ne plaise pas.	JOUBERT Joseph	Pensées		393     création artistique	1754-1824.	berkeley	3459
Enseigner, c'est apprendre deux fois.	JOUBERT Joseph	Pensées		421     initiation	1754-1824.	berkeley	3462
Vivre est une maladie, dont le sommeil nous soulage toutes les seize heures; c'est un palliatif: la mort est le remède.	CHAMFORT Nicolas-Sébastien de	Maximes et pensées		510     ironie	1740/1794. Ac. Française	berkeley	1135
Les trois quarts des folies ne sont que des sottises.	CHAMFORT Nicolas-Sébastien de	Maximes et pensées		510     ironie	1740/1794. Ac. Française	berkeley	1137
Chaque fois qu'on me loue, je respire mon tombeau.	MONTHERLANT Henry Millon de	La Reine morte, I, 2, Ferrante		441     sang-froid	1896-1973.	berkeley	4485
Les grandes idées ne sont pas charitables.	MONTHERLANT Henry Millon de	Le Maître de Santiago, I, 4, Obregon		441     sang-froid	1896-1973.	berkeley	4486
Il s'agit à tout moment de sacrifier ce que nous sommes à ce que nous pouvons devenir.	DU BOS Charles	Approximations.		440     courage	1882-1939.	berkeley	2169
Personne ne tend plus de pièges aux tyrans que ceux qui feignent de les aimer le plus sincèrement.	Xénophon	Hiéron, I, 38		239     servitudes du pouvoir autoritaire	v. 430-v. 355 av. J.-C.	berkeley	5501
Une sottise ou une infamie, en se renforçant d'une autre, peut devenir respectable. Collez la peau d'un âne sur un pot de chambre, et vous en faites un tambour.	FLAUBERT Gustave	Carnets		221     vanité	1821-1880.	berkeley	2722
Qui veut la gloire passionnément, finit par l'obtenir, ou du moins en approche de bien près. Mais il faut vouloir, et non pas une fois; il faut vouloir à tous les instants.	HéRAULT DE SéCHELLES Marie-Jean	Voyage à Montbard		321     volonté	1759-1794.	berkeley	3127
N'est-il pas honteux que les fanatiques aient du zèle et que les sages n'en aient pas ? Il faut être prudent mais non pas timide.	VOLTAIRE	Pensées détachées de Monsieur l"Abbé de St-Pierre.		440     courage		berkeley	5332
Je n'ai plus d'ennemis quand ils sont malheureux.	HUGO Victor	L"Année terrible		420     capital affectif	1802-1885.	berkeley	3320
Ainsi dit le renard ; et flatteurs d'applaudir.	LA FONTAINE Jean de	Fables, Les Animaux malades de la peste.		222     fourberie		berkeley	3680
Nombre d'actions humaines sont commandées par une sorte d'intérêt que l'on appelle, en propre terme, le désintéressement.	DUHAMEL Georges	Positions françaises		331     altruisme	1884-1966.	berkeley	2206
Regarde en avant ! (Look to the front)	Dictons et Proverbes			440     courage	Devise des Chasseurs à pied de l"armée britanique.	berkeley	2030
Père de famille sois partout ; Dernier couché, premier debout.	Dictons et Proverbes	Dicton.		440     courage		berkeley	2031
Certaines choses sont si sérieuses qu'il vous faut les tourner en dérision.	BOHR Niels			510     ironie		berkeley	779
La vraie générosité envers l'avenir consiste à tout donner au présent.	CAMUS Albert	L"Homme révolté		440     courage	1913-1960.	berkeley	1011
Le manteau de la liberté sert à couvrir nombre de petites chaînes.	BROSSES Président de	Lettres, à Voltaire		215     mystifications	1709-1777.	berkeley	872
La bouée crée parfois les apparences de la profondeur.	LEC Stanislas	Pensées Echevelées.		222     fourberie		berkeley	4082
Les jeux des enfants ne sont pas des jeux, et les faut juger en eux comme leurs plus sérieuses actions.	MONTAIGNE Michel Eyquem de	Essais, I, 23		421     initiation	1533-1592.	berkeley	4352
Avoir plu aux puissants n'est pas le plus haut mérite.  Principibus placuisse viris non ultima laus est.	Horace	Epîtres, I, XVII, 35		221     vanité	65-8 av. J.-C. (Quintus Horatius Flaccus)	berkeley	3235
Connaître par non-connaissance est très élevé.	LAO TSEU	Tao tö King, LXXI		320     intuition		berkeley	4031
L'âme, c'est la vanité et le plaisir du corps tant qu'il est bien portant.	CéLINE L.-F.	Voyage au bout de la nuit		433     perversion	1894-1961. (Louis-Ferdinand Destouches)	berkeley	1076
Ecoute, mais n'entends pas.	CHAR René	La Parole en archipel		441     sang-froid	1907-1988.	berkeley	1184
On ne doit pas accorder sa confiance à quelqu'un qui ne sourit jamais.	MONTHERLANT Henry Millon de	Carnets		234     communication	1896-1973.	berkeley	4471
On reconnaît au premier coup d'oeil quelqu'un qui est content de ce qu'il fait.	CLANCY Tom	La somme de toutes les peurs. II.	1991	312     foi		berkeley	1419
Que de choses il faut ignorer pour 'agir'! 	VALéRY Paul	Choses tues		510     ironie	1871-1945.	berkeley	5249
Un sot ni n'entre, ni ne sort, ni ne s'assied, ni ne se lève, ni ne se tait, ni n'est sur ses jambes, comme un homme d'esprit.	LA BRUYERE Jean de	Les Caractères		515     tragédie	1645-1696.	berkeley	3626
Il vient toujours un moment où l'essentiel d'une doctrine qui a paru abstruse est expliquée en trois mots par un homme d'esprit.	VALERY Paul			370     esprit		berkeley	5239
J'ai compris que lorsqu'on tient trop à une chose, même à la vie, on devient prisonnier.	WEST Morris	Les bouffons de Dieu.	1981	430     paradoxal émotionnel		berkeley	5419
Tout homme est sensible quand il est spectateur. Tout homme est insensible quand il agit.	CHARTIER Emile	Vigiles de l"esprit		340     sensibilité	1868-1951. (Emile Chartier)	berkeley	1225
Je suis plus sûr de mon jugement que de mes yeux.	DIDEROT Denis	Pensées philosophiques		365     discernement	1713-1784.	berkeley	2093
On ne subit pas le salut. On le fait.	CLEMENCEAU Georges	Démosthène		390     création	1841-1929.	berkeley	1483
Il est aussi difficile à un poète de parler de poésie qu' à une plante de parler horticulture.	COCTEAU Jean			234     communication	 à François Mauriac	berkeley	1497
Courir plus vite que la beauté.	COCTEAU Jean	Journal d"un inconnu		311     distinction	1889-1963.	berkeley	1498
C'est ... cette manière d'épauler, de viser, de tirer vite et juste, que je nomme le style.	COCTEAU Jean	Le Secret professionnel		311     distinction	1889-1963.	berkeley	1499
La sérénité ne peut être atteinte que par un esprit désespéré, et pour être désespéré, il faut avoir beaucoup vécu et aimer encore le monde.	CENDRARS Blaise	Une nuit dans la forêt		330     coeur	1887-1961. (Frédéric Sauser)	berkeley	1084
On est toujours fils de ses oeuvres.  Cada uno es hijo de sus obras.	CERVANTES SAAVEDRA Miguel de	Don Quichotte, I, 4		390     création	1547-1616. (Espagnol)	berkeley	1089
Seules errances d'amour  Sont dignes de pardon.  Que los yerros por amores  Son dignos de perdonar.	CERVANTES SAAVEDRA Miguel de	La comedia entretenida		430     paradoxal émotionnel	1547-1616. (Espagnol)	berkeley	1090
Trente moines et leur abbé ne peuvent faire braire un âne contre sa volonté.	CERVANTES SAAVEDRA Miguel de	Les Nouvelles exemplaires.		510     ironie	1547-1616. (Espagnol)	berkeley	1092
L'homme a imaginé Dieu pour ne pas se tuer.	DOSTOIEVSKI Fiodor Mikhaïlovitch			510     ironie		berkeley	2150
Pour un lecteur, aucune journée n'est perdue ; chacune lui apporte une connaissance ou une sympathie de plus. Et il aura d'autant plus d'indulgence pour les hommes que les écrivains lui auront mieux fait comprendre les motifs de leur action et les fatalités de leur conduite.	JALOUX Edmond			421     initiation		berkeley	3412
Je ne sais quel homme* disait: 'Je voudrais voir le dernier des Rois étranglé avec le boyau du dernier des Prêtres.' 	CHAMFORT Nicolas-Sébastien de	Caractères et anecdotes 		215     mystifications	1740/1794. Ac. Française. * Diderot peut-être.	berkeley	1111
Chaque civilisation a les ordures qu'elle mérite.	DUHAMEL Georges	Querelles de famille		539     ironie sociale	1884-1966.	berkeley	2220
A certains moments culminants de l'existence, il suffit d'un mot pour que nous options pour l'héroïsme ou la lâcheté (...) Mais ce mot, personne ne le dit. Amour-propre, sans doute, mais aussi courage, simple courage.	UNIENVILLE Alix d"	En Vol.	1950	441     sang-froid	récit d"un vol aérien mouvementé par l"orage, donné en pige à ELLE et qui vaut à l"auteur de recevoir le Prix Albert Londres 1950.	berkeley	5231
Si vous voulez vivre longtemps, vivez vieux.	SATIE Erik	Cahiers d"un mammifère		433     perversion	1866-1925.	berkeley	4963
Qui sait s'il ne faut pas dépasser beaucoup (la nature) pour entendre ce qu'elle veut nous dire.	SADE Marquis de	Aline et Valcour		140     rapport à la cosmogonie	1740-1814.	berkeley	4901
J'ai toujours peur d'un sot. On n'est jamais sûr qu'il ne s'agit pas aussi d'un coquin.  I am always afraid of a fool. One cannot be sure that he is not a knave as well.	HAZLITT William	Characteristics		222     fourberie	1778-1830. (Anglais)	berkeley	3089
Les morts dorment en paix dans le sein de la terre : Ainsi doivent dormir nos sentiments éteints. Ces reliques du coeur ont aussi leur poussière.	MUSSET Alfred de	La nuit d"octobre.		540     mémoire		berkeley	4550
Il faut se servir de ses conquêtes pour conquérir.	DUMAS Alexandre	Napoléon Bonaparte, III, 1		441     sang-froid	1802-1870. (père)	berkeley	2235
Rien n'est si dangereux qu'un ignorant ami;  Mieux vaudrait un sage ennemi.	LA FONTAINE Jean de	Fables, l"Ours et l"Amateur des jardins		370     esprit	1621-1695.	berkeley	3700
Ami, cache ta vie et répands ton esprit.	HUGO Victor	Les Rayons et les Ombres.		234     communication		berkeley	3299
Attendre d'en savoir assez pour agir en toute lumière, c'est se condamner à l'inaction.	ROSTAND Jean	Inquiétudes d"un biologiste		520     ironie de soi	1894-1977.	berkeley	4874
L'homme de pouvoir est l'esclave des intérêts qu'il administre pour préserver la force de l'interface politique qui le relie au monde. Sa parole ne pèse jamais plus que le poids de la complaisance qu'il porte à son oeuvre, c'est à dire, à lui-même.	FAIRGAGNETR Oscar	ir e	1991	232     servitudes du pouvoir	Pot de terre et pot de fer, méandres, suite, etc...	berkeley	2512
Un coeur n'est jamais à vendre ou à louer. Ne donne jamais le tien qu' à celles et ceux qui le savent.	FAIRGAGNETR Oscar	vitalités.	1992	234     communication		berkeley	2513
Ce grand monde ... c'est le miroir où il nous faut regarder pour nous connaître de bon biais.	MONTAIGNE Michel Eyquem de	Essais, I, 26		421     initiation	1533-1592.	berkeley	4354
La vraie solitude ... se peut jouir au milieu de villes et de cours de rois; mais elle se jouit plus commodément à part.	MONTAIGNE Michel Eyquem de	Essais, I, 39		423     solitude	1533-1592.	berkeley	4355
Le langage de la vérité est simple.  Veritatis simplex oratio est.	Sénèque	Lettres à Lucilius, XLIX		440     courage		berkeley	5028
Bien que la sagesse ne puisse s'acquérir avec de l'or, elle peut encore moins s'acquérir sans lui.  Though wisdom cannot be gotten for gold, still less can it be gotten without it.	BUTLER Samuel	Notebooks		560     sagesse	1835-1902. (Anglais)	berkeley	932
L'histoire est une galerie de tableaux où il y a peu d'originaux et beaucoup de copies.	TOCQUEVILLE Alexis de	L"Ancien Régime et la Révolution		540     mémoire	1805-1859.	berkeley	5211
Rien n'est plus rare que la véritable bonté; ceux mêmes qui croient en avoir n'ont d'ordinaire que de la complaisance ou de la faiblesse.	LA ROCHEFOUCAULD François de	Maximes		221     vanité	1613-1680.	berkeley	3811
La minorité a toujours raison.	IBSEN Henrik	Un ennemi du peuple		120     grégarité	1828-1906. (Norvégien)	berkeley	3376
Si j'étais rossignol, j'accomplirais l'oeuvre du rossignol; si j'étais un cygne, celle du cygne. Mais je suis un être raisonnable, je dois chanter Dieu.	EPICTETE	Entretiens, I, 6, 20-21		560     sagesse	v. 50-v. 125.	berkeley	2360
On devient cuisinier, mais on naît rotisseur.	BRILLAT-SAVARIN Anthelme	Physiologie du Goût.		110     entropie	compagnon de captivité du Connétable, en 14/18.	berkeley	860
L'art occupe le milieu entre le sensible pur et la pensée pure.	HEGEL Friedrich	Esthétique.		393     création artistique	1770/1831	berkeley	3096
Il préférait avoir été malheureux pour une bonne raison qu'heureux pour une mauvaise.	SAGAN Françoise	Aimez-vous Brahms?		433     perversion	1935-. (Françoise Quoirez)	berkeley	4912
On peut faire semblant d'être grave ; on ne peut pas faire semblant d'avoir de l'esprit. Il faut en avoir et n'en a pas qui veut.	GUITRY Sacha	L"esprit de Paris.		370     esprit		berkeley	3060
Le bonheur s'attache aux plus fragiles aspects, et naît, de préférence, des choses minimes et du vent.	BRASILLACH Robert	L"Enfant De La Nuit.		140     rapport à la cosmogonie		berkeley	834
Chaque mot écrit est une victoire contre la mort.	BUTOR Michel	Entretiens avec Georges Charbonnier		393     création artistique	1926-.	berkeley	935
On ne doit jamais écrire que de ce qu'on aime.	RENAN Ernest	Souvenirs d"enfance et de jeunesse.		393     création artistique		berkeley	4810
Nous gagnerions plus de nous laisser voir tels que nous sommes que d'essayer de paraître ce que nous ne sommes pas.	LA ROCHEFOUCAULD François de	Maximes.		221     vanité		berkeley	3798
Le mal que nous faisons ne nous attire pas tant de persécution et de haine que nos bonnes qualités.	LA ROCHEFOUCAULD François de	Maximes		539     ironie sociale	1613-1680.	berkeley	3939
Tout n'est formé que des parties d'un Tout prodigieux Dont le corps est la Nature, et Dieu, l'âme.	POPE A.	Essai sur l"Homme.		140     rapport à la cosmogonie		berkeley	4728
Traînant l'aile et tirant le pied.	LA FONTAINE Jean de	Fables		442     démission	1621-1695.	berkeley	3736
Malheur à vous qui riez maintenant, car vous connaîtrez le deuil et les larmes! 	Evangiles	Evangile selon saint Luc, VI, 25		215     mystifications		berkeley	2421
J'aime qu' à mes desseins la fortune s'oppose:  Car la peine de vaincre en accroît le plaisir.	BERTAUT Jean	Stances		440     courage	1552-1611.	berkeley	732
Le clerc se sentait libre comme la bête et menacé comme elle, équilibré comme l'arbre entre le monde d'en bas et le monde d'en haut, ployé lui aussi par des pressions s'exerçant sur lui et qui ne cesseraient qu' à sa mort.	YOURCENAR Marguerite	L"OEuvre au Noir	1968	430     paradoxal émotionnel	Académie Française. vivait en Nouvelle-Angleterre	berkeley	5511
L'idée de Dieu est, je l'avoue, le seul tort que je ne puisse pardonner à l'homme.	SADE Marquis de	Juliette		215     mystifications	1740-1814.	berkeley	4904
Pour que l'intérêt d'un avantage justifie infailliblement l'injustice, il conviendrait d'être, toujours, juge et partie.	FAIRGAGNETR Oscar	Vitalités.	1994	225     cynisme		berkeley	2510
La communication n'est souvent qu'un jeu de lumières entre des miroirs en quête d'éclairage.	FAIRGAGNETR Oscar	Vitalités.	1993	234     communication		berkeley	2522
Pour plaire, il est nécéssaire et suffisant d'afficher de la confiance en soi.	FAIRGAGNETR Oscar	Aphorismes.	1992	235     séduction		berkeley	2526
On juge un homme sur ses ennemis aussi bien que sur ses amis.  You shall judge of a man by his foes as well as by his friends.	CONRAD Joseph	Lord Jim, 34		370     esprit	1857-1924. (Konrad Korzeniowski) (Anglais d"origine polonaise)	berkeley	1615
Qui mérite le non de sage ? Celui qui trouve quelqu chose à apprendre de chaque homme.	MISHNA			560     sagesse		berkeley	4290
Les gens du monde ne sont pas plus tôt attroupés qu'ils se croient en société.	CHAMFORT Nicolas-Sébastien de	Maximes et pensées		120     grégarité	1740/1794. Ac. Française	berkeley	1105
A nous de savoir, à personne d'autre.	HELIAS Pierre-Jakez	Les autres et les miens.		423     solitude		berkeley	3108
Il y a des gens qu'il faut étourdir pour les persuader.	HELVéTIUS Claude Adrien	Notes, maximes et pensées		214     guerre du savoir	1715-1771.	berkeley	3109
L'art du politique est de faire en sorte qu'il soit de l'intérêt de chacun d'être vertueux.	HELVéTIUS Claude Adrien	Notes, maximes et pensées		215     mystifications	1715-1771.	berkeley	3110
Rien n'est plus dangereux que les passions dont la raison conduit l'emportement.	HELVéTIUS Claude Adrien	Notes, maximes et pensées		433     perversion	1715-1771.	berkeley	3111
La conversation devient plate à proportion que ceux avec qui on la tient sont plus élevés en dignité.	HELVéTIUS Claude Adrien	Notes, maximes et pensées		539     ironie sociale	1715-1771.	berkeley	3112
Les lois de nos désirs sont des dés sans loisir.	DESNOS Robert	Corps et biens		433     perversion	1900-1945.	berkeley	1961
Travailler sans en avoir envie, ce n'est pas un travail qu'on fait, c'est une besogne. Et c'est à ces moments-l à qu'on se rend compte à quel point l'on a peu de mérite à faire les choses qui vous plaisent. Quand on travaille dans la joie, dans l'enthousiasme, on n'a droit à rien. On n'a même pas droit au succès. On est payé d'avance.	GUITRY Sacha	Théatre, je t"adore.		380     travail		berkeley	3062
Le bon sens est le concierge de l'esprit : son office est de ne laisser entrer ni sortir les idées suspectes.	STERN Daniel			360     bon sens		berkeley	5157
Une décision rapide, même mauvaise, est de loin préférable à la bonne qui vient trop tard.	PRESTES Luis Carlos		1935	440     courage	leader communiste brésilien	berkeley	4732
L'observation est l'investigation d'un phénomène naturel, et l'expérience est l'investigation d'un phénomène modifié par l'investigateur.	BERNARD Claude	Introduction à l"étude de la médecine expérimentale		390     création	1813-1878.	berkeley	703
A l'égard des modes, les gens raisonnables doivent changer les derniers, mais ils ne doivent pas se faire attendre.	MONTESQUIEU Charles de	Mes pensées		365     discernement	1689-1755. (C. de Secondat, baron de La Brède et de M.)	berkeley	4435
Quand on a été femme à Paris on ne peut être femme ailleurs.	MONTESQUIEU Charles de	Mes pensées		420     capital affectif	1689-1755. (C. de Secondat, baron de La Brède et de M.)	berkeley	4436
L'étude a été pour moi le souverain remède contre les dégoûts de la vie, n'ayant jamais eu de chagrin qu'une heure de lecture n'ait dissipé.	MONTESQUIEU Charles de	Pensées diverses.		421     initiation		berkeley	4437
Nous n'inventons rien vraiment. Nous empruntons et recréons.	MILLER Henry			390     création		berkeley	4285
Mais comment donc rénover, comment restaurer l'ordre sans tout d'abord instaurer le désordre? 	SEGALEN Victor	Peintures		440     courage	1878-1919.	berkeley	4991
Se réveiller, c'est se mettre à la recherche du monde.	CHARTIER Emile	Vigiles De L"esprit.		340     sensibilité	alias Alain (1868-1951)	berkeley	1226
Une nation n'a de caractère que lorsqu'elle est libre.	STAEL Madame de	De la littérature		239     servitudes du pouvoir autoritaire	1766-1817. (Germaine Necker, baronne de Staël-Holstein)	berkeley	5123
Les peuples d'Europe ayant exterminé ceux de l'Amérique, ils ont dû mettre en esclavage ceux de l'Afrique, pour s'en servir à défricher tant de terres.	MONTESQUIEU Charles de	De l"esprit des lois		239     servitudes du pouvoir autoritaire	1689-1755. (C. de Secondat, baron de La Brède et de M.)	berkeley	4427
Il faut bien connaître les préjugés de son siècle, afin de ne les choquer pas trop, ni trop les suivre.	MONTESQUIEU Charles de	Les causes qui peuvent affecter les esprits et mes pensées.		365     discernement		berkeley	4431
Il faut savoir le prix de l'argent: les prodigues ne le savent pas, et les avares encore moins.	MONTESQUIEU Charles de	Mes pensées		365     discernement	1689-1755. (C. de Secondat, baron de La Brède et de M.)	berkeley	4434
La plus subtile de toutes les finesses est de savoir bien feindre de tomber dans les pièges que l'on nous tend [...]	LA ROCHEFOUCAULD François de	Maximes.		441     sang-froid	1613/1680	berkeley	3894
Il faut toujours réaliser ses désirs lorsqu'on le peut, ne serait-ce que pour mieux peser le sens et le valable. [...] Les seuls regrêts doivent naître des choses qu'on n'a pas pu accomplir.	SARRAZIN Albertine	Biftons de prison.		440     courage		berkeley	4952
Préférer les roses piquantes aux fleurs fanées.	FAIRGAGNETR Oscar		1992	370     esprit		berkeley	2550
Hélas! combien je croyais savoir  D'amour, et combien peu j'en sais!  Ai, las! tan cuidava saber 	VENTADOUR Bernard de	D"amor, e tan petit en sai!		520     ironie de soi	XIIe siècle (Provençal)	berkeley	5272
Ne cesse pas de reculer derrière toi-même.	DAUMAL René	Le Contre-ciel		441     sang-froid	1908-1944.	berkeley	1778
Lorsque, comme Lazare, je fus enlevé à la nuit, que m'aveugla la lumière d'un jour nouveau, je sus que ma vie ne serait plus la même.	WEST Morris	Lazare.	1990	510     ironie		berkeley	5441
La littérature anticipe toujours la vie. Elle ne la copie point, mais la moule à ses fins.	WILDE Oscar	La décadence du mensonge.		393     création artistique		berkeley	5474
La réponse est le malheur de la question.	BLANCHOT Maurice	L"Entretien infini		510     ironie	1907-.	berkeley	772
Je ne saurais vous dire comme tout ça me dégoûte. C'est si laid. Avoir travaillé honnêtement, ma foi, et pour une bonne cause, et être obligé ensuite de se battre tous les jours pour les pauvres choses qu'on a acquises... C'était bien la peine, mon Dieu, d'être convenable jusqu'au bout pour être obligé [...] de se débattre comme un fou pour ce que j'ai acquis non seulement avec mes sous, ce qui serait peu, mais avec tout mon être, ce qui est beaucoup.	KAHNWEILER Daniel-Heinrich	Lettre à Fernand Léger.	1919	510     ironie		berkeley	3530
L'on voit des hommes tomber d'une haute fortune par les mêmes défauts qui les y avaient fait monter.	LA BRUYERE Jean de	Les Caractères		510     ironie	1645-1696.	berkeley	3624
Des dons techniques s'arrêteront toujours court si l'homme est mesquin, petit. Picasso, lui, est un grand homme.	KAHNWEILER Daniel-Heinrich	Préface au catalogue de l"expo "Pour les 80 ans de Picasso.	1961	550     grandeur	Los Angeles, UCLA Art galleries, oct/nov.1961.	berkeley	3531
Un menteur a besoin d'une grande mémoire.	QUINTILIEN	L"institution oratoire.		222     fourberie		berkeley	4753
Tous les hommes cherchent le bonheur, même ceux qui vont se pendre.	PASCAL Blaise			510     ironie	510     iron\\010r"†\\010r*\\020´	berkeley	4648
Heureuse par l'amour, quelle femme discute son bonheur ?  L'homme qui le lui donne est le premier parmi les hommes.  Il n'est pas question de le comparer : il est roi...	PREVOST Marcel	Sa Maitresse et moi.		531     communication amoureuse		berkeley	4735
Une oeuvre où il y a des théories est comme un objet sur lequel on laisse la marque du prix.	PROUST Marcel	Le Temps Retrouvé.	1927	393     création artistique	1871/1922	berkeley	4736
La faiblesse d'un enfant est une prison. Baste. Il suffit de ne jamais lâcher prise. La vie apportera les solutions.	QUEFFELEC Henri	Ce Sont Voiliers Que Vent Emporte.		420     capital affectif		berkeley	4745
A fermeté de père, courage d'un fils.	QUEFFELEC Henri	Ce Sont Voiliers Que Vent Emporte.	1984	421     initiation		berkeley	4746
Les délinquants font moins de mal qu'un mauvais juge.  Menos mal hacen los delincuentes, que un mal juez.	QUEVEDO Y VILLEGAS Francisco Gomez de	Política de Dios y Gobierno de Cristo, I, 9		221     vanité	1580-1645. (Espagnol)	berkeley	4749
J'aime la vérité. Je crois que l'humanité en a besoin ; mais elle a plus grand besoin encore du mensonge qui la flatte, la console, lui donne des espérances infinies. Sans le mensonge, elle périrait de désespoir et d'ennui.	FRANCE Anatole	La Vie en fleur.		510     ironie		berkeley	2868
Tout ce qui n'est pas Dieu n'est rien, et doit n'être compté pour rien.  Et quidquid Deus non est, nihil est, et pro nihilo computari debet.	GROOTE Geert	L"Imitation de Jésus-Christ, III, 31, 11		215     mystifications	1340-1384.	berkeley	3032
La poésie n'a de rôle à jouer qu'au-del à de la philosophie.	BRETON André	Les Pas perdus		393     création artistique	1896-1966.	berkeley	850
La philosophie éclaire comme la lanterne sourde et ne jette de la lumière en avant qu' à la condition de faire de l'ombre derrière elle.	HUGO Victor	Tas de pierres		221     vanité	1802-1885.	berkeley	3296
Enfin sa fécondité n'engendre que barbelés, miradors, flicaille en tout genre : officielle (avec uniforme), parallèle (milices), officieuse (police politique), souterraine (téléphone et courrier), sans compter les douaniers, chargés de prévenir l'entrée et surtout la sortie. Le voil à, le vrai bilan (globalement carcéral) : Le marxisme n'aura décidément su créer que des prisons.	MORENO Roland	Théorie du Bordel Ambiant	1990	215     mystifications	Inventeur de la carte à mémoire, vendue cash.	berkeley	4498
Si tu crains beaucoup la souffrance, si elle n'est pour toi nullement agréable, ne fais le mal ni ouvertement, ni en secret.	Udânavarga	Udânavarga, IX, 3.		330     coeur		berkeley	5225
Je pourrais surmonter ma peine car l'enrichissement intérieur demeure.	UHDE Wilhelm			440     courage	marchand et auteur de "Von Bismarck to Picasso".	berkeley	5226
Il faut demeurer d'accord à l'honneur de la vertu que les plus grands malheurs des hommes sont ceux où ils tombent par leurs crimes.	LA ROCHEFOUCAULD François de			210     violence		berkeley	3791
Tous les hommes ont un secret attrait pour les ruines ... Les ruines jettent une grande moralité au milieu des scènes de la nature.	CHATEAUBRIAND François-René de	Le Génie du christianisme		442     démission	1768-1848.	berkeley	1306
Ne te courbes pas pour aimer.	CHAR René			530     ironie amoureuse		berkeley	1188
Malheur à vous quand tout le monde dira du bien de vous! C'est bien de cette manière que leurs pères traitaient les faux prophètes.	Evangiles	Evangile selon saint Luc, VI, 26		120     grégarité		berkeley	2399
... une douleur n'étant ni petite ni grande,  Qu'autant que le courage est ou grand ou petit.	BERTAUT Jean	Cantique		440     courage	1552-1611.	berkeley	733
Il faut se ressembler un peu pour se comprendre, mais il faut être un peu différents pour s'aimer. Oui, semblables et et dissemblables..	GERALDY Paul	L"Homme et l"Amour.		234     communication		berkeley	2923
Mon Dieu, le plus souvent l'apparence déçoit : Il ne faut pas toujours juger sur ce que l'on voit.	MOLIERE	Tartuffe.		441     sang-froid		berkeley	4299
La pitié ne naît point dans l'esprit sans culture, mais dans celui du sage.	Euripide	Electre, 294-295		560     sagesse	480-406 av. J.-C.	berkeley	2396
Un homme qui enseigne peut devenir aisément opiniâtre, parce qu'il fait le métier de quelqu'un qui n'a jamais tort.	MONTESQUIEU Charles de			221     vanité	221     vani\\010N à\\020\\010Nä&#240;	berkeley	4407
La connaissance craque, aussi bien que l'amour, aux hommes sans courage.	CHARTIER Emile	Sentiments, Passions Et Signes.		440     courage	alias Alain (1868-1951)	berkeley	1261
J'aime mieux une pensée fausse qu'une routine vraie.	CHARTIER Emile	Propos D"un Normand, T. II.		440     courage	alias Alain (1868-1951)	berkeley	1262
Comme rien n'est plus précieux que le temps, il n'y a pas de plus grande générosité qu' à le perdre sans compter.	JOUHANDEAU Marcel	Journaliers		510     ironie	1888-1979.	berkeley	3484
Il n'est point de plus grande gloire pour les hommes que celle d'être brave par les pieds et par les bras.	HOMERE	L"Odyssée.		120     grégarité		berkeley	3214
Ce n'est pas la passion qui détruit l'oeuvre d'art, c'est la volonté de prouver.	MALRAUX André	Le Temps Du Mépris.		234     communication		berkeley	4203
Tout pouvoir sans contrôle rend fou.	CHARTIER Emile	Politique.		232     servitudes du pouvoir	alias Alain (1868-1951)	berkeley	1214
Les confidences ... sont toujours de fausses confidences.	CHARTIER Emile	Histoire De Mes Pensées.		234     communication	alias Alain (1868-1951)	berkeley	1215
Invoquer sa postérité, c'est faire un discours aux asticots.	CéLINE L.-F.	Voyage au bout de la nuit		221     vanité	1894-1961. (Louis-Ferdinand Destouches)	berkeley	1071
...Les escadres aériennes, capables d'opérer au loin, douées d'une foudroyante vitesse, manoeuvrant dans les trois dimensions, frappant des coups verticaux - les plus impressionnants de tous - doivent jouer un rôle capital dans la guerre de l'avenir.	DE GAULLE Charles	Vers l"armée de métier.	1934	211     guerre		berkeley	1795
La beauté sauvera le monde.	DOSTOIEVSKI  Fiodor Mikhaïlovitch			550     grandeur		berkeley	2146
Je suis toujours la ligne droite, mais je change parfois de ligne droite.	SALACROU Armand	Histoire de rire.		441     sang-froid		berkeley	4943
Les lâches clameurs de l'envie Te suivent jusque dans les cieux ; Crois-moi, dédaigne d'en descendre, Ne t'abaisse pas pour entendre Ces bourdonnements détracteurs.	LAMARTINE Alphonse de	Méditations, I.		423     solitude		berkeley	4002
Mon coeur, lassé de tout, même de l'espérance  N'ira plus de ses voeux importuner le sort.	LAMARTINE Alphonse de	Premières Méditations poétiques, le Vallon		442     démission	1790-1869.	berkeley	4005
La chance, cette belle fille au sourire céleste.	WEISS Pierre			510     ironie		berkeley	5347
Il mange tout, ce gros glouton, Il boit tout ce qu'il a de rente ; Son pourpoint n'a plus qu'un bouton, Mais son nez en a plus que trente.	GOMBAULD J.O. de			110     entropie		berkeley	2995
On trouve des disciples de la sagesse qui ne sont pas parfaits; on n'a jamais vu un homme sans principes qui fût parfait.	CONFUCIUS	Entretiens, VII, 14		546     éthique	551-479 av. J.-C. (Chinois)	berkeley	1609
La mort attrape d'abord ceux qui courent.	GIONO Jean	L"Iris De Suse.		441     sang-froid		berkeley	2956
... Je ne sais ce que c'est que vouloir sans faire.	CHARTIER Emile	Entretiens Au Bord De La Mer.		321     volonté	alias Alain (1868-1951)	berkeley	1222
Réfléchir, c'est nier ce que l'on croit.	CHARTIER Emile	Propos Sur La Religion.		433     perversion	alias Alain (1868-1951)	berkeley	1258
La vie est un travail qu'il faut faire debout.	CHARTIER Emile	Propos D"un Normand.		440     courage	alias Alain (1868-1951)	berkeley	1260
La terre entière, continuellement imbibée de sang, n'est qu'un autel immense où tout ce qui vit doit être immolé sans fin, sans mesure, sans relâche, jusqu' à la consommation des choses, jusqu' à l'extinction du mal, jusqu' à la mort de la mort.	MAISTRE Joseph de	Les Soirées de Saint-Pétersbourg		110     entropie	1753-1821.	berkeley	4176
Madame, si c'est possible, c'est fait; impossible, cela se fera.  	CALONNE Charles Alexandre de	Réponse du ministre des Finances à une demande de la reine Marie-Antoinette.		215     mystifications	1734-1802.	berkeley	972
Il faut aimer, et ne laisser pas de vivre.	FONTENELLE Bernard le Bovier de	Lettres galantes du chevalier d"Her...		546     éthique	1657-1757.	berkeley	2835
Il n'est nullement besoin d'être aimé pour bien jouir et ... l'amour nuit plutôt aux transports de la jouissance qu'il n'y sert.	SADE Marquis de	Juliette		530     ironie amoureuse	1740-1814.	berkeley	4909
Je ne suis le porte-drapeau de personne... Ecrire est une entreprise tellement solitaire...	SAGAN Françoise	interview.		393     création artistique		berkeley	4911
La voie de l'homme sage s'exerce sans lutter.	LAO TSEU	Tao tö King, LXXXI		560     sagesse		berkeley	4039
Un homme dépourvu de sincérité et de fidélité est un être incompréhensible à mes yeux. C'est un grand char sans flèche, un petit char sans timon; comment peut-il se conduire dans le chemin de la vie ?	CONFUCIUS	Doctrine ; Le Lun-Yu.		110     entropie		berkeley	1590
Dès le premier instant, Churchill avait décelé chez le monumental 'Connétable de France' une grande 'aptitude à la douleur'. Il aurait pu percevoir chez lui une égale aptitude à rompre, à partir, fondée sur une puissance de concentration si intense qu'elle se dénoue périodiquement dans une sorte de relachement, de dégoût. On ne s'impose pas impunément des fardeaux si formidables...	LACOUTURE Jean	De Gaulle.	1984	310     énergie		berkeley	3973
Tout, l à-bas, tendait au repli, à la clôture, à l'exaltation du passé. Ici, au vent du large, on se déploie, on ambitionne, on fait des plans non plus pour survivre, mais pour renaître.	LACOUTURE Jean	De Gaulle.	1984	390     création	 à propos des deux faces d"une France de Vichy et d"Alger.	berkeley	3974
La parole venue de Londres sera pendant quatre ans la voix nocturne de l'imaginaire - cette rébellion de l'esprit contre le réel, qui peut aussi être une préfiguration du réel.	LACOUTURE Jean	DE GAULLE	1984	430     paradoxal émotionnel		berkeley	3976
Comme souvent, l'action parut être la voie vers la synthèse. Comment mieux ressouder une alliance que dans le risque pris en commun ?	LACOUTURE Jean	DE GAULLE.	1984	440     courage		berkeley	3978
Le bonheur des méchants comme un torrent s'écoule.	RACINE Jean	Andromaque		110     entropie		berkeley	4767
Le petit mot 'Je ferai' a perdu des empires. Le futur n'a de sens qu' à la pointe de l'outil.	CHARTIER Emile	Minerve Ou De La Sagesse.		441     sang-froid	alias Alain (1868-1951)	berkeley	1267
La raison est virile devant l'objet, puérile devant le récit.	CHARTIER Emile	Vigiles De L"esprit.		441     sang-froid	alias Alain (1868-1951)	berkeley	1268
L'erreur propre aux artistes est de croire qu'ils trouveront mieux en méditant qu'en essayant ... Ce qu'on voulait faire, c'est en le faisant qu'on le découvre.	CHARTIER Emile	Avec Balzac.		441     sang-froid	alias Alain (1868-1951)	berkeley	1269
On dit fort bien que si les triangles faisaient un Dieu, ils lui donneraient trois côtés.	MONTESQUIEU Charles de	Lettres persanes.	1721	221     vanité	1689/1755	berkeley	4409
Apprenez que tout flatteur  Vit aux dépens de celui qui l'écoute.	LA FONTAINE Jean de	Fables, le Corbeau et le Renard		222     fourberie	1621-1695.	berkeley	3679
Voltaire n'écrira jamais une bonne histoire. Il est comme les moines qui n'écrivent pas pour le sujet qu'ils traitent, mais pour la gloire de leur ordre. Voltaire écrit pour son couvent.	MONTESQUIEU Charles de	Mes pensées		221     vanité	1689-1755. (C. de Secondat, baron de La Brède et de M.)	berkeley	4412
Il y a trois manières de se ruiner, disait le grand Rothschild : le jeu, les femmes et les ingénieurs. Les deux premières sont les plus agréables, mais la dernière est la plus sure.	DETOEUF Auguste			510     ironie	1883/1947	berkeley	1971
Je tiens la connaissance de soi comme une source de soucis, d'inquiétudes et de tourments. Je me suis fréquenté le moins possible.	FRANCE Anatole	Le Petit Pierre		520     ironie de soi	1844-1924. (Anatole François Thibault)	berkeley	2869
Tout en marchant à la tête du cortège, je sens qu'en ce moment même des ambitions me font escorte en même temps que des dévouements.	DE GAULLE Charles	Mémoires de guerre.		120     grégarité	le 25 août 1944, entrant dans Paris.	berkeley	1785
La réalité ne se plie point à l'idéal, mais le confirme.	FLAUBERT Gustave	L"amour de l"art.	1915	422     confiance en soi	(1821/1880) édition posthume	berkeley	2760
La mort ne surprend point le sage:  Il est toujours prêt à partir.	LA FONTAINE Jean de	Fables		560     sagesse	1621-1695.	berkeley	3766
... Je voudrais qu' à cet âge  On sortît de la vie ainsi que d'un banquet,  Remerciant son hôte, et qu'on fît son paquet.	LA FONTAINE Jean de	Fables, la Mort et le Mourant		560     sagesse	1621-1695.	berkeley	3767
En France, le premier jour est pour l'engouement, le second pour la critique et le troisième pour l'indifférence.	LA HARPE Jean François de	Mélanges		539     ironie sociale	1739-1803.	berkeley	3773
Si j'ai perdu mes jours dans la volupté, ah! rendez-les moi, grands dieux, pour les reperdre encore.	LA METTRIE Julien Offroy de	L"Art de jouir		431     désir	1709-1751.	berkeley	3774
L'esprit a, comme le corps, ses maladies épidémiques et son scorbut.	LA METTRIE Julien Offroy de	L"Homme machine		433     perversion	1709-1751.	berkeley	3775
Savez-vous pourquoi je fais encore quelque cas des hommes? C'est que je les crois sérieusement des machines.	LA METTRIE Julien Offroy de	Système d"Epicure		560     sagesse	1709-1751.	berkeley	3780
On ne doit pas être soudain à juger les intentions de ces grands Chefs, car ils ont des considérations que l'effet découvre par après être autres que beaucoup n'eussent cuidé* 	LA NOUE François de	Discours politiques et militaires 		391     commandement	1531-1591.  *Cru.	berkeley	3781
L'ambition, c'est la richesse des pauvres	PAGNOL Marcel			510     ironie		berkeley	4631
Les besoins produisent les organes.	DIDEROT Denis	Le Rêve de d"Alembert		390     création	1713-1784.	berkeley	2101
La solitude choisie est l'initiation qui porte à la liberté.	FAIRGAGNETR Oscar	Vitalités.	1994	423     solitude		berkeley	2580
Le charisme, c'est aussi une question d'hormones.	FAIRGAGNETR Oscar	Vitalités.	1994	425     charisme		berkeley	2582
L'artiste qui abdique le privilège de la création délibérée pour favoriser et capter de divines surprises ne parvient qu' à produire de l'accidentel.	CAILLOIS Roger	Cases d"un échiquier		393     création artistique	1913-1978.	berkeley	963
Il n'est plus temps de dormir, car le Temps ne dort jamais, mais passe comme le vent... Pour reconstruire l'ensemble, il faut détruire l'ancien, à partir des fondations.	Catherine de Sienne	Lettre à Grégoire XI en Avignon.		211     guerre	cité par Morris WEST dans "Les bouffons de Dieu".	berkeley	1054
Il faut détruire Carthage.	CATON l"Ancien			215     mystifications	234-149 av. J.-C. Delenda Carthago, mots par lesquels Caton l"Ancien terminait tous ses discours, sur quelque sujet que ce fût.	berkeley	1057
Une théorie de la science ne peut être que théorie de l'unité de la science.	CAVAILLES Jean	Sur la logique et la théorie de la science		545     épistémologie	1903-1944.	berkeley	1060
Ils croient que j'ai des idées générales. Ce n'est pas à moi de leur révéler que je vis sur le fonds de frivolité qui vient au secours des existences longues. Qu'un âge arrive où il faut choisir entre l'amer- tume, le pessimisme comme on disait autrefois, et le contraire, et qu'il y a beau temps que mon choixest fait - disons, plus véridique- ment, qu'il est affiché.	COLETTE Sidonie Gabrielle	L"Etoile Vesper.		510     ironie		berkeley	1565
Au désert chassent les bêtes sauvages, Guettant l'audacieux solitaire Qui défie les dieux du désert Et recherche les périls...	HERBERT Franck	Dune	1965	440     courage		berkeley	3149
Souvent une fausse joie vaut mieux qu'une tristesse dont la cause est vraie.	DESCARTES René	Les Passions de l"âme		510     ironie	1596-1650.	berkeley	1949
Tout ce qui vaut la peine d'être fait vaut la peine d'être bien fait.  Whatever is worth doing at all is worth doing well.	CHESTERFIELD Philip Stanhope, comte de	Letters, 10 mars 1746		546     éthique	1694-1773. (Anglais)	berkeley	1345
... Un diplomate qui s'amuse est moins dangereux qu'un diplomate qui travaille.	PORTO-RICHE Georges de	Le Passé, III, 7, François		221     vanité	1849-1930.	berkeley	4729
Il travaille lentment, lit avec difficulté, se plaint de ne pas retenir ses leçons et souffre d'être considéré par son père comme un enfant paresseux, alors qu'il a personnellement l' impression de fournir de réels efforts.	LAMBRICHS Louise L.	La Dyslexie en question.	1989	410     santé		berkeley	4019
Jésus lui dit: 'Tu aimeras le Seigneur ton Dieu de tout ton coeur, de toute ton âme et de tout ton esprit: voil à le plus grand et le premier commandement. Le second lui est semblable: tu aimeras ton prochain comme toi-même.' 	Evangiles	Evangile selon saint Matthieu, XXII, 37-39		215     mystifications	De l"art de pousser l"individu à une schizophrénie de l"esprit où le libre arbitre est repoussé au second rang des droits de l"homme et la considération de soi au rang des devoirs de sociabilité grégaire.	berkeley	2411
Je crois qu'un homme est jugé d'après la lumière qu'il a reçue. Si vous choisissez une solution stoïcienne à une situation insupporta- ble, je pourrais condamner l'acte, mais je ne peux émettre aucun jugement sur celui qui agit.	WEST Morris	Les bouffons de Dieu.	1981	370     esprit		berkeley	5393
Il faut être un homme de caractère.	DE GAULLE Charles			321     volonté		berkeley	1816
Porté jusqu'aux nues, Tout puissant dans l'Empire ; Mais le sage d'en rire : Fourmis grouillant, sans plus.	LI KONG-TSOUO	Le Gouverneur de l"Etat tributaire du Sud.		120     grégarité		berkeley	4127
La victoire a une portée plus morale que matérialiste.	LIDDELL HART B.H.	Réflexions sur la Guerre	1944	230     pouvoir		berkeley	4128
Nous nous battons pour les portes du paradis.	LIEBKNETCHT Karl		1919	221     vanité	Leader assassiné du soulèvement spartakiste.	berkeley	4129
J'aime ceux qui ne savent pas trop pourquoi ils aiment, c'est alors qu'ils aiment vraiment.	GIDE André			530     ironie amoureuse		berkeley	2945
Les spéculations purement intellectuelles dépouillent l'univers de son manteau sacré.	GIONO Jean	Les Vraies Richesses		140     rapport à la cosmogonie		berkeley	2947
Tout est joué avant que nous ayons douze ans.	PEGUY Charles	L"argent		421     initiation		berkeley	4663
Il est sage de verser sur, sur le rouage de l'amitié, l'huile de la politesse délicate.	COLETTE Sidonie Gabrielle	Le pur et l"impur.		234     communication		berkeley	1541
La guerre est une simple continuation de la politique par d'autres moyens.	CLAUSEWITZ	De la Guerre. I/24.	1812	211     guerre		berkeley	1470
Les heureux sont ceux qui n'ont rien d'autre qu'une ardente envie de vivre. Des rocs sans faille. Contre leur écorce d'acier, l'aiguille la mieux trempée se brise comme du verre. On ne peut pas leur faire une injection de souvenir.	CLAVEL Bernard	L"ouvrier de la nuit.	1956	310     énergie	310     éner\\010f8\\020\\010f?Ä	berkeley	1474
Pour écrire, il faut déj à écrire.	BLANCHOT Maurice	L"Espace littéraire		380     travail	1907-.	berkeley	768
Un superordinateur dont l'intelligence vaut celle de mille hommes ? Pas de quoi pavoiser : il suffit de mettre mille d'entre nous ensemble et ils se comportent comme des idiots.  	MULLIGAN Chad			120     grégarité		berkeley	4509
Ils n'étaient pas de la même espèce ; ils n'avaient pas acquis cette ressemblance mutuelle qu'acquièrent les couples heureux.	MURDOCH Iris	Le Rêve de Bruno.		530     ironie amoureuse		berkeley	4510
La guerre seule porte toutes les énergies humaines à leur tension maximum et imprime le sceau de noblesse sur ceux qui ont le courage de lui faire face.	MUSSOLINI Benito	Fascisme.		110     entropie		berkeley	4553
Inventer au fond c'est se ressouvenir.	NERVAL Gérard de			390     création		berkeley	4570
La volupté même et le bonheur ne se perçoivent point sans vigueur et sans esprit.	MONTAIGNE Michel Eyquem de	Essais, I, 42		312     foi	1533-1592.	berkeley	4336
Serait-il vrai, que pour être bon tout à fait, il nous le faille être par occulte, naturelle et universelle propriété, sans loi, sans raison, sans exemple ?	MONTAIGNE Michel Eyquem de			330     coeur		berkeley	4337
On ne peut aller contre les inclinations de la nature qu'en lui opposant ses propres inclinations.	FAIRGAGNETR Oscar	Vitalités.	1993	232     servitudes du pouvoir		berkeley	2527
Les illusions tombent l'une après l'autre, comme les écorces d'un fruit, et le fruit, c'est l'expérience. Sa saveur est amère.	NERVAL Gérard de	Les Filles du feu, Sylvie		432     expérience	1808-1855. (Gérard Labrunie)	berkeley	4575
Un souvenir, mon ami. Nous ne vivons qu'en avant ou en arrière.	NERVAL Gérard de	Fragments, Un souvenir		441     sang-froid	1808-1855. (Gérard Labrunie)	berkeley	4577
[...] Avec les plus belles vertus du monde, on ne réussit rien sans méthode.	GIDE André	Journal.		370     esprit		berkeley	2931
L'histoire n'est pas une science, c'est un art. On n'y réussit que par l'imagination.	FRANCE Anatole	Le Jardin d"Epicure		540     mémoire	1844-1924. (Anatole François Thibault)	berkeley	2873
Qu'est-ce au fond qu'un peintre ? C'est un collectionneur qui veut se constituer une collection en faisant lui-même les tableaux qu'il aime chez ls autres. C'est comme ça que je commence et puis ça devient autre chose.	PICASSO Pablo		1934	393     création artistique	cité par Pierre Assouline in DHK.	berkeley	4702
L'amour constant ressemble à la fleur du soleil,  Qui rend à son déclin, le soir, le même hommage  Dont elle a, le matin, salué son réveil! 	NERVAL Gérard de	Poésies diverses, Mélodie		531     communication amoureuse	1808-1855. (Gérard Labrunie)	berkeley	4579
L'amour donne des ailes.	Dictons et Proverbes			140     rapport à la cosmogonie		berkeley	1994
Tout pouvoir vient d'une discipline et se corrompt dès qu'on en néglige les contraintes.	CAILLOIS Roger	Art poétique		230     pouvoir	1913-1978.	berkeley	955
Toute respiration propose un règne.	CHAR René	Seuls demeurent		140     rapport à la cosmogonie	1907-1988.	berkeley	1176
Toute pensée efface un rêve.	PETIT Henri	Les Justes Solitudes.		360     bon sens	1900/1978	berkeley	4688
Je n'ai rien à offrir que du sang, du labeur, des larmes et de la sueur.	CHURCHILL Sir Winston Leonard Spencer		1940	440     courage	Discours devant la Chambre des Communes, le 13 mai 1940.	berkeley	1371
Non parce que Socrate l'a dit, mais parce qu'en vérité c'est mon humeur, et à l'aventure non sans quelque excès, j'estime tous les hommes nos compatriotes et embrasse un Polonais comme un Français, postposant* cette liaison nationale à l'universelle et commune.	MONTAIGNE Michel Eyquem de	Essais, III, 9 		441     sang-froid	1533-1592.  *Subordonnant.	berkeley	4364
La vieillesse nous attache plus de rides en l'esprit qu'au visage.	MONTAIGNE Michel Eyquem de	Essais, III, 2		442     démission	1533-1592.	berkeley	4366
Pourquoi crains-tu ton dernier jour? Il ne confère* non plus à ta mort que chacun des autres.	MONTAIGNE Michel Eyquem de	Essais, I, 20 		442     démission	1533-1592.  *Contribue.	berkeley	4367
Comment prétendons-nous qu'un autre garde notre secret, si nous n'avons pu le garder nous-même ?	LA ROCHEFOUCAULD François de	Pensées.		441     sang-froid		berkeley	3895
Chacun dit du bien de son coeur, et personne n'en ose dire de son esprit.	LA ROCHEFOUCAULD François de	Maximes		441     sang-froid	1613-1680.	berkeley	3896
Ce n'est pas un grand malheur d'obliger des ingrats, mais c'en est un insupportable d'être obligé à un malhonnête homme.	LA ROCHEFOUCAULD François de	Maximes		441     sang-froid	1613-1680.	berkeley	3897
Le gouvernement est stationnaire, l'espèce humaine est progressive. Il faut que la puissance du gouvernement contrarie le moins qu'il est possible la marche de l'espèce humaine.	CONSTANT Benjamin	Réflexions sur les constitutions		231     légitimité du pouvoir	1767-1830. (Henri-B. de Rebecque)	berkeley	1622
Il n'y a qu'une maxime absolue, c'est qu'il n'y a rien d'absolu.	COMTE Auguste			441     sang-froid		berkeley	1584
J'éprouve l'émotion la plus forte devant le mystère de la vie. Ce sentiment fonde le beau et le vrai, il suscite l'art et la science. Si quelqu'un ne connait pas cette sensation ou ne peut plus ressentir étonnement ou surprise, il est un mort vivant et ses yeux sont désormais aveugles.	EINSTEIN Albert	Comment je vois le Monde	1934	341     étonnement	rééd.corr. en 1952 et 1978.	berkeley	2305
Quand les princes pensent plus au luxe qu'aux armes, ils perdent leur Etat.	MACHIAVEL Nicolas	Le Prince		240     débauche		berkeley	4160
Petit poisson deviendra grand,  Pourvu que Dieu lui prête vie.	LA FONTAINE Jean de	Fables, le Petit Poisson et le Pêcheur		410     santé	1621-1695.	berkeley	3710
Nourris-toi toujours des vérités assez fortes pour te porter en avant.	FAIRGAGNETR Oscar	Vitalités.	1993	440     courage		berkeley	2599
Il est assez puni par son sort rigoureux;  Et c'est être innocent que d'être malheureux.	LA FONTAINE Jean de	Elégie aux nymphes de Vaux		420     capital affectif	1621-1695.	berkeley	3711
C'est par la souffrance que nous sommes instruits.	Dictons et Proverbes	Proverbe grec & proverbe du Moyen-Age.		421     initiation		berkeley	2024
Ce n'est pas au moment de la prise de la ville que se montrent les hommes les plus hideux, c'est le lendemain.	CHAMSON André	Ecrit en 1940		110     entropie	1900-1983.	berkeley	1153
Il ne faut jamais faire confiance à l'avenir. Il ne le mérite pas.	CHAMSON André	On ne voit pas les coeurs		441     sang-froid	1900-1983.	berkeley	1156
Chacun porte en soi sa grandeur ou son abjection, et rien ne s'ajoute ou ne se retranche à ce qu'il doit être.	CHAMSON André	Le Chiffre de nos jours		520     ironie de soi	1900-1983.	berkeley	1157
Mourir pour le pays est un si digne sort  Qu'on briguerait en foule une si belle mort.	CORNEILLE Pierre	Horace, II, 3, Horace  		215     mystifications	1606-1684. Ces deux vers reprennent et aménagent deux vers du Cid.	berkeley	1648
Le pire des Etats, c'est l'Etat populaire.	CORNEILLE Pierre	Cinna, II, 1, Cinna		215     mystifications	1606-1684.	berkeley	1649
Et, monté sur le faîte, il aspire à descendre.	CORNEILLE Pierre	Cinna, II, 1, Auguste		221     vanité	1606-1684.	berkeley	1650
A vaincre sans péril, on triomphe sans gloire.	CORNEILLE Pierre	Le Cid, II, 2, le comte		221     vanité	1606-1684.	berkeley	1651
... Il faut aller jusqu' à l'horreur quand on se connaît.	BOSSUET Jacques Bénigne	Lettre, au maréchal de Bellefonds		441     sang-froid	1627-1704.	berkeley	810
O Dieu! qu'est-ce donc que l'homme ? Est-ce un assemblage monstrueux de choses imcompatibles ?	BOSSUET Jacques Bénigne	Oraison funèbre de L. de Vallière.		510     ironie		berkeley	811
... Dans les grandes actions il faut uniquement songer à bien faire, et laisser venir la gloire après la vertu.	BOSSUET Jacques Bénigne	Oraison funèbre de Louis de Bourbon, prince de Condé		550     grandeur	1627-1704.	berkeley	813
[le style] donne aux pires désordres de l'âme le visage de la sérénité. Il efface le ressentiment, et il 'rend singulières les choses les plus communes', comme le disait Voltaire.	BOTT François	Lettre aux esprits chagrins. (Les séductions de l"existence)	1990	235     séduction		berkeley	814
A moins qu'ils ne se reconnaîssent, devenant l'un à l'autre et devant le monde une indestructible force de plénitude, le roi de coeur est, d'essence, un être de solitude, la reine de coeur un être abusé.	FAIRGAGNETR Oscar	vitalités.	1992	530     ironie amoureuse		berkeley	2638
De l'homme à l'homme vrai, le chemin passe par l'homme fou.	FOUCAULT Michel	Histoire de la folie à l"âge classique		510     ironie	1926-1984.	berkeley	2846
Le mal de la grandeur, c'est quand du pouvoir elle sépare la conscience.	SHAKESPEARE William	Jules César.		232     servitudes du pouvoir		berkeley	5047
Les petits oiseaux entretiennent l'amitié.	OBALDIA René de	Les Richesses naturelles, les Amitiés difficiles		510     ironie	1918-.	berkeley	4616
Tant qu'il y a des victoires, le monde appartient à l'homme ; la défaite venue, il appartient à la femme parce que l'élite des hommes a disparu.	WEST Morris	La seconde victoire.	1972	510     ironie		berkeley	5438
Ce n'est plus une ardeur dans mes veines cachée : C'est Vénus toute entière à sa proie attachée.	RACINE Jean	Phèdre.		530     ironie amoureuse		berkeley	4790
Wagner: un beau coucher de soleil que l'on a pris pour une aurore ...	DEBUSSY Claude	Monsieur Croche, antidilettante		393     création artistique	1862-1918.	berkeley	1868
Qui pense peu se trompe beaucoup.  Chi poco pensa, molto erra.	VINCI Léonard de	Carnets		365     discernement	1452-1519. (Italien)	berkeley	5314
La fortune ne reste fidèle qu' à ceux qui la partagent.	Dictons et Proverbes			320     intuition	proverbe préféré de Harry HARRYVELLA, britanique de Hong Kong.	berkeley	1983
Un roi faible affaiblit le peuple le plus fort.  Um fraco rei faz fraca a forte gente.	CAMOENS Luis Vaz de	Les Lusiades, III, 138		442     démission	1524-1580. (Portugais)	berkeley	979
Le goût est une aptitude à bien juger des choses de sentiment. Il faut donc avoir de l'âme pour avoir du goût.	VAUVENARGUES Marquis de	Introduction à la connaissance de l"Esprit humain.		340     sensibilité	CLAPIER Luc de	berkeley	5264
Le sentiment de savoir ce que nous pouvons, nous donne la puissance d'action.	KRAMER Edward L.	Chemins vers la puissance.		422     confiance en soi		berkeley	3577
Les erreurs, comme des pailles, flottent à la surface.  Celui qui veut chercher des perles doit plonger en profondeur.  Errors, like straws, upon the surface flow.  He who would search for pearls must dive below.	DRYDEN John	All for love, Prologue		440     courage	1631-1700. (Anglais)	berkeley	2159
L'homme sage n'est pas comme un vase ou un instrument qui n'a qu'un usage; il est apte à tout.	CONFUCIUS	Entretiens, I, 2		560     sagesse	551-479 av. J.-C. (Chinois)	berkeley	1614
Toutes les belles choses sont difficiles, comme dit le proverbe, et celui-l à ne saura jamais le violon qui n'a su que s'y amuser.	CHARTIER Emile		1927	380     travail	alias ALAIN	berkeley	1237
La loi suprême de l'invention humaine est que l'on n'invente qu'en travaillant.	CHARTIER Emile	Système des Beaux-Arts.		380     travail	alias ALAIN	berkeley	1238
L'éducation n'est en somme que l'art de révéler à l'être humain le sens intime qui doit gouverner ses actes, préparer l'emploi de ses énergies et lui communiquer le goût et la force de vivre pleinement.	BORDEAUX Henry	Les Pierres du foyer.		421     initiation		berkeley	791
Quand on court après l'esprit, on attrape la sottise.	MONTESQUIEU Charles de	Pensées diverses.		221     vanité		berkeley	4408
Il n'y a de passions que celles qui nous frappent d'abord et nous surprennent; les autres ne sont que des liaisons où nous portons volontairement notre coeur. Les véritables inclinations nous l'arrachent malgré nous.	LA FAYETTE M.-M.	Zaïde		430     paradoxal émotionnel	1634-1693. (Pioche de la Vergne, comtesse de)	berkeley	3636
Je suis si persuadée que l'amour est une chose incommode que j'ai de la joie que mes amis et moi en soyons exempts.	LA FAYETTE M.-M.	Lettres		442     démission	1634-1693. (Pioche de la Vergne, comtesse de)	berkeley	3638
Toutes mes résolutions sont inutiles; je pensais hier tout ce que je pense aujourd'hui et je fais aujourd'hui le contraire de ce que je résolus hier.	LA FAYETTE M.-M.	La Princesse de Clèves		520     ironie de soi	1634-1693. (Pioche de la Vergne, comtesse de)	berkeley	3639
A mon sens, l'oeuvre d'art est l'expression esthétique d'un vécu affectif et éthique. L'artiste dit ce qu'il doit. Le public reçoit ce qu'il sent. Si ls deux s'accordent sur une rencontre, l'oeuvre vit.	FAIRGAGNETR Oscar	Vitalités.	1992	393     création artistique		berkeley	2566
Pas de plaisir plus subtil que de passer pour un crétin aux yeux d'un con congénital.	RENARD Jules			422     confiance en soi		berkeley	4813
Il s'agit à tout moment de sacrifier ce que nous sommes à ce que nous pouvons devenir.	DU BOS Charles	Approximations.		421     initiation		berkeley	2167
Le monde abonde en alphabets hors d'usage, dont le code est perdu.	CAILLOIS Roger	Cases d"un échiquier		234     communication	1913-1978.	berkeley	957
Le fruit est aveugle. C'est l'arbre qui voit.	CHAR René	Feuillets d"Hypnos		390     création	1907-1988.	berkeley	1177
Une civilisation qui renonce à la violence en pensée et en action se détruit elle-même. Elle se transforme en un troupeau de moutons qui se fera égorger par le premier venu. Il en va de même pour les individus.	PEREZ-REVERTE Arturo	Le Maître d"escrime	1985	210     violence		berkeley	4666
Rarement le sommeil visite le chagrin ; quand il daigne le faire, c'est un consolateur tout puissant.	SHAKESPEARE William	La Tempête.		430     paradoxal émotionnel		berkeley	5053
Hormis ses propres faiblesses, rien ne peut entacher la détermination d'un homme de caractère.	FAIRGAGNETR Oscar		1991	441     sang-froid		berkeley	2611
... Qu'est-ce qu'une grande vie sinon une pensée de la jeunesse exécutée par l'âge mûr? 	VIGNY Alfred de	Cinq-Mars		550     grandeur	1797-1863.	berkeley	5301
Votre potentiel créateur va se manifester si vous avez des buts, des rêves et des objectifs.	VINCENT Raymond	La Passion du succès.		390     création		berkeley	5306
On perd son feu à vouloir le communiquer à des morceaux de glace.	STENDHAL	Le Rouge et le Noir		234     communication		berkeley	5148
Homme! Il est d'autres hommes.	DESNOS Robert	Fortunes		520     ironie de soi	1900-1945.	berkeley	1962
Le gouvernement d'un peuple, à certains moments de son histoire, est aux mains de demi-fous.	RIBOT Th.			238     servitudes du pouvoir politique		berkeley	4817
On dit que les soldats et les hommes de loi n'ont jamais pu prospérer de concert dans un même comté.	RICH Barnabe	Anatomy of Ireland	1615	232     servitudes du pouvoir		berkeley	4818
Creusez, fouillez, bêchez ; ne laissez nulle place Où la main ne passe et repasse.	LA FONTAINE Jean de	Le Laboureur et ses Enfants.		421     initiation		berkeley	3712
- Vous parlez de morale, je parle de politique : les deux choses s'excluent. [...] La politique est l'art et la science de gouverner des hommes imparfaits au moyen de systèmes imparfaits.	WEST Morris	Toute la vérité.	1957	238     servitudes du pouvoir politique		berkeley	5375
Vous êtes comme les roses du Bengale, Marianne, sans épine et sans parfum.	MUSSET Alfred de			515     tragédie		berkeley	4544
Quand le gouvernement viole les droits du peuple, l'insurrection est pour le peuple le plus sacré et le plus indispensable des devoirs.	ROBESPIERRE Maximilien de	A la Convention nationale, 10 juillet 1794		215     mystifications	1758-1794.	berkeley	4841
La connaissance est le seul instrument de production qui n'est pas sujet à la dépréciation.	CLARCK J.-M.	Journal d"Economie Politique.	1927	392     création économique		berkeley	1436
L'homme a beaucoup appris qui a beaucoup souffert.  Mult ad apris ki bien conuist ahan.	Chanson de Roland			421     initiation	v. 1100 	berkeley	1164
L'homme évite habituellement d'accorder de l'intelligence à autrui, sauf quand par hasard il s'agit d'un ennemi.	EINSTEIN Albert	Comment je vois le Monde	1934	225     cynisme	rééd.corr. en 1952 et 1978.	berkeley	2301
Mais quoi? Le naturel des femmes est volage  Et à chaque moment abuse leur courage*.  Bien fol qui s'y abuse et qui de loyauté  Pense jamais trouver compagne une beauté.	GARNIER Robert	Marc Antoine 		510     ironie	v. 1545?-1590  *Courage: coeur.	berkeley	2917
La physiologie, l'analyse des idées et la morale, ne sont que les trois branches d'une seule et même science, qui peut s'appeler, à juste titre, la science de l'homme.	CABANIS Pierre-Jean-Georges	Rapports du physique et du moral de l"homme		546     éthique	1757-1808.	berkeley	948
Les maux réels affectent moins les hommes que l'idée qu'ils se font de leur condition.	CHARDONNE Jacques	L"Amour, c"est beaucoup plus que l"amour		433     perversion	1884-1968.	berkeley	1196
Toute femme varie.  	François Ier			510     ironie	1494-1547.   Le mot est rapporté par Brantôme (Les Dames galantes, septième discours). Il avait été gravé par François Ier sur le côté gauche de la chambre du roi à Chambord. Victor Hugo passe pour avoir, en visitant le château, détaché et emporté le morceau de la fenêtre portant l"inscription.	berkeley	2875
Si je suis malheureux à ce point, il y a un port assuré, la mort... Aussi rien n'est difficile dans la vie. Quand tu le veux, tu sors, et tu n'es plus gêné par la fumée.	EPICTETE	Entretiens, IV, 10, 27		440     courage	v. 50-v. 125.   Voir: Entretiens (I, 25, 18): "Le foyer fume dans l"appartement; s"il n"y a pas trop de fumée, je resterai; s"il y en a trop, je m"en vais. Car il faut se souvenir et bien retenir que la porte est ouverte." Marc-Aurèle, Pensées (V, 29): "... Sors plutôt de la vie, mais persuadé que tu n"en souffres aucun mal. De la fumée... je m"en vais. ".	berkeley	2354
Les occasions sont indifférentes, l'usage qu'on en fait ne l'est pas.	EPICTETE	Entretiens, II, 5, 1		441     sang-froid	v. 50-v. 125.	berkeley	2357
Homme, si tu es quelqu'un, va te promener seul, converse avec toi-même et ne te cache pas dans un choeur.	EPICTETE	Entretiens, III, 14, 2		441     sang-froid	v. 50-v. 125.	berkeley	2358
Les choses extérieures ne dépendent pas de moi; ma volonté dépend de moi. Où chercher le bien et le mal? En moi-même, dans ce qui est mien.	EPICTETE	Entretiens, II, 5, 4-5		560     sagesse	v. 50-v. 125.	berkeley	2362
Les gens heureux ne traversent les problèmes que le temps de les dissiper vers d'autres, les mal nourris de l'affect, qui, en pure complaisance, sauront toujours s'assouplir assez pour devenir, contre de vaines promesses, les porteurs volontaires des malheurs du monde et de chacun.	FAIRGAGNETR Oscar	Vitalités.	1992	420     capital affectif		berkeley	2568
Comportes-toi en stupide et tu deviendras impénétrable pour l'éternité.( ) Les templiers restent indéchiffrables à cause de leur confusion mentale. C'est pour cel à que tant de gens les vénèrent.	ECO Umberto	Le Pendule de Foucault	1988	215     mystifications		berkeley	2264
L'oisiveté est comme la rouille ; elle use plus que le travail.	FRANKLIN Benjamin			380     travail	1706/1790	berkeley	2876
L'expérience est une école onéreuse, mais les sots ne s'instruisent que l à.  Experience keeps a dear school, but fools will learn in no other.	FRANKLIN Benjamin	Poor Richard"s Almanac		432     expérience	1706-1790. (Américain)	berkeley	2877
Vous voulez vous aimer : aimez-vous dans les autres ; car notre vie est dans les autres et sans les autres votre vie n'est rien.	LEROUX Pierre	Avenir.		330     coeur		berkeley	4115
Paris montre toujours les dents. Quand il ne gronde pas, il rit.	HUGO Victor	Les Misérables		539     ironie sociale	1802-1885.	berkeley	3344
Les gens de qualité savent tout sans avoir rien appris.	MOLIERE	Les Précieuses Ridicules.		370     esprit		berkeley	4298
La plupart de nos congénaires s'ingénient à se rendre esclaves de leurs égos jusqu'au jour du soulagement ou ils lui trouvent enfin un maître suffisemment autoritaire, voire injuste, pour qu'ils puissent, en toute quiétude, commencer à s'adonner à ce qu'il aiment plus que tout : se bien plaindre des autres, des vilenies et des souffrances qu'ils suscitent.	FAIRGAGNETR Oscar		1992	221     vanité		berkeley	2504
Tous les moyens de l'esprit sont enfermés dans le langage; et qui n'a point réfléchi sur le langage n'a point réfléchi du tout.	CHARTIER Emile	Propos Sur L"éducation.		370     esprit	alias Alain (1868-1951)	berkeley	1229
Le secrêt d'ennuyer est celui de tout dire.	VOLTAIRE	Discours en vers sur l"homme.		234     communication		berkeley	5327
La vanité est la plus incurable et la plus meurtière des folies de l'âme.	FAIRGAGNETR Oscar	Vitalités.	1995	221     vanité		berkeley	2500
Je* plie et ne romps pas.	LA FONTAINE Jean de	Fables 		321     volonté	1621-1695.  *Le roseau.	berkeley	3691
L'immortalité, c'est de travailler à une oeuvre éternelle.	RENAN Ernest	L"avenir de la science.		390     création		berkeley	4809
Le vin est fort, le roi est plus fort, les femmes le sont plus encore, mais la vérité est plus forte que tout. Der Wein ist stark, der König stärker, die Weiber noch stärker, aber die Wahrheit am allerstärksten.	LUTHER Martin	Propos de table		546     éthique		berkeley	4153
Pour moy, je ne juge la valeur d'autre besogne plus obscurément que la mienne ; et loge les Essais tantost bas, tantost haut, fort inconstamment et doubteusement.	MONTAIGNE Michel Eyquem de	"autre besog\\010NU à\\010NY\\020		520     ironie de soi		berkeley	4380
La tangente a plus de puissance que la sécante.	HUGO Victor	Tas de pierres		441     sang-froid	1802-1885.	berkeley	3333
Sois réservé sans ostentation pour éviter de t'attirer l'incompréhension haineuse des ignorants.	PYTHAGORE	Vers dorés.		120     grégarité		berkeley	4744
L'esprit à sec et la tête ivre,  Fini, mais ne sachant finir,  Il mourut en s'attendant vivre  Et vécut s'attendant mourir.	CORBIERE Tristan	Les Amours jaunes		442     démission	1845-1875. (Edouard Joachim Corbière)	berkeley	1643
Tout poème est une mise en demeure.	CAYROL Jean	Pour tous les temps		393     création artistique	1911-.	berkeley	1066
Le monde est incapable de vivre au niveau de ses grands hommes.  The world cannot live at the level of its great men.	FRAZER Sir	Le Rameau d"or, XXXVII		539     ironie sociale	1854-1941. (Anglais)	berkeley	2879
Il est beau de faire des ingrats; il est infâme de l'être.	FRéDéRIC II le Grand	Dialogue de morale à l"usage de la jeune noblesse		520     ironie de soi	1712-1786., roi de Prusse	berkeley	2880
Tâcher de faire avec les adversaires la plus grande partie de la route.	ROSTAND Jean	Carnets d"un biologiste.		232     servitudes du pouvoir		berkeley	4866
Je demande à un livre de créer en moi le besoin de ce qu'il m'apporte.	ROSTAND Jean	Carnets d"un biologiste.		234     communication		berkeley	4867
Le biologiste passe, la grenouille reste.	ROSTAND Jean	Inquiétude d"un Biologiste	1967	520     ironie de soi	\\010nFp\\020	berkeley	4873
Personne ne peut rester fort en permanence. Personne ne dure si longtemps.	WEST Morris	Les bouffons de Dieu.	1981	310     énergie		berkeley	5382
En leur règle n'était que cette clause : Fais ce que voudras, parce que gens libères, bien nés, bien instruits, conversant en compagnies honnêtes, ont par nature un instinct et aiguillon qui toujours les pousse à faire vertueux et retire de vice, lequel ils nommaient honneur.	RABELAIS François	GARGANTUA	1534	560     sagesse	1494/1553	berkeley	4759
Parmi les arts, celui de la parole est le plus décevant de tous.	GARÇON Maurice	Tableau de l"éloquence judiciaire		221     vanité	1889-1967.	berkeley	2913
L'esprit de parti abaisse les plus grands hommes jusqu'aux politesses du peuple.	LA BRUYERE Jean de	Les Caractères.		120     grégarité		berkeley	3594
Si terrible que soit la vie, l'existence de l'activité créatrice sans autre but qu'elle-même suffit à la justifier.	FAURE Elie	L"Esprit des formes.		390     création		berkeley	2674
Ne te glorifie point en toi-même, mais plutôt en ton voisin.	Dictons et Proverbes	Maxime bouddiste siamoise.		232     servitudes du pouvoir		berkeley	2006
La modestie n'est qu'une sorte de pudeur de l'orgueil.	JOUHANDEAU Marcel	De la grandeur		510     ironie	1888-1979.	berkeley	3483
La France est une nation qui s'ennuie.	LAMARTINE Alphonse de	Discours, 25 février 1848		221     vanité	1790-1869.	berkeley	3994
Le soin de chaque jour à chaque jour suffit.	LAMARTINE Alphonse de	Premières Méditations poétiques, Philosophie		360     bon sens	1790-1869.	berkeley	3997
Le souverain est le premier serviteur de l'Etat.  Der Fürst ist der erste Diener des Staats.  	FRéDéRIC II le Grand			215     mystifications	1712-1786.   Cette maxime de Frédéric II fut adoptée par ses successeurs, qui en firent leur devise.	berkeley	2881
Il y a dans la jalousie plus d'amour-propre que d'amour.	LA ROCHEFOUCAULD François de	Maximes.		530     ironie amoureuse		berkeley	3923
Il est plus facile de prendre de l'amour quand on n'en a pas, que de s'en défaire quand on en a.	LA ROCHEFOUCAULD François de	Maximes.		530     ironie amoureuse		berkeley	3924
Ceux qui ont eu de grandes passions se trouvent toute leur vie heureux et malheureux d'en être guéris.	LA ROCHEFOUCAULD François de	Maximes.		530     ironie amoureuse		berkeley	3925
La parfaite valeur est de faire sans témoins ce qu'on serait capable de faire devant tout le monde.	LA ROCHEFOUCAULD François de	Maximes.		550     grandeur		berkeley	3944
Le vrai honnête homme est celui qui ne se pique de rien.	LA ROCHEFOUCAULD François de	Maximes		560     sagesse	1613-1680.	berkeley	3946
A la maison de ta tante, Mais non tous les jours ; A la maison de ton frère, Mais non tous les soirs.	Dictons et Proverbes	Dicton.		420     capital affectif		berkeley	2022
Un homme modeste apprend dix choses et en croit une  Un homme complaisant apprend une chose et en croit dix.	Dictons et Proverbes	Proverbe Chinois		421     initiation	(début de notre ère)	berkeley	2023
Voyez les oiseaux du ciel: ils ne sèment, ni ne moissonnent, ni ne recueillent en des greniers, et votre Père céleste les nourrit! Ne valez-vous pas plus qu'eux? 	Evangiles	Evangile selon saint Matthieu, VI, 26		215     mystifications		berkeley	2403
Celui qui ne peut plus éprouver ni étonnement ni surprise est pour ainsi dire mort ; ses yeux sont éteints.	EINSTEIN Albert	Comment je vois le monde.		341     étonnement		berkeley	2306
Malheur à ceux qui remuent le fond d'une nation! 	RIVAROL Comte de	Maximes et pensées		215     mystifications	1753-1801. (Antoine Rivarol)	berkeley	4838
L'ennui est entré dans le monde par la paresse.	LA BRUYERE Jean de	Les Caractères		110     entropie	1645-1696.	berkeley	3587
... coïncidences  Véritables fanaux dans la nuit du sens.	BRETON André	Fata Morgana		140     rapport à la cosmogonie	1896-1966.	berkeley	844
Le fabricateur souverain  Nous créa besaciers tous de même manière ...  Il fit pour nos défauts la poche de derrière,  Et celle de devant pour les défauts d'autrui.	LA FONTAINE Jean de	Fables, la Besace		520     ironie de soi	1621-1695.	berkeley	3753
Il faudrait aussi un centre de désintoxication pour les hommes ivres de bonheur.	LEC Stanislas	Pensées Echevelées.		430     paradoxal émotionnel		berkeley	4085
Un missionnaire qui a été mangé est-il en droit de considérer qu'il a rempli sa mission ?	LEC Stanislas	Pensées Echevelées.		510     ironie		berkeley	4087
Un couvercle de cercueil n'est pas décoré du côté de son utilisateur.	LEC Stanislas	Pensées Echevelées.		510     ironie		berkeley	4088
On a bien de la peine à rompre quand on ne s'aime plus.	LA ROCHEFOUCAULD François de	Maximes		530     ironie amoureuse	1613-1680.	berkeley	3929
Qui va aux chiottes tire la chasse.	SAHORES François			510     ironie		berkeley	4913
La machine a gagné l'homme, l'homme s'est fait machine, fonctionne et ne vit plus.	GANDHI Mahatma			110     entropie		berkeley	2904
Tout homme craque à un moment ou à un autre, tôt ou tard.	HIGGINS Jack	Opération Cornouailles.	1990	310     énergie		berkeley	3185
Etranger, ma coutume est d'honorer les hôtes.	Homère	L"Odyssée, XIV, 56-57		331     altruisme	IXe ou VIIIe s. av. J.-C.	berkeley	3217
Souvent déj à de faibles causes ont produit de grands maux.	Isocrate	Contre Lokhitès, 7		433     perversion	436-338 av. J.-C.	berkeley	3395
Il n'y a que les passions et les grandes passions, qui puissent élever l'âme aux grandes choses.	DIDEROT Denis	Pensées philosophiques		550     grandeur	1713-1784.	berkeley	2118
Un communiste est une personne qui mange son gâteau et désire le vôtre aussi.	Digeste Catholique.	Digeste Catholique.		510     ironie		berkeley	2121
Le bon critique est celui qui raconte les aventures de son âme au milieu des chefs-d'oeuvre.	FRANCE Anatole	La Vie littéraire		393     création artistique	1844-1924. (Anatole François Thibault)	berkeley	2860
On met la femme au singulier quand on a du bien à en dire, et on en parle au pluriel sitôt qu'elle vous a fait quelque méchanceté.	GUITRY Sacha	N"écoutez pas Mesdames		221     vanité	1885-1957.	berkeley	3054
L'un des mensonges les plus fructueux, les plus intéressants qui soient, et l'un des plus faciles en outre, est celui qui consiste à faire croire à quelqu'un qui vous ment qu'on le croit.	GUITRY Sacha	Toutes Réflexions faites		234     communication	1885-1957.	berkeley	3055
Le propre de l'homme, c'est de ne jamais savoir ce qui est impossible.	JULLIAN Marcel		1994	510     ironie	dans "Faut pas Rêver" du 4 mars 1994.	berkeley	3506
Nous sommes plus jaloux de la considération des autres que de leur estime.	MARIVAUX Pierre Carlet de Chamblain de	La Vie de Marianne		221     vanité	1688-1763.	berkeley	4220
Il n'y a rien de plus bas, et qui convienne mieux au peuple, que de parler en des termes magnifiques de ceux mêmes dont l'on pensait très modestement avant leur élévation.	LA BRUYERE Jean de	Les Caractères		120     grégarité	1645-1696.	berkeley	3595
Il y a des circonstances où le mensonge est le plus saint des devoirs.	LABICHE Eugène	Les Vivacités du capitaine Tic		441     sang-froid	1815-1888	berkeley	3958
La vraisemblance rend les mensonges sans conséquence, en ôtant le désir de les vérifier.	LACLOS Pierre Choderlos de	Les Liaisons dangereuses		215     mystifications	1741-1803.	berkeley	3961
La générosité à l'encontre des gredins est presque une indélicatesse à l'encontre du bien.	FLAUBERT Gustave	L"amour de l"art.	1915	331     altruisme	(1821/1880) édition posthume	berkeley	2736
Mais il vient des mots étouffants;  On laissera les chers enfants  Livrés à de vagues désastres.	CROS Charles	Le Collier de griffes, Almanach		442     démission	1842-1888.	berkeley	1728
L'oubliance est douce.	CROS Charles	Le Collier de griffes, A la plus belle		442     démission	1842-1888.	berkeley	1729
L'art est long et le temps est court.	CROS Charles	Le Collier de griffes, Insoumission		510     ironie	1842-1888.	berkeley	1730
La connaissance du coeur humain, c'est l'érudition des flâneurs.	CUREL François de	L"amour brode		510     ironie	1854-1928.	berkeley	1731
En sport, comme en amour, il arrive un moment où il n'y a plus de tricherie possible. Il n'y a plus que la vérité, non pas le jeu de la vérité, mais l'épreuve de la vérité elle-même.	TAPIE Bernard	Gagner.	1986	440     courage		berkeley	5190
Le plus grand chef-d'oeuvre de la littérature n'est jamais qu'un dictionnaire en désordre.	COCTEAU Jean	Le Potomak		510     ironie	1889-1963.	berkeley	1524
Mon instinctif penchant qui se plaît à la courbe, à la sphère et au cercle... Tendre vers l'achevé, c'est revenir à son point de départ.	COLETTE Sidonie Gabrielle	Discours de réception.		390     création		berkeley	1547
Quand de toute ma bonne foi, j'estime qu'il se trompe, je dis au prince qu'il se trompe.	ETIEMBLE René	Confucius		440     courage	1909-.	berkeley	2386
Notre intérêt se trouve à la limite dangereuse des choses.	BROWNING Robert			440     courage		berkeley	880
La gravité est un mystère du corps inventé pour cacher les défauts de l'esprit.	LA ROCHEFOUCAULD François de	Maximes.		370     esprit		berkeley	3856
La pensée est dans le mal et le mal est dans la pensée, sans qu'on sache qui a commencé.	CROMMELYNCK Fernand	Tripes d"or		433     perversion	1886-1970.	berkeley	1724
Il y a plus d'héroïsme à souffrir longtemps qu' à mourir vite.	CROMMELYNCK Fernand	Le Cocu magnifique		442     démission	1886-1970.	berkeley	1725
L'aide systématique et chronique est une arme à double tranchant. Parfois elle marginalise ceux qui en ont besoin en créant une espèce de sous-classe d'assistés. Aux Etats-Unis, hélas, il existe une culture selon laquelle tout est chiffrable et mesurable. Les américains ne prêtent pas grande attention aux causes profondes créatrices de la dégénérescence sociale. Au contraire, ils ont tendance à croire qu'il est suffisant d'en traiter les symptômes avec l'argent. En fait, comme l'a souligné le professeur Walter Williams, de l'Université George Mason, l'argent qui a été dépensé aux Etats-Unis pour les programmes de pauvreté depuis les années 60 'aurait permis d'acquérir les actifs des cinq cents premières sociétés classées par le magazine Fortune', c'est- à-dire les cinq cents plus grandes sociétés d'Amérique, et 'virtuellement, de surcroît, toutes les terres agricoles américaines.	GOLDSMITH Jimmy	Le Piège.	1993	331     altruisme		berkeley	2991
Fais-leur comprendre qu'ils n'ont d'autre devoir au monde que de la joie! 	CLAUDEL Paul	Le Père humilié, II, 2, le pape Pie		546     éthique	1868-1955.	berkeley	1467
Tout est sauvé si on demeure capable d'étonnement.	GUEHENNO Jean			341     étonnement		berkeley	3034
Le plus grand dérèglement de l'esprit, c'est de croire les choses parce qu'on veut qu'elles soient, et non parce qu'on a vu qu'elles sont en effet.	BOSSUET Jacques Bénigne	Traité de la connaissance de Dieu et de soi-même		433     perversion	1627-1704.	berkeley	808
Pourquoi le laissez-vous trainer votre coeur ?	Dictons et proverbes			520     ironie de soi	\\010g• \\020	berkeley	2071
L'enracinement de l'existence est plus spontanément ancré dans l'affectif, voir l'émotionnel, que dans une conscience du monde qui ne vaut ni plus ni moins que le prix de sa démystification.	FAIRGAGNETR Oscar		1991	140     rapport à la cosmogonie		berkeley	2490
Je me révolte, donc je suis.	CAMUS Albert	L"Eté		510     ironie	1913-1960.	berkeley	1017
Le métier de soldat est l'art du lâche ; c'est l'art d'attaquer sans merci quand on est fort, et de se tenir loin du danger quand on est faible. Voil à tout le secret de la victoire.	SHAW G.-B.	Le Héros et le Soldat.		211     guerre		berkeley	5071
C'est avec celui-l à* qu'il est bon de veiller;  Ouvrez-le sur votre oreiller,  Vous verrez se lever l'aurore.  Molière l'a prédit, et j'en suis convaincu,  Bien des choses auront vécu  Quand nos enfants liront encore  Ce que le bonhomme a conté,  Fleur de sagesse et de gaîté.	MUSSET Alfred de	Poésies, Silvia 		393     création artistique	1810-1857.  *La Fontaine.	berkeley	4532
La grande question dans la vie, c'est la douleur que l'on cause, et la métaphysique la plus ingénieuse ne justifie pas l'homme qui a déchiré le coeur qui l'aimait.	CONSTANT Benjamin	Adolphe		515     tragédie	1767-1830. (Henri-B. de Rebecque)	berkeley	1632
Et, si de t'agréer je n'emporte le prix,  J'aurai du moins l'honneur de l'avoir entrepris.	LA FONTAINE Jean de	Fables, Dédicace au Dauphin		360     bon sens	1621-1695.	berkeley	3699
Je me suis mis d'accord avec moi-même, ce qui est bien la plus grande victoire que nous puissions remporter sur l'impossible.	FROMENTIN Eugène	Dominique.		430     paradoxal émotionnel	1820-1876	berkeley	2894
C'est la grande idée de Broch : le roman dit ce qui ne peut pas être dit autrement que par le roman.	FUENTES Carlos			393     création artistique	\\010r®P\\020	berkeley	2895
Tu sais, mon amouré Les calins ne valent que les émotions qu'ils catharsisent.	FAIRGAGNETR Oscar	Vitalités.	1998	530     ironie amoureuse		berkeley	2461
Il ne reste que la violence du jeu, de l'ivresse du pouvoir et de l'énergie du désespoir, à celui qui lutte, sans amour, contre l'entropie.	FAIRGAGNETR Oscar	Vitalités.	1996	110     entropie		berkeley	2463
Etrange voyage dans la brume!  O vie où nous sommes perdus.  Où nul jamais ne connaît l'autre,  Où tout est solitude.  Seltsam im Nebel zu wandern!  Leben ist Einsamsein.  Kein Mensch kennt den andern,  Jeder ist allein.	HESSE Hermann	Maler Freude		423     solitude	1877-1962. (Allemand)	berkeley	3178
Si l'homme échoue à concilier la justice et la liberté, alors il échoue à tout.	CAMUS Albert	Carnets		546     éthique	1913-1960.	berkeley	1027
Des vers ne peuvent plaire ni durer longtemps, s'ils ont été écrits par des buveurs d'eau.  Nulla placere diu nec vivere carmina possunt, quae scribuntur aquae potoribus...	Horace	Epîtres, I, XIX, 2-3  		393     création artistique	65-8 av. J.-C. (Quintus Horatius Flaccus)  On a surtout retenu les deux derniers mots, que l"on emploie par dédain ou dérision. Le proverbe était d"origine grecque. On dit en français: les méchants sont buveurs d"eau.	berkeley	3243
C'est maintenant qu'il faut boire.  Nunc est bibendum.	Horace	Odes, I, XXXVII, 1		440     courage	65-8 av. J.-C. (Quintus Horatius Flaccus)	berkeley	3248
Pour assurer le triomphe du mal, il suffit que les hommes de bien s'abstiennent d'agir.	BURKE Edmund			442     démission		berkeley	915
Ce que je peux faire, ce n'est pas ce que me dit un homme de loi; mais ce que l'humanité, la raison et la justice me disent que je devrais faire.  It is not what a lawyer tells me I may do; but what humanity, reason, and justice tell me ought to do.	BURKE Edmund	Resolutions for Conciliation with America, 1775		546     éthique	1729-1797. (Irlandais)	berkeley	916
Diogène frappait le père quand le fils jurait.  Diogenes struck the father when the son swore.	BURTON Robert	The Anatomy of Melancholy, III		421     initiation	1577-1640. (Anglais)	berkeley	918
C'est l'accident qui fait l'artiste.	GRENIER Jean	Lexique		393     création artistique	1898-1971.	berkeley	3014
L'homme veut connaitre et, lorsqu'il perd cette envie, il cesse d'être un homme.	BRATTAIN Walter			110     entropie	Nobel de physique.	berkeley	839
L'art de raisonner se réduit à une langue bien faite.	CONDILLAC Etienne Bonnot de	La Logique ou les Premiers Développements de l"art de penser		545     épistémologie	1714-1780.	berkeley	1587
Nu comme un plat d'argent, - nu comme un mur d'église,  Nu comme le discours d'un académicien.	MUSSET Alfred de	Premières Poésies, Namouna		221     vanité	1810-1857.	berkeley	4520
Presque toutes les monarchies n'ont été fondées que sur l'ignorance des arts et n'ont été détruites que parce qu'on les a trop cultivés.	MONTESQUIEU Charles de	Lettres persanes		539     ironie sociale	1689-1755. (C. de Secondat, baron de La Brède et de M.)	berkeley	4454
Je regarde la grammaire comme la première partie de l'art de penser.	CONDILLAC Etienne Bonnot de	Cours d"étude pour l"instruction du prince de Parme		545     épistémologie	1714-1780.	berkeley	1588
L'amour-propre d'un sot est aussi dangereux que celui d'un homme d'esprit est utile.	LIGNE Prince de	Mes écarts		234     communication	1735-1814.	berkeley	4135
L'homme a établi sa domination sur son environnement naturel en faisant naître un environnement artificiel ; et ce monstre (...) se révèle être un maître bien plus intraitable et plus impitoyable que cet environnement naturel que les ouvrages de l'homme ont surmonté ou étouffé et risquent même d'anéantir.	TOYNBEE Arnold	L"autre moitié du monde. Avant-Propos.		210     violence	1884/1975	berkeley	5220
Ils avaient tous deux des hauts et des bas, mais jamais synchrones. S'ils avaient su se maintenir ensemble en haut de la même vague ne fût-ce que quelques minutes, ils auraient gagné.	WEST Morris	De main de Maître.	1982	430     paradoxal émotionnel		berkeley	5420
'Quid sit futurum cras, fuge quaerere.' Horace. Si tu passes ta vie à attendre la tempête, tu ne profiteras jamais du beau temps.	WEST Morris	Les bouffons de Dieu.	1981	430     paradoxal émotionnel		berkeley	5421
Que méprisez-vous ? Par cel à, on vous connait vraiment.	HERBERT Franck	Dune	1965	221     vanité		berkeley	3134
Mon imitation n'est point un esclavage.  Je ne prends que l'idée, et les tours, et les lois  Que nos maîtres suivaient eux-mêmes autrefois.	LA FONTAINE Jean de	Epître à Huet		539     ironie sociale	1621-1695.	berkeley	3760
Quiconque a beaucoup vu Peut avoir beaucoup retenu.	LA FONTAINE Jean de	L"Irondelle et les petits Oiseaux.		540     mémoire		berkeley	3762
Que de tout inconnu le sage se méfie.	LA FONTAINE Jean de	Fables, le Renard, le Loup et le Cheval		560     sagesse	1621-1695.	berkeley	3763
Je n'ai aucune espèce de joie à faire le bonheur des gens qui ne me plaisent pas.	BERNARD Tristan	Jules, Juliette et Julien		235     séduction	1866-1947. (Paul Bernard)	berkeley	714
Les grands esprits sont sûrement de proches alliés de la folie, et de minces cloisons les en séparent.  Great wits are sure to madness near allied,  and thin partitions do their bounds divide.	DRYDEN John	Absalom and Achitophel, I		370     esprit	1631-1700. (Anglais)	berkeley	2158
La liberté pose de nombreux problèmes et la démocratie n'est pas parfaite, mais nous n'avons jamais été obligés d'élever un mur pour conserver chez nous notre peuple.	KENNEDY John F.		1963	238     servitudes du pouvoir politique		berkeley	3545
Et le joueur d'échecs est généralement un individu réservé, opprimé d'une manière ou d'une autre... L'attaque du roi qui est ce que l'on cherche aux échecs, attenter à l'autorité, serait une sorte de libération de cet état.	PEREZ-REVERTE Arturo	Le Tableau du Maître flamand	1990	433     perversion		berkeley	4675
Il n'était pas difficile de l'imaginer prenant plaisir à médire des autres, projetant sur eux ses complexes et ses frustrations. Personnalité étiolée, opprimée par la vie.	PEREZ-REVERTE Arturo	Le Tableau du Maître flamand	1990	433     perversion	on	berkeley	4676
L'amour, après tout, n'est qu'une curiosité supérieure, un appétit de l'inconnu qui vous pousse dans l'orage, poitrine ouverte et tête en avant.	FLAUBERT Gustave	L"amour de l"art.	1915	530     ironie amoureuse	(1821/1880) édition posthume	berkeley	2784
S'il échoue qu'au moins il échoue en osant de grandes choses, de sorte que sa place ne soit jamais parmi ces âmes froides et timides qui ne connaissent ni la victoire, ni la défaite.	ROOSEVELT Théodore			140     rapport à la cosmogonie		berkeley	4858
Il faut secouer la vie ; autrement elle nous ronge.	STENDHAL	lettre à sa soeur Pauline	1809	110     entropie		berkeley	5144
La terre est bleue comme une orange.	ELUARD Paul			510     ironie		berkeley	2335
Puisse la route venir à la rencontre de vos pieds et le vent rester toujours dans votre dos.	Dictons et Proverbes	Proverbe irlandais		140     rapport à la cosmogonie		berkeley	1991
Ne fais pas de signes d'adieu à la caravane, tu la rejoindras bientôt...	Dictons et Proverbes	Proverbe des gens du désert.		140     rapport à la cosmogonie		berkeley	1992
Quand la liberté rentrera, je rentrerai.	HUGO Victor	Actes et paroles		540     mémoire	1802-1885.	berkeley	3348
Je crois ce que je dis, et je fais ce que je crois.	HUGO Victor	L"Année terrible.		546     éthique		berkeley	3350
La perte du croyant, c'est de rencontrer son église.	CHAR René	A une sérénité crispée		510     ironie	1907-1988.	berkeley	1187
La lucidité est la blessure la plus proche du soleil.\t	CHAR René\t\t\t			370     esprit	affiché au CDI Elsa Triolet par Mireille Caruso	berkeley	1189
Qui a deux femmes perd son âme ; Qui a deux maisons perd sa raison.	Dictons et Proverbes	Dicton.		410     santé		berkeley	2019
L'expérience est le nom que chacun donne à ses erreurs.	WILDE Oscar	L"éventail De Lady Windermere.		432     expérience		berkeley	5476
Car il n'y a que la seule irrésolution qui cause les regrets et les repentirs.	DESCARTES René	Correspondance, à Elisabeth, 15 septembre 1645	1645	440     courage	1596-1650.	berkeley	1945
Considérez la race dont vous êtes,  créés non pas pour vivre comme brutes,  mais pour suivre vertu et connaissance.  Considerate la vostra semenza:  fatti non foste a viver come bruti,  ma per seguir virtute e conoscenza.	Dante Alighieri	Divina Commedia, L"Inferno, XXVI		370     esprit	1265-1321. (Italien)	berkeley	1754
La fortune, pour arriver à moi, passera par les conditions que lui impose mon caractère.	CHAMFORT Nicolas-Sébastien de	Maximes et Pensées		520     ironie de soi	1740/1794. Ac. Française	berkeley	1147
Il faut savoir faire les sottises que nous demande notre caractère.	CHAMFORT Nicolas-Sébastien de	Maximes et pensées		520     ironie de soi	1740/1794. Ac. Française	berkeley	1148
Les peuples démocratiques haïssent souvent les dépositaires du pouvoir central; mais ils aiment toujours ce pouvoir lui-même.	TOCQUEVILLE Alexis de	De la démocratie en Amérique		231     légitimité du pouvoir	1805-1859.	berkeley	5205
Il faut se défier de la gaieté que montre souvent le Français dans ses plus grands maux; elle prouve seulement que, croyant sa mauvaise fortune inévitable, il cherche à s'en distraire en n'y pensant point, et non qu'il ne la sent pas.	TOCQUEVILLE Alexis de	L"Ancien Régime et la Révolution		442     démission	1805-1859.	berkeley	5208
La création artistique semble même procéder d'une si noble nature - en raison même de son incroyable ambition à déterminer le plaisir/émotion - qu'il serait décidément risible de prétendre en maitriser (par automatisme) un quelconque processus : l'artiste peut produire des résultats, non pas des générateurs de résultats.	MORENO Roland	Théorie du Bordel Ambiant	1990	393     création artistique	Inventeur de la carte à mémoire, vendue cash.	berkeley	4503
L'ambition est le fumier de la gloire.  L'ambizione è lo sterco della gloria.	L"ARéTIN Pierre	Lettere.		221     vanité	1492-1556 (Italien) (Pietro Aretino)	berkeley	3580
L'homme est un apprenti, la douleur est son maître,  Et nul ne se connaît tant qu'il n'a pas souffert.	MUSSET Alfred de	Poésies, la Nuit d"octobre		421     initiation	1810-1857.	berkeley	4534
Il faut au grand chef moins de vertu que de grandeur.	DE GAULLE Charles			391     commandement		berkeley	1824
Aimons les nouveautés en novateurs prudents.	DELAVIGNE Casimir	Les Comédiens		441     sang-froid	1793-1843.	berkeley	1889
La vérité est comme la religion: elle n'a que deux ennemis, le trop et le trop peu.  Truth is like religion; it has only two enemies - the too much and the too little.	BUTLER Samuel	Erewhon, 13		441     sang-froid	1835-1902. (Anglais)	berkeley	926
Il y a autant de vices qui viennent de ce qu'on ne s'estime pas assez, que de ce qu'on s'estime trop.	MONTESQUIEU Charles de	Mes pensées		422     confiance en soi	1689-1755. (C. de Secondat, baron de La Brède et de M.)	berkeley	4440
L'oisiveté est la lie de l'existence.  A state of idleness is the very dregs of life.	DEFOE Daniel	Robinson Crusoe, II		442     démission	1660-1731. (Anglais)	berkeley	1876
Après que nous avons fait notre mieux touchant les choses qui nous sont extérieures, tout ce qui manque de nous réussir est au regard de nous absolument impossible.	DESCARTES René	Discours de la méthode		520     ironie de soi	1596-1650.	berkeley	1952
L'éducation consiste à nous donner des idées, et la bonne éducation à les mettre en proportion.	MONTESQUIEU Charles de	Essai sur les causes qui peuvent affecter les esprits et les caractères		421     initiation	1689-1755. (C. de Secondat, baron de La Brède et de M.)	berkeley	4438
Mon travail me met en contact avec toutes sortes d'auteurs, hommes, femmes, génies, idiots, psychopathes, asociaux, je ne sais jamais sur qui je vais tomber. Alors, j'ai mis au point une technique. Je m'installe aux commandes dès le premier instant. J'essaye de les mettre mal à l'aise, puis je les rassure. C'est ce que j'ai fait avec vous. Mais ça n'a pas marché. Je m'excuse.	WEST Morris	De main de Maître.	1988	391     commandement		berkeley	5397
Qu'est-ce que l'esprit ? Raison assaisonnée ; Par ce seul mot la dispute est bornée.	ROUSSEAU Jean-Baptiste			370     esprit	1670/17341. français.	berkeley	4880
Je connais trop les hommes pour ignorer que souvent l'offensé pardonne mais que l'offenseur ne pardonne jamais.	ROUSSEAU Jean-Jacques	ignorer que \\010{&#237;		221     vanité		berkeley	4884
Rabelais surtout est incompréhensible : son livre est une énigme, quoi qu'on veuille dire, inexplicable; ... c'est un monstrueux assemblage d'une morale fine et ingénieuse, et d'une sale corruption. Où il est mauvais, il passe bien loin au-del à du pire, c'est le charme de la canaille; où il est bon, il va jusques à l'exquis et à l'excellent, il peut être le mets des plus délicats.	LA BRUYERE Jean de	Les Caractères		393     création artistique	1645-1696.	berkeley	3613
Il y a bien autant de paresse que de faiblesse à se laisser gouverner.	LA BRUYERE Jean de	Les Caractères		110     entropie	1645-1696.	berkeley	3588
Il ne faut ni vigueur, ni jeunesse, ni santé, pour être avare.	LA BRUYERE Jean de	Les Caractères		110     entropie	1645-1696.	berkeley	3589
Ce genre de choses ne sert qu' à jouer au Trivial Pursuit... et nous sommes dans une galerie d'art, pas dans un café.	WEST Morris	De main de Maître.	1988	510     ironie		berkeley	5444
Après tout, puisque la chance nous sourit, continuons jusqu' à ce qu'elle grimace.	WEST Morris	De main de Maître.	1988	510     ironie		berkeley	5445
L'homme est du bois dont on fait les bûchers.	CAMUS Albert	L"Etat de siège		515     tragédie	1913-1960.	berkeley	1021
L'amour qui mène le soleil et les étoiles.  L'amor che move il sole e l'altre stelle.  Divina Commedia, Il Paradiso, XXXIII  	Dante Alighieri	Dernier vers de la Divine Comédie.		530     ironie amoureuse	1265-1321. (Italien)	berkeley	1756
Après le pain, l'éducation est le premier besoin d'un peuple.	DANTON			421     initiation		berkeley	1757
Suffisamment est un mot ignoble qui tue toute ambition.	DARD Frédéric	La Vieille qui marchait dans la Mer. San-Antonio.	1988	110     entropie		berkeley	1758
L'illusion est au coeur ce que l'oxygène est à l'appareil respiratoire.	DES OMBIAUX Maurice	Le Guignol de l"Après-Guerre.		510     ironie		berkeley	1902
Le meilleur remède que je sache pour les douleurs présentes, c'est d'oublier les joies passées, en espérance de mieux avoir.	DES PéRIERS Bonaventure	Cymbalum mundi		312     foi	v. 1510-v. 1544.	berkeley	1903
Il vaut mieux tomber dans les mains d'un médecin heureux que d'un médecin savant.	DES PéRIERS Bonaventure	Nouvelles Récréations et joyeux devis		510     ironie	v. 1510-v. 1544.	berkeley	1904
Je crois d'un bon citoyen de préférer les paroles qui sauvent aux paroles qui plaisent.	Démosthène	Olynthiennes, III, 21		231     légitimité du pouvoir	384-322 av. J.-C.	berkeley	1898
Le ciel fit l'eau pour Jean qui pleure,  Et fit le vin pour Jean qui rit.	DéSAUGIERS Marc-Antoine	Chansons		140     rapport à la cosmogonie	1772-1827.	berkeley	1905
Les surréalistes sont des gens qui se font installer le téléphone et qui, ensuite, coupent le fil.	VLAMINCK Maurice			221     vanité	 à DHK	berkeley	5321
Quand je n'aurais appris qu' à m'étonner, je me trouverais bien payée de vieillir.	COLETTE Sidonie Gabrielle	Prisons et paradis		341     étonnement	1873-1954.	berkeley	1544
J'appelle bourgeois quiconque pense bassement.  	FLAUBERT Gustave			221     vanité	1821-1880. Rapporté par Guy de Maupassant dans son Etude sur G. Flaubert.	berkeley	2718
Nous ne pouvons aimer que notre égal, le miroir, l'écho de notre être.	HEGEL Friedrich			531     communication amoureuse		berkeley	3100
Les leçons de l'expérience sont celles qi nous permettent de ne pas recommencer toujours les choses à leur début.	FAIRGAGNETR Oscar	Vitalités.	1993	432     expérience		berkeley	2586
Veux-tu être heureux ? Donne du bonheur.	SAINT-EXUPERY Antoine de			530     ironie amoureuse		berkeley	4919
[...] le diplôme est l'ennemi mortel de la culture.	VALERY Paul			510     ironie		berkeley	5243
La morale va au-devant de l'action; la loi l'attend.	CHATEAUBRIAND François-René de	Histoire de France		546     éthique	1768-1848.	berkeley	1316
Au lieu que c'est une vertu d'avoir pitié des moindres afflictions qu'ont les autres, c'est une espèce de lâcheté de s'affliger pour les nôtres propres.	DESCARTES René	Correspondance, à Huygens, 20 mai 1637		520     ironie de soi	1596-1650.	berkeley	1909
Je suis comme un milieu entre Dieu et le néant.	DESCARTES René	Méditations.		140     rapport à la cosmogonie		berkeley	1910
Il faut être ignorant comme un maître d'école  Pour se flatter de dire une seule parole  Que personne ici-bas n'ait pu dire avant vous.	MUSSET Alfred de	Premières Poésies, Namouna		221     vanité	1810-1857.	berkeley	4522
Philosopher, c'est apprendre à mourir.	MONTAIGNE Michel Eyquem de			510     ironie		berkeley	4372
On connaît des comédiens aigris, il n'en est guère de désillusionnés.	COLETTE Sidonie Gabrielle	Paysages et portraits		510     ironie	1873-1954.	berkeley	1563
Plus on vieillit et plus on se persuade que Sa sacrée Majesté le Hasard fait les trois quarts de la besogne de ce misérable univers.	FRéDéRIC II le Grand	Lettre à Voltaire, 12 mars 1759	1759	510     ironie	1712-1786., roi de Prusse	berkeley	2883
Bien qu'on vante la solitude, A la longue elle fait baîller.	TREMBLEY A.	Fables, Le Lapin, la Marmotte et la Chatte.		423     solitude		berkeley	5222
Je n'écris plus une phrase affirmative sans être tenté d'y ajouter : 'peut-être'.	GIDE André	Les Faux-Monnayeurs		432     expérience		berkeley	2940
Où tu ne peux pas dire tant mieux, dis : tant pis, Nathanaël. Il y a de grandes promesses de bonheur.	GIDE André	Les Nourritures terrestres.		440     courage		berkeley	2941
L'amour-propre est, hélas ! le plus sot des amours.	DESHOULIERES Mme	Réflexions diverses.		520     ironie de soi		berkeley	1956
Quand vous vous sentez bien, les ondes alpha de votre cerveau ont une période de dix hertz. Même chose quand vous gonflez vos biceps. C'est un spectre de fréquences que nous trouvons constam- ment chez les insectes et autres animaux, dans leurs mécanismes sensitifs.	COLLINS Larry	Dédale.	1989	410     santé		berkeley	1570
Il faut toujours tirer l'aspect positif d'une situation qui ne l'est pas forcément.	COMAS Erik		1992	430     paradoxal émotionnel	interwievé par Patrick Camus d"Auto Hebdo.	berkeley	1572
De tous les animaux qui s'élèvent dans l'air, Qui marchent sur la terre, ou nagent dans la mer, De Paris au Pérou, du Japon jusqu' à Rome, Le plus sot animal, à mon avis, c'est l'homme.	BOILEAU Nicolas	Satire, VIII.		510     ironie		berkeley	784
L'absurde se nomme. Le désespoir se chante. Tout vient se perdre dans les mots et y ressusciter.	PARAIN Brice	Recherches Sur La Nature Et...		510     ironie	... les fonctions du langage.	berkeley	4632
Le ciel et la terre passeront, mais mes paroles ne passeront point.	Evangiles	Evangile selon saint Matthieu, XXIV, 35		215     mystifications		berkeley	2418
Celui qui n'est pas avec moi est contre moi.	Evangiles	Evangile selon saint Matthieu, XII, 30		239     servitudes du pouvoir autoritaire		berkeley	2434
Le fait qu'un homme soit né dans une écurie ne signifie pas nécéssairement qu'il soit un cheval	WELLINGTON Duc de			365     discernement		berkeley	5348
La mort est le génie qui inspire le philosophe, l'Apollon musagète de la philosophie... S'il n'y avait pas la mort, on ne philosopherait guère.  Der Tod ist der eigentliche inspirierende Genius oder der Musaget der Philosophie. .. Schwerlich sogar würde, ohne den Tod, philosophiert werden.	SCHOPENHAUER Arthur	Le Monde comme volonté et représentation		365     discernement	1788-1860. (Allemand)	berkeley	4971
Tous les méchants sont buveurs d'eau ; C'est bien prouvé par le déluge.	SEGUR L.-Ph.	Chanson morale.		510     ironie		berkeley	4996
Shakespeare est au nombre des cinq ou six écrivains qui ont suffi au besoin et à l'aliment de la pensée; ces génies-mères semblent avoir enfanté et allaité tous les autres.	CHATEAUBRIAND François-René de	Essai sur la littérature anglaise		393     création artistique	1768-1848.	berkeley	1300
Il n'y a pas d'athées dans les tranchées.	MAC ARTHUR Douglas			430     paradoxal émotionnel		berkeley	4154
La culpabilité est le cadeau qui ne s'épuise jamais.	Dictons et Proverbes	Proverbe Juif		420     capital affectif		berkeley	1984
L'éminence même d'un spécialiste le rend plus dangereux.	CARREL Alexis	L"Homme, cet inconnu		433     perversion	1873-1944.	berkeley	1041
Il n'y a que les pauvres qu'on puisse dépouiller.	CASSOU Jean	Le Livre de Lazare		210     violence	1897-1986.	berkeley	1047
La banalité est faite d'un mystère qui n'a pas jugé utile de se dénoncer.	BLANCHOT Maurice	Faux Pas		110     entropie	1907-.	berkeley	763
L'homme, quoi qu'on dise, est maître de son destin. De ce qu'on lui a donné, il peut toujours faire quelque chose.	GRENIER Jean	Inspirations méditérranéennes.		130     liberté		berkeley	3013
Toute forme de communication durablement efficace trouve sa source dans une sémiologie de la confiance. Toute forme de propagande convaincante trouve sa source dans une sémiologie de perversion du rêve.	FAIRGAGNETR Oscar	Sémiologie.	1992	433     perversion		berkeley	2588
Ce qui fait que si peu de personnes sont agréables dans la conversation, c'est que chacun songe plus à ce qu'il veut dire qu' à ce que les autres disent.	LA ROCHEFOUCAULD François de	Réflexions diverses		221     vanité	1613-1680.	berkeley	3803
Qui vole un oeuf volera un boeuf.	HERBERT George	Jacula Prudentum		222     fourberie	1593/1632	berkeley	3155
Tout est possible à celui qui croit.	Evangiles	Evangile selon saint Marc, IX, 23		312     foi		berkeley	2435
Il est des hommes débiles qui ne peuvent se surmonter. D'un bonheur médiocre, ils font leur bonheur. Ils s'arrêtent dans une auberge pour la vie.	SAINT-EXUPERY Antoine de	Citadelle.	1948	110     entropie	ouvrage posthume.	berkeley	4917
Ce n'est pas à l'Université que se fait la Révolution.	GUéHENNO Jean	Caliban et Prospéro		214     guerre du savoir	1890-1978.	berkeley	3035
Je ne me fie quasi jamais aux premières pensées qui me viennent.	DESCARTES René	Discours De La Méthode.		360     bon sens		berkeley	1920
C'est tuer pour rien, parfois, que de ne pas tuer assez.	CAMUS Albert	Les Justes		441     sang-froid	1913-1960.	berkeley	1015
L'absurde, c'est la raison lucide qui constate ses limites.	CAMUS Albert	Le Mythe de Sisyphe		510     ironie	1913-1960.	berkeley	1016
Il n'est pas de destin qui ne se surmonte par le mépris.	CAMUS Albert	Le Mythe de Sisyphe		515     tragédie	1913-1960.	berkeley	1022
Je me sens comme Lazare quand il a entendu la grande voix lui dire de sortir au soleil, et il ne pouvait pas marcher parce qu'il était attaché dans son linceul, et il ne pouvait pas sortir parce qu'il y avait cette grosse pierre qui fermait le tombeau... Et puis, tout d'un coup, il se trouve dehors : et le monde est l à, neuf et étincelant comme s'il ne l'avait jamais vu auparavant et qu'il devait tout rapprendre depuis le début...	WEST Morris	Kaloni le navigateur.	1972	421     initiation		berkeley	5410
L'homme est fils de ses habitudes et de son milieu, et non fils de sa nature et de son mélange d'humeurs.	Ibn Khaldun	Prolégomènes		442     démission	1332-1406. (Arabe)	berkeley	3373
Dans la nature innée des hommes se trouve le penchant vers la tyrannie et l'oppression mutuelle.	Ibn Khaldun	Prolégomènes		515     tragédie	1332-1406. (Arabe)	berkeley	3374
Chercher le bonheur dans cette vie, c'est l à le véritable esprit de rébellion.	IBSEN Henrik	Les Revenants, I		321     volonté	1828-1906. (Norvégien)	berkeley	3378
Dire que l'homme est un composé de force et de faiblesse, de lumière et d'aveuglement, de petitesse et de grandeur, ce n'est pas lui faire son procès, c'est le définir.	DIDEROT Denis	Addition aux Pensées philosophiques		520     ironie de soi	1713-1784.	berkeley	2114
La personnalité créatrice doit penser et juger par elle-même  car le progrès moral de la société dépend exclusivement de son indépendance. Sinon la société est inexorablement vouée à l'échec, comme l'être humain privé de la possibilité de communiquer. Je définis une société saine par cette double liaison. Elle n'existe que par des êtres indépendants mais profondément unis au groupe.	EINSTEIN Albert	Comment je vois le Monde	1934	390     création	rééd.corr. en 1952 et 1978.	berkeley	2313
Ce manant devinait les droits de l'homme. Il fut pendu, cela devait être.	COURIER Paul-Louis	Lettres au rédacteur du "Censeur"		225     cynisme	1772-1825.	berkeley	1695
C'est une grande habileté que de savoir cacher son habileté.	LA ROCHEFOUCAULD François de	Maximes.		370     esprit	1613/1680	berkeley	3857
Je remplace la mélancolie par le courage, le doute par la certitude, le désespoir par l'espoir, la méchanceté par le bien, les plaintes par le devoir, le scepticisme par la foi, les sophismes par la froideur du calme et l'orgueil par la modestie.	LAUTRéAMONT Comte de	Poésies, exergue		441     sang-froid	1846-1870. (Isidore Ducasse)	berkeley	4052
Il est du véritable amour comme de l'apparition des esprits: tout le monde en parle, mais peu de gens en on vu.	LA ROCHEFOUCAULD François de	Maximes		531     communication amoureuse	1613-1680.	berkeley	3937
Si on juge de l'amour par la plupart de ses effets, il ressemble plus à la haine qu' à l'amitié 	LA ROCHEFOUCAULD François de	Maximes		530     ironie amoureuse	1613-1680.	berkeley	3919
L'Art, c'est la nature accélérée et Dieu au ralenti.	CHAZAL Malcolm de	Sens plastique		393     création artistique	1902-1981.	berkeley	1325
On rencontre beaucoup d'hommes parlant de liberté, mais on en voit très peu dont la vie n'ait pas été principalement consacrée à se forger des chaines.	LE BON Gustave	Hier et Demain.		110     entropie		berkeley	4058
Pour bien saisir les différences, il faut refroidir sa tête, et ralentir le mouvement de sa pensée. - Pour bien remarquer les analogies, il faut échauffer sa tête, et accélérer le mouvement de sa pensée.	HéRAULT DE SéCHELLES Marie-Jean	Théorie de l"ambition		365     discernement	1759-1794.	berkeley	3128
Je suivrai le bon parti jusqu'au feu, mais exclusivement si je puis* 	MONTAIGNE Michel Eyquem de	Essais, III, 1 		441     sang-froid	1533-1592.  *Boutade reprise de Rabelais.	berkeley	4365
En matière de prévision, le jugement est supérieur à l'intelligence. L'intelligence montre toutes les possibilités pouvant se produire. Le jugement discerne parmi ces possibilités celles qui ont le plus de chance de se réaliser.	LE BON Gustave	Hier et Demain.		441     sang-froid		berkeley	4068
Il parait bien démuni celui qui se retouve sans amis et, plus encore, celui qui ne connait ni la valeur ni le prix de l'amitié.	FAIRGAGNETR Oscar	Vitalités.	1993	330     coeur		berkeley	2542
Faute d'organe, il est très naturel que les gens de peu de sensibilité ne puissent distinguer entre gentillesse et faiblesse.	FAIRGAGNETR Oscar	Vitalités.	1993	330     coeur		berkeley	2544
Riez mais enfants ! Riez ! Dans cent ans, aucun de nous n'y pensera plus.	VIAN Boris			510     ironie		berkeley	5290
La description par Hobbes de l'état de nature, c'est la critique des utopies humaines, c'est le constat de l'impuissance des peuples à bâtir pacifiquement un idéal. Littéralement, celui qui veut faire l'ange fait la bête et l'état de pureté, la quête de la perfection, l'imposition aux autres d'un Bien préconçu conduisent à un déchaînement de rivalités violentes où l'homme, pour servir les prescriptions de sa raison, s'en remet aux forces les plus animales de sa nature.	RUFIN Jean-Christophe	La Dictature Libérale.		232     servitudes du pouvoir	Le secret de la toute-puissance des démocraties au 20e siècle	berkeley	4895
On peut tout acquérir dans la solitude, hormis du caractère.	STENDHAL	De L"amour.		423     solitude	Henri Beyle dit STENDHAL	berkeley	5152
Un pessimiste est un optimiste bien informé.	Dictons et Proverbes			510     ironie		berkeley	2043
L'homme n'est qu'un roseau, le plus faible de la natureê; mais c'est un roseau pensant.	PASCAL Blaise			370     esprit		berkeley	4645
Le coeur a ses raisons que la raison ne connait point ; on le sait en mille choses.	PASCAL Blaise	Pensées.		430     paradoxal émotionnel	1623/1662. recueil posthume.	berkeley	4647
Passe encor de bâtir: mais planter à cet âge! 	LA FONTAINE Jean de	Fables, le Vieillard et les Trois Jeunes Hommes		510     ironie	1621-1695.	berkeley	3740
Mais un fripon d'enfant (cet âge est sans pitié) ...	LA FONTAINE Jean de	Fables		510     ironie	1621-1695.	berkeley	3741
- Adieu, dit le renard. Voici mon secret. Il est très simple: on ne voit bien qu'avec le coeur. L'essentiel est invisible pour les yeux.	SAINT-EXUPéRY Antoine de	Le Petit Prince		330     coeur	1900-1944.	berkeley	4925
Qui aurait besoin de pitié, sinon ceux qui n'ont compassion de personne! 	CAMUS Albert	L"Etat de siège		221     vanité	1913-1960.	berkeley	988
Pour réussir dans le monde, retenez bien ces trois maximes : voir, c'est savoir ; vouloir, c'est pouvoir ; oser, c'est avoir.	MUSSET Alfred de	Barbarerie.		140     rapport à la cosmogonie		berkeley	4517
Les hommes trébuchent parfois sur la vérité, mais la plupart se redressent et passent vite leur chemin comme si rien ne leur était arrivé.	CHURCHILL Sir Winston Leonard Spencer			433     perversion	\\010byp\\020	berkeley	1368
La mort et la douleur seront nos compagnons de voyage; les privations notre vêtement, la constance et la vaillance notre seul bouclier.  Death and sorrow will be the companions of our journey; hardship our garment, constancy and valour our only shield.  	CHURCHILL Sir Winston Leonard Spencer			440     courage	1874-1965.   Paroles prononcées par Winston Churchill le 8 octobre 1940 devant la Chambre des Communes.	berkeley	1369
La faim n'a aucune fidélité. Ces peuples avaient vu trop de conquérants venir et s'en aller. Leur soumission allait aux forts et non aux doux. C'était une terre rude et son histoireétait rude. Ce n'était pas l'héritage des doux.	WEST Morris	L"Avocat du Diable.	1959	210     violence		berkeley	5358
L à où Dieu a un temple, le diable aura une chapelle.  Where God hath a temple, the Devil will have a chapel.	BURTON Robert	The Anatomy of Melancholy		221     vanité	1577-1640. (Anglais)	berkeley	917
Il y a une forte raison de ne pas dire au premier arrivant ce qui vient à l'esprit, c'est qu'on ne le pense point.	CHARTIER Emile	Eléments De Philosophie.		441     sang-froid	alias Alain (1868-1951)	berkeley	1271
Aucun possible n'est beau; le réel seul est beau.	CHARTIER Emile	Système Des Beaux-arts.		441     sang-froid	alias Alain (1868-1951)	berkeley	1272
Nous avons le coeur étrangement léger quand, de bonne foi, nous acceptons notre nullité dans un domaine quelconque.  There is the strangest lightness about the heart when one's nothingness in a particular line is once accepted in good faith.	JAMES William	Principles of Psychology, XII		520     ironie de soi	1842-1910. (Américain)	berkeley	3420
Sache te faire du bien et tu pourras en faire à d'autres. Sache diriger ta vitalité et tu iras au-del à de tes rêves.	FAIRGAGNETR Oscar	Vitalités.	1992	390     création		berkeley	2556
Le courage d'agir nait au coeur de la pensée, grandit avec la volonté de construire et vit dans le succès de la réalisation en devenir.	FAIRGAGNETR Oscar		1991	390     création		berkeley	2557
L'homme trop occupé des femmes reçoit d'elles, un jour, sa punition.	COLETTE Sidonie Gabrielle	Chambre d"hôtel		433     perversion	1873-1954.	berkeley	1557
Une femme qui reste une femme, c'est un être complet.	COLETTE Sidonie Gabrielle	Ces plaisirs		440     courage	1873-1954.	berkeley	1558
C'est au moment où l'on triche pour le beau que l'on est artiste.	JACOB Max	Art poétique.		393     création artistique	1876/1944	berkeley	3410
Un roi sans la vertu porte le sceptre en vain.	RONSARD Pierre de	Discours		221     vanité	1524-1585.	berkeley	4852
Vue de loin, la situation européenne me parait plus que jamais insensée. Elle constitue en tout cas la preuve la plus accablante de l'inanité de notre civilisation.	LEIRIS Michel	Lettre à DHK	1932	240     débauche		berkeley	4100
Il faut mentir s'il n'y a que du mal à attendre de l'aveu d'une vérité.	LEIRIS Michel	Fibrilles.		441     sang-froid		berkeley	4101
Croire tout découvert est une erreur profonde ; C'est prendre l'horizon pour les bornes du monde.	LEMIERRE Antoine-Marin	Utilité des découvertes,etc.		110     entropie	1723/1793	berkeley	4103
Le chef-d'oeuvre est garant du génie, le génie n'est pas garant du chef-d'oeuvre.	MALRAUX André	Antimémoires		393     création artistique	1901-1976.	berkeley	4205
S'il existe une solitude où le solitaire est un abandonné, il en existe une où il n'est solitaire que parce que les hommes ne l'ont pas encore rejoint	MALRAUX André	Le Triangle Noir.		423     solitude		berkeley	4207
La vérité d'un homme, c'est d'abord ce qu'il cache.	MALRAUX André	Antimémoires		510     ironie	1901-1976.	berkeley	4208
Un grand coeur dédaigne et oublie, mais le lâche se réjouit dans la haine.	MANZONI Alessandro	Le comte de Carmagnola.		330     coeur		berkeley	4213
Non seulement Dieu joue aux dés, mais en plus, il triche.	HEISENBERG Wehrner			215     mystifications		berkeley	3107
Les Français semblent* des guenons qui vont grimpant contremont+ un arbre, de branche en branche, et ne cessent d'aller jusqu' à ce qu'elles sont arrivées à la plus haute branche, et y montrent le cul quand elles y sont.	MONTAIGNE Michel Eyquem de	Essais, II, 17  		221     vanité	1533-1592. * Ressemblent à + En escaladant.	berkeley	4327
Braves devant l'ennemi, lâches devant la guerre, c'est la devise des vrais généraux.	GIRAUDOUX Jean			211     guerre		berkeley	2964
L'histoire ne repasse pas les plats.	CéLINE L.-F.	In l"hebdomadaire l"Express, n° 312		510     ironie	1894-1961. (Louis-Ferdinand Destouches)	berkeley	1082
Chacun de nous ne peut suivre que le chemin tracé devant lui. Chacun de nous est soumis aux conséquences de ses propres convictions [...].	WEST Morris	L"Avocat du Diable.	1959	320     intuition	n	berkeley	5384
Il ne peut y avoir de progrès véritable qu'intérieur. Le progrès matériel est un néant.	GREEN Julien	Journal.		370     esprit		berkeley	3007
Le néant se nie s'il se nomme.	CHAPELAN Maurice	Main courante		441     sang-froid	1906-.	berkeley	1171
La règle d'or de la conduite est la tolérance mutuelle, car nous ne penserons jamais tous de la même façon, nous ne verrons qu'une partie de la vérité et sous des angles différents.	GANDHI Mahatma			370     esprit	cité dans "Tous les hommes sont frères".	berkeley	2905
L'optimisme est propre aux âmes qui n'ont qu'une seule dimension.  El optimismo es propio de las almas que tienen una sola dimension.	GARCIA LORCA Federico	DiAlogos de un caricaturista salvaje		221     vanité	1899-1936. (Espagnol)	berkeley	2908
Il est aussi noble de tendre à l'équilibre qu' à la perfection; car c'est une perfection que de garder l'équilibre.	GRENIER Jean	Nouveau Lexique		510     ironie	1898-1971.	berkeley	3021
La porte du ciel est fermée pour celui qui vécut seul ;  Sauve une âme, et elle sauvera la tienne. Heaven's gate is shut to him who comes alone  Save thou a soul, and it shall save thy own.	WHITTIER John Greenleaf	Maud Muller		140     rapport à la cosmogonie	1807-1892. (Américain)	berkeley	5463
Tout homme a une mission et, si minime que soit la mienne, je ne pense pas qu'il soit sage de l'annuler.	LOCKQUELL Clément	Les élus que vous êtes.		321     volonté		berkeley	4145
[...] vous ne pouvez pas vivre en même temps dans deux univers. Si vous voulez vivre selon la loi, vous devez en accepter les codes. Si vous voulez vivre dans la jungle, vous êtes libres ; mais cel à vous coûtera cher.	WEST Morris	La seconde victoire.	1972	130     liberté		berkeley	5352
Chaque classe d'hommes tombe dans un excès qui lui est particulier. On peut connaître la vertu d'un homme en observant ses défauts.	CONFUCIUS	Entretiens, II, 4		140     rapport à la cosmogonie	551-479 av. J.-C. (Chinois)	berkeley	1591
Il faut vivre de peu pour être riche de tout.	CONFUCIUS			140     rapport à la cosmogonie		berkeley	1592
Je n'ai pas encore vu un homme qui aimât la vertu autant qu'on aime une belle apparence.	CONFUCIUS	Entretiens, VIII, 15		221     vanité	551-479 av. J.-C. (Chinois)	berkeley	1593
Il faut que le disciple de la sagesse ait le coeur grand et courageux. Le fardeau est lourd et le voyage est long.	CONFUCIUS	Entretiens, IV, 8		421     initiation	551-479 av. J.-C. (Chinois)	berkeley	1598
Tout le monde ne sait pas douter: on a besoin de lumière pour y parvenir, et de force pour s'en tenir l à.	FONTENELLE Bernard le Bovier de	Réflexions sur la poétique		365     discernement	1657-1757.	berkeley	2818
Quand je pourrai me perdre dans tes yeux et toi dans les miens, nous saurons qu'il existe une vie d'amour après la solitude du malheur.	FAIRGAGNETR Oscar	tes yeux et \\010W&#235;`\\010W&#248;P		531     communication amoureuse		berkeley	2640
Les mots sont les passants mystérieux de l'âme.	HUGO Victor	Les Contemplations		340     sensibilité	1802-1885.	berkeley	3305
- ... Désormais, la France et la Grande-Bretagne ne seront plus    deux nations, mais une seule union franco-britannique... - Ce que vous me dites l à, c'est vous qui le dites, ou bien    c'est Churchill ?    grandes conséquences. Il faut tenir !	DE GAULLE & CHURCHILL & RAYNAUD	Projet Monnet-Corbin	1940	440     courage	Projet Monnet-Corbin d""anglo-french unity" avec gouv.fed.unique.	berkeley	1780
Il faut avoir une parfaite conscience des ses propres limites, surtout si on veut les élargir.	GRAMSCI Antonio	Lettres de prison.		370     esprit		berkeley	3003
C'est une triste chose de penser que la nature parle et que le genre humain n'écoute pas.	HUGO Victor	Carnets, albums, journaux		140     rapport à la cosmogonie	1802-1885.	berkeley	3281
Ce sont les Grecs qui nous ont légué le plus beau mot de notre langue : le mot 'enthousiasme' - du grec 'en theo', un Dieu intérieur.	PASTEUR Louis			312     foi	1822/1895	berkeley	4656
Que de routes prend et que de raisons se donne le coeur pour en arriver à ce qu'il veut! 	DUMAS Alexandre	Préface de la Dame aux camélias		430     paradoxal émotionnel	1824-1895. (fils)	berkeley	2231
La maladie de l'esprit est faite d'ignorance et d'incertitude.	WEST Morris	Le Loup Rouge.	1971	430     paradoxal émotionnel		berkeley	5418
Tel donne à pleines mains qui n'oblige personne:  La façon de donner vaut mieux que ce qu'on donne.	CORNEILLE Pierre	Le Menteur, I, 1, Cliton		330     coeur	1606-1684.	berkeley	1655
Oui, j'ai une patrie: la langue française.	CAMUS Albert	Carnets		393     création artistique	1913-1960.	berkeley	1003
Les affections profondes ressemblent aux honnêtes femmes; elles ont peur d'être découvertes, et passent dans la vie les yeux baissés.	FLAUBERT Gustave	L"Education sentimentale		530     ironie amoureuse	1821-1880.	berkeley	2781
Mais la jeunesse ardente et prompte aux changements  Toujours mit sous le pied nos admonestements.	GARNIER Robert	Les Juives		421     initiation	v. 1545?-1590 	berkeley	2915
Je ne sais pas ce que peut être la conscience d'une canaille, mais je sais ce qu'est la conscience d'un honnête homme: c'est effrayant.	HERMANT Abel	Le Bourgeois		433     perversion	1862-1950.	berkeley	3163
Au-dessous de la Loire, le mensonge est une forme de la sociabilité, et comme une politesse de la race.	HERMANT Abel	Eloge du mensonge		510     ironie	1862-1950.	berkeley	3164
Me juger toujours responsable ; autrui, jamais.	PRéVOST Jean	Les Caractères.		423     solitude	1901-1944	berkeley	4733
Trouver de mauvaises raisons à ce que l'on croit en vertu d'autres mauvaises raisons - voil à la philosophie.  Finding bad reasons for what one believes for other bad reasons - that's philosophy.	HUXLEY Aldous	Brave New World, 17.		433     perversion	1894-1963 (Anglais)	berkeley	3363
A force de chercher, je trouve l'expression juste, qui était la seule et qui est en même temps, l'harmonieuse [...]. Le mot ne manque jamais quand on possède l'idée.	FLAUBERT Gustave	Correspondance.		370     esprit		berkeley	2738
Apprendre par coeur; ce mot me plaît. Il n'y a guère en effet que le coeur qui retienne bien, et qui retienne vite.	HéRAULT DE SéCHELLES Marie-Jean	Réflexions sur la déclamation		421     initiation	1759-1794.	berkeley	3130
Maintenant le champ de bataille est une terre de cadavres debouts ; ceux qui sont résolus à mourir vivront ; ceux qui espèrent sauver leur vie périront.	WU CH"I			440     courage		berkeley	5499
Grant ne m'a pas laché quand j'étais fou, je ne l'ai pas laché quand il était ivre et maintenant, que diable, nous nous serons les coudes.	SHERMAN Général William T.		1870	330     coeur	(attribué au..., vers 1870)	berkeley	5078
La leçon des faits n'instruit pas l'homme prisonnier d'une croyance ou d'une formule.	LE BON Gustave	Hier et Demain.		432     expérience		berkeley	4065
Ce n'est à la raison, mais au bon sens, qu'il eut fallu jadis élever un temple. Beaucoup d'hommes sont doués de raison, très peu de bon sens.	LE BON Gustave	Hier et Demain.		441     sang-froid		berkeley	4069
Toute ironie mise à part, j'ai le sentiment profond que si je cessais de respecter les idéaux et les gens, mes réalisations finiraient rapidement d'exister. Ce n'est pas exprimable en dollars, mais pourtant beaucoup de ce qui constitue le Spectre est en rapport avec les gens, lesquels ne peuvent figurer sur une feuille de bilan financier.	SMALL Dave		1991	392     création économique	interview publiée dans ST Mag de janvier 92.	berkeley	5088
Une vie sans examen ne vaut pas la peine d'être vécue.	SOCRATE	conversation avec ses juges, rapportée par Platon		110     entropie	469/399 av. JC, condamné à mort à Athènes pr cause de "sagesse".	berkeley	5091
Sauvez le faible Aischa des vertiges de Nahash, sauvez la plaintive Héva des mirages de la sensibilité, et que les Khérubs me gardent.	PELADAN Joséphin	Comment on devient Fée	1893	510     ironie		berkeley	4665
Qui séjourne auprès de la négation ne peut se servir d'elle.	BLANCHOT Maurice	L"Espace littéraire		110     entropie	1907-.	berkeley	762
Tout ce qui n'est pas passion est sur un fond d'ennui.	MONTHERLANT Henry Millon de	Aux fontaines du désir		312     foi	1896-1973.	berkeley	4474
Le peintre doit rester maître de son sujet, le dominer. Le mien m'écrasait. J'étais inondé, c'est le mot.	CLAVEL Bernard	L"ouvrier de la nuit.	1956	393     création artistique		berkeley	1479
C'est aussi ce qui fait un bon artiste. Il faut être fort pour s'imposer une discipline personnelle de travail, et survivre ensuite aux échecs.	WEST Morris	De main de Maître.	1988	390     création		berkeley	5394
Montaigne eût dit: que sais-je? et Rabelais: peut-être.	HUGO Victor	Marion Delorme, IV, 8, L"Angely		370     esprit	1802-1885.	berkeley	3312
Quand on fait trop le grand, on paraît bien petit.	Destouches	Le Glorieux, III, 5, Lisette		221     vanité	1680-1754. (Philippe Néricault)	berkeley	1965
L'homme ne vit pas seulement de pain,  mais de toute parole qui sort de la bouche de Dieu.	Evangiles	Evangile selon saint Matthieu, IV, 3-4		215     mystifications	De l"art de récupérer au profit de la mystification Déiste de l"immanence la quête spirituelle de l"individu.	berkeley	2413
Une couronne d'épines, ce n'est qu'une couronne de roses d'où les roses sont tombées.	FLERS Robert de	Primerose, II, 12, Primerose		215     mystifications	1872-1927. (et Gaston Arman de Caillavet)	berkeley	2791
J'ai bien une sérénité profonde, mais tout me trouble à la surface ; il est plus facile de commander à son coeur qu' à son visage.	FLAUBERT Gustave	L"amour de l"art.	1915	320     intuition	(1821/1880) édition posthume	berkeley	2729
Les choses ennuyeuses ont toujours un prestige que les choses amusantes n'ont pas.	FLERS Robert de	Le Roi		221     vanité	1872-1927. (et Emmanuel Arène, Gaston A. de Caillavet)	berkeley	2793
L'espérance, toute trompeuse qu'elle est, sert au moins à nous mener à la fin de la vie par un chemin agréable.	LA ROCHEFOUCAULD François de	Maximes		312     foi	1613-1680.	berkeley	3839
La faiblesse est plus opposée à la vertu que le vice.	LA ROCHEFOUCAULD François de	Maximes		321     volonté	1613-1680.	berkeley	3844
A chacune de ses escales, le bateau du Temps débarque une gloire. Mais il arrive qu'il la réembarque lors d'une escale nouvelle.	BOSCH F. van den	Aphorismes du temps présent.		510     ironie		berkeley	792
C'est par la force des images que, par la suite des temps, pourraient bien s'accomplir les 'vraies' révolutions.	BRETON André	Les Nouvelles littéraires, Hommage à Saint-Pol Roux, 1925		234     communication	1896-1966.	berkeley	846
A tous les Français, La France a perdu une bataille, mais la France n'a pas perdu la guerre. Des gouvernants de rencontre ont pu capituler, cédant à la panique, oubliant l'honneur, livrant le pays à la servitude. Cependant, rien n'est perdu ! ... Voil à pourquoi, je convie tous les Français, où qu'ils se trouvent, à s'unir avec moi dans l'action, dans le sacrifice et dans l'espérance...	DE GAULLE Charles	Affiche fleurissant sur les murs de Londres - juillet 1940.	1940	391     commandement		berkeley	1826
Nous avons le coeur étrangement léger quand, de bonne foi, nous acceptons notre nullité dans un domaine quelconque.  There is the strangest lightness about the heart when one's nothingness in a particular line is once accepted in good faith.	JAMES William	Principles of Psychology, XII		520     ironie de soi	1842-1910. (Américain)	berkeley	3421
Dieu est le plus court chemin de zéro à l'infini, dans un sens ou dans l'autre.	JARRY Alfred	Gestes et opinions du Dr. Faustroll, pataphysicien		215     mystifications	1873-1907.	berkeley	3424
La simplicité n'a pas besoin d'être simple, mais du complexe resserré et synthétisé 	JARRY Alfred	Les Minutes de sable mémorial		370     esprit	1873-1907.	berkeley	3425
L'insurrection est un calcul sur des grandeurs particulièrement indéfinies dont la valeur est chaque jour susceptible de se modifier.	MARX Karl			210     violence		berkeley	4242
Parler plus bas pour se faire mieux écouter d'un public sourd.	JOUBERT Joseph	Carnets		234     communication	1754-1824.	berkeley	3453
L'indiscipline aveugle et de tous les instants fait la force principale des hommes libres.	JARRY Alfred	Ubu enchaîné, I, 2, le caporal		433     perversion	1873-1907.	berkeley	3426
Peut-être que vous trouverez que ce qui semble confusion est un art caché, et si vous savez rencontrer le point par où il faut regarder les choses, toutes les inégalités se rectifieront, et vous ne verrez que sagesse où vous n'imaginiez que désordre.	BOSSUET Jacques Bénigne	Sermon sur la providence		421     initiation	1627-1704.	berkeley	804
Tout, jusqu' à la vérité, trompe dans ses écrits.	LA HARPE Jean François de	Eloges		221     vanité	1739-1803. A propos de J.-J. Rousseau.	berkeley	3770
En France, le premier jour est pour l'engouement, le second pour la critique et le troisième pour l'indifférence.	LA HARPE Jean François de	Mélanges		221     vanité	1739-1803.	berkeley	3771
Le conflit présent sera tôt ou tard marqué par des mouvements, des surprises, des irruptions, des poursuites, dont l'ampleur et la rapidité dépasseront infiniment celles des plus fulgurants évènements du passé. Beaucoup de signes annoncent déj à ce déchaînement des forces nouvelles [...]. Ne nous y trompons pas ! Le conflit qui est commencé pourrait bien être le plus étendu, le plus complexe, le plus violent de tous ceux qui ravagèrent la terre. La crise politique, économique, sociale, morale dont il est issu revêt une telle profondeur et présente un tel caractère d'ubiquité qu'elle aboutira fatalement à un bouleversement complet de la situation des peuples et de la structure des Etats.	DE GAULLE Charles	L"Avènement de la force mécanique. Mémorandum.	1940	211     guerre	ronéotypé à 80 exemplaires adressés à autant de personnalités civiles et militaires le 26/01.	berkeley	1791
La France est le seul pays du monde où, si vous ajoutez dix citoyens à dix autres, vous ne faites pas une addition, mais vingt divisions.	DANINOS Pierre	Les Carnets du major W. Marmaduke Thompson		539     ironie sociale	1913-.	berkeley	1749
La France ? Une nation de bourgeois qui se défendent de l'être en attaquant les autres parce qu'ils le sont.	DANINOS Pierre	Les Carnets du major W. Marmaduke Thompson		539     ironie sociale	1913-.	berkeley	1750
A l'affamé appartient le pain que tu gardes. A l'homme nu, le manteau que recèlent tes coffres. Au va-nu-pieds la chaussure qui pourrit chez toi. Au miséreux, l'argent que tu tiens enfoui.	ST.BASILE	Patrologie grecque, XXXI, Homélie 6		330     coeur	329-379.	berkeley	5115
A trop se vouloir satisfaire, sans laisser au temps le temps de comprendre ce dont nous avons le plus besoin hors l'urgence des apparences, nous commettons des injustices.	FAIRGAGNETR Oscar		1991	210     violence		berkeley	2496
La guerre, seule, rassemble les déçus. Elle est la folie ultime de la fraternisation grégaire et de l'idolâtrie.	FAIRGAGNETR Oscar		1992	211     guerre		berkeley	2497
Le plaisir est une prière  Et l'aumône une volupté 	LAMARTINE Alphonse de	Harmonies poétiques et religieuses, Pour une quête		460     plaisir	1790-1869.	berkeley	4006
On jugerait bien plus sûrement un homme d'après ce qu'il rêve que d'après ce qu'il pense.	HUGO Victor	Les Misérables		365     discernement	1802-1885.	berkeley	3309
Toujours par quelque endroit fourbes se laissent prendre.	LA FONTAINE Jean de	Fables		222     fourberie	1621-1695.	berkeley	3675
Ce qu'on donne aux méchants, toujours on le regrette ...  Laissez-leur prendre un pied chez vous,  Ils en auront bientôt pris quatre.	LA FONTAINE Jean de	Fables, la Lice et sa Compagne		222     fourberie	1621-1695.	berkeley	3678
Je ne suis pas de ceux qui disent: 'Ce n'est rien,  C'est une femme qui se noie.'  Je dis que c'est beaucoup ; et ce sexe vaut bien Que nous le regrettions, puisqu'il fait notre joie.	LA FONTAINE Jean de	Fables, la Femme noyée		330     coeur	1621-1695.	berkeley	3693
Parbleu! dit le meunier, est bien fou du cerveau  Qui prétend contenter tout le monde et son père.	LA FONTAINE Jean de	Fables, le Meunier, son Fils et l"Ane		560     sagesse	1621-1695.	berkeley	3765
Oiseaux de même plumage volent en compagnie.	CERVANTES SAAVEDRA Miguel de	Don Quichotte.		120     grégarité	1547-1616. (Espagnol)	berkeley	1087
On n'a jamais que le choix de se battre ou de renoncer.	FAIRGAGNETR Oscar	Vitalités.	1992	510     ironie		berkeley	2618
Dans les grandes choses, les hommes se montrent comme il leur convient de se montrer ; dans les petites, ils se montrent comme ils sont.	CHAMFORT Nicolas-Sébastien de	Maximes et Pensées.		235     séduction	1740/1794. Ac. Française	berkeley	1115
Tous les pays qui n'ont plus de légende  Seront condamnés à mourir de froid...	LA TOUR DU PIN Patrice de	Une somme de poésie		539     ironie sociale	1911-1975.	berkeley	3953
L'humiliation et l'angoisse sont mauvaises conseillères.	LACOUTURE Jean	De Gaulle.	1984	441     sang-froid		berkeley	3980
Baise m'encor, rebaise-moi et baise ;  Donne m'en un de tes plus savoureux ;  Donne m'en un de tes plus amoureux,  Je t'en rendrai quatre plus chauds que braise.	LABE Louise	Sonnets, XVII		460     plaisir	Labé Louise (1524/1566)	berkeley	3955
Avant d'obliger un homme, assurez-vous bien d'abord que cet homme n'est pas un imbécile.	LABICHE Eugène	Le Voyage de M. Perrichon		330     coeur	1815-1888	berkeley	3957
La manière la plus profonde de sentir quelque chose est d'en souffrir.	FLAUBERT Gustave	Carnets		510     ironie	1821-1880.	berkeley	2779
A moins d'être un crétin, on meurt toujours dans l'incertitude de sa propre valeur et de celle de ses oeuvres.	FLAUBERT Gustave	Correspondance, 1842, à Louise Colet, 1852		520     ironie de soi	1821-1880.	berkeley	2780
Le dénigrement de ceux que nous aimons toujours nous en détache quelque peu. Il ne faut pas toucher aux idoles. La dorure en reste aux mains.	FLAUBERT Gustave	Madame Bovary		530     ironie amoureuse		berkeley	2782
Le travail réclame l'élite des humains.  Labor optimos citat.	Sénèque	De la providence, 5		380     travail		berkeley	5013
Ce que j'ai appris, je ne le sais plus. Le peu que je sais encore, je l'ai deviné.	CHAMFORT Nicolas-Sébastien de	Maximes et pensées		320     intuition	1740/1794. Ac. Française	berkeley	1116
Etre et penser sont pour nous la même chose.	BUFFON Georges-Louis Leclerc de	Histoire Naturelle.		370     esprit	1707-1788	berkeley	895
Ceux qui écrivent comme ils parlent, quoiqu'ils parlent très bien, écrivent mal.	BUFFON Georges-Louis Leclerc de			390     création	1707-1788. Discours sur le style, prononcé à l"Académie française, le jour de sa réception, le 25 août 1753.	berkeley	897
Une mouche ne doit pas tenir, dans la tête d'un naturaliste, plus de place qu'elle n'en tient dans la nature.	BUFFON Georges-Louis Leclerc de	Histoire Naturelle.		441     sang-froid	1707-1788	berkeley	898
L'esprit de bien des gens n'est que l'art de se taire.	DARU Comte	La Cléopide.		370     esprit		berkeley	1765
N'est-ce pas une sagesse supérieure que laisser vaquer en paix les serviteurs sincères de la vérité !	EINSTEIN Albert	Comment je vois le Monde	1934	546     éthique	rééd.corr. en 1952 et 1978.	berkeley	2322
Il n'y a qu'une méthode pour inventer, qui est d'imiter. Il n'y a qu'une méthode pour bien penser, qui est de continuer quelque pensée ancienne et éprouvée.	CHARTIER Emile	Propos Sur L"éducation.		390     création	alias Alain (1868-1951)	berkeley	1241
Il n'y a qu'une méthode pour inventer, qui est d'imiter. Il n'y a qu'une méthode pour bien penser, qui est de continuer quelque pensée ancienne et éprouvée.	CHARTIER Emile	Propos sur l"éducation.		390     création	alias ALAIN	berkeley	1242
L'amitié? Elle disparaît quand celui qui est aimé tombe dans le malheur, ou quand celui qui aime devient puissant.	CHATEAUBRIAND François-René de	Vie de Rancé		510     ironie	1768-1848.	berkeley	1311
Il faut être économe de son mépris étant donné le grand nombre de nécéssiteux.	CHATEAUBRIAND François-René de			510     ironie		berkeley	1312
Nous sommes tous des farceurs: nous survivons à nos problèmes.	CIORAN Emile-Michel	Syllogismes de l"amertume		441     sang-froid	1911-.	berkeley	1393
Je ne suis ni un homme, ni un poète, ni une feuille,  mais un pouls blessé qui pressent l'au-del à.  Yo no soy un hombre, ni un poeta, ni una hoja,  pero sí un pulso herido que sonda las cosas del otro lado.	GARCIA LORCA Federico	El poeta en Nueva York, Poema doble del lago Edem		520     ironie de soi	1899-1936. (Espagnol)	berkeley	2912
Lorsque l'esprit est plein de joie, cela sert beaucoup à faire que le corps se porte mieux et que les objets présents paraissent plus agréables.	DESCARTES René	Correspondance		312     foi	1596-1650.	berkeley	1914
Nous sommes nés à quêter* la vérité; il appartient de la posséder à une plus grande puissance.	MONTAIGNE Michel Eyquem de	Essais, III, 8 		520     ironie de soi	1533-1592.  *Faits naturellement pour chercher.	berkeley	4382
Les contraires se connaissent l'un par l'autre: l'injustice de l'amour-propre se connaît par la justice de la charité.	BOSSUET Jacques Bénigne	Traité de la concupiscence		430     paradoxal émotionnel	1627-1704.	berkeley	806
Celui-l à est un incomparable naïf qui accorde à celui-ci plus de considération que celui-ci ne s'en porte à lui-même.	FAIRGAGNETR Oscar		1991	370     esprit		berkeley	2554
Le génie, c'est sans doute cette aptitude à pouvoir marier en un seul corps l'innocence de l'esprit à l'énergie de la création.	FAIRGAGNETR Oscar	Vitalités.	1995	390     création		berkeley	2555
... Faisant de cet ouvrage  Une ample comédie à cent actes divers,  Et dont la scène est l'Univers.	LA FONTAINE Jean de	Fables, le Bûcheron et Mercure		393     création artistique	1621-1695.	berkeley	3708
Amants, heureux amants, voulez-vous voyager?  Que ce soit aux rives prochaines.  Soyez-vous l'un à l'autre un monde toujours beau,  Toujours divers, toujours nouveau;  Tenez-vous lieu de tout, comptez pour rien le reste.	LA FONTAINE Jean de	Fables		531     communication amoureuse	1621-1695.	berkeley	3757
Ne soyez à la cour, si vous voulez y plaire,  Ni fade adulateur ni parleur trop sincère.  Et tâchez quelquefois de répondre en Normand.	LA FONTAINE Jean de	Fables, la Cour du Lion		539     ironie sociale	1621-1695.	berkeley	3759
La Fortune aime les gens peu sensés; elle aime les audacieux et ceux qui ne craignent pas de dire: 'Le sort en est jeté.' La sagesse, au contraire, rend timide.  Amat Fortuna parum cordatos, amat audaciores et quibus illud placet Alea jacta est. At Sapientia timidulos reddit.	ERASME Didier	L"Eloge de la folie, LXI		510     ironie	v. 1469-1536 	berkeley	2367
Les français sont des veaux.	DE GAULLE Charles			110     entropie		berkeley	1783
Les antialcooliques sont des malades en proie à ce poison, l'eau, si dissolvant et corrosif qu'on l'a choisi entre autres substances pour les abiutions et lessives, et qu'une goutte versée dans un liquide pur, l'absinthe, par exemple, le trouble.	JARRY Alfred	Spéculations		510     ironie	1873-1907.	berkeley	3427
Nous n'échappons pas à notre enveloppe, et nous ne la trahissons qu'au prix de mille peines.	COLETTE Sidonie Gabrielle	Discours de réception.		432     expérience	1873/1954	berkeley	1553
Il y a autant de faiblesse à fuir la mode qu' à l'affecter.	LA BRUYERE Jean de	Les Caractères, De la mode		221     vanité	1645-1696.	berkeley	3599
La cour est comme un édifice de marbre; je veux dire qu'elle est composée d'hommes fort durs, mais fort polis.	LA BRUYERE Jean de	Les Caractères, De la cour		222     fourberie	1645-1696.	berkeley	3600
Quand une lecture vous élève l'esprit et qu'elle vous inspire des sentiments nobles et courageux, ne cherchez pas une autre règle pour juger de l'ouvrage : il est bon et fait de main d'ouvrier.	LA BRUYERE Jean de	Les Caractères.		234     communication		berkeley	3601
L'esprit de la conversation consiste bien moins à en montrer beaucoup qu' à en faire trouver aux autres: celui qui sort de votre entretien content de soi et de son esprit l'est de vous parfaitement.	LA BRUYERE Jean de	Les Caractères		234     communication	1645-1696.	berkeley	3602
Il y a un goût dans la pure amitié où ne peuvent atteindre ceux qui sont nés médiocres.	LA BRUYERE Jean de	Les Caractères		234     communication	1645-1696.	berkeley	3603
Il y a quelques rencontres* dans la vie où la vérité et la simplicité sont le meilleur manège du monde.	LA BRUYERE Jean de	Les Caractères 		234     communication	1645-1696.  *Circonstances.	berkeley	3604
Etre avec des gens qu'on aime, cela suffit; rêver, leur parler, ne leur parler point, penser à eux, penser à des choses plus indifférentes, mais auprès d'eux, tout est égal.	LA BRUYERE Jean de	Les Caractères		234     communication	1645-1696.	berkeley	3605
Ne songer qu' à soi et au présent, source d'erreur dans la politique.	LA BRUYERE Jean de	Les Caractères		238     servitudes du pouvoir politique	1645-1696.	berkeley	3606
Il faut des fripons à la cour auprès des grands et des ministres, même les mieux intentionnés; mais l'usage en est délicat, et il faut savoir les mettre en oeuvre.	LA BRUYERE Jean de	Les Caractères		238     servitudes du pouvoir politique	1645-1696.	berkeley	3607
C'est une grande misère que de n'avoir pas assez d'esprit pour bien parler, ni assez de jugement pour se taire.	LA BRUYERE Jean de	Les Caractères, De la société et de la conversation		320     intuition	1645-1696.	berkeley	3608
La femme est l'unique vase qui nous reste encore où verser notre idéalité.	GOETHE Johann Wolfgang von	Entretiens Eckermans		530     ironie amoureuse		berkeley	2980
Qui ne sait pas tirer les leçons de 3000 ans vit seulement au jour le jour.	GOETHE Johann Wolfgang von			540     mémoire		berkeley	2981
Quand les idées manquent, C'est alors qu'un mot vient à propos tenir la place.	Goethe Johann Wolfgang von	Faust, I.		510     ironie		berkeley	2982
Le gigantisme, pour les corporatistes, est un but en soi.	GOLDSMITH Jimmy	Le Piège.	1993	212     guerre économique		berkeley	2986
L'argent donne tout ce qui semble aux autres le bonheur.	RéGNIER Henri de	"Donc..."		510     ironie	1864-1936.	berkeley	4803
C'est par ses admirations surtout que le symbolisme a été grand. Il a mis presque tout son génie à choisir ses patronages.	GRACQ Julien	Préférences		393     création artistique	1910-. (Louis Poirier)	berkeley	3002
Nous attendons l'invasion promise de longue date. Les poissons aussi.	CHURCHILL Sir Winston Leonard Spencer		1940	441     sang-froid	Message sur la BBC, adressé aux français le 21 octobre 1940.	berkeley	1374
De fait, face aux imprévisibles combinaisons que provoquent continûellement le déroulement du Réel, l'une des stratégies gagnantes est sans doute l'étonnement perpétuel : inlassable jouissance à profiter de tout ce qui bouge. L'ennui ne peut, pas plus que lorsqu'on invente ou que l'on crée soi-même, quand on acquiert la manie de capter cette création perpétuelle... Car l'invention et la contemplation ravie (ou scandalisée) du spectacle du monde qui se déroule devant nous procède des mêmes mécanismes et offrent des plaisirs de même nature.	MORENO Roland	Théorie du Bordel Ambiant	1990	341     étonnement	Inventeur de la carte à mémoire, vendue cash.	berkeley	4502
Quand le nazisme apparaît, les Soviétiques ne verront d'abord en lui qu'une épine dans le pied des sociaux-démocrates. Les communistes allemands, soumis à la ligne dure du Komintern, épauleront longtemps les nazis. Ils participeront même à une grève des transports déclenchée par les nazis trois mois avant l'arrivée au pouvoir de Hitler.	RUFIN Jean-Christophe	La Dictature Libérale.		225     cynisme	Le secret de la toute-puissance des démocraties au 20e siècle	berkeley	4889
Les âmes communes n'apprennent le sentiment de la justice que lorsqu'elles ont eu des déboires.	MONTHERLANT Henry Millon de	Carnets		546     éthique	1896-1973.	berkeley	4491
Je fais la guerre, je fous, je batis.	Henri IV			230     pouvoir	1553/1610	berkeley	3119
Vous pensez ce que ça pouvait signifier pour un peintre qui ne pouvait faire de la peinture qu' à la sauvette... J'étais comme demi-fou. Avec Kahnweiler, en somme, j'ai eu une stabilité et j'ai commencé à faire de la peinture sérieusement. Vraiment sérieusement, avec la possibilité de ne penser qu' à cela.	MASSON André			420     capital affectif		berkeley	4246
Le désespoir est une bonne chose mais il le faut entrelardé (de joie).	DUBUFFET Jean	Prospectus et tous Ecrits suivants		430     paradoxal émotionnel	1901-1985.	berkeley	2187
Le succès matériel ne doit être qu'un résultat, et jamais un but. Autrement, on perd la boule, on n'a même plus le sens pratique. Faisons bien, puis advienne que pourra !	FLAUBERT Gustave	L"amour de l"art.	1915	441     sang-froid	1821/1880, édition posthume	berkeley	2770
D'abord, vous devez vous rendre compte que les peuples vaincus n'ont aucune fidélité. Leurs chefs ont failli à leurs devoirs envers eux. Leurs fils sont morts pour une cause perdue. Ils n'ont foi en personne - même pas en eux-mêmes.	WEST Morris	L"Avocat du diable.	1959	240     débauche		berkeley	5380
O puissance d'imaginer, toi qui nous emporte parfois si loin hors de nous qu'on ne s'aperçoit pas que sonnent alentour mille trompettes, qui te met en mouvement, si les sens ne t'exitent ?	Dante Alighieri	La Divine Comédie; Le Purgatoire.		350     imagination		berkeley	1753
Le travail, l'intuition et la volonté suffisent à nourrir un coeur d'homme.	FAIRGAGNETR Oscar	lonté suffis\\010P&#243;p\\010P&#246; à	1991	440     courage	après le 5e courrier à H.T., dans l"attente de la suite...	berkeley	2600
La moitié de Madrid pille l'autre moitié 	HUGO Victor	Ruy Blas, III, 2, Ruy Blas		539     ironie sociale	1802-1885.	berkeley	3345
Un soldat est un esclave en uniforme.  Un soldado es un esclavo con uniforme.	DONOSO CORTéS Juan	Discurso en las Cortes, 1849		211     guerre	1809-1853. (Espagnol)	berkeley	2138
L'Amour est nu mais il n'est pas crotté.	DORAT Claude Joseph	Contes et nouvelles		531     communication amoureuse	1734-1780.	berkeley	2139
Les fous ouvrent les voies qu'empruntent ensuite les sages.  I pazzi aprono le vie che poi percorrono i savi.	DOSSI Carlo	Note Azzurre, 4971		560     sagesse	1849-1910. (Italien)	berkeley	2145
La minorité est l'incapacité de se servir de son entendement sans être dirigé par un autre. Elle est due à notre propre faute quand elle résulte non pas d'un manque d'entendement, mais d'un manque de résolution et de courage pour s'en servir sans être dirigé par un autre. Sapere aude ! Aie le courage de te servir de ton propre entendement ! Voil à la devise des lumières.	KANT	Qu"est-ce que les Lumières ?	1784	130     liberté		berkeley	3535
Les mots peuvent ressembler aux rayons X si l'on s'en sert convenablement - ils transpercent n'importe quoi.  Words can be like X-rays, if you use them properly - they'll go through anything.	HUXLEY Aldous	Brave New World, 4		234     communication	1894-1963. (Anglais)	berkeley	3356
Il faut mener un homme, tout homme, jusqu' à lui-même et lui apprendre à se construire.	GRENIER Jean	Inspirations méditérranéennes.		421     initiation		berkeley	3016
Il n'y a pas de simplicité véritable. Il n'y a que des simplifications.	FARGUE Léon-Paul	Sous la lampe		510     ironie	1876-1947.	berkeley	2671
L'éloignement est indispensable. Il y a un élément d'ordre religieux dans la confiance des hommes en un autre homme. Il faut que les subordonnés aient la croyance que le chef est comme d'une essence supérieure à la leur... Cette croyance disparait quand les masses qui lui obéissent le voient de trop près réfléchir, hésiter, changer d'avis, reconnaître une erreur, bref être un homme [...].  Un proverbe populaire exprime grossièrement ce fait : il n'y a pas de grand homme pour son valet de chambre.	DE GAULLE Charles	Le fil de l"Epée.	1932	391     commandement		berkeley	1822
Qui craint de souffrir, il souffre déj à de ce qu'il craint.	MONTAIGNE Michel Eyquem de	Essais, III, 13		433     perversion	1533-1592.	berkeley	4356
Et chacun croit fort aisément  Ce qu'il craint et ce qu'il désire.	LA FONTAINE Jean de	Fables, le Loup et le Renard		430     paradoxal émotionnel	1621-1695.	berkeley	3716
Jamais le christianisme, si vous y regardez de près, ne vous paraîtra plus sublime, plus digne de Dieu, et plus fait pour l'homme qu' à la guerre.	MAISTRE Joseph de	Les Soirées de Saint-Pétersbourg		215     mystifications	1753-1821.	berkeley	4180
... Car c'est double plaisir de tromper le trompeur.	LA FONTAINE Jean de	Fables, le Coq et le Renard		510     ironie	1621-1695.	berkeley	3747
Aimer est le grand point, qu'importe la maîtresse?  Qu'importe le flacon pourvu qu'on ait l'ivresse? 	MUSSET Alfred de	Premières Poésies, la Coupe et les lèvres		530     ironie amoureuse	1810-1857.	berkeley	4546
Il y a des femmes que leur bon naturel et la sincérité de leur coeur empêchent d'avoir deux amants à la fois.	MUSSET Alfred de	La Confession d"un enfant du siècle		531     communication amoureuse	1810-1857.	berkeley	4547
L'art de lire, c'est l'art de penser avec un peu d'aide.	FAGUET Emile	L"Art de lire		421     initiation	1847-1916.	berkeley	2450
Le sentiment de solitude, qui est la misère et la fierté des hommes supérieurs.	FAGUET Emile	t la misère \\010of@\\010ok\\020´		423     solitude		berkeley	2452
Ceux qui ne se reconnaissent que dans le regard d'autrui recherchent la complaisance qui leur cachera leur totale absence de personnalité.	FAIRGAGNETR Oscar	Vitalités.	1998	120     grégarité		berkeley	2454
Moi, j'ai toujours l'amour cousu dans mes entrailles.	GARNIER Robert	Antigone		420     capital affectif	v. 1545?-1590 	berkeley	2914
La plupart des mépris ne valent que des mépris.	MONTESQUIEU Charles de	Mes pensées		221     vanité	1689-1755. (C. de Secondat, baron de La Brède et de M.)	berkeley	4417
La plupart des hommes sont plus capables de grandes actions que de bonnes.	MONTESQUIEU Charles de	Mes pensées		221     vanité	1689-1755. (C. de Secondat, baron de La Brède et de M.)	berkeley	4418
Etre asservi à soi-même est le plus pénible des esclavages.  Sibi servire gravissima servitus est.	Sénèque	Questions naturelles, préface du 3e Livre		433     perversion		berkeley	5032
(Paris) Je l'aime tendrement jusqu' à ses verrues et à ses taches.	MONTAIGNE Michel Eyquem de	Essais, III, 9		539     ironie sociale	1533-1592.	berkeley	4387
Les expressions de Shakespeare nous apparaissent comme celles-l à mêmes dont se serviraient les plus grands objets naturels: une montagne, un glacier, s'ils condescendaient à s'exprimer.	DU BOS Charles	Journal 		393     création artistique	1882-1939.	berkeley	2166
Une oeuvre d'art est un coin de la création vu à travers	ZOLA Emile	Mes Haines.		393     création artistique		berkeley	5524
Autant légaliser la sodomie que reconnaître les bolcheviks.	CHURCHILL Sir Winston Leonard Spencer			225     cynisme	rapporté cité par P. Johnson, La Fin de la vieille Europe, Laffont, p. 86. par JC Rufin, la Dictature libérale, Lattès 1994, p. 55.	berkeley	1366
Après la mort, il n'y a rien et la mort elle-même n'est rien.  Post mortem nihil est ipsaque mors nihil.	Sénèque	Les Troyennes, 398		510     ironie		berkeley	5033
L'univers leur sait gré du mal qu'ils ne font pas.	LA FONTAINE Jean de	Fables, le Milan, le Roi et le Chasseur		140     rapport à la cosmogonie	1621-1695.	berkeley	3651
Je suis oiseau: voyez mes ailes ...  Je suis souris, vivent les rats! 	LA FONTAINE Jean de	Fables, la Chauve-souris et les Deux Belettes		140     rapport à la cosmogonie	1621-1695.	berkeley	3652
Et, si tu bois de l'eau, ne dis pas à tout propos que tu bois de l'eau.	EPICTETE	Manuel, XLVII		425     charisme	v. 50-v. 125.	berkeley	2352
Colère : oeuf de la Peur. Seuls les yeux sans paupières Sont francs. Nul ne guérit Le poison du Cobra Ni du Cobra les mots. Franchise, à tes côtés, Attirera Vigueur Et sa soeur Courtoisie. Mesure à ta longueur Jusqu'où tu peux frapper. Mais aux branches pourries Ne confie pas ta force. Et n'ouvre pas la bouche Plus grand que n'est le daim, de peur de voir tes yeux T'étouffer le gosier. Une fois rassasié, Cherches-tu à dormir ? Prends soin que ton repaire Soit caché, soit profond. Jusqu' à toi peut conduire Le pas de l'assassin. Est ou Ouest, Nord ou Sud, Va : sois propre et tais-toi ! (Toi, Jungle Intermédiaire, Du bord des étangs bleus Jusqu'aux rocs à lésardes, Protège-le ! Suis-le !) La Faveur de la Jungle T'accompagne partout !	KIPLING Rudyard	Le second livre de la Jungle.	1895	421     initiation	La dernière chanson, Kaa à Mowgli.	berkeley	3562
Shakespeare est le seul biographe de Shakespeare.  Shakespeare is the only biographer of Shakespeare.	EMERSON Ralph Waldo	Representative Men, Shakespeare		393     création artistique	1803-1882. (Américain)	berkeley	2342
Qui oserait affirmer que la rose en pleine floraison est plus parfaite que le bouton qui s'ouvre ?	WEST Morris	De main de Maître.	1988	510     ironie		berkeley	5440
Un objet qui soit comme un vrai objet et qui soit faux, c'est le véritable vrai, c'est la vérité du Théâtre.	JOUVET Louis	Témoignages sur le théâtre		215     mystifications	1887-1951.	berkeley	3499
Rien de plus futile, de plus faux, de plus vain, rien de plus nécessaire que le théâtre.	JOUVET Louis	Le Comédien désincarné		234     communication	1887-1951.	berkeley	3500
Le cerveau des enfants est comme une bougie allumée dans un lieu exposé au vent : sa lumière vacille toujours.	FENELON	De l"éducation des filles.		420     capital affectif		berkeley	2680
La raison européenne est analytique par utilisation, la raison nègre, intuitive par participation.	SENGHOR	que par util\\010R\\022&#240;\\010R\\026 à		140     rapport à la cosmogonie		berkeley	5034
Nous sommes d'un métal pur ou alors nous ne sommes rien.	PSICHARI			440     courage		berkeley	4743
Ceux-l à aussi avaient servi leur pays, sans savoir que ce dernier ignorait de quel service il avait besoin. Une armée est composée de jeunes gens qui font leur boulot sans comprendre et offrent leur vie. Et dans le cas présent, ils offraient leur mort.	CLANCY Tom	Danger Immédiat	1989	214     guerre du savoir		berkeley	1408
Amitié de cour, foi de renards et société de loups.	CHAMFORT Nicolas-Sébastien de	Maximes et pensées		120     grégarité	1740/1794. Ac. Française	berkeley	1107
Heureux les pauvres en esprit, car le Royaume des Cieux est à eux.	Evangiles	Evangile selon saint Matthieu, V, 3		215     mystifications		berkeley	2415
Il faut vaincre. Le vainqueur est celui qui le veut le plus énergiquement.	DE GAULLE Charles		1914	321     volonté	lettre à sa mère, envoyée du front.	berkeley	1815
La joie de contempler et de comprendre, voil à le langage que me porte la nature.	EINSTEIN Albert	Comment je vois le Monde	1934	341     étonnement	rééd.corr. en 1952 et 1978.	berkeley	2304
La vie est une phrase interrompue.	HUGO Victor	Tas de pierres		510     ironie	1802-1885.	berkeley	3337
Les hommes naissent et demeurent libres et égaux en droits; les distinctions sociales ne peuvent être fondées que sur l'utilité commune.	Déclaration des Droits de l"Homme	Article premier	1789	215     mystifications	1789. (et du Citoyen)	berkeley	1873
Le plus beau triomphe de l'écrivain est de faire penser ceux qui peuvent penser.	DELACROIX Eugène	Ecrits.		234     communication	1799/1863	berkeley	1880
Le temps n'épargne pas ce qu'on a fait sans lui.	FAYOLLE François	Discours sur la littérature et les littérateurs		140     rapport à la cosmogonie	1774-1852.	berkeley	2675
Un estomac creux n'est pas un bon conseiller politique.  An empty stomach is not a good political adviser.	EINSTEIN Albert	Cosmic Religion		130     liberté	1879-1955. (Allemand, naturalisé Américain)	berkeley	2290
(La France): Ses vertus partent du coeur, ses vices tiennent à l'esprit.	DUCLOS Charles Pinot	Considérations sur les moeurs de ce siècle		539     ironie sociale	1704-1772.	berkeley	2196
Il y a dans les hommes plus de choses à admirer que de choses à mépriser.	CAMUS Albert	La Peste		330     coeur	1913-1960.	berkeley	999
La chance, c'est pas une question de veine, il faut vouloir...	JEANSON Francis	Quand les lilas refleuriront		321     volonté		berkeley	3431
Pénétrer de présent la tradition elle-même: premier moyen de lui résister.	FEBVRE Lucien	Combats pour l"histoire		365     discernement	1878-1956.	berkeley	2676
Faire du commerce sans publicité, c'est comme faire de l'oeil à une femme dans l'obscurité. Vous savez ce que vous faites, mais personne d'autre ne le sait.  Doing business without advertising is like winking at a girl in the dark. You know what you are doing, but nobody else does.	BRITT Styuart Henderson	New York Herald Tribune, 30 octobre 1956		234     communication	1907-. (Américain)	berkeley	862
Dans l'ombre de mon coeur, mes plus fraîches amours,  Mes amours de quinze ans refleuriront toujours! 	BRIZEUX Auguste	Marie		420     capital affectif	1803-1858.	berkeley	863
Les âmes sont les idées de Dieu.	NERVAL Gérard de	Paradoxe et vérité		312     foi	1808-1855. (Gérard Labrunie)	berkeley	4569
Les grandes idées ne viennent pas du mauvais esprit.	NERVAL Gérard de	Sur un carnet		390     création	1808-1855. (Gérard Labrunie)	berkeley	4571
Le vrai, c'est le faux - du moins en art et en poésie.	NERVAL Gérard de	Les Nuits d"octobre, la Femme mérinos		393     création artistique	1808-1855. (Gérard Labrunie)	berkeley	4572
Il est dangereux de passer trop tôt pour un écrivain de bon sens: c'est le privilège des médiocrités mûres.	NERVAL Gérard de	La Bohème galante		393     création artistique	1808-1855. (Gérard Labrunie)	berkeley	4573
La politique est cet art mineur qui permet à des amateurs de s'approprier le privilège d'administrer les intérêts des ignorants.	FAIRGAGNETR Oscar	Vitalités.	1995	231     légitimité du pouvoir		berkeley	2511
Naitre, vivre et passer, c'est changer de forme.	DIDEROT Denis			510     ironie		berkeley	2113
Heureux deux amis qui s'aiment assez pour (savoir) se taire ensemble.	PEGUY Charles	Victor-Marie, comte Hugo.		330     coeur		berkeley	4661
Quand, d'aventure, l'esprit prend la bêtise à temoin, il s'enrhume.	FAIRGAGNETR Oscar	Vitalités.	1993	441     sang-froid		berkeley	2546
De mauvaises lois sont la pire sorte de tyrannie.  Bad laws are the worst sort of tyranny.	BURKE Edmund	Speech in Bristol, 1780		231     légitimité du pouvoir	1729-1797. (Irlandais)	berkeley	908
Quant à vos poltrons de capitaines, pendez-les haut et court car tudieu, c'est tout ce qu'ils méritent.	DU CASSE Commodore M.	Lettre à l"Amiral John BENBOW	1702	110     entropie	J.BENBOW,mort.bles.au large Santa-Maria.Colombie(22/08/1702)	berkeley	2172
Vous combattez et détruisez toutes les erreurs; mais que mettez-vous à leur place ? 	DU DEFFAND Marie de Vichy-Chamrond	Lettre à Voltaire		221     vanité	1697-1780. Marquise	berkeley	2173
Quand la bourse se rétrécit, la conscience s'élargit.	DU FAIL Noël	Contes et discours d"Eutrapel		365     discernement	1520-1591.	berkeley	2176
La décision est une belle chose, mais le vrai principe fécond, par conséquent le vrai principe artistique, c'est la réserve.	MANN Thomas	Goethe et Tolstoï.		441     sang-froid		berkeley	4211
Toute ma vie, j'ai fait comme si...	DE GAULLE Charles			234     communication		berkeley	1782
Le glaive de la justice n'a pas de fourreau.	MAISTRE Joseph de	Les Soirées de Saint-Pétersbourg		215     mystifications	1753-1821.	berkeley	4182
On n'est point toujours une bête pour l'avoir été quelquefois.	DIDEROT Denis	Les Bijoux indiscrets		365     discernement	1713-1784.	berkeley	2095
La timidité est un défaut dont il est dangereux de reprendre les personnes que l'on en veut corriger.	LA ROCHEFOUCAULD François de	Maximes.		430     paradoxal émotionnel		berkeley	3874
Le secret pour voyager d'une façon agréable consiste à savoir poliment écouter les mensonges des autres et à les croire le plus possible ; on vous laissera, à cette condition, produire à votre tour votre petit effet, et ainsi le profit sera réciproque.	DOSTOIEVSKI Fiodor Mikhaïlovitch	Journal d"un écrivain.		120     grégarité		berkeley	2148
Il n'est pour le vrai sage aucun revers funeste.	MOLIERE	Les Femmes Savantes.		560     sagesse		berkeley	4304
Qu'a donc dit Saint-Augustin ? Que lorsque l'esprit commande au corps il est obéi, mais que lorsqu'il commande à lui-même il rencontre de la résistance ? Oui... Depuis quelques temps, je rencontre plus de résistance. Je devrais me retirer tranquillement en moi-même.	HERBERT Franck	Dune	1965	321     volonté		berkeley	3136
Il n'y a probablement pas de révélation plus terrible que l'instant où vous découvrez que votre père est un homme... fait de chair.	HERBERT Franck	Dune	1965	421     initiation		berkeley	3141
L'anarchie est partout quand la responsabilité n'est nulle part.	LE BON Gustave	Hier et Demain.		110     entropie		berkeley	4059
Les hommes veulent être esclaves quelque part, et puiser l à de quoi dominer ailleurs.	LA BRUYERE Jean de	Les Caractères		110     entropie	1645-1696.	berkeley	3586
Heureux qui vit en paix du lait de ses brebis,  Et qui de leur toison voit filer ses habits.	RACAN Honorat de Bueil, marquis de	Les Bergeries, V, 1		130     liberté	1589-1670.	berkeley	4761
Il faut se contenter de découvrir, mais se garder d'expliquer.	BRAQUE Georges	Le Jour Et La Nuit.		390     création	1882/1963	berkeley	830
C'est une grande folie de vouloir être sage tout seul.	LA ROCHEFOUCAULD François de	Maximes.		221     vanité		berkeley	3819
L'Angleterre est un empire ; l'Allemagne, une race, et la France, une personne.	MICHELET J.	Histoire de France, t.II.		215     mystifications		berkeley	4281
Rien n'est plus paralysant que de s'apitoyer sur soi-même.	MILGER Peter		1992	440     courage	cinéaste et explorateur polaire allemand (Arte 22/10/92)	berkeley	4282
L'histoire est remplie de faits montrant la vérité réduite au silence par la persécution.	MILL John Stuart	Pour la liberté.		210     violence		berkeley	4283
L'obéissance à la loi qu'on s'est prescrite est liberté.	ROUSSEAU Jean-Jacques	Le Contrat Social.	1762	130     liberté		berkeley	4881
Tout homme qui ne se croit pas du génie n'a pas de talent.	GONCOURT Edmond de	Journal		422     confiance en soi		berkeley	2996
Faire route à pied par un beau temps, dans un beau pays, sans être pressé, et avoir pour terme de ma course un objet agréable : voil à de toutes les manières de vivre celle qui est le plus à mon gout.	ROUSSEAU Jean-Jacques	Confessions.		130     liberté		berkeley	4882
J'ai toujours passionnément aimé l'eau.	ROUSSEAU Jean-Jacques			140     rapport à la cosmogonie		berkeley	4883
Il y a eu des mésaventures et des leçons à en tirer.	HEPBURN Katharine			421     initiation		berkeley	3122
Les ânes préféreraient la paille à l'or.	Héraclite	Fragment, 9 Diels		225     cynisme	fin du VIe-Ve s. av. J.-C.	berkeley	3123
Supposer aux autres verbalement et avec un air de confiance, les vertus dont on a besoin en eux, afin qu'ils se les donnent au moins en apparence et pour le moment.	HéRAULT DE SéCHELLES Marie-Jean	Théorie de l"ambition		234     communication	1759-1794.	berkeley	3126
Je ne trouve qu'en vous je ne sais quelle grâce Qui me charme toujours et jamais ne me lasse.	RACINE Jean	Esther.		531     communication amoureuse		berkeley	4792
La solitude est à l'esprit ce que la diète est au corps, mortelle lorsqu'elle est trop longue, quoique nécéssaire.	VAUVENARGUES Marquis de	Pensées et maximes.		423     solitude	CLAPIER Luc de	berkeley	5266
Juger autrui, c'est se juger.	SHAKESPEARE William	Hamlet.		370     esprit		berkeley	5050
L'art ne fait que des vers: le coeur seul est poète.	CHéNIER André de	Elégies		330     coeur	1762-1794.	berkeley	1335
L'homme bon, du trésor de son coeur, tire la bonté ; et le méchant, du trésor de son coeur, la méchanceté.	Nouveau Testament	Evangiles, Luc, VI,35.		330     coeur		berkeley	4607
La dernière raison des rois, le boulet*. La dernière raison des peuples, le pavé 	HUGO Victor	Littérature et philosophie mêlées 		539     ironie sociale	1802-1885.  *Rappel de l"ultima ratio regum, devise que Louis XIV avait fait graver sur ses canons.	berkeley	3343
L'empirisme, dans la connaissance, n'est jamais certain.	HUME			360     bon sens	cité par A. EINSTEIN in Comment je vois le Monde.	berkeley	3351
Le plus important, c'est le plaisir des autres.	HUSSON Patrick		1994	330     coeur	Soprano. Jardinier pendant 20 ans.	berkeley	3352
Le mensonge et la crédulité s'accouplent et engendrent l'opinion.	VALERY Paul			215     mystifications		berkeley	5235
En France, où l'on brille par la parole, un homme qui se tait, socialement se tue. En Angleterre, où l'art de la conversation consiste à savoir se taire, un homme brille par son côté terne.	DANINOS Pierre	Les Carnets du major W. Marmaduke Thompson		539     ironie sociale	1913-.	berkeley	1751
Si vous n'aviez pas peur, vous n'auriez aucun mérite à faire ce que vous faites. S'il n'y avait pas de risques, il n'y aurait pas de sacrifice.	WEST Morris	La seconde victoire.	1972	440     courage		berkeley	5428
Le calembour est la fiente de l'esprit qui vole.	HUGO Victor	Les Misérables		370     esprit	1802-1885.	berkeley	3313
L'important n'est pas de devenir meilleur mais de devenir soi-même.	FORTHSYTHE		1995	421     initiation	Chorégraphe anglais contemporain	berkeley	2840
Nous rions et nous rirons, car le sérieux a toujours été l'ami des imposteurs.Ridiamo et rideremo, perchè la seriet à fu sempre amica degli impostori.	FOSCOLO Ugo	Accademia dei pitagorici		450     rire	1778-1827. (Italien)	BERKELEY	2841
L'angoisse est un mouvement occupationnel de l'esprit désoeuvré que seule la confiance de l'action peut écraser.	FAIRGAGNETR Oscar	Vitalités.	1993	430     paradoxal émotionnel		berkeley	2584
Parce que le millardaire n'a pas récolté sans peine, il s'imagine qu'il a semé 	JAURES Jean	L"Armée nouvelle		433     perversion	1859-1914.	berkeley	3430
Un peu d'amour pour s'alléger. Ca ne s'achète pas chez le pharmacien, cela va de soi, et d'ailleurs il n'y en a pas assez pour tout le monde, alors nous prescrivons à la place des sédatifs et des tranquillisants.	WEST Morris	Le Loup Rouge.	1971	420     capital affectif		berkeley	5402
Et le rapide oubli, second linceul des morts, A couvert le sentier qui menait vers ces bords.	LAMARTINE Alphonse de	Harmonies poétiques et religieuses.		540     mémoire		berkeley	4013
L'homme est Dieu par la pensée.	LAMARTINE Alphonse de	Les Méditations		546     éthique	1790-1869.	berkeley	4015
Les malheureux font de bonnes victimes.	FAIRGAGNETR Oscar	Vitalités.	1994	420     capital affectif		berkeley	2572
Le bonheur ?.., une certaine manière de travailler toujours à l'élargissement du champ des possibles.	FAIRGAGNETR Oscar	Vitalités.	1994	421     initiation		berkeley	2573
Je ne sais en quel temps c'était, je confonds toujours l'enfance et l'Eden  Comme je mêle la Mort et la Vie - un pont de douceur les relie.	SENGHOR Léopold Sédar	Ethiopiques		510     ironie	1906-.	berkeley	5035
Moins le Blanc est intelligent, plus le Noir lui paraît bête.	GIDE André	Voyage au Congo.	1927	360     bon sens	1869/1951	berkeley	2930
Envier le bonheur d'autrui, c'est folie ; on ne saurait pas s'en servir. Le bonheur ne se veut pas tout fait, mais sur mesure.	GIDE André	L"Immoraliste.		370     esprit		berkeley	2932
Il ne suffit pas d'avoir de l'esprit. Sans le caractère, les oeuvres d'art, quoi qu'on en fasse, seront toujours médiocres ; l'honnêteté est la première condition de l'esthétique.	FLAUBERT Gustave	L"amour de l"art.	1915	546     éthique	1821/1880, édition posthume	berkeley	2788
Pour ce qui est d'un corps, on ne s'emploie jamais assez à le rendre heureux.	GIROUD Françoise	Ce que je crois.		410     santé		berkeley	2966
Un homme qui consent à devenir esclave durant sa vie l'est naturellement durant sa mort.	OBALDIA René de	Les Richesses naturelles		442     démission	1918-.	berkeley	4615
Vos scrupules font voir trop de délicatesse.	LA FONTAINE Jean de	Fables		222     fourberie	1621-1695.	berkeley	3673
Un moment présent, même terrible, n'est pas toujours vainqueur du passé délicieux.	COLETTE Sidonie Gabrielle	De ma fenêtre		420     capital affectif	1873-1954.	berkeley	1549
La plupart du temps, c'est l'ordinaire qui me pique et me vivifie.	COLETTE Sidonie Gabrielle	Le Fanal bleu		430     paradoxal émotionnel	1873-1954.	berkeley	1551
La sagesse du moine de Rabelais est la vraie sagesse, pour son repos et pour celui des autres: faire son devoir tellement quellement*; toujours dire du bien de Monsieur le Prieur, et laisser aller le monde à sa fantaisie.	DIDEROT Denis	Le Neveu de Rameau 		441     sang-froid	1713-1784.  *Tant bien que mal.	berkeley	2110
Ma théorie se borne à utiliser les passions réprouvées telles que la nature les donne, et sans y rien changer.	FOURIER Charles	Théorie de l"unité universelle		110     entropie	1772-1837.	berkeley	2851
Ventre affamé n'a point d'oreilles.	LA FONTAINE Jean de	Fables, le Milan et le Rossignol		410     santé	1621-1695.	berkeley	3709
Le Ciel peut faire des dévots, le Prince fait des hypocrites.	MONTESQUIEU Charles de	Mes pensées		215     mystifications	1689-1755. (C. de Secondat, baron de La Brède et de M.)	berkeley	4405
Ce n'est pas les médecins qui nous manquent, mais la médecine.	MONTESQUIEU Charles de	Mes pensées		215     mystifications	1689-1755. (C. de Secondat, baron de La Brède et de M.)	berkeley	4406
C'est la faute qui fait la vertu.	DUHAMEL Georges	Tel qu"en lui-même		441     sang-froid	1884-1966.	berkeley	2212
L'une des plus grandes sagesses en l'art militaire, c'est de ne pousser son ennemi au désespoir.	MONTAIGNE Michel Eyquem de	Essais, I, 47		441     sang-froid	1533-1592.	berkeley	4360
La route qui monte et descend est une et la même.	Héraclite	Fragment, 60		441     sang-froid	fin du VIe-Ve s. av. J.-C.	berkeley	3124
L'art ne reproduit pas le visible, il rend visible.	KLEE Paul			393     création artistique		berkeley	3569
Tous ceux qui prennent le glaive périront par le glaive.	Evangiles	Evangile selon saint Matthieu, XXVI, 52		210     violence		berkeley	2401
Un esprit solide dans un corps humain, c'est la plus grande force dans la plus grande faiblesse.	Isocrate	A Démonicos, 40		510     ironie	436-338 av. J.-C.	berkeley	3397
C'est faire confiance à la vie, que se mesurer avec l'impossible.	ISTRATI Panaït	Pour avoir aimé la terre		422     confiance en soi	1884-1935.	berkeley	3400
On choisit son père plus souvent qu'on ne pense.	YOURCENAR Marguerite	Electre ou la Chute des masques, II, 4, Pylade à Oreste		430     paradoxal émotionnel	1903-1987. (Marguerite de Crayencour)	berkeley	5509
Le plaisir des disputes, c'est de faire la paix.	MUSSET Alfred de	On ne badine pas avec l"amour, III, 6, Perdican		433     perversion	1810-1857.	berkeley	4536
La moralité n'est bien souvent qu'une affaire d'éclairage et tu es le gardien de ton propre phare.	JOUHANDEAU Marcel	Eléments pour une éthique		546     éthique	1888-1979.	berkeley	3494
Elles ne sont vraiment pas belles  Les personnes qui ont raison.	CROS Charles	Le Collier de griffes, Ballade des mauvaises personnes		221     vanité	1842-1888.	berkeley	1727
Nous n'avouons jamais nos défauts que par vanité.	LA ROCHEFOUCAULD François de	Maximes.		221     vanité		berkeley	3796
Tout le monde ne peut pas être Shakespeare, mais on peut chercher, sans se diminuer, à être Marivaux.	DEBUSSY Claude	Monsieur Croche, antidilettante		221     vanité	1862-1918.	berkeley	1866
Parfois les militaires s'exagèrent l'impuissance relative de l'intelligence [...].	DE GAULLE Charles	1ere Leçon à l"Ecole supérieure de guerre.	1927	110     entropie		berkeley	1781
'mener les Français par les songes.'	CHATEAUBRIAND François-René de			391     commandement		berkeley	1299
Toutes les guerres ayant leur caractère propre et présentant dans leur évolution un grand nombre de caractères particuliers, chacune d'elle peut être considérée comme une mer inconnue du général en chef...	CLAUSEWITZ			211     guerre		berkeley	1468
La politique est la faculté intelligente, la guerre étant simplement son instrument.	CLAUSEWITZ	De la guerre.		211     guerre		berkeley	1469
Repose-toi du son dans le silence, et, du silence, daigne revenir au son. Seul, si tu sais être seul, déverse-toi parfois jusqu' à la foule.	SEGALEN Victor	Stèles		423     solitude	1878-1919.	berkeley	4994
Jouis, il n'est pas d'autre sagesse; fais jouir ton semblable, il n'est pas d'autre vertu.	SENANCOUR Etienne Pivert de	Sur les généralités actuelles		140     rapport à la cosmogonie	1770-1846.	berkeley	4999
L'homme propose et dispose. Il ne tient qu' à lui de s'appartenir tout entier.	BRETON André	Manifeste du surréalisme		221     vanité	1896-1966.	berkeley	845
Laissez faire aux boeufs de devant.	DU FAIL Noël	Propos rustiques		391     commandement	1520-1591.	berkeley	2177
Il n'y a de vraiment beau que ce qui ne peut servir à rien. Tout ce qui est utile est laid.	GAUTIER Théophile			510     ironie		berkeley	2920
'Je vivrai ici pendant la saison des pluies; l à pendant la saison froide; ailleurs pendant la canicule'; ainsi l'insensé fait en son coeur des projets pour s'assurer de ce qui peut les contrarier.	BOUDDHA	Le Dhammapada.		360     bon sens		berkeley	815
N'oublie pas que les gens ne viennent pas pour te voir jouer... Ils viennent pour jouer avec toi.	BOUQUET Michel			234     communication	 à Fabrice Lucchini qui le cite et le rapporte.	berkeley	817
Je ne cherche pas, je trouve.	PICASSO Pablo			390     création		berkeley	4700
Les marchés libres ne peuvent fonctionner valablement que s'ils sont constitués d'économies raisonnablement homogènes.	GOLDSMITH Jimmy	Le Piège.	1993	236     servitudes du pouvoir économique		berkeley	2990
Dieu sait que nous n'avons jamais à rougir de nos larmes, car elles sont comme une pluie sur la poussière aveuglante de la terre qui recouvre nos coeurs endurcis.	DICKENS Charles	Les Grandes Espérances.		330     coeur		berkeley	1977
Toute mémoire humaine est chargée de chagrins et de troubles.  All human memory is fraught with sorrow and trouble.	DICKENS Charles	A Christmas Carol, stave 2		420     capital affectif	1812-1870. (Anglais)	berkeley	1978
Les plus jolies choses du monde, Tom, ne sont que des ombres.  The loveliest things in life, Tom, are but shadows.	DICKENS Charles	Martin Chuzzlewit, 12		510     ironie	1812-1870. (Anglais)	berkeley	1979
Aucun homme n'a assez de mémoire pour réussir dans le mensonge.	LINCOLN Abraham			222     fourberie		berkeley	4140
En amour, le plaisir que j'éprouve est pour moi secondaire. Ma sensualité se satisfait fort bien du plaisir que je donne.	GUITRY Sacha			531     communication amoureuse		berkeley	3071
De toutes les tyrannies, la pire est celle qui peut ainsi compter ses sujets et voir de son siège les limites de son empire.	GUIZOT François	Essais sur l"histoire de France		239     servitudes du pouvoir autoritaire	1787-1874.	berkeley	3072
Dans la vie, mademoiselle Trevaunce, les douleurs les plus aiguës ne sont pas provoquées par les épines de rose mais par les pétales fripés, ne croyez-vous pas ? [...] - Les pétales de rose froissés, mademoiselle Trevaunce. Je vous avais prévenue. - Surmonterai-je ce que je viens de traverser ? - Tout passe. Partez vite.	HIGGINS Jack	Opération Cornouailles.	1990	420     capital affectif		berkeley	3189
Voyez-vous, même des situations les plus mauvaises, il peut sortir quelque chose de bon.	HIGGINS Jack	Opération Cornouailles	1990	432     expérience		berkeley	3190
On se remet de tout avec le temps. Mais cela, vous le découvrirez vous-même.	HIGGINS Jack	Opération Cornouailles.	1990	432     expérience		berkeley	3191
Les années passées lui avaient appris de manière assez dure à ne jamais croire aux coïncidences.	HIGGINS Jack	Opération Virgin	1993	432     expérience		berkeley	3192
Le malheur est que, parfois, des souhaits s'accomplissent, afin que se perpétue le supplice de l'espérance.	YOURCENAR Marguerite	Denier du rêve		433     perversion	1903-1987. (Marguerite de Crayencour)	berkeley	5512
Une chose n'est pas juste parce qu'elle est loi. Mais elle doit être loi parce qu'elle est juste.	MONTESQUIEU Charles de	Mes pensées		546     éthique	1689-1755. (C. de Secondat, baron de La Brède et de M.)	berkeley	4458
Ce n'est pas l'Allemagne qui se convertira au bolchevisme mais le bolchevisme qui deviendra une forme du national-socialisme... (...) ce qui nous lie aux bolcheviks est plus important que ce qui nous en sépare...(...) J'ai donné l'ordre que tout ancien communiste soit admis sans discussion dans le parti.	HITLER Adolph	Un carnaval d"E		110     entropie		berkeley	3195
Comme vous, je suis homme et mortel, et, comme vous, il peut m'arriver d'oublier.	MAHOMET			540     mémoire		berkeley	4174
Si tous les hommes étaient parfaitement contents, il n'y aurait plus d'activité dans le monde.	Holbach	Système de la nature		390     création	1723-1789. (Paul Henri Dietrich, baron d")	berkeley	3205
Agis au plus tôt pour éviter le mirage de raisonnements qui n'éclairent que les idées.	Houang Tsong-Hi	Traduction D. Tsan		440     courage	1610-1695. (Chinois)	berkeley	3269
Le symbolique est donc dispensé de s'inscrire dans un système réel. Il doit, en contrepartie, s'inscrire dans un processus de représentation. C'est l à, finalement le seul filtre dressé face aux combinaisons du symbolique : la nécéssité d'une conformité aux règles (nous y voil à) d'un système de représentation.	MORENO Roland	Théorie du Bordel Ambiant	1990	231     légitimité du pouvoir	Inventeur de la carte à mémoire, vendue cash.	berkeley	4499
Une vie qui n'est pas mise à l'épreuve ne vaut pas d'être vécue.	EPICTETE			440     courage	Philosophe grec de l"école stoïcienne.	berkeley	2363
De tous les biens que la sagesse nous procure pour le bonheur de notre vie, celui de l'amitié est de beaucoup le plus grand.	EPICURE	Maximes.		330     coeur		berkeley	2364
Je continue à penser qu'une prose où chaque mot vaut son pesant d'or est illisible.	TRIOLET Elsa			393     création artistique		berkeley	5223
Oh! Pourquoi donc le vent, sur moi, souffle-t-il si fort ? Est-ce parce que je suis l'enfant de personne ?	CASE P.-H.	L"enfant de personne.		420     capital affectif		berkeley	1046
Je t'adore ! Soleil ! ô toi dont la lumière, Pour bénir chaque front et mûrir chaque miel, Entrant dans chaque fleur et dans chaque chaumière, Se divise et demeure entière Ainsi que l'amour maternel !	ROSTAND Edmond	Chantecler.		140     rapport à la cosmogonie		berkeley	4862
On tue un homme, on est un assassin. On tue des millions d'hommes, on est un conquérant. On les tue tous, on est un dieu.	ROSTAND Jean	Pensées d"un biologiste.		215     mystifications		berkeley	4863
L'odieux de la mauvaise foi, c'est qu'elle finit par donner mauvaise conscience à la bonne foi.	ROSTAND Jean	Carnets d"un biologiste.		225     cynisme		berkeley	4865
Un baiser légal ne vaut jamais un baiser volé 	MAUPASSANT Guy de	Oeuvres posthumes, Confession d"une femme		433     perversion	1850-1893.	berkeley	4254
Au fond, en littérature, on arrive, comme dans l'armée, à l'ancienneté; le principal est de débuter.	HUYSMANS Joris-Karl	Lettre, 2 mars 1901		380     travail	1848-1907.	berkeley	3368
Chacun doit être l'aide-jardinier de sa propre âme ...	HUYSMANS Joris-Karl	En route		423     solitude	1848-1907.	berkeley	3369
Le démon ne peut rien sur la volonté, très peu sur l'intelligence, et tout sur l'imagination.	HUYSMANS Joris-Karl	L"Oblat		433     perversion	1848-1907.	berkeley	3370
Dieu ne nous remplit qu'autant que nous sommes vides.	MONTHERLANT Henry Millon de	Port-Royal, la soeur Angélique		215     mystifications	1896-1973.	berkeley	4464
La religion est la maladie honteuse de l'humanité. La politique en est le cancer.	MONTHERLANT Henry Millon de	Carnets		215     mystifications	1896-1973.	berkeley	4466
La politique est l'art de se servir des gens.	MONTHERLANT Henry Millon de	Carnets		215     mystifications	1896-1973.	berkeley	4467
(Il y a) des pertes triomphantes à l'envi des victoires.	MONTAIGNE Michel Eyquem de	Essais, I, 31		215     mystifications	1533-1592.	berkeley	4319
Aimer, c'est n'avoir plus droit au soleil de tout le monde. On a le sien. Savoir aimer, c'est ne pas aimer. Aimer, c'est ne pas savoir.	JOUHANDEAU Marcel	Algèbre des valeurs morales.		531     communication amoureuse		berkeley	3492
Le bien est dans le bon usage que l'on fait de n'importe quoi.	JOUHANDEAU Marcel	Eléments pour une éthique		546     éthique	1888-1979.	berkeley	3493
Les hommes croient ce qu'ils désirent.  Homines id quod volunt credunt.	CéSAR Jules	La Guerre civile, III, 18, 6		215     mystifications	101-44 av. J.-C. (Caius Julius Caesar)	berkeley	1095
Peu de philosophie mène à mépriser l'érudition ; beaucoup de philosophie mène à l'estimer.	CHAMFORT Nicolas-Sébastien de	Maximes et Pensées.		432     expérience	1740/1794. Ac. Française	berkeley	1126
Je suis venu, j'ai vu, j'ai vaincu.  	CéSAR Jules			215     mystifications	101-44 av. J.-C.   Veni, vidi, vici: c"est par ces mots célèbres que César décrivit au sénat la rapidité de la victoire qu"il venait de remporter à Zéla sur Pharnace, roi du Pont.	berkeley	1096
J'aimerais mieux être le premier dans ce village que le second à Rome.  	CéSAR Jules			221     vanité	101-44 av. J.-C.   C"est Plutarque qui, dans sa Vie de César, rapporte ce mot. Le héros, passant par une petite ville des Alpes peuplée de quelques misérables habitants, ses amis lui demandèrent, en manière de plaisanterie, s"il pensait qu"il y eût dans cette ville des rivalités pour exercer les charges et pour commander. "César, écrit Plutarque, leur répondit très sérieusement qu"il aimerait mieux être le premier parmi ces Barbares que le second dans Rome."	berkeley	1097
Si les Gaulois sont ardents et prompts à entreprendre une guerre, pour supporter les désastres leur esprit est mou et sans résistance.  Ut ad bella suscipienda Gallorum alacer ac promptus est animus, sic mollis ac minime resistens ad calamitates perferendas mens eorum est.	CéSAR Jules	La Guerre des Gaules, III, 19		240     débauche	101-44 av. J.-C. (Caius Julius Caesar)	berkeley	1098
Je suis morte déj à puisque je dois mourir.	NOAILLES Comtesse Anna de			110     entropie	1876/1933	berkeley	4600
L'immortalité, c'est une question de volonté.	TOPOR Roland		1990	321     volonté	Interview TV A2 "Envoyé Spécial" (04/08/90)	berkeley	5216
Jamais nous ne trouverons la vérité si nous nous contentons de ce qui est déj à trouvé.	TOURNAI Gilbert de			110     entropie		berkeley	5217
On sait qu'on aime quelqu'un quand on aime son visage plus que toute autre partie de son corps.	TOURNIER Michel			531     communication amoureuse		berkeley	5218
Je les grignote.  	JOFFRE Maréchal			441     sang-froid	1852-1931.   Réponse de Joffre à une question sur sa nouvelle stratégie, lorsque la guerre des tranchées, à la fin de 1914, remplaça la guerre de mouvement.	berkeley	3444
Leur sort à tous est sur le tranchant du rasoir.	Homère	L"Iliade, X, 173		539     ironie sociale	IXe ou VIIIe s. av. J.-C.	berkeley	3226
Chacun en a sa part et tous l'ont toute entière.	HUGO Victor			140     rapport à la cosmogonie		berkeley	3284
Une calomnie dans les journaux c'est de l'herbe dans un pré. Cela pousse tout seul.	HUGO Victor	Tas de pierres		210     violence	1802-1885.	berkeley	3285
Il est permis aux laides demoiselles de se masquer pour n'être connues, mais quant aux belles, je les condamne d'aller à visage découvert.	PASQUIER Etienne	Epître à Abel l"Angelier.		510     ironie		berkeley	4655
Je règne par l'étonnant pouvoir de l'absence.	SEGALEN Victor	Stèles		425     charisme	1878-1919.	berkeley	4992
Chaque fois qu'on produit un effet, on se donne un ennemi. Il faut rester médiocre pour être populaire.	WILDE Oscar	Le portrait de Dorian Gray.		120     grégarité		berkeley	5466
En perdant la beauté, petite ou grande, on perd tout. La jeunesse est le seul bien qui vaille.	WILDE Oscar	Le portrait de Dorian Gray.		130     liberté		berkeley	5467
Les tragédies des autres sont toujours d'une banalité désespérante.	WILDE Oscar	Le Portrait de Dorian Gray, 4		221     vanité	1854-1900. (Anglais)	berkeley	5468
Qu'est-ce qu'un cynique ? C'est un homme qui connaît le prix de tout et la valeur de rien.	WILDE Oscar	L"éventail De Lady Windermere.		221     vanité		berkeley	5469
Qu'est-ce qu'un cynique? C'est un homme qui connaît le prix de tout et la valeur de rien.	WILDE Oscar	L"Eventail de Lady Windermere		225     cynisme	1854-1900. (Anglais)	berkeley	5471
Les enfants commencent par aimer leurs parents ; quand ils sont grands, ils les jugent ; parfois, ils leur pardonnent.	WILDE Oscar	Le Portrait de Dorian Gray.		370     esprit		berkeley	5472
Tout portrait que l'on peint avec âme est un portrait, non du modèle mais de l'artiste.	WILDE Oscar	Le Portrait de Dorian Gray.		393     création artistique		berkeley	5473
Mon erreur fut de me confiner exclusivement aux ombres de ce qui me semblait le côté ensoleillé du jardin et de fuir l'autre côté à cause de ses ombres et de son obscurité.	WILDE Oscar	De Profundis.		440     courage		berkeley	5477
Les femmes se défendent en attaquant, et leurs attaques sont faites d'étranges et brusques capitulations.	WILDE Oscar	Le Portrait de Dorian Gray.		440     courage		berkeley	5478
Nul ne rencontre deux fois l'idéal. Combien peu le rencontrent même une fois.	WILDE Oscar	Le portait de Dorian Gray.		510     ironie		berkeley	5479
La Vie imite l'Art bien plus que l'Art n'imite la Vie.	WILDE Oscar	La Décadence du Mensonge	1889	510     ironie	1854/1900	berkeley	5480
La seule manière de se délivrer d'une tentation, c'est d'y céder.	WILDE Oscar	Le Portrait De Dorian Gray		510     ironie		berkeley	5482
L'amour est un sacrement qui doit être pris à genoux.	WILDE Oscar	De Profundis.		510     ironie		berkeley	5483
A l'homme qui veut faire de la vie un art, le cerveau tient lieu de coeur.	WILDE Oscar	Le Portrait de Dorian Gray.		510     ironie		berkeley	5484
Quand les dieux veulent nous punir, ils exaucent nos prières.  When the gods wish to punish us they answer our prayers.	WILDE Oscar	Un mari idéal		520     ironie de soi	1854-1900. (Anglais)	berkeley	5485
Les livres que le monde appelle immoraux sont ceux qui lui montrent sa propre ignominie.	WILDE Oscar	Le Portrait de Dorian Gray		539     ironie sociale	1854-1900. (Anglais)	berkeley	5486
Mon principe de base, c'est de ne jamais avoir d'ennemis. Sinon on commet des fautes.	WILLIAMS Frank	e jamais avo\\010ré†\\010rñÄ	1992	238     servitudes du pouvoir politique		berkeley	5487
Pousse-toi, renouvelle-toi, ne sois jamais satisfaite de ce que tu écris et cherche systématiquement l'inspiration ou la matière en dehors de ta vie.	WILSON Angus			440     courage	Rapporté par Rose Tremain dans un entretien à Lire d"octobre 94 (romancière anglaise et auteur de "Le royaume interdit").	berkeley	5488
Rien ne sert de courir; il faut partir à point.	LA FONTAINE Jean de	Fables, le Lièvre et la Tortue		441     sang-froid	1621-1695.	berkeley	3722
Tel qui vit d'espoir meurt à jeun.  He that lives upon hope will die fasting.	FRANKLIN Benjamin	Poor Richard"s Almanac		515     tragédie	1706-1790. (Américain)	berkeley	2878
Que chacun reste dans sa nature.	LAUTRéAMONT Comte de	Les Chants de Maldoror		360     bon sens	1846-1870. (Isidore Ducasse)	berkeley	4049
Amour, folie aimable; ambition, sottise sérieuse.	CHAMFORT Nicolas-Sébastien de	Maximes et pensées		510     ironie	1740/1794. Ac. Française	berkeley	1144
L'avenir c'est du passé en préparation.	DAC Pierre	L"Os A Moelle		320     intuition	André ISAAC dit Pierre Dac	berkeley	1736
Les occasions nous font connaître aux autres, et encore plus à nous-mêmes.	LA ROCHEFOUCAULD François de	Maximes		432     expérience	1613-1680.	berkeley	3878
Notre envie dure toujours plus longtemps que le bonheur de ceux que nous envions.	LA ROCHEFOUCAULD François de	Maximes.		433     perversion		berkeley	3880
Ceux qui pensent être les plus sages sont les plus fous de l'espèce à deux jambes et sans plumes dont nous avons l'honneur d'être.	FRéDéRIC II le Grand	Lettre à Voltaire, 12 mars 1759	1759	221     vanité	1712-1786., roi de Prusse	berkeley	2882
Le théâtre est dans la cité et la cité dans le théâtre.	GONZAGUE Vespasien de	a cité dans \\010rûp\\010r&#254;0´	1500	215     mystifications		berkeley	2998
Il s'était trop longtemps absenté du monde, il était temps de se remettre au travail de la vie.	WEST Morris	De main de Maître.	1988	423     solitude		berkeley	5415
La solitude est un bain de jouvence.	Dictons et Proverbes	Proverbe.		423     solitude		berkeley	2029
La contrainte te délivre et t'apporte la seule liberté qui compte.	SAINT-EXUPéRY Antoine de	Citadelle		130     liberté	1900-1944.	berkeley	4923
Ce qui ne peuvent se rappeler le passé sont condamnés à le répéter.	SAMTAYANA	Vie de raison.		540     mémoire		berkeley	4949
Ta foi, c'est toi. Protège la toujours et tu vivras.	FAIRGAGNETR Oscar	Vitalités.	1993	130     liberté		berkeley	2484
Car j'avais dormi seul trop longtemps. Un symptôme de mon malaise était que je ne me sentais ni prêt ni enclin à prendre de nouveaux engagements. Je n'avais alors à donner que ma semence, ni atta- chement, ni sympathie, rien de moi-même qui valût d'être partagé, pas même la curiosité d'une rencontre fortuite. Et voil à qu'en un seul jour tout était transformé.	WEST Morris	Le Loup Rouge.	1971	423     solitude		berkeley	5416
...'la sombre nuit de l'âme'. C'est un moment d'extrême obscurité, d'intense confusion, de désespoir presque, pendant lequel l'esprit semble être privé de toute aide humaine ou divine.	WEST Morris	Les bouffons de Dieu.	1981	423     solitude		berkeley	5417
Le renom d'habileté vient souvent de maladresses dont on a su tirer parti.	RéGNIER Henri de	"Donc..."		215     mystifications	1864-1936.	berkeley	4802
A moins, bien sûr, d'être un menteur exceptionnel,  la meilleure politique est toujours de dire la vérité.  It is always the best policy to speak the truth, unless of course you are an exceptionally good liar.	JEROME Jerome K.	In le journal The Idler, 1892		234     communication	1859-1927. (Anglais)	berkeley	3435
Le plus grand crime de l'homme c'est d'être né.	SCHOPENHAUER Arthur			510     ironie		berkeley	4980
Laissons le passé être le passé.	Homère	L"Iliade, XVI, 60		540     mémoire	IXe ou VIIIe s. av. J.-C.	berkeley	3227
Je hais la foule profane.  Odi profanum vulgus.	Horace	Odes, III, I, 1		120     grégarité	65-8 av. J.-C. (Quintus Horatius Flaccus)	berkeley	3232
Ce qui importe par-dessus tout dans une oeuvre d'art, c'est la profondeur vitale de laquelle elle a pu jaillir.  The supreme question about a work of art is out of how deep a life does it spring.	JOYCE James	Ulysses		393     création artistique	1882-1941. (Irlandais)	berkeley	3505
Une erreur ne devient un faute que lorsqu'on ne veut pas en démordre.	JUNGER Ernst	Sur les falaises de marbre.	1939	440     courage		berkeley	3508
Une erreur ne devient une faute que lorsqu'on ne veut pas en démordre.  Ein Irrtum wird dann erst zum Fehler, wenn man in ihm beharrt.	JÜNGER Ernst	Sur les falaises de marbre		221     vanité	1895-. (Allemand)	berkeley	3509
Le public ne peut pas juger par lui-même. Il a besoin d'être guidé, ce qui donne sa vraie dimension à la responsabilité du marchand.	KAHNWEILER DAniel-Heinrich	Lettre à Cooper, de la Mayor Gallery.	1936	550     grandeur		berkeley	3515
Je viens de saisir quelque chose que je n'avais pas compris auparavant. Staline était un pessimiste.	KAHNWEILER Daniel-Heinrich	que je n"av\\010Z£p\\010Z¨†		221     vanité	Conv. avec Picasso qui le pousse à s"incrire au PC.fin années 50	berkeley	3516
Il n'y a que le malheur qui soit vieux; il n'y a que la passion qui soit raisonnable.	LESPINASSE Julie de	Lettres, à M. de Guibert		440     courage	1732-1776.	berkeley	4116
La guerre est ... divine en elle-même, puisque c'est une loi du monde.	MAISTRE Joseph de	Les Soirées de Saint-Pétersbourg		215     mystifications	1753-1821.	berkeley	4181
Les déshérités ont besoin de beaucoup d'amour (...).	WEST Morris	L"Avocat du Diable.	1959	331     altruisme		berkeley	5389
[Pour Kahnweiler] un tableau dit non-figuratif est un non-sens. La peinture étant ce qui forme le monde extérieur des hommes, ce	KAHNWEILER Daniel-Heinrich	Lettre à Fernand Graindorge.	1946	393     création artistique		berkeley	3521
Ah! docteurs, j'ai bien failli vous perdre !	GUITRY Sacha			510     ironie	reprenant conscience après une très grave opération.	berkeley	3069
Mon jeu à moi, mon très cher ami, c'est d'esquiver tous les jours les échecs de la vie, ce qui n'est pas une mince affaire [...].	PEREZ-REVERTE Arturo	Le Tableau du Maître flamand	1990	432     expérience		berkeley	4672
Nombreux sont ceux qui d'espoir vivent dans la gaité nombreux sont les ânes qui resteront bâtés...	PEREZ-REVERTE Arturo	Le Maître d"escrime	1985	433     perversion		berkeley	4674
Pour qui n'aime plus personne, la vie est toujours plus loin.	JACCOTET Philippe			420     capital affectif		berkeley	3403
La mauvaise foi est l'âme de la discussion.	ROQUEPLAN Nestor	Nouvelles A La Main.		221     vanité		berkeley	4859
Je connais trop la jungle pour ête brutal. Un coeur plein de foi et le sang-froid pour seconde nature seront toujours de plus sûres garanties.	FAIRGAGNETR Oscar	Vitalités.	1992	440     courage	440     cour\\010vM\\020\\010vP\\020	berkeley	2601
La modestie, qui semble refuser les louanges, n'est qu'un désir d'en avoir de plus délicates.	LA ROCHEFOUCAULD François de	Maximes.		510     ironie		berkeley	3903
Il passe un vent de toute beauté sur l'Enfer ...	LA TOUR DU PIN Patrice de	Une somme de poésie		433     perversion	1911-1975.	berkeley	3950
Qui bien aime, aime impatiemment.	JODELLE Etienne	Didon se sacrifiant		531     communication amoureuse	1532-1573.	berkeley	3442
Le vulgaire ne comprend rien. En choisissant de ne pas agir, il choisit de ne rien comprendre. C'est son choix. On peut être  l'agent du destin ou sa victime, tout le monde a le choix.	CLANCY Tom	La somme de toutes les peurs. II.	1991	110     entropie		berkeley	1400
Les gens qui ont hérité de leur richesse - une richesse gagnée par des ancêtres pleins de suffisance dont on oublie pudiquement les manières rustiques - ne sont jamais à l'aise avec ceux qui ont fait leur fortune eux-mêmes, au lieu d'en hériter. Et ce qui vaut pour les individus vaut aussi pour les nations.	CLANCY Tom	La somme de toutes les peurs. I.	1991	120     grégarité		berkeley	1402
Je serai comme cet arbre ; je mourrai au sommet.	SWIFT Jonathan			321     volonté	cité par W. SCOTT dans "La Vie de Swift".	berkeley	5180
Il n'y a pas de grandeur où il n'y a pas de vérité.	LESSING G.-E.	Dramaturgie.		550     grandeur		berkeley	4118
..Nous dirions volontiers, comme îdipe à Colone : 'Accepte le destin, mais sache le maudire! [...] Voir jeter aux quatre vents du ciel les trésors d'ardeur, de valeur, de force que nous représentions ensemble [...] cela, c'est une blessure profonde. Mais c'est aussi une blessure féconde et que nous laisserons s'élargir car elle nous marque et nous détermine.	DE GAULLE Charles		1929	440     courage	allocution des "Obsèques" du 19e BCP que de Gaulle dirigea 2 ans avant que son démantellement ne soit décidé.	berkeley	1846
Il y a deux choses que l'expérience doit apprendre : la première, c'est qu'il faut beaucoup corriger ; la seconde, c'est qu'il ne faut pas trop corriger.	DELACROIX Eugène	Journal.		432     expérience		berkeley	1881
L'inertie des peuples est la meilleure forteresse des princes.	MACHIAVEL Nicolas			110     entropie		berkeley	4158
La vraie valeur d'un homme se détermine d'abord en examinant dans quelle mesure et dans quel sens il est parvenu à se libérer du Moi.  Der wahre Wert eines Menschen ist in erster Linie dadurch bestimmt, in welchem Grade und in welchem Sinne er zur Befreiung vom Ich gelangt ist.	EINSTEIN Albert	Comment je vois le monde		130     liberté	1879-1955. (Allemand, naturalisé Américain)	berkeley	2291
Prends un siège, Cinna, prends et sur toute chose observe exactement la loi que je t'impose.	CORNEILLE Pierre			421     initiation		berkeley	1658
M. Churchill me parut être de plein-pied avec la tâche la plus rude pourvu qu'elle fût grandiose... Il était, de par son caractère, fait pour agir, risquer, jouer le rôle, très carrément et sans scrupule... Je le trouvais bien assis à sa place de guide et de chef... Winston Churchill m'apparut, d'un bout à l'autre du drame, comme le grand champion d'une grande entreprise et le grand artiste d'une grande Histoire...	DE GAULLE Charles	Mémoires de guerre.		391     commandement		berkeley	1821
De notre naissance à notre mort, nous sommes un cortège d'autres qui sont reliés par un fil ténu.	COCTEAU Jean	Poésie critique		520     ironie de soi	1889-1963.	berkeley	1535
Il est d'un esprit économique de l'âme de réserver une part de désir jusqu' à la fin.	BOSCO Henri	L"Ane Culotte		431     désir	1888-1976.	berkeley	797
Les vertus sont frontières des vices.	LA ROCHEFOUCAULD François de	Réflexions diverses		546     éthique	1613-1680.	berkeley	3941
On peut feindre d'avoir du coeur, pas d'avoir de l'esprit.	MORAND Paul			370     esprit		berkeley	4493
Le monde est créé pour être recréé.	DUHAMEL Georges	Deux Hommes		390     création	1884-1966.	berkeley	2207
S'expliquer, c'est mentir.	PERRET Jacques	La Bête Mahousse.		221     vanité		berkeley	4683
Défie-toi du boeuf par devant, de la mule par derrière et du moine de tous les côtés.	CERVANTES SAAVEDRA Miguel de	Les Nouvelles exemplaires.		441     sang-froid	1547-1616. (Espagnol)	berkeley	1091
Il est des moments où il ne faut être prêt qu' à en baver.	FAIRGAGNETR Oscar	Vitalités.	1994	441     sang-froid		berkeley	2610
Le premier symptôme de l'amour vrai chez un jeune homme c'est la timidité, chez une jeune fille c'est la hardiesse.	HUGO Victor	Les Misérables		531     communication amoureuse	1802-1885.	berkeley	3342
La tentation la plus dangereuse: ne ressembler à rien.	CAMUS Albert	Carnets		221     vanité	1913-1960.	berkeley	990
La Nature devient la stylisation d'une vérité propre à son auteur.	DUFY Raoul	Carnet		545     épistémologie	1877-1953.	berkeley	2202
L'on devient ce que l'on connait.	Shankara et le védânta			421     initiation		berkeley	5068
En dehors de l'amour, un homme ne vit pas : il s'agite.	TOESCA Maurice	Un nouvel art d"aimer.		420     capital affectif		berkeley	5212
Dis ce qui est dessous, parle...	BRETON André	Les Etats généraux		440     courage	1896-1966.	berkeley	854
Quelques crimes toujours précèdent les grands crimes.	RACINE Jean	Phèdre.		110     entropie		berkeley	4766
Le bon écrivain est celui qui enterre un mot chaque jour.	FARGUE Léon-Paul	Sous la lampe		393     création artistique	1876-1947.	berkeley	2665
Le fou est celui qui a tout perdu sauf la raison.	CHESTERTON Gilbert Keith			433     perversion		berkeley	1349
Dans l'Histoire des temps la vie n'est qu'une ivresse, la Vérité c'est la Mort.	CéLINE L.-F.	Semmelweis		510     ironie	1894-1961. (Louis-Ferdinand Destouches)	berkeley	1083
Pour exécuter de grandes choses, il faut vivre comme si on ne devait jamais mourir.	CLAPIER Luc de	Réflexions et maximes.		440     courage	Marquis de Vauvenargues	berkeley	1435
Les hommes en général ressemblent aux chiens qui hurlent quand ils entendent de loin d'autres chiens hurler.	VOLTAIRE	Fragments Historiques.		120     grégarité		berkeley	5323
Le bourreau et le souverain forment couple.	CAILLOIS Roger	Instincts et société		232     servitudes du pouvoir	1913-1978	BERKELEY	956
Il ne se voit point d'âmes, ou fort rares, qui en vieillissant ne sentent l'aigre et le moisi.	MONTAIGNE Michel Eyquem de	Essais, III, 2		442     démission	1533-1592.	berkeley	4370
On gouverne les hommes avec la tête. On ne joue pas aux échecs avec un bon coeur.	CHAMFORT Nicolas-Sébastien de	Maximes et pensées		391     commandement	1740/1794. Ac. Française	berkeley	1119
La pire de toutes les mésalliances est celle du coeur.	CHAMFORT Nicolas-Sébastien de	Maximes et pensées		420     capital affectif	1740/1794. Ac. Française	berkeley	1120
L'imitation est la plus sincère des flatteries.	COLTON C.-C.	Lacon		120     grégarité		berkeley	1571
... de toute boue  faire un ciment, un marbre, un ciel, un nuage et une joie et une épave.	DESNOS Robert	Fortunes		390     création	1900-1945.	berkeley	1960
La loi est la même pour tous les misérables.  La legge è uguale per tutti gli straccioni.	DOSSI Carlo	Note Azzurre, 2023	23	539     ironie sociale	1849-1910. (Italien)	berkeley	2142
A beaucoup de gens il ne manque que de l'argent pour être honnêtes.  A molti non mancano che i denari per essere onesti.	DOSSI Carlo	Note Azzurre, 521		539     ironie sociale	1849-1910. (Italien)	berkeley	2144
Toutes nos passions reflètent les étoiles	HUGO Victor			140     rapport à la cosmogonie		berkeley	3283
Vous appelez le génie à votre secours, lorsque le danger est imminent, et dès qu'il se présente, vous vous effrayez de lui.	SCHILLER	Wallenstein.		510     ironie		berkeley	4970
Le poète se souvient de l'avenir.	COCTEAU Jean	Journal d"un inconnu		393     création artistique	1889-1963.	berkeley	1504
Mais sans argent l'honneur n'est qu'une maladie.	RACINE Jean	Phèdre.		230     pouvoir		berkeley	4774
Une lettre parfaite est une lettre qui ne contient qu'une idée.	REBOUX Paul	Le nouveau savoir-écrire.		390     création		berkeley	4800
Les fleurs ne sauraient être absentes.	RILKE Rainer Maria			460     plaisir		berkeley	4821
L'esprit militaire français répugne à reconnaitre à l'action de guerre le caractère essentiellement empirique qu'elle doit revêtir.  Il s'efforce sans cesse de construire une doctrine qui lui permette, à priori, d'orienter tout au moins l'action et d'en concevoir la forme, sans tenir compte des circontances qui devraient en être la base. Il tente perpétuellement de déduire la conception de constantes connues à l'avance, alors qu'il faut, pour chaque cas particulier, l'induire de faits contingents et variables.	DE GAULLE Charles		1925	211     guerre		berkeley	1792
L'homme le plus fort du monde est celui qui est le plus seul.	IBSEN Henrik	Un ennemi du peuple		423     solitude	1828-1906. (Norvégien)	berkeley	3379
Quand le combat commence en nous-même, nous allons vers la perfection.	BROWNING Robert			441     sang-froid		berkeley	881
[...] la sympathie, l'amitié, l'affection, l'amour ne sont que des réactions de défense, qui nous font désespérément rechercher un soutien, une protection contre nous-mêmes et contre les autres.	LENTERIC Bernard	La nuit des enfants rois.	1981	530     ironie amoureuse		berkeley	4112
Emerson Thwaites parlait, marchait, travaillait, vivait dans un calme absolu. Il avait la foi la plus ferme dans la mauvaise foi définitive de l'humanité en général, et néanmoins aimait l'humanité en général.	LENTERIC Bernard	La nuit des enfants rois.	1981	560     sagesse		berkeley	4113
Malheur aux gens qui n'ont jamais tord ; ils n'ont jamais raison.	LIGNE Prince Ch. de	Mes écarts.		221     vanité		berkeley	4130
Ce que les hommes vous pardonnent le moins, c'est le mal qu'ils ont dit de vous.	MAUROIS André	De La Conversation.		120     grégarité	Emile Herzog, dit André Maurois	berkeley	4261
Tous les hommes seraient des tyrans s'ils le pouvaient.  All men would be tyrants if they could.	DEFOE Daniel	The Kentish Petition, Addenda		433     perversion	1660-1731. (Anglais)	berkeley	1875
La jeunesse retarde toujours un peu.	MONTHERLANT Henry Millon de	Le Maître de Santiago, I, 4, Alvaro		421     initiation	1896-1973.	berkeley	4478
Un artiste n'est comptable que devant lui-même.	JOUVE Pierre Jean	En miroir		393     création artistique	1887-1976.	berkeley	3496
Il est facile de faire dire aux personnages ce qu'on pense d'eux.	JOUVET Louis	Témoignages sur le théâtre		393     création artistique	1887-1951.	berkeley	3501
Debout ! Comme un voleur déchainé Dresse-toi ! Méprise la molle couche et les rêves ! Vois, l à-bas, le Soleil brillant appelle le Travail !	JOVKIC Proka	Le livre du combat de la vie.		380     travail		berkeley	3504
De toutes les passions, la seule vraiment respectable me paraît être la gourmandise.	MAUPASSANT Guy de	Amoureux et primeurs, in le Gaulois		510     ironie	1850-1893.	berkeley	4256
Le rire est le meilleur désinfectant du foie.	CHAZAL Malcolm de	Sens plastique		450     rire	1902-1981.	berkeley	1331
- Qu'est-ce donc qu'on appelle amour chez les humains?  - Rien n'est plus doux, ma fille, ni amer tout ensemble.	Euripide	Hippolyte, 347-348		530     ironie amoureuse	480-406 av. J.-C.	berkeley	2395
La vie me semble trop courte pour la passer à entretenir des ressentiments ou ressasser des griefs.	BRONTE Charlotte			560     sagesse		berkeley	866
La bonne grâce est au corps ce que le bon-sens est à l'esprit.	LA ROCHEFOUCAULD François de	Maximes.		410     santé		berkeley	3863
Nous ne devons jamais ni trop admirer ni trop mépriser.	MIRABEAU Gabriel	Lettre au major de Mauvillon		441     sang-froid	1749-1791. (Gabriel Honoré Riqueti, comte de Mirabeau)	berkeley	4288
L'idolâtrie naît toujours d'un désir d'ordre.	WEST Morris	Les bouffons de Dieu.	1981	110     entropie		berkeley	5351
C'est avoir déj à tord que d'avoir trop raison.	ECOUCHARD-LEBRUN	A.M. de BRANCAS.		221     vanité		berkeley	2280
Le courage de Guillaumet, avant tout, est un effet de sa droiture.  Sa véritable qualité n'est point l à. sa grandeur, c'est de se sentir responsable. Responsable de lui, du courrier et des camarades qui espèrent. Il tient dans ses mains leur peine ou leur joie. Responsable de ce qui se batit de neuf, l à-bas, chez les vivants,  ce à quoi il doit participer. Responsable un peu du destin des hommes, dans la mesure de son travail. Il fait partie des êtres larges qui acceptent de couvrir de larges horizons de leur feuillage. Etre homme, c'est précisément être responsable. C'est connaitre la honte en face d'une misère qui ne semblait pas dépendre de soi. C'est être fier d'une victoire que les camarades ont remportée. C'est sentir, en posant sa pierre, qu'on contribue à batir le monde.	SAINT-EXUPERY Antoine de	Terre des Hommes.	1939	550     grandeur		berkeley	4921
Qui veut faire l'ange fait la bête.	PASCAL Blaise	Pensées.		221     vanité	1623/1662. Recueil posthume établi d"après des brouillons.	berkeley	4639
Quand la pensée se tait, les révolutions parlent.  Cuando el pensamiento calla, las revoluciones hablan.	CASTELAR Y RIPOLL Emilio	En el discurso defendiendo al periodico, La Soberanía nacional		240     débauche	1832-1899. (Espagnol)	berkeley	1051
La fin couronne l'oeuvre.	Dictons et proverbes	Proverbe latin		546     éthique		berkeley	2074
En face d'une oeuvre d'art, il importe de se taire comme en présence d'un prince: attendre de savoir s'il faut parler et ce qu'il faut dire, et ne jamais prendre la parole le premier. Faute de quoi, on risquerait fort de n'entendre que sa propre voix.	SCHOPENHAUER Arthur			393     création artistique	1788-1860. (Allemand)  Vor ein Bild hat jeder sich hinzustellen wie vor einen Fürsten, abwartend ob und was es zu ihm sprechen werde; und, wie jenen, auch dieses nicht selbst anzureden: denn da würde er nur sich selbst 	berkeley	4972
Nous querellons les malheureux pour nous dispenser de les plaindre.	VAUVENARGUES Marquis de	Pensées et Maximes.		221     vanité	CLAPIER Luc de	berkeley	5258
Les jeunes consciences ont le plumage raide et le vol bruyant.	MICHAUX Henri			421     initiation		berkeley	4278
Chien chez soi se croit le roi.	KIPLING Rudyard	Le livre de la jungle	1894	221     vanité		berkeley	3551
Les serments les plus forts se consument au feu de la passion comme une paille légère.	SHAKESPEARE William	La Tempête.		530     ironie amoureuse		berkeley	5065
A la façon dont va le monde, être honnête, c'est être un homme marqué entre dix mille.	SHAKESPEARE William	Hamlet.		546     éthique		berkeley	5067
L'esclavage humain a atteint son point culminant à notre époque sous forme de travail librement salarié.	SHAW G.-B.	Bréviaire du Révolutionnaire.		130     liberté		berkeley	5069
Beaucoup de gens ne sont jamais jeunes ; quelques personnes ne sont jamais vieilles.	SHAW G.-B.			130     liberté		berkeley	5070
On peut reconnaître de quatre manières que le flatteur est un faux ami : il approuve lorsque vous agissez mal, il approuve lorsque vous agissez bien, il proclame vos louanges devant vous et vous dénigre derrière vous.	Sigâlovâda-sutta			222     fourberie		berkeley	5080
Un secret a toujours la forme d'une oreille.	COCTEAU Jean	Le Rappel à l"ordre		510     ironie	1889-1963.	berkeley	1518
De la musique avant toute chose.	VERLAINE Paul	Jadis et Naguère.		460     plaisir		berkeley	5283
C'est vous, le nègre? Eh bien, continuez.	MAC-MAHON Comte de			225     cynisme	1808-1893.   A l"époque de Mac-Mahon, dans l"argot de l"école militaire de Saint-Cyr, le major de promotion s"appelait, dit-on, le "nègre". La phrase du maréchal, prononcée au cours d"une visite à cette école, s"expliquerait donc tout naturellement. Mais ce "nègre" se trouva être un mulâtre... Les adversaires politiques de Mac-Mahon ne manquèrent pas d"interpréter avec malignité sa phrase malheureuse.	berkeley	4156
Pour s'assurer la victoire, les troupes doivent avoir confiance en elles comme en ceux qui les commandent.	MACHIAVEL Nicolas	Discours. XXXIII.	1531	440     courage		berkeley	4161
A l'oeuvre, on connaît l'artisan.	LA FONTAINE Jean de	Fables, le Frelon et les Mouches à miel		380     travail	1621-1695.	berkeley	3705
Dans le conflit présent comme dans ceux qui l'ont précédé, être inerte, c'est être battu.	DE GAULLE Charles	L"Avenir des forces mécanisées		442     démission	1890-1970.	berkeley	1850
Le bon sens est la chose du monde la mieux partagée : car chacun pense en être si bien pourvu, que ceux mêmes qui sont les plus difficiles à contenter en toute autre chose, n'ont point coutume d'en désirer plus qu'il n'en ont. En quoi il n'est pas vraisemblable que tous se trompent ; mais plutôt cela témoigne que la puissance de bien juger, et distinguer le vrai d'avec le faux, qui est proprement ce qu'on nomme le bon-sens ou la raison, est naturellement égale en tous les hommes ; et ainsi que la diversité de nos opinions ne vient pas de ce que les uns sont plus raisonnables que les autres, mais seulement de ce que nous conduisons nos pensées par diverses voies, et ne considérons pas les mêmes choses. Car ce n'est pas assez d'avoir l'esprit bon, mais le principal est de l'appliquer bien.	DESCARTES René	Discours de la méthode pour bien conduire sa raison	1637	365     discernement	(1596/1650)	berkeley	1925
La maxime que j'ai le plus observée en toute la conduite de ma vie a été de suivre seulement le grand chemin, et de croire que la principale finesse est de ne vouloir point du tout user de finesse.	DESCARTES René	Correspondance, à Elisabeth, janvier 1646		370     esprit	1596-1650.	berkeley	1927
La lecture, une porte ouverte sur un monde enchanté.	MAURIAC François	Le Figaro littéraire		370     esprit		berkeley	4259
Si contraignante soit l'essence, l'existence, chez de Gaulle, c'est d'abord l'effort constant de la volonté et de l'imagination. Les choses étant ce qu'elles sont, les hommes sont ce qu'ils font. Lui surtout.	LACOUTURE Jean	De Gaulle.		440     courage		berkeley	3977
Dans le doute, il faut parier sur la bonne foi des gens.	LACOUTURE Jean	De Gaulle.	1984	441     sang-froid		berkeley	3981
Il n'est pas de grand homme qui, circonvenu, contesté, harcelé par les moins grands, ne fasse connaître de saison en saison sa lassitude ou son dégout.	LACOUTURE Jean			442     démission		berkeley	3982
Nous ne discutons pas la famille. Quand la famille se défait, la maison tombe en ruines.	SALAZAR Oliveira	Principes d"Action.		420     capital affectif		berkeley	4944
Votre âme est un paysage choisi...	VERLAINE Paul			321     volonté	extrait d"un quatrain cité par M. WEST dans Les bouffons de Dieu	berkeley	5282
La technique atteindra un tel niveau de perfection que l'homme pourra se passer de lui-même.	LEC Stanislas	Pensées Echevelées.		510     ironie		berkeley	4090
Le voyage n'est nécessaire qu'aux imaginations courtes.	COLETTE Sidonie Gabrielle	Belles Saisons		350     imagination	1873-1954.	berkeley	1545
Le sentiment de révolte devant la passive acceptation jamais ne le quittera. Jusqu'au dernier jour, jusqu' à sa dernière pensée, il souf- frira de se sentir toujours attaqué, injurié, parcequ' à l'inverse des autres il ne se plie pas aux évènements en les baptisant 'destin'.	LEFRANC Pierre	Avec De Gaulle	1979	423     solitude	2e édition en 1990	berkeley	4096
C'est à la guerre que j'ai mis les pieds sur le sol... la guerre, je l'ai touchée... c'est l à que j'ai été formé...	LEGER Fernand			421     initiation		berkeley	4097
Grands yeux dans ce visage, Qui vous a placés l à ? De quel vaisseau sans mâts Etes-vous l'équipage ?	SUPERVIELLE Jules	Le Forçat innocent.		420     capital affectif		berkeley	5172
Le malheur, comme la piété peut devenir une habitude.	GREENE Graham	La Puissance et la Gloire.		110     entropie		berkeley	3008
Il faut se retirer, pour penser, de la foule Et s'y confondre pour agir.	LAMARTINE Alphonse de			440     courage		berkeley	4004
L'égalité, la seule égalité en ce monde, l'égalité devant l'asticot.	FABRE Jean Henri	Souvenirs entomologiques		510     ironie	1823-1915.	berkeley	2443
C'est à mon sens un grand avantage que d'obtenir jeune un commandement.	FARRAGUT David G.	Journal de l"auteur	1819	391     commandement		berkeley	2672
Les catholiques envisagent l'enfer sans en mourir, c'est plus confortable que rien.	FAUCONNIER Henri	Malaisie		221     vanité	1879-1973.	berkeley	2673
Comprendre c'est compliquer. C'est enrichir en profondeur. C'est élargir de proche en proche. C'est mêler à la vie.	FEBVRE Lucien	Combats pour l"histoire		421     initiation	1878-1956.	berkeley	2677
Antisthène disait que la science la plus difficile était de désapprendre le mal.	FENELON	Antisthène.		421     initiation		berkeley	2681
La parole humaine est comme un chaudron fêlé où nous battons des mélodies à faire danser les ours, quand on voudrait attendrir les étoiles.	FLAUBERT Gustave	Madame Bovary		234     communication	1821-1880.	berkeley	2723
La guerre engendre toutes choses.	Dicton militaire	Dictons et proverbes.		240     débauche		berkeley	1982
Il est plus honorable d'esquiver la platitude en étant clair que de jouer le génie en étant obscur.	ROSTAND Jean	De la vanité.		440     courage		berkeley	4871
La vraie condition de l'homme, c'est de penser avec ses mains.	ROUGEMONT Denis de	Penser avec les mains		380     travail	1906-1985.	berkeley	4876
La loi du monde est que l'homme lutte contre le monde, en assumant le risque de sa propre perte.	ROUGEMONT Denis de	Penser avec les mains		440     courage	1906-1985.	berkeley	4877
L'amour est le comble de l'esprit.	ROUGEMONT Denis de	Penser avec les mains		531     communication amoureuse	1906-1985.	berkeley	4879
Représenter sur une toile à deux dimensions des solides qui en ont trois. [le Cubisme]	CEZANNE			393     création artistique	cité in "Gris, sa vie..." de DHK. Gallimard 1946.	berkeley	1100
Je pardonne aisément, par la raison que je ne sais pas haïr. Il me semble que la haine est douloureuse.	MONTESQUIEU Charles de	Mes pensées		520     ironie de soi	1689-1755. (C. de Secondat, baron de La Brède et de M.)	berkeley	4449
Nommer est toujours appeler, c'est déj à ordonner.	CAILLOIS Roger	L"Homme et le sacré		380     travail	1913-1978.	berkeley	961
Si vous connaissez la vie, donnez moi son adresse.	Dictons et proverbes			510     ironie		berkeley	2067
Je respecte toutes les croyances et j'exige la discrétion sur les miennes. Si vous me faites confiance, je ne vous mentirai jamais. Si vous me mentez, je le comprendrai, mais je ne vous ferai plus jamais confiance.	WEST Morris	Les bouffons de Dieu.	1981	234     communication		berkeley	5373
Il comprit que rien ne pouvait plus l'émouvoir ni le torturer : toutes les chaines de la volonté qui l'attachaient au monde n'avaient plus aucune prise sur lui ; il avait rompu ces liens. Le sourire aux lèvres, il contemplait paisiblement la farce de ce monde qui jadis avait pu l'attendrir ou l'attrister, mais qui à cette heure le laissait indifférent.	COMBESCOT Pierre	Les Chevaliers du Crépuscule.		110     entropie		berkeley	1573
Tout vient à point à qui sait attendre...	Dictons et Proverbes			441     sang-froid		berkeley	2042
Ceux qui manquent de probité dans les plaisirs n'en ont qu'une feinte dans les affaires.	VAUVENARGUES Marquis de	Réflexions et Maximes.		222     fourberie	CLAPIER Luc de	berkeley	5261
La licence étend toutes les vertus et tous les vices.	VAUVENARGUES Marquis de	Pensées et Maximes.		240     débauche	CLAPIER Luc de	berkeley	5262
Il faut aujourd'hui de l'or, beaucoup d'or, pour jouir du droit de parler; nous ne sommes pas assez riche. Silence au pauvre.	LAMENNAIS Félicité Robert de			221     vanité	1782-1854.	berkeley	4022
La machine conduit l'homme à se spécialiser dans l'humain.	FOURASTIé Jean	Le Grand Espoir du XXe siècle		380     travail	1907-1990.	berkeley	2849
On ne choisit pas ce qu'on voudrait.	DUHAMEL Georges	Les Sept Dernières Plaies		520     ironie de soi	1884-1966.	berkeley	2216
Sa croupe se recourbe en replis tortueux.	RACINE Jean	Phèdre.		222     fourberie	e	berkeley	4771
Les déplaisirs talonnent toujours les contentements.	HENRI IV	Lettres		441     sang-froid	1553-1610.	berkeley	3118
Une extrême justice est souvent une injure.	RACINE Jean	La Thébaïde.		215     mystifications		berkeley	4769
Qui ne se montre point ami des vices devient ennemi des hommes. Chi non si mostra amico dei vizi, diventa nemico degli uomini.	L"ARéTIN Pierre	L"Ipocrito.		120     grégarité	1492-1556 (Italien) (Pietro Aretino)	berkeley	3579
L'excès est une preuve d'idéalité: aller au-del à du besoin.	FLAUBERT Gustave	Carnets		433     perversion	1821-1880.	berkeley	2765
Si un aveugle guide un aveugle, tous les deux tomberont dans un trou.	Evangiles	Evangile selon saint Matthieu, XV, 14		214     guerre du savoir		berkeley	2402
Dans les individus de l'espèce humaine, ainsi que dans les sociétés politiques, la progression des besoins est une chose nécessaire; elle est fondée sur l'essence même de l'homme, il faut que les besoins naturels, une fois satisfaits, soient remplacés par des besoins que nous nommons imaginaires, ou besoins d'opinion: ceux-ci deviennent aussi nécessaires à notre bonheur que les premiers.	Holbach	Système de la nature		431     désir	1723-1789. (Paul Henri Dietrich, baron d")	berkeley	3206
[...] Mais la clarté du jour et la gravité de la nuit, mais la terre et le ciel sont réunis pour moi en ce seul être ! Voil à comment j'aime !	HÖLDERLIN Friedrich	ich		140     rapport à la cosmogonie		berkeley	3208
Toute rencontre restra à jamais le fruit d'un miracle.	FAIRGAGNETR Oscar	Vitalités.	1995	234     communication		berkeley	2515
L'oeuvre est une expression de ce qu'est l'homme, de ce qu'il sent, de ce en quoi il croit. Si elle se perpétue et si elle se développe, ce n'est pas tant à cause de l'homme qui l'a entreprise, mais parce que d'autres hommes pensent et sentent de la même façon.	WEST Morris	L"Avocat du Diable.	1959	393     création artistique		berkeley	5398
Comme tout artiste, elle réarrangeait la réalité - dans son esprit, sur la toile. Elle changeait l'éclairage, la mise en valeur, la  composition, l'ordre des évènements et leur tonalité émotionnelle.	WEST Morris	De main d Maître.	1988	393     création artistique		berkeley	5399
Notre bonheur n'est qu'un malheur plus ou moins consolé.  	DUCIS Jean-François	Cité par Sainte-Beuve: Consolations I.		510     ironie	1733-1816.	berkeley	2193
Nous ne sommes hommes et ne nous tenons les uns aux autres que par la parole.	MONTAIGNE Michel Eyquem de	Essais, I, 9		440     courage	1533-1592.	berkeley	4359
Dans sa première passion, la femme aime son amant,  et dans toutes les autres, tout ce qu'elle aime est l'amour.  In her first passion woman loves her lover.  In all the others, all she loves is love.	BYRON George Gordon lord	Don Juan, III, 3		530     ironie amoureuse	1788-1824. (Anglais)	berkeley	946
Notre Ennemi, c'est notre Maître: Je vous le dis en bon françois.	LA FONTAINE Jean de	Fables, le Vieillard et l"Ane		130     liberté	1621-1695.	berkeley	3650
Il n'y a rien de plus inutile que ces amitiés héroïques qui demandent des circonstances pour se prouver.	FLAUBERT Gustave	L"amour de l"art.	1915	530     ironie amoureuse	(1821/1880) édition posthume	berkeley	2785
De l'autre côté des tombeaux, Les yeux qu'on ferme Voient encore...	PRUDHOMME Sully			510     ironie		berkeley	4742
Un peuple qui veut vivre doit donc non seulement s'assurer de la part des autres des garanties de secours (assistance mutuelle) mais encore organiser sa propre force, de manière à pouvoir réagir dans les mêmes conditions que l'agresseur agira.	DE GAULLE Charles	lettre à Jean Auburtin évoquant la réoccupation rhénane d"Hitler	1936	238     servitudes du pouvoir politique		berkeley	1807
Les meilleurs médecins sont : le Dr Diète, le Dr Tranquille et le Dr Joyeux.	SWIFT Jonathan	Conversation polie.		410     santé		berkeley	5181
Evolution: Prométhée, de nos jours, serait un député de l'opposition.	CIORAN Emile-Michel	Syllogismes de l"amertume		215     mystifications	1911-.	berkeley	1385
Rien ne dessèche tant un esprit que sa répugnance à concevoir des idées obscures.	CIORAN Emile-Michel	Syllogismes de l"amertume		221     vanité	1911-.	berkeley	1386
Le Sage dit: Etant sage, je ne me suis jamais occupé des hommes.	SEGALEN Victor	Stèles		433     perversion	1878-1919.	berkeley	4995
La matière brute sensible, l'unique source de notre connaissance, nous modifie, nous fait croire, espérer.	EINSTEIN Albert	Comment je vois le Monde	1934	340     sensibilité	réédition corrigée en 1952 et 1978.	berkeley	2307
L'imagination est plus importante que le savoir.  Imagination is more important than knowledge.	EINSTEIN Albert	On Science		350     imagination	1879-1955. (Allemand, naturalisé Américain)	berkeley	2308
Les démagogues font d'autant mieux leurs affaires qu'ils ont jeté leur pays dans la discorde.	Esope	Fables, 27, le Pêcheur qui bat l"eau		215     mystifications	VIe s. av. J.-C.	berkeley	2376
Quiconque est loup agisse en loup;  C'est le plus certain de beaucoup.	LA FONTAINE Jean de	Fables, le Loup devenu berger		110     entropie	1621-1695.	berkeley	3641
Qui craint est esclave.	SENEQUE	Lettres à Lucilius.		120     grégarité		berkeley	5002
La fraternité se ressemble.	JODELLE Etienne	Eugène		234     communication	1532-1573.	berkeley	3440
Prenez, prenez, tout cela ne me coûte rien, c'est l'argent de l'Etat.	SADE Marquis de	Juliette		539     ironie sociale	1740-1814.	berkeley	4910
Le coeur a ses prisons que l'intelligence n'ouvre pas.	JOUHANDEAU Marcel	De la grandeur		420     capital affectif	1888-1979.	berkeley	3477
Le mystère est une position trop favorable pour qu'un esprit bien élevé s'y maintienne.	COCTEAU Jean	Le Rappel à l"ordre		520     ironie de soi	1889-1963.	berkeley	1532
Les gouvernements ont un nombre infini de circuits, tous définis par leurs règles de fonctionnement, comprises par les joueurs.	CLANCY Tom	Danger Immédiat	1989	238     servitudes du pouvoir politique		berkeley	1416
Sans doute un homme meurt-il lorsqu'il est prêt à mourir, et il est prêt lorsqu'il est trop malheureux.	GARY Romain			420     capital affectif		berkeley	2918
Ce sont les regardeurs qui font les tableaux.	DUCHAMP Marcel	Marchand du sel		234     communication	1887-1968.	berkeley	2189
Car la culture ne s'hérite pas, elle se conquiert.	MALRAUX André			421     initiation		berkeley	4206
Mon orgueil s'est coloré avec le pourpre de ma honte.	GENET Jean	Journal du Voleur.		221     vanité		berkeley	2922
La reconnaissance a la mémoire courte.	CONSTANT Benjamin	De la doctrine politique qui peut réunir les partis en France		221     vanité	1767-1830. (Henri-B. de Rebecque)	berkeley	1619
Nos émotions sont dans nos mots comme des oiseaux empaillés.	MONTHERLANT Henry Millon de	Carnets		234     communication	1896-1973.	berkeley	4472
Chacun des grains de cette pierre, chaque éclat minéral de cette montagne pleine de nuit, à lui seul, forme un monde. La lutte elle-même vers les sommets suffit à remplir un coeur d'homme. Il faut imaginer Sisyphe heureux.	CAMUS Albert	Le mythe de Sisyphe.	1942	550     grandeur		berkeley	1028
Un artiste n'est comptable que devant lui-même.	JOUVE Pierre Jean	En Miroir.		550     grandeur		berkeley	3497
Celui qui aime beaucoup ne pardonne pas facilement.	CLAUDEL Paul	L"Otage.		330     coeur		berkeley	1444
Un homme compétent est un homme qui se trompe selon les règles.	VALERY Paul	Mauvaises pensées et autres.		433     perversion		berkeley	5241
Ce que dit une femme à l'amant qui brûle pour elle, il faut l'inscrire dans le vent et sur l'onde rapide.  ... Mulier cupido quod dicit amanti,  In vento et rapida scribere oportet aqua.	Catulle	Poésies, 70		530     ironie amoureuse	v. 87-v.. 54. av. J.-C. (Caius Valerius Catullus)	berkeley	1059
Nul n'est méchant volontairement.	PLATON	Gorgias.		210     violence	paradoxe socratique	berkeley	4713
Lorsque tu affirmes, tu interroges encore.	BLANCHOT Maurice	L"Attente, l"Oubli		520     ironie de soi	1907-.	berkeley	773
Rarement nous pouvons découvrir un homme qui dise avoir vécu heureux et qui, son temps fini, quitte la vie content comme un convive rassasié.  Inde fit, ut raro, qui se vixisse beatum  Dicat et exacto contentus tempore vita  Cedat uti conviva satur, reperire queamus.	Horace	Satires, I, 1, 117	17	420     capital affectif	65-8 av. J.-C. (Quintus Horatius Flaccus)	berkeley	3246
Demain, puis demain, puis demain, rampe à petits pas, de jour en jour, jusqu' à la dernière syllabe du souvenir ; et tous nos hiers ont éclairé pour des fous le chemin vers la poussière et la mort. Eteins-toi, éteins-toi, court flambeau ! La vie n'est qu'une ombre qui passe, un pauvre histrion qui se pavane et s'échauffe une heure sur la scène et puis qu'on n'entends plus... une histoire contée par un idiot, pleine de fureur et de bruit et qui ne veut rien dire.	SHAKESPEARE William	Macbeth.	1606	110     entropie		berkeley	5041
Les vertus sont sujettes à des vices particuliers qui les rendent inutiles.	JOUHANDEAU Marcel	Algèbre des valeurs morales.		510     ironie		berkeley	3482
Les poltrons meurent plusieurs fois avant leur mort ; Le vaillant ne goûte jamais à la mort qu'une fois.	SHAKESPEARE William	Jules César.		440     courage		berkeley	5056
L'égo masculin est une chose fragile.	CLANCY Tom	La somme de toutes les peurs. II.	1991	520     ironie de soi		berkeley	1431
Ne jugez pas le grain de poivre d'après sa petite taille, goutez-le et vous sentirez comme il pique.	Dictons et proverbes	Proverbe arabe.		110     entropie		berkeley	2059
Si vous menez un âne loin, et même à la Mecque,il n'en reviendra jamais qu'un âne.	Dictons et proverbes	Proverbe turc.		510     ironie		berkeley	2066
Si un homme pouvait penser complètement la mort, il mourrait à cet instant-l à.	ROUGEMONT Denis de	Entretien avec Pierre Lhoste		442     démission	1906-1985. Les Nouvelles littéraires, 24 décembre 1970	berkeley	4878
Après nous, le déluge !	POMPADOUR Marquise de			221     vanité	 à Louis XV.	berkeley	4726
Les sots admirent tout dans un auteur estimé. Je ne lis que pour moi ; je n'aime que ce qui est à mon usage.	VOLTAIRE	Candide.		234     communication		berkeley	5326
Les Français ne parlent presque jamais de leurs femmes: c'est qu'ils ont peur d'en parler devant des gens qui les connaissent mieux qu'eux.	MONTESQUIEU Charles de	Lettres persanes		530     ironie amoureuse	1689-1755. (C. de Secondat, baron de La Brède et de M.)	berkeley	4451
J'ai toujours vu que pour réussir dans le monde, il fallait avoir l'air fou et être sage.	MONTESQUIEU Charles de	Mes pensées		539     ironie sociale	1689-1755. (C. de Secondat, baron de La Brède et de M.)	berkeley	4452
Mais les ouvrages les plus courts  Sont toujours les meilleurs ...	LA FONTAINE Jean de	Fables, les Lapins		370     esprit	1621-1695.	berkeley	3701
Le vice et la vertu sont comme la vie et la mort, ou comme l'esprit et la matière: des choses qui ne sauraient exister sans être définies par leur contraire.  Virtue and vice are like life and death or mind and matter: things which cannot exist without being qualified by their opposite.	BUTLER Samuel	The Way of All Flesh		546     éthique	1835-1902. (Anglais)	berkeley	931
Toutes ls familles heureuses se ressemblent ; chaque famille heureuse est malheureuse à sa manière.	TOLSTOI Léon	Anna Karénine.		420     capital affectif		berkeley	5213
Honni soit qui mal y pense !	EDOUARD III	Devise de l"Ordre de la Jarretière.		433     perversion		berkeley	2282
Tout homme qui, à quarante ans, n'est pas misanthrope, n'a jamais aimé les hommes.	CHAMFORT Nicolas-Sébastien de	Journal de Paris		330     coeur	1740/1794. Ac. Française	berkeley	1117
Ne change pas. Creuse au fond de toi, mais ne change pas.	MANSET G.			422     confiance en soi		berkeley	4212
La passion la plus forte du vingtième siècle : la servitude.	CAMUS Albert	Carnets		240     débauche	1913-1960.	berkeley	994
Il y a dans les hommes plus de choses à admirer que de choses à mépriser.	CAMUS Albert	La Peste		312     foi	1913-1960.	berkeley	995
Apprendre, c'est se retrouver.	CHAZAL Malcolm de	Sens plastique		421     initiation	1902-1981.	berkeley	1327
On désespère des autres pour ne pas trop espérer de soi.	PETIT Henri	Les Justes Solitudes.		221     vanité	1900/1978	berkeley	4686
Ainsi que tous les gens sérieux, je ne crois pas à la vérité historique, mais je crois à la vérité légendaire.	DUHAMEL Georges	Remarques sur les Mémoires imaginaires		540     mémoire	1884-1966.	berkeley	2222
Il faut tenir les promesses que l'on n'a pas faites.	DUHAMEL Georges	Défense des lettres		546     éthique	1884-1966.	berkeley	2223
Quand vous vous regardez dans une glace, vous n'avez pas envie de l'essuyer ?	Dictons et proverbes			510     ironie		berkeley	2068
Nous louons les gens à proportion de l'estime qu'ils ont pour nous.	MONTESQUIEU Charles de	Mes pensées		221     vanité	1689-1755. (C. de Secondat, baron de La Brède et de M.)	berkeley	4420
Laissons les fous, tenons-nous-en aux sages.  Laissun les fols, as sages nus tenuns!	Chanson de Roland			441     sang-froid	v. 1100 	berkeley	1166
Dans le centre caché d'une clarté profonde,  Dieu repose en lui-même ...	CHAPELAIN Jean	La Pucelle		140     rapport à la cosmogonie	1595-1674.	berkeley	1167
Qui n'aime personne se déteste : l'amour de soi passe par autrui.	CHAPELAN Maurice			330     coeur		berkeley	1168
Les petits la veulent bavarde ; les grands l'acceptent muette.[la gloire]	CHAPELAN Maurice	Amours Amour.		423     solitude		berkeley	1169
Pour s'épanouir, l'intution doit laisser sa part à la foi. L'esprit et la raison n'y suffisent pas.	FAIRGAGNETR Oscar	Vitalités.	1993	320     intuition		berkeley	2534
Les erreurs de jugement témoignent souvent de la vulgarité de celui qui les fait.	FAIRGAGNETR Oscar	Vitalités.	1994	320     intuition		berkeley	2535
Il n'y a qu'un soleil : ne divise pas ton coeur.	PETIT Henri	Les Justes Solitudes.		330     coeur	1900/1878	berkeley	4687
Ceux qui élèvent les enfants se figurent qu'ils leur inculqueront la moralité, en leur dépeignant l'honnêté et la vertu comme les règles mêmes que suit tout le monde : plus tard, quand l'expérience leur apprend, et souvent à leurs dépens, une tout autre leçon, alors ils découvrent que les maîtres de leurs jeunes ans ont été les premiers à les tromper, et cette découverte peut faire plus de tort en eux à la moralité, que n'eût pu en faire la franchise et la loyauté dont on leur eût donné un premier exemple en leur disant : 'Le monde est plein de mal ; les hommes ne sont point ce qu'ils devraient être : mais que cela ne t'induise pas en erreur ; toi, sois meilleur.'	SCHOPENHAUER Arthur	Le fondement de la morale.		215     mystifications		berkeley	4975
On ne peut pas changer le but que poursuit la volonté, mais seulement le chemin qu'elle se fraye pour y arriver. Avec l'instruction, vous agissez sur le choix des moyens, non sur celui de la fin dernière de tous les actes : cette fin, c'est la volonté de l'individu qui se la propose, et en cel à, elle suit sa nature primitive.	SCHOPENHAUER Arthur	Le fondement de la morale.	1840	321     volonté		berkeley	4978
L'homme patient et courageux fait lui-même son bonheur...	SYRUS Publilius	Sentences.		441     sang-froid		berkeley	5182
J'aime mieux, en soucis et pensers élevés,  Etre un aigle abattu d'un grand coup de tonnerre  Qu'un cygne vieillissant ès jardins cultivés.	BERTAUT Jean	Stances		520     ironie de soi	1552-1611.	berkeley	735
Nier l'individu, car l'asservir à la collectivité c'est bien le nier, c'est casser les ressorts innombrables et dispersés du progrès. Or le progrès nait de l'utilisation à plein des capacités, des aptitudes, des compétences, du dynamisme, des motivations, du désir de réaliser des individus, du plus grand nombre possible d'individus.	LATTES Robert	Le Risque et la Fortune.	1990	392     création économique		berkeley	4044
Ceux qui ne savent pas rester chez eux sont toujours des ennuyés et, par conséquent, des ennuyeux.	LIGNE Prince de	Mes écarts		120     grégarité	1735-1814.	berkeley	4132
Le silence est si doux, lorsqu'il peut consoler l'amour-propre! 	LESPINASSE Julie de	Lettres		441     sang-froid	1732-1776.	berkeley	4117
Le suicide c'est la ressource des hommes dont le ressort a été rongé par la rouille.	DRIEU LA ROCHELLE Pierre	Le Feu follet		442     démission	1893-1945.	berkeley	2157
Le génie n'est qu'une plus grande aptitude à la patience.	BUFFON Comte de			370     esprit		berkeley	887
Nul savoir, si étendu qu'il soit, ne permet d'atteindre à la plénitude de la sagesse, sans la connaissance de soi-même.	CLAIRVAUX Bernard de			421     initiation		berkeley	1399
La Sorbonne, ce musée Dupuytren de toutes les servilités [...]	CREVEL René	Le Clavecin De Diderot.		120     grégarité		berkeley	1716
D'où l'homme tirera-t-il sa force, s'il n'entretient pas en soi la colère et l'appétit de plusieurs fauves? 	CAILLOIS Roger	Les Impostures de la poésie		515     tragédie	1913-1978.	berkeley	968
Rien ne me paraît juste qui contrarie mon bon plaisir.  Nada me parece justo  en siendo contra mi gusto.	CALDERON DE LA BARCA Pedro	La vida es sueño		110     entropie	1600-1681. (Espagnol)	berkeley	969
Je ne veux pas du chemin où se traînent les pas de la foule.	Callimaque	Epigrammes, XXVIII, 1-2		120     grégarité	v. 310-v. 235 av. J.-C.	berkeley	970
Tu ne veux point t'inquiéter des grands problèmes, tu as eu bien assez de mal à oublier ta condition d'homme. Tu n'es point l'habitant d'une planète errante, tu ne poses point de questions sans réponse : tu es un petit bourgeois de Toulouse. Nul ne t'a saisi par les épaules quand il était encore temps. Maintenant, la glaise dont tu es formé a séché et s'est durcie, et nul en toi ne saurait désormais réveiller le musicien endormi, ou le poète, ou l'astronome qui peut-être t'habitait d'abord.	SAINT-EXUPERY Antoine de	Terre des Hommes	1939	110     entropie		berkeley	4916
On frémit parfois de rencontrer tant de portes sombres ouvertes sur le néant.	NERVAL Gérard de	Les Illuminés.		110     entropie		berkeley	4564
Il voulait tout savoir mais il n'a rien connu.	NERVAL Gérard de	Poésies diverses, Epitaphe		221     vanité	1808-1855. (Gérard Labrunie)	berkeley	4566
Dans l'affection que je vous porte, il y a trop de passé pour qu'il n'y ait pas beaucoup d'avenir.	NERVAL Gérard de	Lettres, à Jenny Colon		234     communication	1808-1855. (Gérard Labrunie)	berkeley	4568
Je me reproche d'avoir dit trop de choses à dire et pas assez de choses à ne pas dire.	COCTEAU Jean	La Difficulté d"être		520     ironie de soi	1889-1963.	berkeley	1534
Je ne serais pas si hardi à parler s'il m'appartenait d'en être cru.	MONTAIGNE Michel Eyquem de	Essais, III, 11		520     ironie de soi	1533-1592.	berkeley	4385
Sans travail, un don n'est qu'une sale manie.	BRASSENS Georges			380     travail		berkeley	837
Les querelles ne dureraient pas longtemps si le tord n'était que d'un côté.	LA ROCHEFOUCAULD François de	Maximes.		221     vanité		berkeley	3801
Il est plus aisé de connaître l'homme en général que se connaître un homme en particulier.	LA ROCHEFOUCAULD François de	Maximes		520     ironie de soi	1613-1680.	berkeley	3916
Le goût est le bon sens du génie.	CHATEAUBRIAND François-René de	Essai sur la littérature anglaise		360     bon sens	1768-1848.	berkeley	1296
Notre temps est peu propice à la formation des chefs militaires [car], comme le dit Scharnhorst, les esprits organisés mécaniquement triomphent, en temps de paix, de ceux qui ont du génie et du sentiment... Le recrutement des chefs de valeur devient malaisé quand la paix se prolonge... Il s'agit de discerner leurs mérites et de faire en sorte que les meilleurs atteignent le sommet... Le choix qui administre les carrières se porte plus volontiers sur ce qui plaît que sur ce qui mérite...	DE GAULLE Charles	1ere Leçon à l"Ecole supérieure de guerre.	1927	120     grégarité	\\010ht&#240;\\020	berkeley	1786
Plus on plaît généralement, moins on plaît profondément.	STENDHAL	De L"amour.		120     grégarité	Henri Beyle dit STENDHAL	berkeley	5145
Parodies et caricatures sont les plus pénétrantes des critiques.  Parodies and caricatures are the most penetrating of criticisms.	HUXLEY Aldous	Point Counter Point, 28		234     communication	1894-1963. (Anglais)	berkeley	3357
A l'opposé d'un certain autre, j'aimerais mieux, à l'aventure, être le second ou le troisième à Périgueux que le premier à Paris.	MONTAIGNE Michel Eyquem de	Essais, III, 9		365     discernement	1533-1592.	berkeley	4343
Mieux vaut un homme vivant qu'un lion mort.	SHAKELTHON			441     sang-froid	Explorateur polaire anglais.	berkeley	5040
Tous les mangeurs de gens ne sont pas grands seigneurs;  Où la guépe a passé, le moucheron demeure.	LA FONTAINE Jean de	Fables		223     cupidité	1621-1695.	berkeley	3681
Contre de telles gens, quant à moi, je réclame.  Ils ôtent à nos coeurs le principal ressort;  Ils font cesser de vivre avant que l'on soit mort.	LA FONTAINE Jean de	Fables, le Philosophe scythe		225     cynisme	1621-1695.	berkeley	3682
Chacun se dit ami; mais fou qui s'y repose:  Rien n'est plus commun que ce nom,  Rien n'est plus rare que la chose.	LA FONTAINE Jean de	Fables, Parole de Socrate		234     communication	1621-1695.	berkeley	3686
Il voyait trop.  Et voir est un aveuglement.	CORBIERE Tristan	Raccrocs		340     sensibilité	1845-1875. (Edouard Joachim Corbière)	berkeley	1642
D'un homme qui ne parle et chien qui n'aboie, garde-toi.	Dictons et Proverbes	Dicton.		310     énergie		berkeley	2013
Je voudrais aussi qu'on fût soigneux de lui* choisir un conducteur+ qui eût plutôt la tête bien faite que bien pleine, et qu'on y requît tous les deux, mais plus les moeurs et l'entendement que la science.	MONTAIGNE Michel Eyquem de	Essais, I, 26		421     initiation	1533-1592.  * A l"enfant, + Précepteur. Cette image, l"une des plus connues des Essais, est généralement citée à tort et appliquée à l"élève, non au précepteur. Elle était courante au XVIe siècle; on la trouve, entre autres chez Henri Estienne dans son Apologie pour Hérodote.	berkeley	4351
Trop de paroles, péché certain.  Qui trop parole, il se mesfait.	Chrétien de Troyes	Le Conte Du Graal.		233     spéculation	Seconde moitié du XIIe siècle.	berkeley	1357
C'est une grande difformité dans la nature qu'un vieillard amoureux.	LA BRUYERE Jean de	Les Caractères, De l"homme		530     ironie amoureuse	1645-1696.	berkeley	3630
Quand Paris est souffrant, tout le monde a mal à la tête.	HUGO Victor			120     grégarité		berkeley	3279
L'enfance est un voyage oublié.	LA VARENDE Jean de	Le Centaure de Dieu		540     mémoire	1887-1959.	berkeley	3954
Les bêtes savent trop de choses, et ne sont pas heureuses.	BOSCO Henri	L"Ane Culotte 		510     ironie	1888-1976.	berkeley	799
Le hasard est l'oeil de Dieu.	Dictons et Proverbes	Proverbe arabe		140     rapport à la cosmogonie		berkeley	1993
Byron, coiffeur d'orages...	FARGUE Léon-Paul	Sous la lampe		393     création artistique	1876-1947.	berkeley	2664
Quoi que l'heure présente ait de trouble et d'ennui,  Je ne veux point mourir encore.	CHéNIER André de	La Jeune Captive		441     sang-froid	1762-1794.	berkeley	1336
Un homme précis est un homme rassuré.	WEST Morris	De main de Maître.	1988	422     confiance en soi		berkeley	5412
La gloire veut qu'on ose où le péril est grand.	CHENIER Marie-Joseph de	Les Gracques		510     ironie		berkeley	1341
Les plus grands chefs-d'oeuvre sont ceux qui subsisteront lorsqu'il s'agira d'exposer l'histoire de l'art toute entière de manière aussi succinte que possible, mais dans sa stricte continuité. Les oeuvres qui s'avèreront alors indispensables à la formation de séries continues celles-l à seront les plus grandes des oeuvres d'art de l'humanité.	KAHNWEILER Daniel-Heinrich	Confessions esthétiques.	1963	393     création artistique	Gallimard	berkeley	3526
Ils* dînent du mensonge, et soupent du scandale.	CHéNIER Marie-Joseph de	De la calomnie 		221     vanité	1764-1811.  *Les calomniateurs.	berkeley	1342
Ce sont les grands artistes qui font les grands marchands.	KAHNWEILER Daniel-Heinrich			393     création artistique		berkeley	3529
En cessant d'être aimé, on cesse d'être aimable.	PETIT Henri	Les Justes Solitudes.		423     solitude	1900/1978	berkeley	4690
La mort n'est rien. Ce qui importe, c'est l'injustice.	CAMUS Albert	Requiem pour une nonne		210     violence	1913-1960.	berkeley	986
Il n'y a de bonheur possible pour personne sans le soutien du courage.	CHARTIER Emile	Minerve Ou De La Sagesse.		440     courage	alias Alain (1868-1951)	berkeley	1263
Il n'y a de bonheur possible pour personne sans le soutien du courage.	CHARTIER Emile	Minerve ou de la Sagesse		440     courage	alias ALAIN	berkeley	1264
Une idée que j'ai, il faut que je la nie: c'est ma manière de l'essayer.	CHARTIER Emile	Histoire De Mes Pensées.		441     sang-froid	alias Alain (1868-1951)	berkeley	1265
L'artiste doit s'arranger de façon à faire croire à la postérité qu'il n'a pas vécu.	FLAUBERT Gustave	Correspondance, 1842		433     perversion	1821-1880.	berkeley	2764
Pour que demeure le secret  Nous tairons jusqu'au silence.	FOUCHET Max-Pol	Demeure le secret		234     communication	1913-1980.	berkeley	2847
Le journalisme mène à tout - à condition d'en sortir.	JANIN Jules			421     initiation		berkeley	3422
Je m'avance masqué.  Cogitationes privatae  	DESCARTES René			360     bon sens	1596-1650.   "Larvatus prodeo", dit le texte latin original de cet écrit de jeunesse. Le mot a fait l"objet de commentaires multiples. Vraisemblablement, il définissait l"attitude qui restera la sienne toute sa vie: mener ses difficiles travaux - autant que possible - dans la retraite et le silence.	berkeley	1918
Par méthode, j'entends des règles certaines et faciles, grâce auquelles tous ceux qui les observent exactement ne supposeront jamais vrai ce qui est faux, et parviendront sans se fatiguer en efforts inutiles, mais en accroissant progressivement leur science, à la connaissance vraie de tout ce qu'ils peuvent atteindre.	DESCARTES René	Discours de la méthode.	1637	360     bon sens	(1596/1650)	berkeley	1919
Ne disons point au jour les secrêts de la nuit.	PARNY évariste Désiré de	élégies.		441     sang-froid		berkeley	4635
On ne fait pas le droit, il se fait. Cette brève formule contient toute son histoire.	LE BON Gustave	Hier et Demain.		510     ironie		berkeley	4070
Nous sommes à l'une de ces périodes de l'histoire où, pour un instant, les cieux restent vides. Par ce fait seul, le monde doit changer.	LE BON Gustave			510     ironie		berkeley	4071
Un soupçon d'infidélité  Fait quelquefois une infidèle.	LE BRUN Antoine Louis	Epigrammes, madrigaux et chansons		441     sang-froid	1680-1753.	berkeley	4072
Le péché de la chair est le plus abominable de tous les péchés et ce crime est si bien le plus grand de tous les crimes qu'il faut être à deux pour le commettre.	LE CAMUS Cardinal			215     mystifications	1632-1707.	berkeley	4073
L'art est sans doute la seule forme de progrès qui utilise aussi bien les voies de la vérité que celles du mensonge.	LE CLéZIO Jean-Marie Gustave	L"Extase matérielle		393     création artistique	1940-.	berkeley	4074
Quand on a du talent, on fait ce que l'on veut. Quand on a du génie, on fait ce que l'on peut.	GIDE André			520     ironie de soi	cité par Claude NOUGARO, le 15/02/90 sur M6 TV	berkeley	2944
Ne s'émouvoir de rien.  Nil admirari.	Horace	Epîtres, I, VI, 1		441     sang-froid	65-8 av. J.-C. (Quintus Horatius Flaccus)	berkeley	3252
Gardez-vous bien de lui les jours qu'il communie.	DU LORENS Jacques	Les Satires Du Sieur Lorens.		221     vanité	1583-v. 1655	berkeley	2180
Les trônes et les Rois sont rongés par les vers ...	HABERT Philippe	Le Temple de la mort		221     vanité	1605-1637.	berkeley	3076
Je detestais ce gras et prospère élevage du médiocre, du quelconque et de l'ordinaire.	HESSE Hermann			110     entropie		BERKELEY	3177
Le pessimisme est d'humeur ; l'optimisme est de volonté.	CHARTIER Emile	Propos Sur Le Bonheur.		520     ironie de soi	alias Alain (1868-1951)	berkeley	1276
La vertu, sans doute, n'est ni un fruit naturel, ni un effet de l'éducation : mais quand un homme a ce bonheur, de la posséder, c'est sans réflexion, par une faveur divine.	PLATON	Ménon.		550     grandeur		berkeley	4720
Il faut que les principes d'une politique soient faits de justice et de vérité.	Démosthène	Olynthiennes, II, 10		215     mystifications	384-322 av. J.-C.	berkeley	1897
La vieillesse est un naufrage.	CHATEAUBRIAND François-René de			410     santé		berkeley	1301
Il y a peut-être ici une sorte de règle historique : la puissance, dans les sociétés totalitaires, se mesure à la capacité de trahison.	RUFIN Jean-Christophe	La Dictature Libérale.		239     servitudes du pouvoir autoritaire	Le secret de la toute-puissance des démocraties au 20e siècle	berkeley	4898
C'est la pensée qui donne au style sa beauté, mais chez les pseudo-penseurs c'est le style qui doit orner les pensées.  Der Stil erhält die Schönheit vom Gedanken, statt daß bei den Scheindenkern durch den Stil schön werden sollen.	SCHOPENHAUER Arthur	Parerga und Paralipomena		370     esprit	1788-1860. (Allemand)	berkeley	4974
Un couple sans enfants souffre de la faim, une fois la vieillesse venue. Il vaut mieux donc commencer à engendrer avant le mariage...	WEST Morris	La seconde victoire.	1972	530     ironie amoureuse		berkeley	5448
Patience et longueur de temps  Font plus que force ni que rage.	LA FONTAINE Jean de	Fables		441     sang-froid	1621-1695.	berkeley	3724
La grâce de la nouveauté et la longue habitude, quelque opposées qu'elles soient, nous empêchent également de sentir les défauts de nos amis.	LA ROCHEFOUCAULD François de	Maximes.		234     communication	1613/1680	berkeley	3834
Il y a des reproches qui louent et des louanges qui médisent.	LA ROCHEFOUCAULD François de	Maximes		234     communication	1613-1680.	berkeley	3837
La jeunesse est une ivresse continuelle: c'est la fièvre de la santé; c'est la folie de la raison.	LA ROCHEFOUCAULD François de	Maximes		310     énergie	1613-1680.	berkeley	3838
On ne souhaite jamais ardemment ce qu'on ne souhaite que par raison.	LA ROCHEFOUCAULD François de	Maximes.		320     intuition	1613/1680	berkeley	3840
Des larmes d'un enfant sa tombe est arrosée,...	HEREDIA J.-M. de	Epigramme funéraire.		420     capital affectif		berkeley	3158
Un grand obstacle au bonheur, c'est de s'attendre à un trop grand bonheur.	FONTENELLE Bernard le Bovier de			441     sang-froid		berkeley	2824
Vivre, c'est naître lentement. Il serait un peu trop aisé d'emprunter des âmes toutes faites! 	SAINT-EXUPéRY Antoine de	Pilote de guerre		421     initiation	1900-1944.	berkeley	4931
Si tu veux comprendre le mot de bonheur, il faut l'entendre comme récompense et non comme but.	SAINT-EXUPéRY Antoine de	Citadelle		546     éthique	1900-1944.	berkeley	4935
On ne peut point régner innocemment.	SAINT-JUST		1792	230     pouvoir	L""archange de la Terreur" sous la Convention, à 25 ans.	berkeley	4937
Tous les arts ont produit des merveilles; l'art de gouverner n'a produit que des monstres.	SAINT-JUST		1792	238     servitudes du pouvoir politique	L""archange de la Terreur" sous la Convention, à 25 ans.	berkeley	4938
Une parole une fois lancée ne peut revenir.  Nescit vox missa reverti.	Horace	Art poétique, 390		234     communication	65-8 av. J.-C. (Quintus Horatius Flaccus)	berkeley	3237
Comment peut-on être persan ?	MONTESQUIEU Charles de	Lettres persanes.	1721	120     grégarité	1689/1755	berkeley	4394
Rien ne presse* un Etat que l'innovation: le changement donne seul forme à l'injustice et à la tyrannie.	MONTAIGNE Michel Eyquem de	Essais, III, 9 		231     légitimité du pouvoir	1533-1592.  *Accable.	berkeley	4330
Les moins tendues et plus naturelles allures de notre âme sont les plus belles.	MONTAIGNE Michel Eyquem de	Essais, III, 3		311     distinction	1533-1592.	berkeley	4335
La confiance en la bonté d'autrui est un non léger témoignage de la bonté propre.	MONTAIGNE Michel Eyquem de	Essais, I, 14		330     coeur	1533-1592.	berkeley	4338
Il faut avoir un peu de folie, qui* ne veut avoir plus de sottise.	MONTAIGNE Michel Eyquem de	Essais, III, 9 		350     imagination	1533-1592.  *Si l"on.	berkeley	4339
La haute politique n'est que le bon-sens appliqué aux grandes choses.	Napoléon I	Lettres.		230     pouvoir		berkeley	4557
... Ce n'est pas toujours par valeur et par chasteté que les hommes sont vaillants et que les femmes sont chastes.	LA ROCHEFOUCAULD François de	Maximes		510     ironie	1613-1680.	berkeley	3908
Le but du terrorisme est de terroriser, c'est le seul espoir pour un petit pays de lutter contre une grande nation avec des chances de gagner.	Lénine			221     vanité		berkeley	4108
Etre et penser sont pour nous la même chose.	BUFFON Georges-Louis Leclerc de	Histoire naturelle		370     esprit	1707-1788.	berkeley	894
Qu'il n'est pas en notre pouvoir d'être vertueux ou méprisables.	SOCRATE			510     ironie	tel que rapporté (par son élève) Aristote, in Grande Morale I,9.	berkeley	5093
Il n'existe aucune formule diplomatique pour dire non à son patron.	SOLJENITSYNE Alexandre	Le Premier Cercle.		510     ironie		berkeley	5094
L'art reste pour nous, quant à sa suprême destination, une chose du passé.	HEGEL Friedrich			393     création artistique	1770/1831	berkeley	3095
Les jeunes gens n'ont pas besoin de maîtres à penser, mais de maîtres à se conduire.	MONTHERLANT Henry Millon de	Carnets		421     initiation	1896-1973.	berkeley	4479
On blesse l'amour-propre, on ne le tue pas.	MONTHERLANT Henry Millon de	Carnets		422     confiance en soi	1896-1973.	berkeley	4480
Quand on vieillit, les colères deviennent des tristesses.	MONTHERLANT Henry Millon de	La Reine morte, III, 5, Ferrante		430     paradoxal émotionnel	1896-1973.	berkeley	4481
Qui veut trop trouver ne trouve rien.	MONTHERLANT Henry Millon de	Carnets		433     perversion	1896-1973.	berkeley	4482
Mon métier et mon art, c'est vivre.	MONTAIGNE Michel Eyquem de	Essais, II, 6		390     création	1533-1592.	berkeley	4345
Rien n'est beau que le vrai, dit un vers respecté*;  Et moi, je lui réponds, sans crainte d'un blasphème:  Rien n'est vrai que le beau, rien n'est vrai sans beauté.	MUSSET Alfred de	Poésies, Après une lecture		312     foi	1810-1857.	berkeley	4526
Les égaux s'assemblent volontiers avec leurs égaux.  Pares cum paribus facillime congregantur.	Cicéron	De la vieillesse, III, 7		234     communication	106-43 av. J.-C. (Marcus Tullius Cicero)	berkeley	1377
En dépit de ma jeunesse apparente, j'ai des principes assez  traditionnels. On m'a appris que personne ne devrait jamais se vanter de sa bonne fortune, et qu'il ne fallait jamais dire du mal des morts, car ils ne peuvent se défendre. Enfin, il ne faut pas oublier les vivants, qui peuvent toujours vous poursuivre en diffamation.	WEST Morris	De main de Maître.	1988	510     ironie		berkeley	5442
Faire confiance aux hommes c'est déj à se faire tuer un peu.	CéLINE L.-F.	Voyage au bout de la nuit		110     entropie	1894-1961. (Louis-Ferdinand Destouches)	berkeley	1069
Où finissent les lois, la tyrannie commence.	PITT William	Cas de Wilkes, Discours.		210     violence		berkeley	4711
Citer peu et fondre toujours la citation dans le discours, de peur d'en couper le fil et de le refroidir.	HéRAULT DE SéCHELLES Marie-Jean	Théorie de l"ambition		370     esprit	1759-1794., Codicille politique et pratique d"un jeune habitant d"Epône	berkeley	3129
(...) cela est je crois, hors de doute que, si nous vivions avec les droits que la nature nous a donnés et avec les enseignements qu'elle nous apprend, nous serions naturellement (...) sujets à la raison et serfs de personne.	LA BOéTIE Etienne de	Le discours de la servitude volontaire.		560     sagesse	1530/1563. ami de Montaigne.	berkeley	3585
Je m'éveillai à elle ainsi qu'on s'éveille à la première lumière du matin. L'acte d'amour est, ainsi que l'acte de foi, un abandon ; et je crois que l'un est soumis à l'autre.	WEST Morris	L"Avocat du Diable.	1959	531     communication amoureuse		berkeley	5454
Il avait l'air tout à fait innocent, comme n'importe quel homme qui est heureux.	SUSKIND Patrick	Le Parfum.		420     capital affectif		berkeley	5177
Si tous te disent que tu es âne, brais.	Dictons et Proverbes	Dicton.		120     grégarité		berkeley	1986
Tout mépris est pur alibi de la médiocrité de celui qui l'exprime.	CHANCEL Jacques	Le temps d"un regard.		221     vanité		berkeley	1161
J'aime la majesté des souffrances humaines ...	VIGNY Alfred de	Les Destinées, la Maison du berger		433     perversion	1797-1863.	berkeley	5296
Le sage ne s'afflige pas de ce que les hommes ne le connaissent pas; il s'afflige de ne pas connaître les hommes.	CONFUCIUS	Entretiens, I, 1		520     ironie de soi	551-479 av. J.-C. (Chinois)	berkeley	1606
Celui qui honore les autres s'honore lui-même.	St.JEAN CHRYSOSTOME			330     coeur	330     coeu\\010R∏0\\010R∫†	berkeley	5120
Le jeu, la femme et le vin friant, font l'homme pauvre tout en riant.	Dictons et Proverbes	Dicton.		240     débauche		berkeley	2012
Nous avons la notion et le discernement de l'honnête, mais ne le mettons pas en pratique.	Euripide	Hippolyte, 380		442     démission	480-406 av. J.-C.	berkeley	2392
L'homme supérieur est celui qui reste toujours fidèle à l'espérance; ne point persévérer est d'un lâche.	Euripide	Héraclès, 105-106		442     démission	480-406 av. J.-C.	berkeley	2393
Ne jugez pas, pour n'être pas jugés.	Evangiles	Evangile selon saint Matthieu, VII, 1		120     grégarité		berkeley	2397
Malheur au monde à cause des scandales! Il est fatal, certes, qu'il arrive des scandales, mais malheur à l'homme par qui le scandale arrive! 	Evangiles	Evangile selon saint Matthieu, XVIII, 7		120     grégarité		berkeley	2398
Qu'un ami véritable est une douce chose!  Il cherche vos besoins au fond de votre coeur;  Il vous épargne la pudeur  De les lui découvrir vous-même.	LA FONTAINE Jean de	Fables		330     coeur	1621-1695.	berkeley	3692
L'esprit de l'observateur doit être passif, c'est- à-dire se taire.	BERNARD Claude	Introduction à l"étude de la médecine expérimentale		214     guerre du savoir	1813-1878.	berkeley	701
L'Homme est une machine, et il n'y a dans l'Univers qu'une seule substance diversement modifiée.	LA METTRIE Julien Offroy de	L"Homme machine		510     ironie	1709-1751.	berkeley	3777
Toute morale est infructueuse, pour qui n'a pas la sobriété en partage.	LA METTRIE Julien Offroy de	L"Homme machine		546     éthique	1709-1751.	berkeley	3778
Il y a tant de plaisir à faire du bien, à sentir, à connaître celui qu'on reçoit, tant de contentement à pratiquer la vertu ... que je tiens pour assez puni, quiconque a le malheur de n'être pas né vertueux.	LA METTRIE Julien Offroy de	L"Homme machine		546     éthique	1709-1751.	berkeley	3779
Le poisson est un animal dont la croissance est excesssivement rapide entre le moment où il est pris et le moment où le pêcheur en fait la description à ses amis.	Dictons et Proverbes	The Christian Herald.		221     vanité		berkeley	1998
Les anciens, monsieur, sont les anciens, et nous sommes les gens de maintenant.	MOLIERE	Le Malade imaginaire.		214     guerre du savoir		berkeley	4295
Il y a des personnes à qui les défauts siéent bien, et d'autres qui sont disgraciées avec leurs bonnes qualités.	LA ROCHEFOUCAULD François de	Maximes		510     ironie	1613-1680.	berkeley	3909
N'est pas heureux qui ne veut l'être.	JOUBERT Joseph	Pensées		321     volonté	1754-1824.	berkeley	3456
Il n'est pas malaisé de tromper un trompeur.	LA FONTAINE Jean de	Fables, l"Enfouisseur et son Compère		222     fourberie	1621-1695.	berkeley	3677
Le poète ne peut compter sur les moments très rares où il écrit comme sous une dictée. Et il me semble qu'il doit imiter en cela l'homme de science, lequel n'attend pas d'être inspiré pour se mettre au travail.	SUPERVIELLE Jules	En songeant à un art poétique.		393     création artistique		berkeley	5171
La haine n'est qu'une défaite de l'imagination.	GREENE Graham	La Puissance et la Gloire		350     imagination		berkeley	3010
A force d'être juste, on est souvent coupable.	CORNEILLE Pierre	La Mort de Pompée, I, 1, Photin		510     ironie	1606-1684.	berkeley	1682
L'humilité sert à agir avec puissance.	LAO TSEU	Tao tö King, LXI		441     sang-froid		berkeley	4034
Pour aimer, il faut que tous les sens soient en éveil.	Dictons et Proverbes	Proverbe Arabe.		531     communication amoureuse		berkeley	2054
S'il est possible de trouver quelque moyen qui rende communément les hommes plus sages et plus habiles qu'ils n'ont été jusques ici, je crois que c'est dans la médecine qu'on doit le chercher.	DESCARTES René	Discours de la méthode		410     santé	1596-1650.	berkeley	1930
La cause la plus ordinaire de la fièvre lente est la tristesse.	DESCARTES René	Correspondance, à Elisabeth, 18 mai 1645		420     capital affectif	1596-1650.	berkeley	1931
J'ai connu beaucoup d'hommes qui, si on leur avait demandé ce qu'ils pensent de l'Evangile, se seraient contentés de répondre: C'est ingénieux.	FIéVéE Joseph	Correspondance et relations avec Bonaparte		225     cynisme	1767-1839.	berkeley	2707
Il n'est pas pour la civilisation de danger plus redoutable que le fossé que l'on voit parfois s'élargir entre le discours et la coutume.	CAILLOIS Roger	Circonstancielles		215     mystifications	1913-1978.	berkeley	954
Qui veut se connaître, qu'il ouvre un livre.	PAULHAN Jean	Eléments.		421     initiation		berkeley	4658
Le véritable ami est celui à qui on n'a rien à dire. Il contente à la fois notre sauvagerie et notre besoin de sociabilité.	BERNARD Tristan	La Faune des plateaux		234     communication	1866-1947. (Paul Bernard)	berkeley	712
(Dans Montaigne) le 'je' et le 'moi' sont à chaque ligne, mais quelles sont les connaissances qu'on peut avoir, si ce n'est par le 'je' et le 'moi'? 	DU DEFFAND Marie de Vichy-Chamrond	Lettre à Horace Walpole		421     initiation	1697-1780. Marquise	berkeley	2174
Savez-vous, Monsieur, ... ce qui fait que je vous trouve un grand philosophe? C'est que vous êtes devenu riche! Tous ceux qui disent qu'on peut être heureux et libre dans la pauvreté sont des menteurs, des fous et des sots.	DU DEFFAND Marie de Vichy-Chamrond	Lettre à Voltaire		441     sang-froid	1697-1780. Marquise	berkeley	2175
La maison est à l'envers lorsque la poule chante aussi haut que le coq.	DU FAIL Noël	Contes et discours d"Eutrapel		515     tragédie	1520-1591.	berkeley	2179
Les amis ne se choisissent pas. C'est eux qui vous choisissent. Ou on les repousse, ou on les accepte sans réserve.	PEREZ-REVERTE Arturo	Le Tableau du Maître flamand	1990	234     communication		berkeley	4667
Il y a des gens qui n'embrassent que des ombres ; ceux-l à ne possèdent que l'ombre du bonheur.	SHAKESPEARE William	Le marchand de Venise.		420     capital affectif		berkeley	5052
La parole est un laminoir qui allonge toujours les sentiments.	FLAUBERT Gustave	Madame Bovary		234     communication	1821-1880.	berkeley	2724
Les actions parlent plus haut que les paroles.	CARNEGIE Dale	Comment se faire des amis.		440     courage		berkeley	1037
Dans toutes les formes de gouvernement, c'est le peuple qui est le véritable législateur.  In all forms of Government the people is the true legislator.	BURKE Edmund	Tracts of the Popery Laws, III		215     mystifications	1729-1797. (Irlandais)	berkeley	907
Un Etat qui n'a pas les moyens d'effectuer des changements n'a pas les moyens de se maintenir.  A state without the means of some change is without the means of its conservation.	BURKE Edmund	Reflections on the Revolution in France		238     servitudes du pouvoir politique	1729-1797. (Irlandais)	berkeley	909
Il y a, néanmoins, une limite passé laquelle la longanimité cesse d'être une vertu.  There is, however, a limit at which forbearance ceases to be a virtue.	BURKE Edmund	Observations on a Publication, The Present State of the Nation		330     coeur	1729-1797. (Irlandais)	berkeley	910
Innover n'est pas réformer.  Innovate is not to reform.	BURKE Edmund	Letters, to a Noble Lord, 1796		390     création	1729-1797. (Irlandais)	berkeley	911
Il n'y a qu'une préparation à la mort: elle est d'être rassasié.	MONTHERLANT Henry Millon de	Mors et Vita		140     rapport à la cosmogonie	1896-1973.	berkeley	4462
'faire ses plans avec les rêves de ses soldats endormis'.	Napoléon I			391     commandement		berkeley	4559
Ecoutez bien ceci, Kahnweiler, si les dirigeants étaient absolument certains et convaincus que la guerre est impossible et à tout jamais, dans l'état où se trouve actuellement le monde, la guerre étant la seule solution escomptée et possible, ils deviendraient fous ! Fous d'angoisse devant l'impossibilité d'arranger le pays afin qu'il puisse vivre en circuit fermé ou alors d'organiser le monde entier sur un mode égalitaire, fraternel et compter sur le désintéressem- ent individuel et une bonne volonté réciproque !	VLAMINCK Maurice		1934	110     entropie		berkeley	5320
L'habile homme est celui qui fait un grand usage de ce qu'il sait ; le capable peut, et l'habile exécute.	VOLTAIRE	Dictionnaire philosophique.		130     liberté		berkeley	5325
Au fond, c'est un homme de bien, parcequ'il y a en lui beaucoup d'amour : car nul n'est perdu tant qu'il n'exclut pas l'amour de sa vie et n'endurcit pas contre lui sa volonté.	WEST Morris	La seconde victoire.	1972	330     coeur		berkeley	5387
Je me force à me contredire pour éviter de suivre mon goût.	DUCHAMP Marcel			370     esprit		berkeley	2191
Songez, mes filles que nous sommes des atomes jetés dans le gouffre sans fin de l'infini.	CHRISTOPHEL	La Famille Fenouillard	1959	510     ironie		berkeley	1363
Ce que raconte l'histoire n'est en fait que le long rêve, le songe lourd et confus de l'humanité.  Was die Geschichte erzählt, ist in der Tat nur der lange, schwere und verworrene Traum der Menschheit.	SCHOPENHAUER Arthur	Le Monde comme volonté et représentation		215     mystifications	1788-1860. (Allemand)	berkeley	4973
L'homme est né libre et partout, il est dans les fers.	SARTRE Jean-Paul			120     grégarité		berkeley	4953
Nature ! que ne suis-je un homme, rien qu'un homme vis- à-vis de toi ! Oh ! ce serait alors la peine de vivre.	GOETHE Johann Wolfgang von	Le Second Faust.		510     ironie		berkeley	2978
On peut dire des Russes, grands et petits, qu'ils sont ivres d'esclavage.	CUSTINE Astolphe de	La Russie en 1839		515     tragédie	1790-1857.	berkeley	1734
Que diable aller faire aussi dans la galère d'un Turc ?	CYRANO DE BERGERAC Savinien de	Le Pédant joué		360     bon sens	1619-1655. Exclamation reprise par Molière dans les Fourberies de Scapin.	berkeley	1735
Rien n'est jamais perdu tant qu'il reste quelque chose à trouver.	DAC Pierre			321     volonté		berkeley	1737
Si tous ceux qui croient avoir raison n'avaient pas tort, la vérité ne serait pas loin.	DAC Pierre	L"os A Moelle		370     esprit	André ISAAC dit Pierre Dac	berkeley	1739
L'espérance est la plus grande de nos folies.	VIGNY Alfred de	Stello		510     ironie	1797-1863.	berkeley	5297
Le salut des vaincus est de n'en plus attendre.	RACAN Honorat de Bueil, marquis de	Les Bergeries, IV, 2		442     démission	1589-1670.	berkeley	4764
Le jour n'est pas plus pur que le fond de mon coeur.	RACINE Jean	Phèdre.		140     rapport à la cosmogonie		berkeley	4768
Ils envoient leur conscience au bordel et tiennent leur contenance en règle.	MONTAIGNE Michel Eyquem de	Essais, IV, 5		442     démission	1533-1592.	berkeley	4369
Nous ne sommes victimes que du mal que vous portons en nous-même.	COUSTEAU Jacques-Yves			520     ironie de soi		berkeley	1707
La contradiction est la racine de tout mouvement et de toute manifestation vitale.  Der Widerspruch aber ist die Wurzel aller Bewegung und Lebendigkeit.	HEGEL Georg Wilhelm Friedrich	Science de la logique		365     discernement	1770-1831. (Allemand)	berkeley	3102
Quand on voudra s'occuper utilement du bonheur des hommes, c'est par les Dieux du ciel que la réforme doit commencer.	Holbach	Système de la nature		215     mystifications	1723-1789. (Paul Henri Dietrich, baron d")	berkeley	3202
Jouir sans interruption, c'est ne jouir de rien.	Holbach	Système de la nature		240     débauche	1723-1789. (Paul Henri Dietrich, baron d")	berkeley	3204
L'ennui naquit un jour de l'uniformité 	HOUDAR DE LA MOTTE Antoine	Fables, les Amis trop d"accord		110     entropie	1672-1731.	berkeley	3271
Hélas ! que j'en ai vu mourir de jeunes filles !C'est le destin : il faut une proie au trépas.	HUGO Victor	Les Orientales.		110     entropie		berkeley	3276
Pour Chacun en particulier, il n'y a pas plus de chances d'être atteint par une bombe que de gagner le gros lot à la loterie.	MAUROIS André			510     ironie		berkeley	4265
L'avaricieux a plus mauvais compte de sa passion que n'a le pauvre, et le jaloux que le cocu. Et il y a moins de mal souvent à perdre sa vigne qu' à la plaider.	MONTAIGNE Michel Eyquem de	Essais, II, 17		223     cupidité	1533-1592.	berkeley	4329
Les paroles sont toujours une force que l'on cherche hors de soi.	STENDHAL			441     sang-froid		berkeley	5154
La pensée floue est plutôt en action au cours de la phase embryonnaire quand vous recherchez de nouvlles idées, que vous pensez globalement, et que vous manipulez les problèmes. La pensée nette, par contre, est mieux utilisée au cours de la phase pratique quand vous évaluez les idées, que vous vous concentrez sur des solutions pratiques, analysez les risques et vous préparez à mettre l'idée en application. [...] Bien que les pensées floues et nettes aient chacune leurs forces respectives, elles ont également leurs faiblesses. Il est donc important de savoir quand chacune n'est pas opportune. Penser flou au cours de la phase pratique peut empêcher la réalisation d'une idée ; l à, fermeté et franchise sont préférables à rêves et ambiguïté. Réciproquement, penser pratique dans la phase embryonnaire peut limiter le processus créatif.	OECH Roger von	Créatif de choc.	1983	390     création		berkeley	4624
Un ami qui meurt, c'est quelque chose de vous qui meurt.	FLAUBERT Gustave	L"amour de l"art.	1915	420     capital affectif	(1821/1880) édition posthume	berkeley	2754
De tout temps la beauté a été ressentie par certains comme une secrète insulte.	DEBUSSY Claude	Monsieur Croche, antidilettante		221     vanité	1862-1918.	berkeley	1867
Le flatteur qui nous perd est mieux venu souvent Que l'ami qui nous sauve en nous désapprouvant.	DELAVIGNE Casimir	Les Enfants d"Edouard.		110     entropie		berkeley	1882
La vérité, c'est une agonie qui n'en finit pas. La vérité de ce monde, c'est la mort.	CéLINE L.-F.	Voyage au bout de la nuit		442     démission	1894-1961. (Louis-Ferdinand Destouches)	berkeley	1078
Nous éprouvons l'or dans le feu, nous discernons nos amis dans l'adversité.	Isocrate	A Démonicos, 25		234     communication	436-338 av. J.-C.	berkeley	3391
A quelques exceptions près, les premiers logiciels pour micro- ordinateurs sont nés du besoin particulier d'un utilisateur pour un logiciel alors inexistant. Il en avait besoin, alors il l'inventait. Et, bon sang de bonsoir, chanter les louanges de son programme au club d'informatique du coin dont il était membre amenait d'autres membres qui en avaient besoin à se manifester auprès de lui, à vouloir l'acheter, et c'est ainsi que naquit une industrie.	CRINGELY Robert X.	Batisseurs d"empires par accident	1992	390     création		berkeley	1718
Toutes nos pensées touchent à la politique.	CHAMSON André	La Galère		546     éthique	1900-1983.	berkeley	1158
La vrai grandeur, c'est de n'exiger rien que de soi-même, sans rien attendre des autres, pas même qu'ils la reconnaissent.	JOUHANDEAU Marcel	De la grandeur.		550     grandeur		berkeley	3495
Ce n'est pas dans la science qu'est le bonheur, mais dans l'acquisition de la science.	POE Edgar	Puissance de la parole.		390     création		berkeley	4723
Tous les hommes ne sont pas capables de grandes choses, mais tous sont sensibles aux grandes choses.	MUSSET Alfred de	Lorenzaccio.		341     étonnement		berkeley	4530
Donner avec ostentation ce n'est pas très joli, mais ne rien donner avec discrétion, ça ne vaut guère mieux.	DAC Pierre	L"Os A Moelle		330     coeur	André ISAAC dit Pierre Dac	berkeley	1738
L'esclave fait son orgueil de la braise du maître.	SAINT-EXUPéRY Antoine de	Terre des hommes		221     vanité	1900-1944.	berkeley	4924
Ne fît-on que des épingles, il faut être enthousiaste de son métier pour y exceller.	DIDEROT Denis			380     travail		berkeley	2100
Ne pas alourdir ses pensées du poids de ses souliers.	BRETON André			370     esprit		berkeley	849
Un jeune curé fait les meilleurs sermons.	MUSSET Alfred de	Un caprice, 8, Chavigny		510     ironie	1810-1857.	berkeley	4540
Peu importe ce que hait un homme, pourvu qu'il haïsse quelque chose.  It does not matter much what a man hates provided he hates something.	BUTLER Samuel	Notebooks		510     ironie	1835-1902. (Anglais)	berkeley	928
Les mauvaises moeurs sont la seule chose que les gens prêtent sans réfléchir.	COCTEAU Jean	Le Grand Ecart		110     entropie	1889-1963.	berkeley	1489
Les vrais grands écrivains sont ceux dont la pensée occupe tous les recoins de leur style.	HUGO Victor	Tas de pierres		393     création artistique	1802-1885.	berkeley	3318
Quand le poète peint l'enfer, il peint sa vie.	HUGO Victor	Les Voix intérieures, Après une lecture de Dante		393     création artistique	1802-1885.	berkeley	3319
L'on commande au valet, et le valet au chat, et le chat commande à sa queue.	Dictons et Proverbes	Dicton.		510     ironie		berkeley	2050
Il y a souvent loin de la coupe aux lèvres.	Dictons et Proverbes	Proverbe		441     sang-froid	id	berkeley	2039
Lorsque vous aurez compris que l'expérience de la vie est une expérience d'amour, vous aurez trouvé le secret d'une vie bénie.	KRAMER Edward L.	Chemins vers la puissance.		330     coeur		berkeley	3576
L'amour commence avec l'amour et l'on ne saurait passer de la plus forte amitié qu' à un amour faible.	LA BRUYERE Jean de	Les Caractères, Du coeur		531     communication amoureuse	1645-1696.	berkeley	3631
Donner suscite habituellement plus de ressentiment que de reconnaissance.	FAIRGAGNETR Oscar	Vitalités.	1992	510     ironie		berkeley	2625
Tout homme doit être poli; mais il doit aussi être libre.	MONTESQUIEU Charles de	Mes pensées		232     servitudes du pouvoir	1689-1755. (C. de Secondat, baron de La Brède et de M.)	berkeley	4423
Quand on veut gouverner les hommes, il ne faut pas les chasser devant soi. Il faut les faire suivre.	MONTESQUIEU Charles de	Mes pensées		232     servitudes du pouvoir	1689-1755. (C. de Secondat, baron de La Brède et de M.)	berkeley	4424
Tout bonheur est une innocence.	YOURCENAR Marguerite	Alexis ou le Traité du vain combat		140     rapport à la cosmogonie	1903-1987. (Marguerite de Crayencour)	berkeley	5505
Lamartine, fantôme de redingote aux pellicules d'étoiles.	FARGUE Léon-Paul	Sous la lampe		393     création artistique	1876-1947.	berkeley	2659
C'est au courage que va la fortune.  Fortibus est fortuna viris data.	ENNIUS Quintus	Annales		440     courage	239-169 av. J.-C.	berkeley	2346
Entre deux petits, un glorieux ; Entre deux grands, un lourdaud.	Dictons et Proverbes	Dicton.		441     sang-froid		berkeley	2040
Heureux qui ne les connait guère! Plus heureux qui n'en a que faire! [les princes]	VOITURE			232     servitudes du pouvoir		berkeley	5322
La haine et l'amour viennent des tripes et des couilles, pas de la tête.	WEST Morris	Le Loup Rouge.	1971	310     énergie		berkeley	5383
A défaut du pardon, laisse venir l'oubli.	MUSSET Alfred de	Poésies, la Nuit d"octobre		540     mémoire	1810-1857.	berkeley	4552
Il faut exiger de chacun ce que chacun peut donner.	SAINT-EXUPERY Antoine de			441     sang-froid		berkeley	4918
Il ne connaissait pas du tout sa force. Dans la jungle, il se savait faible comparé à l'ours, aux fauves ; mais au village, on le disait fort comme unn taureau. En tout cas, la peur lui était totalement inconnue ; à preuve, le jour où le prêtre l'avertit que, s'il mangeait ses mangues, le dieu du temple se fâcherait contre lui, Mowgli empoigna l'effigie, l'apporta chez le prêtre, qu'il invita à provoquer le courroux du dieu, avec qui il aurait plaisir à se battre. Ce fut un scandale épouvantable.	KIPLING Rudyard	Le livre de la Jungle	1894	215     mystifications		berkeley	3550
Que dit la Loi de la Jungle ? Frappe d'abord, aboie plus tard. A ton insouciance même, ils savent que tu es un homme.	KIPLING Rudyard	Le livre de la jungle	1894	230     pouvoir		berkeley	3552
Les principes sont les principes, dussent les rues ruisseler de sang.	KIPLING Rudyard	Souvenirs.		230     pouvoir		berkeley	3553
Coeur vaillant et belles manières, dit-il, te mèneront loin dans la Jungle, bonhomme.	KIPLING Rudyard	Le livre de la jungle	1894	230     pouvoir		berkeley	3554
[...] personne ne peut espérer mener la Meute pour toujours.	KIPLING Rudyard	Le livre de la jungle	1894	232     servitudes du pouvoir		berkeley	3555
Venant d'où je viens, allant où je vais, il me faut être 'bon' tous les jours.	FAIRGAGNETR Oscar	Vitalités.	1994	441     sang-froid		berkeley	2604
Il y a de l'infini entre ce que je suis et ce que j'ai besoin d'être.	SENANCOUR			520     ironie de soi		berkeley	4998
Créer, c'est essayer de faire, absolument,... une belle tranche de vie.	FAIRGAGNETR Oscar		1992	390     création		berkeley	2561
Celui qui nourrit de grands dessins ne s'embarrasse pas de détails.	WALTER Georges	La Dispute sur le Sel et le Fer.		441     sang-froid		berkeley	5342
La littérature doit être aisée à comprendre et difficile à écrire, non difficile à comprendre et aisée à écrire.	WANG CHUNG	Pensées.		393     création artistique		berkeley	5343
Le seul moyen de réussir, c'est de doubler votre taux d'échecs.	WATSON Thomas J.			440     courage	"fondateur" d"I.B.M.	berkeley	5344
La porte en s'ouvrant laissa passer tant de silence Que ni les vergers ne sont parus ni nulle fleur ; Seul l'espace immense où sont le vide et la lumière Fut soudain présent de part en part, combla le coeur, Et lava les yeux presque aveugles sous la poussière.	WEIL Simone	Poèmes	1942	130     liberté	(1941/42) Gallimard 1968. coll. Espoir NRF	berkeley	5345
Toutes les fois que l'on fait vraiment attention, on détruit du mal en soi.	WEIL Simone	Attente de Dieu.		421     initiation		berkeley	5346
Dieu n'aurait pu être partout et, par conséquent, il créa les mères.	Dictons et Proverbes	Proverbe juif.		420     capital affectif		berkeley	2021
Ces plaisirs qu'on nomme, à la légère, physiques.	COLETTE Sidonie Gabrielle	Ces plaisirs		531     communication amoureuse	1873-1954.	berkeley	1568
Le plaisir de l'amour est d'aimer, et l'on est plus heureux par la passion que l'on a que par celle que l'on donne.	LA ROCHEFOUCAULD François de	Maximes		520     ironie de soi	1613-1680.	berkeley	3917
Une monstrueuse aberration fait croire aux hommes que le langage est né pour faciliter leurs relations mutuelles.	LEIRIS Michel			234     communication		berkeley	4099
Je n'imagine pas le génie sans le courage.	MONTHERLANT Henry Millon de	Carnets.		440     courage		berkeley	4484
La robe est parfois plus humaine que le corps.	FOLLAIN Jean	Usage du temps		441     sang-froid	1903-1971.	berkeley	2815
Le génie est un cheval emballé qui gagne la course.	COCTEAU Jean	Poésie critique		510     ironie	1889-1963.	berkeley	1525
L'avenir n'appartient à personne. Il n'y a pas de précurseurs, il n'existe que des retardataires.	COCTEAU Jean	Le Potomak		510     ironie	1889-1963.	berkeley	1526
Je voudrais que l'intelligence fût reprise au démon et rendue à Dieu.	COCTEAU Jean	Lettre, à Jacques Maritain		510     ironie	1889-1963.	berkeley	1527
Dès qu'un poète se réveille, il est idiot. Je veux dire intelligent.	COCTEAU Jean	Opium		510     ironie	1889-1963.	berkeley	1528
(La beauté) agit même sur ceux qui ne la constatent pas.	COCTEAU Jean	Les Enfants terribles		510     ironie	1889-1963.	berkeley	1529
Le visage humain fut toujours mon grand paysage.	COLETTE Sidonie Gabrielle	Trait pour trait		234     communication	1873-1954.	berkeley	1540
Sois fidèle à ton impression première.	COLETTE Sidonie Gabrielle	Lettre au petit corsaire.		320     intuition		berkeley	1543
Si vous n'êtes pas capable d'un peu de sorcellerie, ce n'est pas la peine de vous mêler de cuisine.	COLETTE Sidonie Gabrielle	Prisons et paradis		390     création	1873-1954.	berkeley	1546
L à où la légèreté nous est donnée, la gravité ne manque pas.	BLANCHOT Maurice	L"Espace littéraire		560     sagesse	1907-.	berkeley	774
Oh! que l'homme est chose méprisable, s'il ne s'élève au-dessus des affaires humaines.  O quam contempta res est homo, nisi supra humana surrexerit! 	Sénèque	Questions naturelles, préface du 1er Livre		441     sang-froid		berkeley	5031
Plus on va loin, plus la connaissance baisse.	LAO TSEU	Tao tö King, XLVII		560     sagesse		berkeley	4038
Heureux qui, comme Ulysse, a fait un beau voyage,  Ou comme celui-l à qui conquit la toison,  Et puis est retourné, plein d'usage et raison,  Vivre entre ses parents le reste de son âge!  Quand reverrai-je, hélas, de mon petit village  Fumer la cheminée, et en quelle saison  Reverrai-je le clos de ma pauvre maison,  Qui m'est une province et beaucoup davantage?  Plus me plaît le séjour qu'ont bâti mes aïeux  Que des palais romains le front audacieux,  Plus que le marbre dur me plaît l'ardoise fine,  Plus mon Loire gaulois que le Tibre latin,  Plus mon petit Liré que le mont Palatin,  Et plus que l'air marin la douceur angevine.	DU BELLAY Joachim	Les Regrets		433     perversion	1522-1560.	berkeley	2163
A chaque époque, les plus vils spécimens de la nature humaine se trouvent parmi les démagogues.	MACAULAY Lord	Histoire d"Angleterre.		215     mystifications		berkeley	4157
Je me sens vieillir veut dire : je me sens mourir.	CHENIER Henri de			410     santé		berkeley	1339
J'ai perdu ma force et ma vie,  Et mes amis et ma gaîté;  J'ai perdu jusqu' à la fierté  Qui faisait croire à mon génie.	MUSSET Alfred de	Poésies, Tristesse		442     démission	1810-1857.	berkeley	4537
Tout ce qui était n'est plus; tout ce qui sera n'est pas encore. Ne cherchez pas ailleurs le secret de nos maux.	MUSSET Alfred de	La Confession d"un enfant du siècle		442     démission	1810-1857.	berkeley	4538
Racine, rencontrant Shakespeare sur ma table,  S'endort près de Boileau qui leur a pardonné.	MUSSET Alfred de	Premières Poésies		510     ironie	1810-1857. , les Secrètes Pensées de Rafaël, gentilhomme français	berkeley	4541
Mieux est de ris que de larmes écrire, Pour ce que rire est le propre de l'homme.	RABELAIS François	GARGANTUA	1534	450     rire	1494/1553	berkeley	4756
Mêlez toute votre âme à la création! 	HUGO Victor	Les Feuilles d"automne, Pan		140     rapport à la cosmogonie	1802-1885.	berkeley	3282
La plus grande chose du monde, c'est de savoir être à soi.	MONTAIGNE Michel Eyquem de	Essais, I, 39		130     liberté		berkeley	4312
Laisse-toi vivre dans la vie sans penser que tu joues de la flûte, et alors tu joueras.	GIONO Jean	Que ma joie demeure		460     plaisir		berkeley	2957
Il n'y a pas de millimètre du monde qui ne soit savoureux.	GIONO Jean	Les Vraies Richesses.		460     plaisir		berkeley	2959
La notion de péché est en complet désaccord avec la rose des vents.	GIONO Jean	Ennemonde.		546     éthique		berkeley	2960
Il n'est pas rare d'entendre des imbéciles proclamer homme d'esprit un incontestable idiot !... De quoi se mèle tout ce petit monde ? Oh ! de ce qui le regarde, bien sûr ! L'idiot, c'est leur homme d'esprit...	GITRY Lucien			120     grégarité		berkeley	2968
Pourquoi suis-je né si ce n'était pas pour toujours ?	IONESCO Eugène			510     ironie		berkeley	3388
Le désir cupide est la plus grande source de chagrin. Paraissant un ami, c'est en secret notre ennemi.	FO-SHO-HING-TSAN-KING			223     cupidité		berkeley	2811
Pour aider quelqu'un à développer un savoir, il importe d'abord de s'adresser à lui comme s'il en était déj à doté. Lorsque le milieu ajuste ses demandes à l'état d'ignorance de quelqu'un, il rend impossible car inutile tout développement de savoirs nouveaux. C'est dans le décalage entre la nécéssité et le savoir actuel que résident les possibilités d'apprentissage.	FOUCAMBERT Jean	Hommes et migrations	1986	421     initiation		berkeley	2844
Qui est mécontent des autres est toujours mécontent de soi [..].	CHARTIER Emile	Propos d"un Normand		430     paradoxal émotionnel	alias ALAIN	berkeley	1256
Les nations étant inévitablement plus bêtes que les individus, toute pensée a le devoir de se sentir en révolte.	CHARTIER Emile	Correspondance...		441     sang-froid	alias Alain (1868-1951). Correspondance avec Romain Rolland	berkeley	1266
C'est le triomphe de la liberté, lorsque les lois criminelles tirent chaque peine de la nature particulière du crime. Tout l'arbitraire cesse ; la peine ne descend point du caprice du législateur, mais de la nature de la chose ; et ce n'est point l'homme qui fait violence à l'homme. [de la légalité des délits et des peines]	MONTESQUIEU Charles de	L"Esprit des lois.	1748	130     liberté		berkeley	4399
Quand il existe quelque chose d'éternel, comment ferais-je pour n'en pas être éternellement le témoin? 	CLAUDEL Paul	Journal		340     sensibilité	1868-1955.	berkeley	1445
La communication, c'est 'la mise en commun d'un ensemble d'analogies'.	KAY Alan			234     communication	ancien chercheur du P.A.R.C., cité in TBA de R.MORENO.	berkeley	3539
Il faut des crimes pour soutenir les crimes.  Scelera enim sceleribus tuenda sunt.	Sénèque	De la clémence, I, 13		210     violence		berkeley	5008
Il accusait toujours les miroirs d'être faux.	LA FONTAINE Jean de	Fables, l"Homme et son Image		433     perversion	1621-1695.	berkeley	3720
Prends garde aux conservateurs de vieilles anarchies.	COCTEAU Jean	Le Potomak		221     vanité	1889-1963.	berkeley	1495
La question réside (...) dans le fait de se concentrer tout en tenant le destin en respect, quand bien même cela ne durerait que le temps nécessaire à ce que l'autre commette l'erreur. Le reste n'est que chimères.	PEREZ-REVERTE Arturo	Le Maître d"escrime	1985	441     sang-froid	id	berkeley	4677
Qu'est-ce au fond qu'un peintre ? C'est un collectionneur qui veut se constituer une collection en faisant lui-même les tableaux qu'il aime chez ls autres. C'est comme ça que je commence et puis ça devient autre chose.	PICASSO Pablo		1934	393     création artistique	cité par Pierre Assouline in DHK.	berkeley	4704
Je voudrais peindre comme un aveugle qui ferait une fesse à tâtons.	PICASSO Pablo		1932	393     création artistique	 à DHK en lui présentant deux nus qu"il vient de terminer.	berkeley	4705
- C'est important, pour vous, l'aspect fini d'une oeuvre ? - Non, il ne s'agit pas de ça [...]. Mais du talent particulier   à chaque mode d'exécution [...].	WEST Morris	De main de Maître.	1988	393     création artistique		berkeley	5400
Dans les grandes affaires, on doit moins s'appliquer à faire naître des occasions qu' à profiter de celles qui se présentent.	LA ROCHEFOUCAULD François de	Maximes.		432     expérience	1613/1680	berkeley	3876
L'amour, tel qu'il existe dans la société, n'est que l'échange de deux fantaisies et le contact de deux épidermes.	CHAMFORT Nicolas-Sébastien de	Maximes et pensées		530     ironie amoureuse	1740/1794. Ac. Française	berkeley	1150
L'amour plaît plus que le mariage, par la raison que les romans sont plus amusants que l'histoire.	CHAMFORT Nicolas-Sébastien de	Maximes et pensées		530     ironie amoureuse	1740/1794. Ac. Française	berkeley	1151
La vieillesse est une voyageuse de nuit: la terre lui est cachée; elle ne découvre plus que le ciel.	CHATEAUBRIAND François-René de	Vie de Rancé		510     ironie	1768-1848.	berkeley	1310
Admirable tremblement du temps! Souvent les hommes de génie ont annoncé leur fin par des chefs-d'oeuvre: c'est leur âme qui s'envole.	CHATEAUBRIAND François-René de	Vie de Rancé		510     ironie	1768-1848.	berkeley	1313
Les amis, qu'on craint moins de mécontenter que les indifférents, sont toujours les derniers servis.	DIDEROT Denis	Lettres, à Mme d"Epinay		221     vanité	1713-1784.	berkeley	2084
Les gens ne devraient pas toujours tant réfléchir à ce qu'ils doivent faire, ils devraient plutôt penser à ce qu'ils doivent être. S'ils étaient seulement bons et conformes à leur nature, leurs oeuvres pourraient briller d'une vive clarté.	ECKHART Maître	Instruction spirituelle.		540     mémoire		berkeley	2257
Donner la liberté au monde par la force est une étrange entreprise pleine de chances mauvaises.	JAURES Jean	L"Armée nouvelle		365     discernement	1859-1914.	berkeley	3429
La vieillesse n'ôte à l'homme d'esprit que des qualités inutiles à la sagesse.	JOUBERT Joseph	Pensées		560     sagesse	1754-1824.	berkeley	3472
La constitution de notre nature est telle que notre esprit a besoin de beaucoup de relâche afin qu'il puisse employer utilement quelques moments en la recherche de la vérité, et qu'il s'assoupirait au lieu de se polir s'il s'appliquait trop à l'étude.	DESCARTES René	Correspondance, à Elisabeth, 6 octobre 1645		390     création	1596-1650.	berkeley	1928
Qu'il s'agisse d'une bête ou d'un enfant, convaincre, c'est affaiblir.	COLETTE Sidonie Gabrielle	Le Pur et l"impur		215     mystifications	1873-1954.	berkeley	1539
Chacun est seul de sa race.	CHARDONNE Jacques	Propos comme ça		423     solitude	1884-1968.	berkeley	1193
Si vous n'avez pas le respect de la personne, dix secondes vous suffiront toujours pour savoir ce que vous appréciez chez elle.	FAIRGAGNETR Oscar	Vitalités.	1995	234     communication		berkeley	2514
Pour communiquer, l'autre a besoin d'être reconnu pour ce qu'il est, avec compassion, respect ou cruauté. Ce sera selon...	FAIRGAGNETR Oscar	Vitalités.	1993	234     communication		berkeley	2519
Ce qui nous manque, ce sont les principes. On a beau dire, il en faut, reste à savoir lesquels. Pour un artiste, il n'y en a qu'un : tout sacrifier à l'art. La vie doit être considérée par lui comme un moyen, rien de plus, et la première personne dont il doit se f... c'est de lui-même.	FLAUBERT Gustave	L"amour de l"art.	1915	393     création artistique	1821/1880, édition posthume	berkeley	2750
Le superflu finit par priver du nécessaire.	LACLOS Pierre Choderlos de	Les Liaisons dangereuses		223     cupidité	1741-1803.	berkeley	3962
C'est drôle comme les gens qui se croient instruits éprouvent le besoin de faire chier le monde.	VIAN Boris	Les Fourmis	1949	221     vanité	Sylvain Vétaux, blog des essayeurs, Sport Auto, n° 646, novembre 2015	2016	6012
\.


--
-- Name: citations_recordid_seq; Type: SEQUENCE SET; Schema: public; Owner: pierre
--

SELECT pg_catalog.setval('citations_recordid_seq', 6012, true);


--
-- Name: citations2_recordid_idx; Type: INDEX; Schema: public; Owner: pierre; Tablespace: 
--

CREATE UNIQUE INDEX citations2_recordid_idx ON citations USING btree (recordid);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

